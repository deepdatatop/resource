{
	"zh": {
		"txt_savenclose":"保存并关闭",
		"txt_close":"关闭"
	},
	"en": {
		"txt_savenclose":"Save & Close",
		"txt_close":"Close"
	}
}