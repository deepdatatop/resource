{
	"zh": {
		"captionStr":"请选择：",
		"saveStr":"确定",
		"cancelStr":"取消""
	},
	"en": {
		"captionStr":"Please select:",
		"saveStr":"Save",
		"cancelStr":"Cancel""
	}
}