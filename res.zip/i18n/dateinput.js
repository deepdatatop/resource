{
	"zh": {
		"txt_ok":"确定",
		"txt_cancel":"取消",
		"txt_hint":"请选择日期："
	},
	"en": {
		"txt_ok":"OK",
		"txt_cancel":"Cancel",
		"txt_hint":"Please select a date:"
	}
}