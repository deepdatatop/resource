{
	"zh": {
		"historyStr": "最近使用",
		"linkStr": "链接路径",
		"linkplaceholderStr": "↸ 输入图片访问路径文本后回车提交",
		"localStr": "本机文件",
		"wechatStr": "扫码传图",
		"addedStr": "已加入",
		"exceedcontainerlimit": "图片数超过限制：",
		"urlduplicated": "图片URL重复！"
	},
	"en": {
		"historyStr": "History",
		"linkStr": "PicURL",
		"linkplaceholderStr": "↸ Input image URL and press enter key to submit",
		"localStr": "Local",
		"wechatStr": "Scan",
		"addedStr": "Added",
		"exceedcontainerlimit": "image quantity exceed limit:",
		"urlduplicated": "image URL duplicated!"
	}
}
