{
	"zh": {
		"txt_caption":"请输入文章访问链接：（一行一个）",
		"txt_run":"开始提取",
		"txt_stop":"停止",
		"txt_restart":"重启",
		"txt_close":"关闭",
		"txt_stopped":"已停止",
		"txt_over":"结束"
	},
	"en": {
		"txt_caption":"Please input remote article page URL: (one per row)",
		"txt_run":"Start pickup",
		"txt_stop":"Stop",
		"txt_restart":"Restart",
		"txt_close":"Close",
		"txt_stopped":"Stopped",
		"txt_over":"Over"
	}
}