{
	"zh": {
		"txt_periodchooser":"日期选择：",
		"txt_today":"今日",
		"txt_yesterday":"昨日",
		"txt_thisweek":"本周",
		"txt_lastweek":"上周",
		"txt_last7days":"近7日",
		"txt_last14days":"近14日",
		"txt_thismonth":"本月",
		"txt_lastmonth":"上月",
		"txt_last30days":"近30日",
		"txt_last60days":"近60日",
		"txt_last3months":"前3个月",
		"txt_last6months":"前6个月",
		"txt_thisyear":"今年",
		"txt_lastyear":"去年"
	},
	"en": {
		"txt_periodchooser":"Common used date periods:",
		"txt_today":"Today",
		"txt_yesterday":"Yesterday",
		"txt_thisweek":"This week",
		"txt_lastweek":"Last week",
		"txt_last7days":"Last 7 days",
		"txt_last14days":"Last 14 days",
		"txt_thismonth":"This month",
		"txt_lastmonth":"Last month",
		"txt_last30days":"Last 30 days",
		"txt_last60days":"Last 60 days",
		"txt_last3months":"Last 3 months",
		"txt_last6months":"Last 6 months",
		"txt_thisyear":"This year",
		"txt_lastyear":"Last year"
	}
}