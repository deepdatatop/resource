{
	"zh": {
		"txt_yes":"是",
		"txt_no":"否",
		"txt_removeornot":"是否删除",
		"txt_descendant":"和所有下级结点",
		"txt_inputlabel":"请输入文本",
		"txt_catalogue":"分类项",
		"txt_packetemptyhint":"本汇编为空，请使用[<i class=\"fa fa-search icon\"></i>查询]功能<i class=\"fa fa-plus-square icon\"></i>在下面窗口中加入文件。<br>或使用右上角<i class=\"fa fa-plus-circle icon\"></i>按钮增加分类项。"
	},
	"en": {
		"txt_yes":"Yes",
		"txt_no":"No",
		"txt_removeornot":"Remove",
		"txt_descendant":"and all descendant",
		"txt_inputlabel":"Please input label text",
		"txt_catalogue":"catalogue item",
		"txt_packetemptyhint":"The file packet is empty, please use [<i class=\"fa fa-search icon\"></i>Search] function to <i class=\"fa fa-plus-square icon\"></i> add file in below window<br>or use top-right corner <i class=\"fa fa-plus-circle icon\"></i> button to add directory item."
	}
}