{
	"zh": {
		"txt_yes": "是",
		"txt_no": "否",
		"txt_emptyornot": "清空所有内容？",
		"txt_outline": "大纲：",
		"txt_text": "文本",
		"txt_image": "图片",
		"txt_appendix": "附件",
		"txt_qrcode": "贴码",
		"txt_task": "进度",
		"txt_map": "地图",
		"txt_table": "表格",
		"txt_chart": "图表",
		"txt_code": "源码",
		"txt_video": "视频"
	},
	"en": {
		"txt_yes": "Yes",
		"txt_no": "no",
		"txt_emptyornot": "Empty all content?",
		"txt_outline": "Outline:",
		"txt_text": "Text",
		"txt_image": "Image",
		"txt_appendix": "Appendix",
		"txt_qrcode": "QRcode",
		"txt_task": "Task",
		"txt_map": "Map",
		"txt_table": "Table",
		"txt_chart": "Chart",
		"txt_code": "Sourcecode",
		"txt_video": "Video"
	}
}
