{
	"zh": {
		"txt_save":"保存",
		"txt_close":"关闭",
		"txt_clear":"清除",
		"txt_clearornot":"是否清空？",
		"t_yes":"是",
		"t_no":"否"
	},
	"en": {
		"txt_save":"Save",
		"txt_close":"Close",
		"txt_clear":"Clear",
		"txt_clearornot":"Clear all?",
		"t_yes":"Yes",
		"t_no":"No"
	}
}