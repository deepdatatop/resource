{
	"zh": {
		"txt_hint": "点击 ⇳ 按压然后上下移动",
		"txt_ok": "确认"
	},
	"en": {
		"txt_hint": "Click ⇳ press and move item up-down",
		"txt_ok": "Confirm"
	}
}