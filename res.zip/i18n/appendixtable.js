{
	"zh": {
		"t_releasenumber": "版本号",
		"t_releasetime": "发行时间",
		"t_osarch": "运行环境",
		"t_filename": "文件名",
		"t_filesize": "文件大小",
		"t_download": "下载"
	},
	"en": {
		"t_releasenumber": "ReleaseNO.",
		"t_releasetime": "Releasetime",
		"t_osarch": "OS&Architecture",
		"t_filename": "Filename",
		"t_filesize": "Filesize",
		"t_download": "Download"
	}
}