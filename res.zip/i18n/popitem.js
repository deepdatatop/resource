{
	"zh": {
		"txt_caption":"代码项编辑",
		"txt_close":"关闭"
	},
	"en": {
		"txt_caption":"Code item editor",
		"txt_close":"Close"
	}
}