{
	"zh": {
		"txt_yes":"是",
		"txt_no":"否",
		"txt_multiplelanguage":"多语言",
		"txt_emptymultieditor":"是否清空所有语言输入？"
	},
	"en": {
		"txt_yes":"Yes",
		"txt_no":"No",
		"txt_multiplelanguage":"multilanguage",
		"txt_emptymultieditor":"empty multilanguage input?"
	}
}