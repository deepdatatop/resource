{
	"zh": {
		"okText":"确定",
		"cancelText":"取消",
		"hintText":"请输入文本："		
	},
	"en": {
		"okText":"OK",
		"cancelText":"Cancel",
		"hintText":"Please input text:"
	}
}