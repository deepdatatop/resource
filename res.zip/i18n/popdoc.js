{
	"zh": {
		"closeText":"关闭"
	},
	"en": {
		"closeText":"Close"
	}
}