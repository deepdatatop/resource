{
	"zh": {
		"txt_yes":"是",
		"txt_no":"否",
		"txt_removeornot":"是否删除",
		"txt_descendant":"和所有下级结点"
	},
	"en": {
		"txt_yes":"Yes",
		"txt_no":"No",
		"txt_removeornot":"Remove",
		"txt_descendant":"and all descendant"
	}
}