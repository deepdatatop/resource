{
	"zh": {
		"txt_tag": "标注",
		"txt_src": "路径",
		"txt_size": "文件大小",
		"txt_ext": "后缀",
		"txt_remove": "删除",
		"txt_yes": "是",
		"txt_no": "否",
		"txt_removeornot": "是否删除",
		"txt_sourcename": "源文件名：",
		"txt_accesspath": "访问路径：",
		"txt_alreadycopied": "已复制到剪贴板！"
	},
	"en": {		
		"txt_tag": "tag",
		"txt_src": "source",
		"txt_size": "size",
		"txt_ext": "extension",
		"txt_remove": "remove",
		"txt_yes": "Yes",
		"txt_no": "No",
		"txt_removeornot": "Remove",
		"txt_sourcename": "Source filename:",
		"txt_accesspath": "Access path:",
		"txt_alreadycopied": "Already copied to clipboard!"
	}
}