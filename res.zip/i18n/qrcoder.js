{
	"zh": {
		"frequentStr": "常用",
		"textStr": "代码",
		"linkplaceholderStr": "↸ 输入二维码文本后回车提交",
		"txt_columns": "单行列数：",
		"txt_halign": "左右对齐：",
		"txt_valign": "上下对齐：",
		"txt_tag": "标注",
		"txt_code": "代码",
		"txt_operation": "操作",
		"txt_choose": "选中",
		"txt_remove": "删除",
		"txt_yes": "是",
		"txt_no": "否",
		"txt_removeornot": "是否删除",
		"txt_emptylist": "清空列表？",
		"txt_codeduplicated": "代码文本重复，已替换！"
		"exceedcontainerlimit": "二维码数超过限制：",
		"codeduplicated": "代码文本重复！"
	},
	"en": {
		"frequentStr": "frequent",
		"textStr": "code",
		"linkplaceholderStr": "↸ Input QR code text and press enter key to submit",
		"txt_columns": "cols per row:",
		"txt_halign": "horizontal align:",
		"txt_valign": "vertical align:",
		"txt_tag": "tag",
		"txt_code": "code",
		"txt_operation": "operation",
		"txt_choose": "choose",
		"txt_remove": "remove",
		"txt_yes": "Yes",
		"txt_no": "No",
		"txt_removeornot": "Remove",
		"txt_emptylist": "Empty list?",
		"txt_codeduplicated": "Duplicate code text, updated.",
		"exceedcontainerlimit": "QRcode quantity exceed limit:",
		"codeduplicated": "code text duplicated!"
	}
}