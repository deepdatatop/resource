{
	"zh": {
		"txt_inputnsearch":"输入名称关键词后回车查询..."		
	},
	"en": {
		"txt_inputnsearch":"input name and press enter key..."
	}
}