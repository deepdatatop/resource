{
	"zh": {
		"okStr": "确定",
		"cancelStr": "取消"
	},
	"en": {
		"okStr": "OK",
		"cancelStr": "Cancel"
	}
}