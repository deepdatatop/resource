{
	"zh": {
		"firstText":"首位",
		"prevText":"前翻",
		"nextText":"后翻",
		"lastText":"末位",
		"closeText":"关闭",
		"txt_savenclose":"保存并关闭",
		"txt_close":"关闭"
	},
	"en": {
		"firstText":"First",
		"prevText":"Prev",
		"nextText":"Next",
		"lastText":"Last",
		"closeText":"Close",
		"txt_savenclose":"Save & Close",
		"txt_close":"Close"
	}
}