{
	"zh": {
		"txt_ok": "确定",
		"txt_close": "关闭",
		"txt_today": "今日",
		"txt_chooseperiod": "起➵止",
		"txt_fullscreen": "全屏选择",
		"txt_moveselect": "移动方框定位月份"
	},
	"en": {
		"txt_ok": "OK",
		"txt_close": "Close",
		"txt_today": "Today",
		"txt_chooseperiod": "Choose period",
		"txt_fullscreen": "Open fullscreen",
		"txt_moveselect": "Move to select the desired period"
	}
}