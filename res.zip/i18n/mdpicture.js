{
	"zh": {
		"txt_emptyornot":"是否清空数据?",
		"txt_yes":"是",
		"txt_no":"否"
	},
	"en": {
		"txt_emptyornot":"Empty or not?",
		"txt_yes":"Yes",
		"txt_no":"No"
	}
}