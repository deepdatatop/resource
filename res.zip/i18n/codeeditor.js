{
	"zh": {
		"txt_actual": "实际",
		"txt_cawidth": "宽度:",
		"txt_caheight": "高度:",
		"txt_hint": "ctrl+enter（回车） 保存内容。"
	},
	"en": {
		"txt_actual": "actual",
		"txt_cawidth": "width:",
		"txt_caheight": "height:",
		"txt_hint": "ctrl+enter save code."
	}
}