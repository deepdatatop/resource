{
	"zh": {
		"txt_yes": "是",
		"txt_no": "否",
		"txt_emptyornot": "清空所有内容？",
		"txt_packet": "文件汇编：",
		"txt_documentadded": "文档已加入！"
	},
	"en": {
		"txt_yes": "Yes",
		"txt_no": "no",
		"txt_emptyornot": "Empty all content?",
		"txt_packet": "Packet:",
		"txt_documentadded": "Document already added!"
	}
}
