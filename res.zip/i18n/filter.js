{
	"zh": {
		"txt_search":"搜索",
		"txt_reset":"重置",
		"txt_recent":"最近",
		"txt_bysequence":"按顺序",
		"txt_byfrequency":"按频率"		
	},
	"en": {
		"txt_search":"Search",
		"txt_reset":"Reset",
		"txt_recent":"Recent",
		"txt_bysequence":"by sequence",
		"txt_byfrequency":"by frequency"
	}
}