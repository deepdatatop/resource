INSERT INTO carousel_bannergroup(carousel_id,banner_id,stretchmode_id,ordinalposition) VALUES(1,1,1,1);
INSERT INTO carousel_bannergroup(carousel_id,banner_id,stretchmode_id,ordinalposition) VALUES(1,2,1,2);
INSERT INTO carousel_bannergroup(carousel_id,banner_id,stretchmode_id,ordinalposition) VALUES(1,3,1,3);