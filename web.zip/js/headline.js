	function HeadlineObject(element,options){
		this.element=element;
		this.defaults={
			txt_caption:'Headline',
			identifier:'article',
			scene:'headline'
		};
		this.options=$.extend({},this.defaults,options);
    };
	HeadlineObject.prototype.init=function(){
		var self=this,thebox=this.element;
		var ss='<div style="width:100%"><i class="fa fa-fire fa-lg" style="color:#f00;"></i> '+self.options.txt_caption+'</div>';
		ss+='<div id="hlbox" style="width:100%;"></div>'
		thebox.append(ss);
		var hlbox=thebox.find('#hlbox');
		$.getJSON('/getdatagrid',{wgt:'GM',idf:self.options.identifier,scene:self.options.scene},
			function(m){
				if(m.status=='success'){
					var i=1;
					$.each(m.data,function(){
						var url='/view?idf='+self.options.identifier+'&iid='+this.id;
						var ss='<div style="line-height:24px;overflow:hidden;">';
						ss+=i.toString()+' <a href="'+url+'">'+this.title+'</a></div>';
						hlbox.append(ss);
						i+=1;
					});
				}else{hlbox.append('<div>'+m.Msg+'</div>');}
			}
		);
	};
    $.fn.Headline=function(options){
		var theheadline=new HeadlineObject(this,options);
		theheadline.init();
		return theheadline;
    };