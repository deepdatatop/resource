function clone(Obj){
	var buf;
	if(Obj instanceof Array){
	    buf=[];
		var i=Obj.length;
		while(i--){
			buf[i]=clone(Obj[i]);
		}
		return buf;
	}else if(Obj instanceof Object){
		buf={};
		for(var k in Obj){
			buf[k]=clone(Obj[k]);
		}
		return buf;
	}else{
		return Obj;
	}
};
var i18n={};
function PopMLObject(element,options){
	this.element=element;
	this.defaults={
		width:800,
		height:540,
		zindex:200,
		i18n: {},
		caption:'',
		widget_dependency_bs64: '',
		txt_savenclose: 'Save & Close',
		txt_close: 'Close',
		identifier: 'navigation',
		onClose: function(modified){}
	};
	this.thegrid=new Object();
	this.old_tbldata=new Object();
	this.new_tbldata=new Object();
	this.popml_modified=0;
	this.po='popml_overlay';
	this.pp='popml_pane';
	this.options=$.extend({},this.defaults,options);
};
PopMLObject.prototype.close_pane=function(){
	this.element.find('#'+this.po).remove();
	this.element.find('#'+this.pp).remove();
	this.options.onClose(this.popml_modified);
};
PopMLObject.prototype.include_callback=function(){//call at include.js
	this.setWidget();
};
PopMLObject.prototype.setWidget=function(){
	var self=this;
	var thebox=this.element;
	$.getJSON('/codesetgridobject',{cst:'navigation'},function(m){
		if(m.Code=='100'){
			try{
				var colModel=JSON.parse($.base64.decode(m.Title));
				var dt=$.base64.decode(m.Data);
				self.old_tbldata=JSON.parse(dt);
				self.new_tbldata=clone(self.old_tbldata);
				self.thegrid = $("#the_grid").pqGrid({
					width: "100%",
					height: "100%-80",
					showTop: false,
					showTitle: false,
					showBottom: false,
					collapsible: false,
					showHeader: true,
					dragColumns: { enabled: false },
					roundCorners: false,
					rowBorders: true,
					columnBorders: true,
					freezeCols: 1,                                   
					selectionModel: { type: 'cell' },
					numberCell: { show: false },
					stripeRows: true,
			        colModel: colModel,
			        dataModel: { data: self.new_tbldata },
					change: function( event, ui ) {
						thebox.find('#pm_savenclose').show();
						self.popml_modified=1;
					}
				});
			}catch(error){
				alert(error);
			}
		}else{
			alert(m.Msg);
		}
	});
};
PopMLObject.prototype.setpane=function(){
	var gd='';
	if(this.options.widget_dependency_bs64.length>0){gd=$.base64.decode(this.options.widget_dependency_bs64);}
	include_queue(this,gd);
};
PopMLObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
PopMLObject.prototype.updatedData=function(){
	var iID=-1;
	var colField=new Array();
	var colModel=this.thegrid.pqGrid("getColModel");
	var key='_key';
	for(var i=0,n=colModel.length;i<n;i++){
		var col=colModel[i];
		if(col.hasOwnProperty(key)){
			if(col[key]=='id'){iID=i;}
			colField.push(col[key]);
		}else{colField.push('');}
	}
	var dat=new Array();
	if(iID>=0){
		for(var i=0,n=this.new_tbldata.length;i<n;i++){
			var rw=new Object();var nn=0;
			for(var j=0,m=colField.length;j<m;j++){
				if(this.old_tbldata[i][j]!=this.new_tbldata[i][j]){
					rw[colField[j]]=this.new_tbldata[i][j];
					nn++;
				}
			}
			if(nn>0){
				rw['id']=this.new_tbldata[i][iID];
				dat.push(rw);
			}
		}
	}
	return dat;
};
PopMLObject.prototype.init=function(){
	this.i18n_options();
	i18n=this.options.i18n;
	var self=this;
	var thebox=this.element;
	var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
	thebox.append('<div id="'+self.po+'" style="'+aos+'"></div>');
	var ao=thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.35);
	var txt= '<div id="'+self.pp+'" style="display: none;overflow:hidden;';
	var height=self.options.height;
	txt += 'width:'+self.options.width+'px;height:'+height+'px;background:#fff;padding:8px;">';
	var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
	ats+='background-repeat: no-repeat;right: 0px;top: 0px;cursor: pointer;';
	txt += '<div><span id="pm_close_icon" style="'+ats+'"></span></div>';
	txt += '<div id="pm_toolbar" style="width:100%;height:34px;">';
	txt += '<span class="caption">'+self.options.caption+'</span>';
	txt += '</div>';
	txt += '<div id="the_grid" style="overflow: auto;"></div>';
	txt += '<div class="pm_footer">';
	txt += '<span style="margin-right:40px;display:none;" class="button" id="pm_savenclose"><i class="fa fa-save">&nbsp;'+self.options.txt_savenclose+'</i></span>';
	txt += '<span class="button" id="pm_close"><i class="fa fa-times-circle-o">&nbsp;'+self.options.txt_close+'</i></span></div>';
	txt += '</div>';
	thebox.append(txt);
	var pane = thebox.find('#'+self.pp);
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('#pm_savenclose').on("click",function(event){
		event.stopPropagation();
		$.getJSON('/savebatchinstance',{idf:'navigation',dat:$.base64.encode(JSON.stringify(self.updatedData()))},
			function(m){
				if(m.Code=='100'){
					self.close_pane();
				}else{alert(m.Msg);}
			}
		);		
	});
	thebox.find('#pm_close_icon').on("click",function(event){
		event.stopPropagation();	self.close_pane();
	});
	thebox.find('#pm_close').on("click",function(event){
		event.stopPropagation();	self.close_pane();
	});
	self.setpane();
};
$.fn.PopML=function(options){
	var apop=new PopMLObject(this,options);
	apop.init();
	return apop;
};