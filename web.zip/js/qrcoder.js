function modifyQRtag(dom,code){
	var self=$(dom);
	var mid=self.attr('mid');
	var text=self.text();
	$('body').SimpleInputDialog({
		//okText:'{{.t_ok}}',
		//cancelText:'{{.t_cancel}}',
		//hintText:'{{.t_inputemail}}',
		doOK:function(text,id){
			var te = new CustomEvent('qr_event',{ 
 				detail:{status:'modified',mid:id,code:code,tag:text}
			});
			window.dispatchEvent(te);
			return true;
		}
	}).textinput(text.trim(),mid);		
}
function removeQR(dom,tag){
	var self=$(dom);
	var mid=self.attr('mid');
	$('body').YesnoAlert({
		//yesText:obj.options.txt_yes,noText:obj.options.txt_no,
		doyes: function(id,action){
			var te=new CustomEvent('qr_event',{detail:{status:'removed',mid:id}});
			window.dispatchEvent(te);					
		}
	}).show_alertpane(mid,'Remove this QR code'+'['+tag+']?','remove');
}
	function QRcoderObject(element,options){
		this.outerID='';
		this.element=element;
		var defaults={
			i18n:{},
			focus_tab:'frequent',/*frequent,text*/
			qrcoder_capacity:64,
			screen_columns: 1,
			cell_align: 'center',
			cell_valign: 'top',
			exceedcontainerlimit: 'QRcode quantity exceed limit:',
			codeduplicated: 'code text duplicated!',
			frequentStr: 'frequent',
			textStr: 'code',
			linkplaceholderStr: 'Input QR code text and press enter key to submit',
			txt_columns: 'cols per row:',
			txt_halign: 'horizontal align:',
			txt_valign: 'vertical align:',
			txt_tag: 'tag',
			txt_code: 'code',
			txt_operation: 'operation',
			txt_choose: 'choose',
			txt_remove: 'remove',
			txt_yes: 'Yes',
			txt_no: 'No',
			txt_removeornot: 'Remove',
			txt_emptylist: 'Empty list?',
			txt_codeduplicated: 'Duplicate code text, updated.',
			saveRecent:function(code,tag){},
			readRecent:function(){return [];},
			screen:{}/*the output windows for qrcode list render*/
		};
		this.options=$.extend({},defaults,options);
		this.cell_align={};
		this.cell_valign={};
		this.column_spinner={};
		this.qrcodes=new Array();/*[{tag:'abc',code:'http://localhost'}]*/
    };
	QRcoderObject.prototype.getIndexbyid=function(id){
		var idx=-1;
		for(var i=0;i<this.qrcodes.length;i++){
			if($.md5(this.qrcodes[i].code)===id){idx=i;break;}
		}
		return idx;
	};
	QRcoderObject.prototype.addNew=function(){
		this.showQRcodeDialog();
	};
	QRcoderObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	QRcoderObject.prototype.init=function(){
		this.i18n_options();
		var obj=this;
		var self=this.element;
		var gridname='qrcodes';
		window.addEventListener('qr_event', function(event){
			var ed=event.detail;
			switch(ed.status){
				case 'modified':
					var idx=obj.getIndexbyid(ed.mid);
					if(idx>=0){
						var o={code:ed.code,tag:ed.tag};
						GridManager.updateRowData(gridname,'code',o);
						obj.setScreenTag(ed.tag,ed.code);
						obj.qrcodes[idx].tag=ed.tag;
						obj.modified();
					}
					break;
				case 'removed':
					var idx=obj.getIndexbyid(ed.mid);
					if(idx>=0){
						obj.rmvScreenQRcode(ed.mid);
						obj.qrcodes.splice(idx,1);
						obj.modified();
						obj.refresh();
					}
					break;
			}
		});
		self.empty();
		var ss='<div id="q_toolbar" style="width:100%;height:36px;padding-top:2px;overflow:hidden;"><span id="qrc" style="font-size:24px;display:inline-block"><i class="fa fa-qrcode"></i></span>';
		ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_columns+'</span><span id="column_number" style="display:inline-block"></span>';
		ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_halign+'</span><span id="cellalign" style="display:inline-block"></span>';
		ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_valign+'</span><span id="cellvalign" style="display:inline-block"></span>';
		ss+='<div style="display:inline-block;position:absolute;right:0px;width:64px;">';
		ss+='<i class="fa fa-2x fa-trash-o qr_empty"></i><span>&nbsp;</span><i class="fa fa-2x fa-plus-square-o qr_add"></i>'
		ss+='</div>';
		ss+='</div>';
		ss+='<table id="qrcode_table" style="width:100%;"></table>';
		self.append(ss);
		self.find('.qr_empty').on('click',function(){obj.empty();});
		self.find('.qr_add').on('click',function(){obj.addNew();});
		obj.column_spinner=self.find('#column_number').Spinner({width:60,value:obj.options.screen_columns,
			onChange: function(val){
				obj.options.screen_columns=val;
				obj.resetScreen();
			}
		});
		obj.cell_align=self.find('#cellalign').StateButton({
			onChange: function(val) {
				obj.options.cell_align=val;
				obj.modified();
				var box=obj.options.screen;
				if(JSON.stringify(box)!='{}'){box.find('td').css('text-align',val);}
			}
		}).Select(obj.options.cell_align);
		obj.cell_valign=self.find('#cellvalign').StateButton({
			item_option:[
				{value:'top',label:'<i class="fa fa-step-forward fa-rotate-270"></i>'},
				{value:'middle',label:'<i class="fa fa-columns fa-rotate-90"></i>'},
				{value:'bottom',label:'<i class="fa fa-step-forward fa-rotate-90"></i>'}
        		],
			onChange: function(val) {
				obj.options.cell_valign=val;
				obj.modified();
				var box=obj.options.screen;
				if(JSON.stringify(box)!='{}'){box.find('td').css('vertical-align',val);}				
			}
		}).Select(obj.options.cell_valign);
		self.find('#qrcode_table').GM({
			gridManagerName: gridname,
			height: '100% - 36px',
			supportCheckbox: false,
			ajaxData: {totals:0,data:[]},
			columnData: [
				{key: 'tag',text: obj.options.txt_tag,
					template: function(tag, row){
						var ss='<span>';
						ss+='<i mid="'+$.md5(row.code)+'" class="qr_modifytag fa fa-edit"';
						ss+=' onclick="modifyQRtag(this,\''+row.code+'\')"> '+tag+'</i>';
						ss+='</span>';
						return ss;
					}},
				{key: 'code',text: obj.options.txt_code},
				{key: 'operation',text: obj.options.txt_operation,
					template: function(operation, row){
						var ss='<span>';
						ss+='<i mid="'+$.md5(row.code)+'" order="'+row.gm_order+'"';
						ss+=' onclick="removeQR(this,\''+row.tag+'\')"';
						ss+=' class="rmvqr fa fa-minus-square-o"> '+obj.options.txt_remove+'</i>';
						ss+='</span>';
						return ss;
					},align: 'center'
				}],
			supportMoveRow: true,
			moveRowConfig: {
				handler: (list, tableData) => {
					var n=obj.qrcodes.length;
					if(n==tableData.length){
						var mapSrcIndex={};
						var old=[];
						var i_s=-1,i_e=-1;
						for(var i=0;i<n;i++){
							var qr=obj.qrcodes[i];
							old.push(qr);
							mapSrcIndex[qr.code]=i;
							if(tableData[i].code!==qr.code){
								if(i_s==-1){i_s=i;}
								i_e=i;
							}
						}
						if(i_e>i_s){
							var id=$.md5(obj.qrcodes[i_e].code);
							var ins='head';
							if(obj.qrcodes[i_s+1].code==tableData[i_s].code){
								ins='end'; id=$.md5(obj.qrcodes[i_s].code);
							}
							/*update screen td ordinal position*/
							var flag=false;
							if(ins=='head'){
								flag=obj.moveupNScreenQRcode(i_s,i_e);
							}else{
								flag=obj.movedownNScreenQRcode(i_s,i_e);
							}
							if(flag){
								obj.qrcodes.length=0;
								for(var i=0;i<n;i++){
									var k=mapSrcIndex[tableData[i].code];
									obj.qrcodes.push(old[k]);
								}
								obj.modified();
							}
						}
						old.length=0;mapSrcIndex={};
					}
				}
			}
		});
	};
	
		/*常用码集
		文本输入
		var placeholder='输入需编码的文本内容后回车提交';
		var htm='<img id="'+id+'" src="/qrcode?el=128&dt='+encodeURIComponent(url)+'">';
		*/
	QRcoderObject.prototype.resize=function(){
	};
	QRcoderObject.prototype.closeQRcodeDialog=function(){
		$('body').find('#i_dialog').remove();
		$('body').find('#dialogbox').remove();
	};
	QRcoderObject.prototype.showQRcodeDialog=function(){
		var obj=this; var self=this.element; var zindex=20000;
		var thebox=$('body');
		var is='position:fixed;z-index:'+zindex+';top:0px;left:0px;height:100%;width:100%;background:#000;display:none;cursor:pointer;';
		var ds='width:80%;height:300px;z-index:'+(zindex+1)+';background-color:#fff;border:solid 1px #dadada;overflow:hidden;dispay:none;';
		ds+='border-radius:5px;';
		thebox.append('<div id="i_dialog" style="'+is+'"></div>');
		thebox.append('<div id="dialogbox" style="'+ds+'"></div>');
		var idialog=thebox.find('#i_dialog');
		idialog.css({"display":"block",opacity:0}).fadeTo(200,0.2);
		var dialogbox=thebox.find('#dialogbox');
		obj.setupDialog(dialogbox);
		var modal_width=dialogbox.outerWidth(); var modal_height=dialogbox.outerHeight();
		dialogbox.css({"display":"block","position":"fixed","opacity":0,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		dialogbox.fadeTo(200,1);
		idialog.off("click").on("click",function(event){
			obj.closeQRcodeDialog();
		});
	};
	QRcoderObject.prototype.setupDialog=function(dialogbox){
		var obj=this;
		var captionheight=36;
		var height=dialogbox.innerHeight()-captionheight-3;
		var cts='font:normal 20px/36px arial;'
		var ss='<div class="q_dialogcaption"><span style="'+cts+'"><i class="fa fa-qrcode">&nbsp;</i>添加二维码</span><div class="q_dialogclose"><span style="font:normal 18px/24px;"><i class="fa fa-close"></i></span></div></div>';
		ss+='<div id="worktop" style="width:100%;height:'+height+'px;"></div>';
		dialogbox.append(ss);
		dialogbox.find('.q_dialogclose').on('click',function(){obj.closeQRcodeDialog();});
		obj.setupWorktop(dialogbox.find('#worktop'));
	};
	QRcoderObject.prototype.setupWorktop=function(worktop){
		var obj=this;
		var self=this.element;
		var ss='<div id="q_worktop"><div>';
		ss+='<span class="q_tab_item'+(obj.options.focus_tab=='frequent'?'_selected':'')+'" id="tab_frequent">'+obj.options.frequentStr+'&nbsp;<i class="fa fa-history"></i></span>';
		ss+='<span class="q_tab_item'+(obj.options.focus_tab=='text'?'_selected':'')+'" id="tab_text">'+obj.options.textStr+'&nbsp;<i class="fa fa-keyboard-o"></i></span>';
		ss+='</div></div>';
		//ss+='<div style="width:100%;height:2px;border:solid 1px #080;"></div>';
		var tabtopheight=36;
		var height = worktop.innerHeight()-tabtopheight;
		ss+='<div id="blockcontainer" style="width:100%;overflow:hidden;height:'+height+'px;border:none;"></div>';
		worktop.append(ss);
		var blockcontainer=worktop.find('#blockcontainer');
		ss='<div id="qr_grid" class="qr_block"'+(obj.options.focus_tab=='frequent'?'':' style="display:none"')+'>';
		ss+='<table id="recentqr_table"></table>';
		ss+='</div>';
		var style='width:100%;height:'+height+'px;overflow:hidden;';
		if(obj.options.focus_tab!='text'){style+='display:none;';}
		ss+='<div id="qr_text" style="'+style+'" class="qr_block">';
		var toolbarheight=36;
		ss+='<textarea class="qrtext" style="width:'+(blockcontainer.innerWidth()-2)+'px;height:'+(height-toolbarheight)+'px;"></textarea>';
		ss+='<div style="width:100%;height:'+toolbarheight+'px;font:14px/30px arial;color:#ccc;text-align:right;border-top:solid 1px #ccc;"><span>'+obj.options.linkplaceholderStr+'</span>';
		ss+='<span class="q_enter_button" style="display:none"><i class="fa fa-level-down fa-lg fa-rotate-90"></i></span></div>';
		ss+='</div>';
		blockcontainer.append(ss);
		blockcontainer.find('#recentqr_table').GM({
			gridManagerName: 'recentqrcodes',
			height: height+'px',
			disableMoveRow: false,
			supportCheckbox: false,
			ajaxData: obj.makeRecentGM_data(),
			columnData: [
				{key: 'tag',text: obj.options.txt_tag},
				{key: 'code',text: obj.options.txt_code},
				{key: 'operation',text: obj.options.txt_choose,
					template: function(operation, row){
						var ss='';
						if(obj.getIndexbyid($.md5(row.code))==-1){
							ss+='<span>';
							ss+='<i class="recentadd fa fa-plus-circle fa-2x"></i>';
							ss+='</span>';
						}
						return ss;
					},align: 'center'
				}
			],
			cellClick: function(row,rowIndex,colIndex){
				var idx=obj.getIndexbyid($.md5(row.code));
				if(idx==-1){
					obj.addQRcode(row.tag,row.code);
					GridManager.updateRowData('recentqrcodes','code',{code:row.code});
					obj.refresh();
				}
			}
		});
		obj.registerWorktopEvent(worktop);
	};
	QRcoderObject.prototype.empty=function(){
		var obj=this;
		if(obj.qrcodes.length>0){
			$('body').YesnoAlert({
				yesText:obj.options.txt_yes,noText:obj.options.txt_no,
				doyes: function(id,action){
					var box=obj.options.screen;
					if(JSON.stringify(box)!='{}'){box.find('table').empty();}
					obj.qrcodes=[];
					obj.modified();
					obj.refresh();
				}
			}).show_alertpane('',obj.options.txt_emptylist,'empty');
		}		
	};
	QRcoderObject.prototype.makeGM_data=function(){
		var gmData = {totals: this.qrcodes.length};
		var data=[];//{tag:'123',code:'http://localhost/img/abc.png'}
		this.qrcodes.forEach(function(qr){
			data.push({tag:qr.tag,code:qr.code});
		});
		gmData['data']=data;
		return gmData;	
	};
	QRcoderObject.prototype.makeRecentGM_data=function(){
		var obj=this;
		var recentqrcodes=this.options.readRecent();
		var gmData = {totals: recentqrcodes.length};
		var data=[];
		recentqrcodes.forEach(function(qr){
			data.push({tag:qr.tag,code:qr.code});
		});
		gmData['data']=data;
		return gmData;	
	};
	QRcoderObject.prototype.setScreen=function(div_item){
		this.options.screen=div_item;	
		var table=div_item.find('table');
		if(table.length==0){
			div_item.append(this.initGridblockText());
		}/*fault-tolerant*/
	};
	QRcoderObject.prototype.show=function(){
		this.element.show();		
	};
	QRcoderObject.prototype.hide=function(){
		this.element.hide();		
	};
	QRcoderObject.prototype.setOuterID=function(id){
		this.outerID = id;
	};
	QRcoderObject.prototype.addQRcode=function(tag,code){
		var msg='';
		if(code.length>0){
			var n=this.qrcodes.length;
			for(var i=0;i<n;i++){
				var qr=this.qrcodes[i];
				if(qr.code===code){
					if(qr.tag!==tag){
						qr.tag=tag;
						this.qrcodes[i]=qr;
						this.modified();
					}
					msg=this.options.txt_codeduplicated;
					break;
				}
			}
			if(msg.length==0){
				this.qrcodes.push({tag:tag,code:code});
				this.addScreenQRcode(tag,code);
				this.options.saveRecent(code,tag);
				this.modified();
			}
		}
		return msg;
	};
	QRcoderObject.prototype.qrtextSubmit=function(val){
		var ss=$.trim(val);
		if(ss.length>0){
			var msg=this.addQRcode('',ss);
			if(msg.length>0){alert(msg);}else{this.refresh();}
			this.element.find('.qrtext').select().focus();
		}
	};
	QRcoderObject.prototype.bindTabitemClick=function(dialogbox,itm){
		var obj=this;
		itm.on('click',function(){
			var itm_sel=itm.siblings('.q_tab_item_selected');
			itm_sel.removeClass('q_tab_item_selected').addClass('q_tab_item');
			obj.bindTabitemClick(dialogbox,itm_sel);
			$(this).removeClass('q_tab_item').addClass('q_tab_item_selected').off('click');
			var qrcode_frequent=dialogbox.find('#qr_grid');
			var qrcode_text=dialogbox.find('#qr_text');
			switch($(this).attr('id')){
				case 'tab_frequent':qrcode_frequent.show();qrcode_text.hide();break;
				case 'tab_text':qrcode_frequent.hide();
					var qrtext=qrcode_text.find('.qrtext');
					qrcode_text.show();qrtext.focus();
					break;
			}
		});
	};
	QRcoderObject.prototype.registerWorktopEvent=function(worktop){
		var obj=this;
		worktop.find('span.q_tab_item').each(function(){obj.bindTabitemClick(worktop,$(this));});
		worktop.find('.qrtext').on('input propertychange',function(e){
			$(this).next().find('.q_enter_button').show();
		});
		worktop.find('.qrtext').on('keypress',function(event){
			if(event.keyCode == "13"){event.preventDefault();obj.qrtextSubmit($(this).val());}
		});
		worktop.find('.q_enter_button').on('click',function(){obj.qrtextSubmit(worktop.find('.qrtext').val());});
	};
	QRcoderObject.prototype.modified=function(){
		this.options.onChange(this.outerID,this.getQRcodes());
	};
	QRcoderObject.prototype.resetScreen=function(){
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			box.empty();
			var n=this.qrcodes.length;
			for(var i=0;i<n;i++){
				var qr=this.qrcodes[i];
				this.addScreenQRcode(qr.tag,qr.code);
			}
			this.modified();
		}	
	};
	QRcoderObject.prototype.appendTR=function(table){
		var n=this.options.screen_columns;
		if(n==0){n=1;}
		var tr='<tr>',width=100;
		var avg=parseInt(width/n);
		for(var i=0;i<n;i++){
			var colwidth=avg; if(i==n-1){colwidth=width-(n-1)*avg;}
			tr+='<td class="blank working" style="text-align:'+this.options.cell_align+';vertical-align:'+this.options.cell_valign+';width:'+colwidth+'%"></td>';		
		}
		tr+='</tr>';
		table.append(tr);	
	};
	QRcoderObject.prototype.initGridblockText=function(){
		return '<div class="ht_gridblock"><table width="100%"></table></div>';
	};
	QRcoderObject.prototype.addScreenQRcode=function(tag,code){//match with entity.go childBlock function
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var obj=this;
			var id=$.md5(code);
			if(box.find('#'+id).length==0){
				var table=box.find('table');
				if(table.length==0){
					box.append(this.initGridblockText());table=box.find('table');
				}
				if(table.find('td.blank').length==0){obj.appendTR(table);}
				var td=table.find('td.blank:first');
				if(td.length==1){
					var qr='<img id="'+id+'" src="/qrcode?dt='+encodeURIComponent(code)+'">';
					if(tag.length>0){
						qr+='<br><span id="tag_'+id+'">'+tag+'</span>';
					}
					td.append(qr);
					td.removeClass('blank').addClass('used');
				}
			}
		}
	};
	QRcoderObject.prototype.setScreenTag=function(tag,code){
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var id=$.md5(code);
			var thetag=box.find('#tag_'+id);
			if(thetag.length==1){
				thetag.text(tag);
			}else{
				var theimg=box.find('img#'+id);
				if(theimg.length==1){
					theimg.after('<br><span id="tag_'+id+'">'+tag+'</span>');
				}
			}
		}
	};
	QRcoderObject.prototype.rmvScreenQRcode=function(id){
		var flag=false;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var qr=box.find('#'+id);
			if(qr.length==1){
				flag=true;
				var td=qr.parent();
				qr.remove();td.removeClass('used').addClass('blank');td.attr('style','');
				var nextids=[];
				td.nextAll('td.used').each(function(){nextids.push($(this).find('img').attr('id'));});
				var tr=td.parent();
				tr.nextAll().find('img').each(function(){nextids.push($(this).attr('id'));});
				var n=nextids.length;
				for(var i=0;i<n;i++){
					var nxt = box.find('#'+nextids[i]);
					if(nxt.length>0){
						var ntd = nxt.parent();
						nxt.appendTo(td);
						td.removeClass('blank').addClass('used');td.attr('style',ntd.attr('style'));
						ntd.removeClass('used').addClass('blank');ntd.attr('style','');
						td=ntd;
					}
				}
				tr.nextAll().each(function(){
					var atr=$(this);if(atr.find('.used').length==0){atr.remove();}
				});
				if(tr.find('.used').length==0){tr.remove();}
				if(box.find('img').length==0){box.find('i.ti').show();}
			}
		}
		return flag;
	};
	QRcoderObject.prototype.moveupNScreenQRcode=function(i_s,i_e){
		var flag=false;
		var obj=this;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var tds=box.find('td.used');
			if(i_e<tds.length){
				box.append('<div id="space" style="display:none"></div>');
				var space=box.find('#space');
				var td=box.find('#'+$.md5(obj.qrcodes[i_e].code)).parent();
				td.children().appendTo(space); var spacestyle=td.attr('style');
				for(var i=i_e;i>i_s;i--){
					var tdpre=box.find('#'+$.md5(obj.qrcodes[i-1].code)).parent();
					tdpre.children().appendTo(td);
					td.attr('style',tdpre.attr('style'));
					td=tdpre;
				}
				space.children().appendTo(td);
				td.attr('style',spacestyle);
				space.remove();
				flag=true;
			}
		}
		return flag;
	};
	QRcoderObject.prototype.movedownNScreenQRcode=function(i_s,i_e){
		var flag=false;
		var obj=this;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var tds=box.find('td.used');
			if(i_e<tds.length){
				box.append('<div id="space" style="display:none"></div>');
				var space=box.find('#space');
				var td=box.find('#'+$.md5(obj.qrcodes[i_s].code)).parent();
				td.children().appendTo(space); var spacestyle=td.attr('style');
				for(var i=i_s;i<i_e;i++){
					var tdnxt=box.find('#'+$.md5(obj.qrcodes[i+1].code)).parent();
					tdnxt.children().appendTo(td);
					td.attr('style',tdnxt.attr('style'));
					td=tdnxt;
				}
				space.children().appendTo(td);
				td.attr('style',spacestyle);
				space.remove();
				flag=true;
			}
		}
		return flag;
	};
	QRcoderObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	QRcoderObject.prototype.parseTextQRcodes=function(txt){
		var obj=this;
		obj.qrcodes=[];
		if(txt.length>0){
			var columns=1;
			var align='center',valign='top';
			/*format A: {"columns":1,"align":"center","valign":"top","qrcodes":[{"code":"/img/ok.png","tag":""}]}*/
			/*format B: code1,code2*/
			/*format C: base64(),base64()*/
			if(obj.isObjectText(txt)){
				var dt=JSON.parse(txt);
				if(dt.hasOwnProperty('columns')){	if(dt.columns>0){columns=dt.columns;}}
				if(dt.hasOwnProperty('align')){if(dt.align.length>0){align=dt.align;}}
				if(dt.hasOwnProperty('valign')){if(dt.valign.length>0){valign=dt.valign;}}
				for(var i=0;i<dt.qrcodes.length;i++){
					obj.qrcodes.push(dt.qrcodes[i]);
				}
			}else{
				var dtdt=txt.split(',');
				var n=dtdt.length;
				for(var i=0;i<n;i++){
					var dt=dtdt[i];
					if(dt.length>0){
						var code=dt;
						if(dt.indexOf('.')<0){/*base64 encode*/
							code=$.base64.decode(dt)
						}
						if(code.length>0){
							obj.qrcodes.push({code:code});
						}
					}
				}
			}
			obj.options.screen_columns=columns;
			obj.options.cell_align=align;
			obj.options.cell_valign=valign;
		}
	};
	QRcoderObject.prototype.refresh=function(){
		var obj=this;
		var self=this.element;
		//var box=obj.options.screen;
		//if(JSON.stringify(box)!='{}'){
		//	if(obj.qrcodes.length==0){box.find('p.editorflag').show();	}
		//}
		obj.column_spinner.setValue(obj.options.screen_columns);
		obj.cell_align.Select(obj.options.cell_align);
		obj.cell_valign.Select(obj.options.cell_valign);
		setTimeout(function(){
			GridManager.setAjaxData('qrcodes',obj.makeGM_data());
		},200);
	};
	QRcoderObject.prototype.setQRcodes=function(val){
		this.parseTextQRcodes(val);
		this.refresh();
		return this;
	};
	QRcoderObject.prototype.getQRcodes=function(){
		var dt={columns:this.options.screen_columns,align:this.options.cell_align,valign:this.options.cell_valign,qrcodes:this.qrcodes};
		return JSON.stringify(dt);
	};
    $.fn.QRcoder=function(options){
		var acoder=new QRcoderObject(this,options);
		acoder.init();
		return acoder;
    };
