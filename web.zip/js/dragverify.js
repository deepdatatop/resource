/**
 * dragverify.js for drag buttons to verify,not input verification code
 *
**/
(function($){
    $.fn.dragverify = function(params){
    		var txt_hint = 'Please drag the slider to the right side.';
		if(params.hasOwnProperty('txt_hint')){
			txt_hint = params['txt_hint'];
		}
    		var txt_success = 'Success!';
		if(params.hasOwnProperty('txt_success')){
			txt_success = params['txt_success'];
		}
        var x ;
        var dragverify = this;
        var moveFlag = false;
        var defaults = {};
        var params = $.extend(defaults,params);
        var htmls = '<div class="dragverifybg"></div><div class="dragverifytext" onselectstart="return false;" unselectable="on">'+txt_hint+'</div><div class="dv_block dv_blockbg"></div>';

        this.append(htmls);

        var block = dragverify.find(".dv_block");
        var dragverifybg = dragverify.find(".dragverifybg");
        var drafverifytext = dragverify.find(".dragverifytext");
        var maxWidth = dragverify.width() - block.width();
        block.mousedown(function(e){
            moveFlag = true;
            x = e.pageX - parseInt(block.css("left"),10);
        });
        $(document).mousemove(function(e){
            var moveX = e.pageX - x;
            if(moveFlag){
                if(moveX > 0 && moveX < maxWidth){
                    block.css({"left":moveX});
                    dragverifybg.css({"width":moveX});
                }else if(moveX > maxWidth){
                    verifySuc();
                }
            }
        }).mouseup(function(e){
            moveFlag = false;
            var mX = e.pageX - x;
            if(mX < maxWidth){
                block.css({"left":0});
                dragverifybg.css({"width":0});
            }
        });
        function verifySuc(){
            block.removeClass("dv_blockbg").addClass("dv_blockbgsuc");
            drafverifytext.text(txt_success);
            dragverify.css({"color":"#ffffff","text-align":"center"});
            block.unbind("mousedown");
            $(document).unbind("mousemove");
            $(document).unbind("mouseup");
            if($.isFunction(params.onSuccess)) params.onSuccess.call(dragverify.$element);
        }
    }
})(jQuery);

/*usedemo
$("#dragverify").dragverify({
	txt_success: '验证通过',txt_hint: '请拖动滑块至右侧 》',
    onSuccess: function () { alert('验证通过!'); }
});*/