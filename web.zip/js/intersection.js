function IntersectionObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		height:500,
		horicodeset:{},/*{"Code":"100","Msg":"success","Caption":"用户类别","Self_hierarchy":false,"Nchildren":5,"Children":[{"Id":1,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"customer","Name":"客户"},{"Id":8,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"staffer","Name":"职员"},{"Id":9,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"director","Name":"部门主管"},{"Id":99,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"master","Name":"业务总管"},{"Id":100,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"administrator","Name":"系统管理员"}]}*/
		vertcodeset:{},
		kvcells:{},/*{"1-1":1,"8-27":1}*/
		onChange: function(){}
	};
	this.options=$.extend({},this.defaults,options);
	this.freezeCols=0;
	this.nRows=0;
	this.cells={};
	this.colids=[];
	this.pqobject={};
};
IntersectionObject.prototype.getData=function(){
	var self=this;
	self.cells={};
	var ocells=self.pqobject.pqGrid("getData",{});
	for(var i=0,n=ocells.length;i<n;i++){
		var rw=ocells[i],r_id=rw['id'];
		for(var j=0,m=self.colids.length;j<m;j++){
			var c_id=self.colids[j],cid='c_'+c_id,cell=false;
			if(rw.hasOwnProperty(cid)){cell=rw[cid];}
			if(cell){
				self.cells[c_id+'-'+r_id]=1;
			}
		}
	}
    return JSON.stringify(self.cells);
};
IntersectionObject.prototype.refresh=function(){
	this.pqobject.pqGrid("refreshDataAndView");
};
IntersectionObject.prototype.clearData=function(){
	var self=this;
	var ocells=self.pqobject.pqGrid("getData",{});
	for(var i=0,n=ocells.length;i<n;i++){
		var rw=ocells[i];
		for(var j=0,m=self.colids.length;j<m;j++){
			var cid='c_'+self.colids[j];
			if(rw.hasOwnProperty(cid)){
				delete rw[cid];
			}
		}
		ocells[i]=rw;
	}
	self.pqobject.pqGrid("refreshDataAndView");
};
IntersectionObject.prototype.modified=function(){
    this.options.onChange();
};
IntersectionObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){	o[k]=o.i18n[k];}
	}
};
IntersectionObject.prototype.makeColModel=function(){
	var self=this;
	var colModel=[];
	var m=self.options.horicodeset;
		if(m.Code=='100'){
			self.colids=[];
			if(m.Self_hierarchy){
				var pos=new Object();
				var childlist=new Object();
				childlist[0]=new Array();
				var n=m.Nchildren;
				for(var i=0;i<n;i++){
					var o=m.Children[i];
					var v=o.Id;
					pos[v]=i;
					childlist[v]=new Array();
				}
				for(var i=0;i<n;i++){
					var o=m.Children[i];
					var parent=o.Parentid;
					if(childlist.hasOwnProperty(parent)){
						childlist[parent].push(o.Id);
					}
				}
				colModel=self.addHTitle(0,m.Children,childlist,pos);
			}else{
				for(var i=0,n=m.Nchildren;i<n;i++){
					var o=m.Children[i];
					self.colids.push(o.Id);
					colModel.push({ 
	                    dataIndx: "c_"+o.Id,
	                    align: "center",
	                    title: "<label><input type='checkbox'>&nbsp;"+o.Name+"</label>",
	                    cb: { header: true, all: true },
	                    type: 'checkbox',
	                    cls: 'ui-state-default', 
	                    dataType: 'bool',
	                    editor: false
	                });
				}
			}
		}
	return colModel;
};
IntersectionObject.prototype.addHTitle=function(pid,children,childlist,pos){
	var self=this;
	var colmodel=[];
	var cc=childlist[pid];
	for(var i=0,n=cc.length;i<n;i++){
		var cid=cc[i];
		var o=children[pos[cid]];
		if(o.Isleaf){
			self.colids.push(o.Id);
			colmodel.push({ 
				dataIndx: "c_"+o.Id,
				align: "center",
				title: "<label><input type='checkbox'>&nbsp;"+o.Name+"</label>",
				cb: { header: true, all: true },
				type: 'checkbox',
				cls: 'ui-state-default', 
				dataType: 'bool',
				editor: false
			});					
		}else{
			colmodel.push({
				title: "<label>"+o.Name+"</label>",
				align: "center",
				colModel: self.addHTitle(o.Id,children,childlist,pos)
			});
		}
	}
	return colmodel;
};
IntersectionObject.prototype.makeVBlock=function(data,mergecells){
	var self=this;
	var vcol=[];
	var v_caption='';
	var maxDepth=1;
	var m=self.options.vertcodeset;
	if(m.Code=='100'){
		v_caption=m.Caption;
		if(m.Self_hierarchy){
			var pos=new Object();
			var childlist=new Object();
			childlist[0]=new Array();
			var n=m.Nchildren;
			for(var i=0;i<n;i++){
				var o=m.Children[i];
				var v=o.Id;
				if(o.Depth>maxDepth){maxDepth=o.Depth;}
				pos[v]=i;
				childlist[v]=new Array();
			}
			for(var i=0;i<n;i++){
				var o=m.Children[i];
				var parent=o.Parentid;
				if(childlist.hasOwnProperty(parent)){
					childlist[parent].push(o.Id);
				}
				if(o.Isleaf){/*add space cells*/
					var row={id:o.Id};
					for(var j=0;j<maxDepth;j++){row[j]='';}
					data.push(row);
				}
			}
			self.nRows=self.addVTitle(0,0,0,maxDepth,m.Children,childlist,pos,data,mergecells);
		}else{
			for(var i=0;i<m.Nchildren;i++){
				var o=m.Children[i];
				data.push({id:o.Id,0:o.Name});
			}
			self.nRows=m.Nchildren;
		}
	}
	self.freezeCols=maxDepth;
	for(var i=0;i<maxDepth;i++){
		var nm='-';
		if(i==0){nm=v_caption;}
		vcol.push({align: "center",title: "<label>"+nm+"</label>"});
	}
	return vcol;
};
IntersectionObject.prototype.addVTitle=function(x,y,pid,maxdepth,children,childlist,pos,data,mergecells){
	var self=this;
	var clst=childlist[pid];
	var yy=y;
	for(var i=0,n=clst.length;i<n;i++){
		var mc={c1:x,r1:yy,cc:1,rc:1,style:'background:#eee;'};
		var cid=clst[i];
		var o=children[pos[cid]];
		var row=data[yy];row[x]=o.Name;
		if(o.Isleaf){
			mc['cc']=maxdepth-x;
			yy+=1;
		}else{
			var rc=self.addVTitle(x+1,yy,cid,maxdepth,children,childlist,pos,data,mergecells);
			mc['rc']=rc;
			yy+=rc;
		}
		//if(mc.rc>1||mc.cc>1){mergecells.push(mc);}
		mergecells.push(mc);
	}
	return yy-y;//rows;
};
IntersectionObject.prototype.init=function(){
	this.i18n_options();
    var self=this,thebox=this.element,so=this.options;
    self.cells=so.kvcells;
	var data = [];
        //    { id: 1, c_1: true, c_8: true, c_9: true, c_99: true },
        //    { id: 2, c_1: false, c_8: true, c_9: false }
	var v_mergecells = [];
	var vcol=self.makeVBlock(data,v_mergecells).concat(self.makeColModel());
	for(var i=0,n=data.length;i<n;i++){
		var rw=data[i];
		for(var j=0,m=self.colids.length;j<m;j++){
			var cid=self.colids[j]+'-'+rw['id'];
			if(self.cells.hasOwnProperty(cid)){
				rw['c_'+self.colids[j]]=true;
			}
		}
		data[i]=rw;
	}
	self.pqobject = thebox.pqGrid({
        scrollModel: { autoFit: true },
        numberCell: { show: false },
        selectionModel: { type: null },
        pasteModel: { on: false },
        height: so.height,
        showTop: false,
        collapsible: { on: false },
        stripeRows: true,
        freezeCols: self.freezeCols,
        pageModel: { rPP: self.nRows },
        colModel: vcol,
        change: function(event,ui){ so.onChange(); },
        dataModel: { data: data },
        mergeCells: v_mergecells
	});
};
$.fn.Intersection=function(options){
	var isect=new IntersectionObject(this,options);
	isect.init();
	return isect;
};