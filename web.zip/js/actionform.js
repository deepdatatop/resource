	function ActionformObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			width:800,
			height:600,
			zindex:200,
			caption:'',
			txt_ok: 'OK',
			txt_cancel: 'Cancel',
			eid: '',
			scene: 'normal',
			widget_dependency: '',//base64 /css/formarea.css,/js/formarea.js
			onCancel: function(){},
			onOK: function(data){}
		};
		this.id='';
		this.po='actionform_overlay';
		this.formarea={};
		this.options=$.extend({},this.defaults,options);
    };
	ActionformObject.prototype.close_pane=function(){
		this.element.find('#editor_area').remove();
		this.element.find('#'+this.po).remove();
		this.element.find('#actionform_pane').remove();
	};
	ActionformObject.prototype.include_callback=function(){//call at include.js
		var self=this;
		var thebox=this.element;
		this.formarea=thebox.find('#editor_area').Formarea({
			entity_id:this.options.eid,scene:this.options.scene
		});	
	};
	ActionformObject.prototype.setpane=function(){
		var wd='';
		if(this.options.widget_dependency.length>0){
			wd=$.base64.decode(this.options.widget_dependency);
		}else{
			$.ajaxSettings.async = false;
			$.getJSON('/readformdependency',{eid:this.options.eid,scene:this.options.scene},function(m){
				if(m.Code=='100'){
					if(m.Dependency_bs64.length>0){
						wd=$.base64.decode(m.Dependency_bs64);
					}
				}
			});
			$.ajaxSettings.async = true;
		}
		include_queue(this,wd);	// ➸ include_callback
	};
	ActionformObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	ActionformObject.prototype.init=function(){
		this.i18n_options();
		var self=this;
		var thebox=this.element;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.po+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.35);
		var txt= '<div id="actionform_pane" style="display: none;';
		txt += 'width:'+self.options.width+'px;height:'+self.options.height+'px;">';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 0px;top: 0px;cursor: pointer;';
		txt += '<div><span id="af_close_icon" style="'+ats+'"></span></div>';
		txt += '<div id="editor_area" style="width:100%;height:'+(self.options.height-34)+'px;overflow-y:scroll;"></div>';
		txt += '<div style="width:100%;text-align:center;line-height:34px;">';
		txt += '<input style="cursor:pointer;margin-right:40px;" type="button" class="button" id="btn_ok" value="'+self.options.txt_ok+'">';
		txt += '<input style="cursor:pointer;" type="button" class="button" id="btn_cancel" value="'+self.options.txt_cancel+'"></div>';
		txt += '</div>';
		thebox.append(txt);
		var pane = thebox.find('#actionform_pane');
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#btn_ok').off("click").on("click",function(event){
			event.stopPropagation();	
			self.options.onOK(self.formarea.getData());
			self.close_pane();
		});
		thebox.find('#btn_cancel').off("click").on("click",function(event){
			event.stopPropagation();	
			self.options.onCancel();
			self.close_pane();
		});
		thebox.find('#'+self.po).off("click").on("click",function(event){/*self.close_pane();*/});
		thebox.find('#af_close_icon').off("click").on("click",function(event){
			self.options.onCancel();self.close_pane();
		});
		self.setpane();
	};
    $.fn.Actionform=function(options){
		var aform=new ActionformObject(this,options);
		aform.init();
		return aform;
    };