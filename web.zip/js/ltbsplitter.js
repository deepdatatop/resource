	function LTBSplitterObject(element,options){
		this.element=element;
		var defaults={
			lr_splitter_width:5,
			tb_splitter_height:5,
			min_left_width:300,
			min_right_width:0,
			min_top_height:240,
			left_block:'',
			top_block:'',
			bottom_block:'',
			lrResize:function(left,right){},
			tbResize:function(top,bottom){}
		};
		this.options=$.extend({},defaults,options);
    };
	LTBSplitterObject.prototype.addLeftblock=function(){
		var self=this.element;
		if(this.options.left_block.length>0){
			self.find('#left_block').append(this.options.left_block);
		}			
	};
	LTBSplitterObject.prototype.addTopblock=function(){
		var self=this.element;
		if(this.options.top_block.length>0){
			self.find('#top_block').append(this.options.top_block);
		}		
	};
	LTBSplitterObject.prototype.addBottomblock=function(){
		var self=this.element;
		if(this.options.bottom_block.length>0){
			self.find('#bottom_block').append(this.options.bottom_block);
		}
	};
	LTBSplitterObject.prototype.init=function(){
		var obj=this;
		var self=this.element;
		self.empty();
		var 	ss = '<div id="left_block"></div>';
		ss += '<div id="lr_splitter"></div>';
		ss += '<div id="right_block">';
		ss += '<div id="top_block"></div>';
		ss += '<div id="tb_splitter"></div>';
		ss += '<div id="bottom_block"></div>';
		ss += '</div>';//'</div>';
		self.append(ss);
		obj.addTopblock();/*must before addLeftblock*/
		obj.addLeftblock();
		obj.addBottomblock();
		obj.windowResize();
		if(obj.options.lr_splitter_width>0){obj.bindLRSplitter(document.getElementById('lr_splitter'));}
		if(obj.options.tb_splitter_height>0){obj.bindTBSplitter(document.getElementById('tb_splitter'));}
		obj.bindResizeEvent();
		self.bind('mousewheel DOMMouseScroll', function(e){e.preventDefault();});
		obj.ex_init();
    };
	LTBSplitterObject.prototype.ex_init=function(){/*virtual function*/};
	LTBSplitterObject.prototype.windowResize=function(){
		var self=this.element,os=this.options;
		var left_block=self.find('#left_block');
		var lr_splitter=self.find('#lr_splitter');
		var right_block=self.find('#right_block');
		var top_block=self.find('#top_block');
		var tb_splitter=self.find('#tb_splitter');
		var bottom_block=self.find('#bottom_block');
		var workviewwidth=self.width();
		var workviewheight=self.height();
		if(os.lr_splitter_width<=0){lr_splitter.hide();}
		if(os.tb_splitter_height<=0){tb_splitter.hide();}
		var left=os.min_left_width,right=os.min_right_width;
		if(os.min_left_width>0){
			left_block.css("width",os.min_left_width+"px");
			right=workviewwidth-left-os.lr_splitter_width;
		}else{
			var w=workviewwidth-os.min_right_width-os.lr_splitter_width;
			left_block.css("width",w+"px");
			left=w;
		}
		os.lrResize(left,right);
		left_block.css("height",workviewheight+"px");
		right_block.css("height",workviewheight+"px");
		var top=os.min_top_height,bottom=workviewheight-top-os.tb_splitter_height-1;
		top_block.css("height",os.min_top_height+"px");
		bottom_block.css("height",bottom+"px");
		os.tbResize(top,bottom);
	};
	LTBSplitterObject.prototype.bindResizeEvent=function(){
		var obj=this;
		$(window).resize(function() {
			obj.windowResize();
		});
	};
	LTBSplitterObject.prototype.bindLRSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var x=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var left_block=self.find('#left_block');
			x=e.clientX-splitter.offsetWidth-left_block.width();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){mouseMove(ev || event);};
				splitter.onmouseup = mouseUp;
			}else{
				left_block.css('cursor','col-resize');
				self.find('#right_block').css('cursor','col-resize');
				$(document).bind("mousemove", mouseMove).bind("mouseup", mouseUp);
			}
		});
		function mouseMove(e){
			e.preventDefault();
			var left_block=self.find('#left_block');
			var left=e.clientX - x;
			if((e.clientX/document.body.clientWidth)<0.8){
				left_block.css('width',left + 'px');
			}
			if(e.clientX<obj.options.lr_splitter_width){left_block.hide();left=0;}else{left_block.show();}
			right=self.width()-left-obj.options.lr_splitter_width;
			obj.options.lrResize(left,right);
		}
		function mouseUp(){
			self.find('#left_block').css('cursor','default');
			self.find('#right_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", mouseMove).unbind("mouseup", mouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var left_block=self.find('#left_block');
			left_block.show();
			var left=obj.options.min_left_width,right=obj.options.min_right_width;
			if(obj.options.min_left_width>0){
				left_block.css("width",obj.options.min_left_width+"px");
				right=self.width()-left-obj.options.lr_splitter_width;
			}else{
				var w=self.width()-obj.options.min_right_width-obj.options.lr_splitter_width;
				left_block.css("width",w+"px");
				left=w;
			}
			obj.options.lrResize(left,right);
			e.preventDefault();
		});
	};
	LTBSplitterObject.prototype.bindTBSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var y=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var top_block=self.find('#top_block');
			y=e.clientY-splitter.offsetHeight-top_block.height();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){tbmouseMove(ev || event);};
				splitter.onmouseup = tbmouseUp;
			}else{
				top_block.css('cursor','row-resize');
				self.find('#bottom_block').css('cursor','row-resize');
				$(document).bind("mousemove", tbmouseMove).bind("mouseup", tbmouseUp);
			}
		});
		function tbmouseMove(e){
			e.preventDefault();
			var top_block=self.find('#top_block');
			var bottom_block=self.find('#bottom_block');
			var max_height=self.find('#right_block').height();
			var top=e.clientY - y;
			var bottom=max_height-top-obj.options.tb_splitter_height;
			if(bottom>=0){
				top_block.css('height',top + 'px');
				bottom=max_height-top-obj.options.tb_splitter_height;
				bottom_block.css('height',bottom+'px');
			}
			if(e.clientY<obj.options.tb_splitter_height){
				top=0;
				top_block.hide();
				bottom=max_height-obj.options.tb_splitter_height;
				bottom_block.css('height',bottom+'px');
			}else{top_block.show();}
			obj.options.tbResize(top,bottom);
		}
		function tbmouseUp(){
			self.find('#top_block').css('cursor','default');
			self.find('#bottom_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", tbmouseMove).unbind("mouseup", tbmouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var max_height=self.find('#right_block').height();
			var top_block=self.find('#top_block');
			top_block.show();
			var top=obj.options.min_top_height,bottom=max_height-top-obj.options.tb_splitter_height;
			top_block.css('height',top+'px');
			self.find('#bottom_block').css('height',(max_height-obj.options.min_top_height-obj.options.tb_splitter_height)+'px');
			obj.options.tbResize(top,bottom);
			e.preventDefault();
		});
	};
    $.fn.LTBSplitter=function(options){
		var ltb=new LTBSplitterObject(this,options);
		ltb.init();
		return ltb;
    };
	
	
/*inherit extend use.
<script type="text/javascript">
	function inheritPrototype(subObject, superObject){
		var prototype = Object.create(superObject.prototype);
		prototype.constructor = subObject;
		subObject.prototype = prototype;
	}
	function CodethirdedObject(element,options){
		LTBSplitterObject.call(this,element,$.extend({},options));
    };
	inheritPrototype(CodethirdedObject,LTBSplitterObject);
	CodethirdedObject.prototype.addLeftblock=function() {
		
	};
    $.fn.Codethirded=function(options){
		var ltb=new CodethirdedObject(this,options);
		ltb.init();
		return ltb;
    };
</script>*/