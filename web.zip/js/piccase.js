function PiccaseObject(element,options){
	this.element=element;
	var defaults={
		
	};
	this.options=$.extend({},defaults,options);
	this.added=0;
	this.ipic=0;
	this.srclist=[];
};
PiccaseObject.prototype.addPic=function(tag,src){
	var thebox=this.element;
	thebox.find('#pic').attr('src',src);
	this.srclist.push(src);
	this.added++;
	this.ipic=this.added;
	this.showHint();
};
PiccaseObject.prototype.showHint=function(){
	this.element.find('.bar_center').text(this.ipic+' / '+this.added);
};
PiccaseObject.prototype.init=function(){
	var self=this;
	var thebox=this.element;
	var ss='<div class="pic_case"><img id="pic"></div>';
	ss+='<div class="pic_bar"><span class="bar_left"></span>';
	ss+='<span class="bar_center"></span><span class="bar_right"></span></div>';
	thebox.append(ss);
	thebox.find('#pic').on('click',function(){
		if(self.added>0){
			self.ipic-=1;
			if(self.ipic==0){self.ipic=self.added;}
			self.showHint();
			var src=self.srclist[self.ipic-1];
			thebox.find('#pic').attr('src',src);
		}
	});
};
$.fn.Piccase=function(options){
	var acase=new PiccaseObject(this,options);
	acase.init();
	return acase;
};