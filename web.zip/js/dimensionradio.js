function DimensionRadioObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
  		identifier:'product',
		scene:'direct',
		ids:'',
		dimension_scene:'',
		sku_scene:'',
		price_scene:'',
		picture_scene:'',
		onChange: function(id,code,price,stock,pic){}
	};
	this.options=$.extend({},this.defaults,options);
	this.picture='';
	this.dimensions={};
	this.SKU={};
};
DimensionRadioObject.prototype.modified=function(){
    //this.options.onChange();
};
DimensionRadioObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){	o[k]=o.i18n[k];}
	}
};
DimensionRadioObject.prototype.setprice=function(){
	var dd=[];
	var keys=Object.keys(this.dimensions);
	for(var i=0,n=keys.length;i<n;i++){
		dd.push(this.dimensions[keys[i]]);
	}
	dd.sort();
	var skucode=dd.join(';');
	if(this.SKU.hasOwnProperty(skucode)){
		var sku=this.SKU[skucode];//{"ID":100,"Code":"0101","Price":"0","Stock":"999"}
		this.options.onChange(sku.ID,sku.Code,sku.Price,sku.Stock,this.picture);
	}
};
DimensionRadioObject.prototype.init=function(){
	this.i18n_options();
    var self=this,so=this.options;
    var thebox=this.element;
    $.getJSON('/drawopt',{idf:so.identifier,scene:so.scene,ids:so.ids,
    			dimension_scene:so.dimension_scene,sku_scene:so.sku_scene,
			price_scene:so.price_scene,picture_scene:so.picture_scene
    		},function(m){
		if(m.Code=='100' && m.SKU_totals>0){
			self.SKU=JSON.parse(m.SKU_stringify);//"10-18;9-11":{"ID":100,"Code":"0101","Price":"0","Stock":"999"}
			var txt='';
			var dimensions=JSON.parse(m.Dimension_stringify);
			for(var i=0,n=dimensions.length;i<n;i++){
				var dim=dimensions[i],enums=dim.Enum;
				txt+='<div class="dimension" id="'+dim.ID+'">';
				txt+='<span class="dtitle">'+dim.Name+'</span>&nbsp;&nbsp;'
				for(var j=0,m=enums.length;j<m;j++){
					var itm=enums[j];
					txt+='<div class="radioblk';
					if(i+j==0){
						txt+=' checked';
						self.dimensions[dim.ID]=itm.Property;
						if(itm.Image.length>0){self.picture=itm.Image;}
					}
					txt+='" property="'+itm.Property+'">';
					if(itm.Image.length>0){txt+='<img class="rimage" src="'+itm.Image+'">';}
					txt+='<span class="rtitle">'+itm.Title+'</span>';
					if(i+j==0){txt+='<i class="fa fa-check flag"></i>';	}
					txt+='</div>';
				}
				txt+='</div>';
			}
			thebox.append(txt);
			thebox.find('.radioblk').on('click',function(){
				var chked='checked';
				if(!$(this).hasClass(chked)){
					var parent=$(this).parent();
					var focusitm=parent.find('.'+chked);
					if(focusitm.length>0){
						focusitm.find('.flag').remove();
						focusitm.removeClass(chked);
					}
					$(this).addClass(chked);
					$(this).append('<i class="fa fa-check flag"></i>');
					var pdim=$(this).parents('.dimension');
					self.dimensions[pdim.attr('id')]=$(this).attr('property');
					var img=$(this).find('.rimage');
					if(img.length==1){self.picture=img.attr('src');}
					self.setprice();
				}
			});
		}
	});
};
$.fn.DimensionRadio=function(options){
	var anradio=new DimensionRadioObject(this,options);
	anradio.init();
	return anradio;
};