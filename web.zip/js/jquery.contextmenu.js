/**
 *
 * Usage:
 *
 *   $('#id').contextPopup({
 *     title: 'title',outerid: '123',doaction:function(outerid,action){},
 *     items: [
 *       {label:'item1', icon:'/some/icon1.png', action:'hello'},
 *       {label:'item2', icon:'/some/icon2.png', action:'world'},
 *       null,
 *       {label:'item3', icon:'/some/icon3.png', action:'seek'}
 *     ]
 *   });
 *
 **/
jQuery.fn.contextPopup = function(menuData) {
	var settings = {
		contextMenuClass: 'contextMenu',
		gutterLineClass: 'gutterLine',
		headerClass: 'header',
		seperatorClass: 'divider',
		icon: '',
		title: '',
		outerid: '',
		custom_event: 'contextpopup',
		//doaction: function(outerid,action){},
		items: []
	};
	$.extend(settings, menuData);
  function createMenu(e) {
    var menu = $('<ul class="' + settings.contextMenuClass + '"><div class="' + settings.gutterLineClass + '"></div></ul>')
      .appendTo(document.body);
    if (settings.title) {
      $('<li class="' + settings.headerClass + '">'+settings.title+'</li>').appendTo(menu);
    }
    settings.items.forEach(function(item){
      if (item) {
    	var rowCode = '<li><a href="#">';
		if(item.icon.length>0){
        	if(item.icon.indexOf('fa-')>=0){
				rowCode += '<i class="fa '+item.icon+'"></i>&nbsp;&nbsp;';
			}else{
				rowCode += '<img src="'+item.icon+'">';
			}
		}
		rowCode += '<span>'+item.label+'</span></a></li>';
		var row=$(rowCode).appendTo(menu);	
        //if (settings.doaction) {
        row.find('a').click(function(){
			/*settings.doaction(settings.outer,item.action);*/
			var te=new CustomEvent(settings.custom_event,
				{detail:{id:settings.outerid,action:item.action,popview:item.popview,intersect:item.intersect}});
			window.dispatchEvent(te);
		});
        //}
      } else {
        $('<li class="' + settings.seperatorClass + '"></li>').appendTo(menu);
      }
    });
    menu.find('.' + settings.headerClass ).text(settings.title);
    return menu;
  }
  this.bind('click', function(e) {	
    var menu = createMenu(e).show();
    
    var left = e.pageX + 5,top = e.pageY;
    if (top + menu.height() >= $(window).height()) {
        top -= menu.height();
    }
    if (left + menu.width() >= $(window).width()) {
        left -= menu.width();
    }
    menu.css({zIndex:1000001, left:left, top:top})
      .bind('contextmenu', function() { return false; });
    var back = $('<div></div>')
      .css({left:0, top:0, width:'100%', height:'100%', position:'absolute', zIndex:1000000})
      .appendTo(document.body)
      .bind('contextmenu click', function() {
        back.remove();
        menu.remove();
        return false;
      });
    menu.find('a').click(function() {
      back.remove();
      menu.remove();
    });
    return false;
  });
  return this;
};