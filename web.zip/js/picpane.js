function PicpaneObject(element,options){
	this.element=element;
	var defaults={
		i18n:{},
		zindex:20000,
		token:'',
		focus_tab:'history',/*history,link,upload*/
		image_capacity:1,
		piccase_width:240,
		supportWechat:false,
		exceedcontainerlimit: 'image quantity exceed limit:',
		urlduplicated: 'image URL duplicated!',
		historyStr: 'History',
		linkStr: 'PicURL',
		linkplaceholderStr: '↸ Input picture URL and press enter key to submit',
		localStr: 'Local',
		wechatStr: 'Scan',
		addedStr: 'Added',
		uploadStr: 'Upload file:',
		dragDropStr: '<span>Drag & Drop Files...</span>',
		multiDragErrorStr: 'Multiple File Drag & Drop is not allowed.',
		extErrorStr: 'is not allowed. Allowed extensions: ',
		duplicateErrorStr: 'is not allowed. File already exists.',
		sizeErrorStr: 'is not allowed. Allowed Max size: ',
		uploadErrorStr: 'Upload is not allowed',
		maxFileCountErrorStr: ' is not allowed. Maximum allowed files are:',
		onAdded: function(tag,src){},
		readRecent:function(){return [];}
	};
	this.options=$.extend({},defaults,options);
	this.slider={};
	this.piccase={};
	this.fileuploader={};
	this.wechatConnection={};
};
PicpaneObject.prototype.added=function(tag,src){
	this.options.onAdded(tag,src);
	if(this.options.image_capacity==1){
		this.closePane();
	}else{
		this.piccase.addPic(tag,src);
	}
};
PicpaneObject.prototype.extractTag=function(src){
	var filename=src;
	var ss=src.split('/');
	var n=ss.length;
	if(n>0){	filename=ss[n-1];}
	ss=filename.split('.');
	if(ss.length>0){filename=ss[0];}
	return filename;
};
PicpaneObject.prototype.closePane=function(){
	var thebox=this.element;
	thebox.find('#pp_dialogpane').remove();
	thebox.find('#pp_dialogbox').remove();
};
PicpaneObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
PicpaneObject.prototype.init=function(){
	this.i18n_options();
	var obj=this;
	var thebox=this.element;
	thebox.append('<div id="pp_dialogpane" style="z-index:'+obj.options.zindex+';"></div>');
	//var ds='width:90%;height:300px;z-index:'+(obj.options.zindex+1)+';background-color:#fff;border:solid 1px #dadada;overflow:hidden;dispay:none;';
	//ds+='border-radius:5px;padding:6px;box-shadow:4px 4px 10px #808080;';
	thebox.append('<div id="pp_dialogbox" style="z-index:'+(obj.options.zindex+1)+';"></div>');
	var idialog=thebox.find('#pp_dialogpane');
	idialog.css({"display":"block",opacity:0}).fadeTo(200,0.2);
	var dialogbox=thebox.find('#pp_dialogbox');
	obj.setupDialog(dialogbox);
	var modal_width=dialogbox.outerWidth(); var modal_height=dialogbox.outerHeight();
	dialogbox.css({"display":"block","position":"fixed","opacity":0,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	dialogbox.fadeTo(200,1);
	idialog.off("click").on("click",function(event){
		obj.closePane();
	});
};
PicpaneObject.prototype.setupDialog=function(dialogbox){
	var obj=this;
	var captionheight=36;
	var height=dialogbox.innerHeight()-captionheight-3;
	var ss='<div class="i_dialogcaption">加图片：</div><div class="i_dialogclose"><i class="fa fa-close"></i></div>';
	ss+='<div id="worktop" style="width:100%;height:'+height+'px;"></div>';
	dialogbox.append(ss);
	dialogbox.find('.i_dialogclose').on('click',function(){obj.closePane();});
	obj.setupWorktop(dialogbox.find('#worktop'));
};
PicpaneObject.prototype.setupWorktop=function(worktop){
	var obj=this;
	var ss='<div id="i_worktop"><div>';
	ss+='<span class="i_tab_item'+(obj.options.focus_tab=='history'?'_selected':'')+'" id="tab_history">'+obj.options.historyStr+'&nbsp;<i class="fa fa-history"></i></span>';
	ss+='<span class="i_tab_item'+(obj.options.focus_tab=='link'?'_selected':'')+'" id="tab_link">'+obj.options.linkStr+'&nbsp;<i class="fa fa-link"></i></span>';
	ss+='<span class="i_tab_item'+(obj.options.focus_tab=='upload'?'_selected':'')+'" id="tab_upload">'+obj.options.localStr+'&nbsp;<i class="fa fa-upload"></i></span>';
	if(obj.options.supportWechat){
		ss+='<span class="i_tab_item'+(obj.options.focus_tab=='wechat'?'_selected':'')+'" id="tab_wechat">'+obj.options.wechatStr+'&nbsp;<i class="fa fa-weixin"></i></span>';
	}
	ss+='</div>';
	if(this.options.image_capacity>1){
		ss+='<div style="float:right;width:'+obj.options.piccase_width+'px;font:normal 18px Arial;margin-top:5px">';
		ss+='<i class="fa fa-film"></i>&nbsp;'+obj.options.addedStr+'</div>';
	}
	ss+='</div>';
	var tabtopheight=36;
	var height = worktop.innerHeight()-tabtopheight;
	if(this.options.image_capacity>1){
		ss+='<div id="piccase" style="float:right;width:'+(obj.options.piccase_width-1)+'px;height:'+height+'px;';
		ss+='overflow-x:hidden;overflow-y:scroll;background:#fff;border-left:1px solid #ccc;"></div>';
	}
	ss+='<div id="blockcontainer" style="padding:0px;';
	if(this.options.image_capacity>1){
		ss+='margin-right:'+obj.options.piccase_width+'px;';
	}
	ss+='height:'+height+'px;"></div>';
	worktop.append(ss);
	var blockcontainer=worktop.find('#blockcontainer');
	ss='<div id="img_gallery" class="illu_block gallery"'+(obj.options.focus_tab=='history'?'':' style="display:none"')+'>';
	ss+='</div>';
	var style='width:100%;height:'+height+'px;overflow:hidden;';
	if(obj.options.focus_tab!='link'){style+='display:none;';}
	ss+='<div id="img_link" style="'+style+'" class="illu_block">';
	var toolbarheight=36;
	ss+='<textarea class="hyperlink" style="width:'+(blockcontainer.innerWidth()-2)+'px;height:'+(height-toolbarheight)+'px;"></textarea>';
	ss+='<div style="width:100%;height:'+toolbarheight+'px;font:14px/30px arial;color:#ccc;text-align:right;border-top:solid 1px #ccc;"><span>'+obj.options.linkplaceholderStr+'&nbsp;</span>';
	ss+='<span class="i_enter_button" style="display:none">↩</span></div>';
	ss+='</div>';
	ss+='<div id="img_upload" class="illu_block"'+(obj.options.focus_tab=='upload'?'':' style="display:none"')+' style="text-align:center;">';
	ss+='<div class="fileuploader"></div>';
	ss+='</div>';
	if(obj.options.supportWechat){
		ss+='<div id="img_transfer" style="text-align:center;'+style+'" class="illu_block"'+(obj.options.focus_tab=='wechat'?'':' style="display:none"')+' style="text-align:center;">';
		ss+='<img class="qrcode" height="'+height+'">';
		ss+='</div>';
	}
	blockcontainer.append(ss);
	if(this.options.image_capacity>1){
		obj.piccase=worktop.find('#piccase').Piccase({
			
		});
	}
	var at='jpg,jpeg,png,gif,ico,webp';
	var uploadobj=worktop.find(".fileuploader").uploadFile({
		allowedTypes: at,
		fileCounterStyle: ". ",
		uploadStr: obj.options.uploadStr+'('+at+')',
		dragDropStr: obj.options.dragDropStr,
		multiDragErrorStr: obj.options.multiDragErrorStr,
		extErrorStr: obj.options.extErrorStr,
		duplicateErrorStr: obj.options.duplicateErrorStr,
		sizeErrorStr: obj.options.sizeErrorStr,
		uploadErrorStr: obj.options.uploadErrorStr,
		maxFileCountErrorStr: obj.options.maxFileCountErrorStr,
		url:"/file-upload",
		showStatusAfterSuccess:false,
		showDelete:true,
		showDownload:false,
		multiple:(obj.options.image_capacity>1),
		dragDrop:true,
		fileName:"up",
		maxFileCount:obj.options.image_capacity,
		maxFileSize:10*1024*1024,
		formData: {owner: 'illu',token: obj.options.token},
		onLoad:function(theobj) {},
		onSuccess: function (files, data, xhr, pd) {//files:local name, data:remote_name
			setTimeout(function(){pd.statusbar.hide();},1500);
			var tag='';if(files.length>0){tag=obj.extractTag(files[0]);}
			obj.added(tag,'/u?n='+data);
			if(obj.options.image_capacity==1){
				uploadobj.selectedFiles=0;
			}
		},
		deleteCallback: function (fname, pd) {
			var filename='illu_'+obj.options.token+'-'+$.md5(fname)+obj.fileExt(fname);//same as server filename rule
			$.post("/file-delete",{name: filename},function (resp,textStatus,jqXHR) { 
				pd.statusbar.hide();
			});
		}
	});
	obj.slider=worktop.find('#img_gallery').ImageSlider({
		images:obj.options.readRecent(),
		onSelect: function(tag,src){obj.added(tag,src);}
	});
	obj.registerWorktopEvent(worktop);
};
PicpaneObject.prototype.hyperlinkSubmit=function(val){
	var ss=$.trim(val);
	if(ss.length>0){
		this.element.find('.hyperlink').select().focus();
		this.added('',ss);
	}
};
PicpaneObject.prototype.setWechatTransfer=function(screen,qrURL){
	var obj=this;
	var thebox=screen;
	if(window["WebSocket"]){
		var wsprotocol="ws://";
		if(document.location.protocol=='https:'){
			wsprotocol="wss://"
		}
		obj.wechatConnection = new WebSocket( wsprotocol+ document.location.host + "/wspt?token="+obj.options.token);
		obj.wechatConnection.onopen = function(evt){
			thebox.empty();
			thebox.append('<img src="'+qrURL+'" height="100%">');
		};
		obj.wechatConnection.onclose = function(evt){
		    thebox.empty().append('<img src="/img/disconnect.png" width="120">');
		};
		obj.wechatConnection.onmessage = function(evt){
			if(evt.data.length>0){/* token:src */
				var ss=evt.data.split(':');
				if(ss.length==2){
					if(ss[0]==obj.options.token){
						obj.added('','/u?n='+ss[1]);
					}
				}
			}
		};
	} else{
		if(thebox.length>0){
			thebox.empty();
			thebox.append('<b>Your browser does not support WebSockets.</b>');
		}
	}
	return conn;
};
PicpaneObject.prototype.bindTabitemClick=function(dialogbox,itm){
	var obj=this;
	itm.on('click',function(){
		var itm_sel=itm.siblings('.i_tab_item_selected');
		itm_sel.removeClass('i_tab_item_selected').addClass('i_tab_item');
		obj.bindTabitemClick(dialogbox,itm_sel);
		$(this).removeClass('i_tab_item').addClass('i_tab_item_selected').off('click');
		var img_gallery=dialogbox.find('#img_gallery');
		var img_link=dialogbox.find('#img_link');
		var img_upload=dialogbox.find('#img_upload');
		var img_transfer={};
		if(obj.options.supportWechat){
			img_transfer=dialogbox.find('#img_transfer');
		}
		switch($(this).attr('id')){
			case 'tab_history':img_gallery.show();img_link.hide();img_upload.hide();if(obj.options.supportWechat){img_transfer.hide();};break;
			case 'tab_link':img_gallery.hide();img_upload.hide();if(obj.options.supportWechat){img_transfer.hide();};
				var hyperlink=img_link.find('.hyperlink');
				hyperlink/*.height(dialogbox.find('#showcase').height()-32)*/.focus();
				img_link.show();hyperlink.focus();
				break;
			case 'tab_upload':img_gallery.hide();img_link.hide();if(obj.options.supportWechat){img_transfer.hide();};
				img_upload.show();break;
			case 'tab_wechat':img_gallery.hide();img_link.hide();img_upload.hide();
				if(obj.options.supportWechat){
					img_transfer.show();
					$.getJSON('/wxti',{n:obj.options.image_capacity},
						function(m){
							if(m.Code=='100'){
								obj.options.token=m.Token;
								obj.setWechatTransfer(img_transfer,m.Picurl);
							}else{alert(m.Msg);}
						}
					);
				}
		}
	});
};
PicpaneObject.prototype.registerWorktopEvent=function(worktop){
	var obj=this;
	worktop.find('span.i_tab_item').each(function(){obj.bindTabitemClick(worktop,$(this));});
	worktop.find('.hyperlink').on('input propertychange',function(e){
		$(this).next().find('.i_enter_button').show();
	});
	worktop.find('.hyperlink').on('keypress',function(event){
		if(event.keyCode == "13"){event.preventDefault();obj.hyperlinkSubmit($(this).val());}
	});
	worktop.find('.i_enter_button').on('click',function(){obj.hyperlinkSubmit(worktop.find('.hyperlink').val());});
};
$.fn.Picpane=function(options){
	var apane=new PicpaneObject(this,options);
	apane.init();
	return apane;
};