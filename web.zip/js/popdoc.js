function PopdocObject(element,options){
	this.element=element;
	this.defaults={
		width:800,
		height:460,
		zindex:20000,
		caption:'',
		scene: '',
		i18n:{},
		closeText:'Close'
	};
	this.po='popdoc_overlay';
	this.pp='popdoc_pane';
	this.options=$.extend({},this.defaults,options);
};
PopdocObject.prototype.close=function(){
	this.element.find('#'+this.pp).remove();
	this.element.find('#'+this.po).remove();
};
PopdocObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
PopdocObject.prototype.init=function(){
	this.i18n_options();
	var header_footer=70;
	var self=this,thebox=this.element,so=self.options;
	var aos='z-index: '+so.zindex+';';
	thebox.append('<div id="'+self.po+'" style="'+aos+'"></div>');
	var ao=thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.5);
	var txt='<div id="'+self.pp+'" style="display: none;width:'+so.width+'px;height:'+so.height+'px;">';
	txt += '<span class="pd_window_icon"><i class="fa fa-window-maximize"></i></span>';
	txt += '<span class="pd_window_icon pd_window_hide"><i class="fa fa-window-restore"></i></span>';
	txt += '<span id="pd_close_icon"><i class="fa fa-close"></i></span>';
	txt += '<div class="pd_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
	txt += '<div id="pd_doc_area" style="height:'+(so.height-header_footer)+'px;"><div class="txttxt"></div></div>';
	txt += '<div class="pd_panebtm">';
	txt += '<div style="text-align:center;width:100%;"><span class="pd_button" id="btn_close"><i class="fa fa-times-circle-o">&nbsp;'+so.closeText+'</i></span></div>';
	txt += '</div></div>';
	thebox.append(txt); pane = thebox.find("#"+self.pp);
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('.pd_window_icon').off("click").on("click",function(event){
		thebox.find('.pd_window_icon').removeClass('pd_window_hide');
		event.stopPropagation();
		$(this).addClass('pd_window_hide');
		var bk = thebox.find('#'+self.po);
		var maxW=bk.outerWidth(),maxH=bk.outerHeight();
		if($(this).find('.fa-window-maximize').length>0){
			pane.css({"margin-left":-(maxW/2)+"px","margin-top":-(maxH/2)+"px","width":maxW+"px","height":maxH+"px"});
			thebox.find('#pd_doc_area').css({"height":(maxH-header_footer)+"px"});
		}else{
			pane.css({"margin-left":-(modal_width/2)+"px","margin-top":-(modal_height/2)+"px","width":modal_width+"px","height":modal_height+"px"});
			thebox.find('#pd_doc_area').css({"height":(modal_height-header_footer)+"px"});
		}
	});
	thebox.find('#btn_close').off("click").on("click",function(event){self.close();});
	thebox.find('#'+self.po).off("click").on("click",function(event){self.close();});
	thebox.find('#pd_close_icon').off("click").on("click",function(event){self.close();});
	$.getJSON('/readdoc',{scene:so.scene},function(m){
		if(m.Code=='100'){
			thebox.find('.txttxt').append($.base64.decode(m.Html_bs64));
		}
	});
};
$.fn.Popdoc=function(options){
	var apopdoc=new PopdocObject(this,options);
	apopdoc.init();
	return apopdoc;
};