function MultidimensionbaseObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		txt_yes: 'Yes',
		txt_no: 'No',
		txt_emptyornot: 'Empty table',
		width: 800,
		height: 200,
  		identifier: 'product',
		roadmapids: '1',
		dim_scene: 'dimension',/*dimension_export*/
		dim_ids: '',/*1,3,7,5*/
		mdt_scene: 'skuprice',/*skuprice_list*/
      	language: '',
		zindex_expand: 20000,
		cell_format: '$##,###.00',
      	drawinstances_url: '/drawinstances',
		readMultidimensiondata:function(){return {};},
		onChange: function(data){}
	};
	this.toolbarheight=32;
	this.isModified=false;
	this.subentity='price';
	this.caption='price';
	this.valueproperty='price';
	this.dimensions=[];
	this.horizontal=[];
	this.vertical=[];
	this.hori_dimes=0;
	this.vert_dimes=0;
	this.celldata={};
	this.cellview={};
	this.updatecell={};
	this.tbl_colModel="";
	this.tbl_dataModel="";
	this.tbl_mergeCells="";
	this.colIDs=[];
	this.rowIDs=[];
	this.new_dim_ids='';
	this.dim_ids=[];/*dimension property id array*/
	this.dim_idx={};/*[id]=0..n*/
	this.value='';
	this.zerovalue='';
	this.bolt=new Object();
	this.PqGrid=new Object();
	this.panecss={};
	this.options=$.extend({},this.defaults,options);
};
/*dimensions format:
[
    {
        "id": "4", 
        "name": "time duration", 
        "padwidth": "2",
        "valueenum": [
            {
                "id": "2", 
                "valuetext": "1 month"
            }, 
            {
                "id": "1", 
                "valuetext": "1 week"
            }, 
            {
                "id": "5", 
                "valuetext": "1 year"
            }
        ]
    }, 
    {
        "id": "5", 
        "name": "membership level",
        "padwidth": "2",
        "valueenum": [
            {
                "id": "8", 
                "valuetext": "free"
            }, 
            {
                "id": "10", 
                "valuetext": "premium"
            }, 
            {
                "id": "9", 
                "valuetext": "standard"
            }
        ]
    }
]
*/
MultidimensionbaseObject.prototype.addHTitle=function(pid,di,cm){
	var nd=di.length;
	var sdi=[];
	if(nd>1){sdi=di.slice(1);}
	var idx=di[0];/*dimension idx list*/
	var dim=this.dimensions[idx];
	for(var i=0,n=dim.valueenum.length;i<n;i++){
		var v=dim.valueenum[i];
		var cid=v.id;
		if(pid.length>0){cid=pid+'-'+cid;}
		if(nd>1){
			var scm=[];
			this.addHTitle(cid,sdi,scm);
			cm.push({title:v.valuetext,align:"center",colModel:scm});
		}else{
			this.colIDs.push(cid);
			cm.push({title:v.valuetext,width:100,align:"center",format:this.options.cell_format});
		}
	}	
};
MultidimensionbaseObject.prototype.addVTitle=function(x,y,pid,pnm,di,dt,mc){//mc{ r1: 10, c1: 7, rc: 400, cc: 4, style: 'background:#eee;' }
	var rows=0;
	var nd=di.length;
	var sdi=[];
	if(nd>1){sdi=di.slice(1);}
	var idx=di[0];/*dimension idx list*/
	var dim=this.dimensions[idx];
	for(var i=0,n=dim.valueenum.length;i<n;i++){
		var rws=1;
		var v=dim.valueenum[i];
		var cid=v.id;
		if(pid.length>0){cid=pid+'-'+cid;}
		if(nd>1){
			var top=y+rows;
			rws=this.addVTitle(x+1,top,cid,v.valuetext,sdi,dt,mc);
			if(rws>1){
				mc.push({r1:top,c1:x,rc:rws,cc:1});
			}
		}else{
			this.rowIDs.push(cid);
			var rw=[];
			for(var j=0;j<x;j++){rw.push('');}
			rw.push(v.valuetext);
			var oo=this.getLatitude(cid);
			if(oo.length>2){
				if(this.vert_dimes==this.dimensions.length){
					var key=this.mergeLongitude(oo,'');
					var val='';
					if(this.cellview.hasOwnProperty(key)){
						val=this.cellview[key];
					}
					rw.push(val);
				}else{
					var m=this.colIDs.length;
					for(var j=this.vert_dimes;j<m;j++){
						var key=this.mergeLongitude(oo,this.colIDs[j]);
						var val='';
						if(this.cellview.hasOwnProperty(key)){
							val=this.cellview[key];
						}
						rw.push(val);
					}
				}
			}
			dt.push(rw);
		}
		if(pid.length>0&&i==0){
			var rw=dt[y+rows];
			rw[x-1]=pnm;
		}
		rows += rws;
	}
	return rows;
};
MultidimensionbaseObject.prototype.makeColModelandData=function(){
	this.colIDs=[];
	this.rowIDs=[];
	var def_colModel=[];
	var horizontal=this.horizontal;
	var vertical=this.vertical;
	var nh=horizontal.length;
	var nv=vertical.length;
	for(var i=0;i<nv;i++){
		var dim=this.dimensions[vertical[i]];
		def_colModel.push({title:dim.name,width:100,align:"center",editable:false});
		this.colIDs.push('');
	}
	if(nh>0){
		this.addHTitle('',horizontal,def_colModel);
	}else{
		def_colModel.push({title:this.caption,width:100,align:"center",format:this.options.cell_format});
		this.colIDs.push('');
	}
	var data=[];
	var def_mergeCells=[];
	if(nv>0){
		this.addVTitle(0,0,'','',vertical,data,def_mergeCells);
	}
	this.tbl_dataModel=JSON.stringify({data:data});
	this.tbl_colModel=JSON.stringify(def_colModel);
	this.tbl_mergeCells=JSON.stringify(def_mergeCells);
};
MultidimensionbaseObject.prototype.setGrid=function(){
	var self=this;
	self.makeColModelandData();
	self.PqGrid.pqGrid("option",{"freezeCols":self.vert_dimes,
			"colModel":JSON.parse(self.tbl_colModel),
			"mergeCells":JSON.parse(self.tbl_mergeCells),
			"dataModel":JSON.parse(self.tbl_dataModel)});
	self.PqGrid.pqGrid("refreshDataAndView");
};
MultidimensionbaseObject.prototype.getLatitude=function(rowpath){
	var o={};
	var rowids=rowpath.split('-');
	var n=this.vertical.length;
	if(n==rowids.length){
		for(var i=0;i<n;i++){
			var v=this.vertical[i];
			o[this.dimensions[v].id]=rowids[i];
		}
	}
	return JSON.stringify(o);
};
MultidimensionbaseObject.prototype.mergeLongitude=function(olatitude,colpath){
	var kvkv=[];
	var o=JSON.parse(olatitude);
	if(colpath.length==0){
		for(let k in o){kvkv.push(k+'-'+o[k]);}
	}else{
		var colids=colpath.split('-');
		var n=this.horizontal.length;
		if(n==colids.length){
			for(var i=0;i<n;i++){
				var h=this.horizontal[i];
				o[this.dimensions[h].id]=colids[i];
			}				
			for(let k in o){kvkv.push(k+'-'+o[k]);}
		}
	}
	return kvkv.sort().join(';');
};
MultidimensionbaseObject.prototype.readRowlist=function(rowList){
	var cols=this.colIDs.length,rows=this.rowIDs.length;
	for(var i=0,n=rowList.length;i<n;i++){
		var row=rowList[i];
		if(row['type']=='update'){
			var rowIndx=parseInt(row['rowIndx']);
			if(rowIndx<rows){
				var oo=this.getLatitude(this.rowIDs[rowIndx]);
				if(oo.length>2){
					var cells=row['newRow'];
					for(var k in cells){
						var key='';
						var kk=parseInt(k);
						if(kk>=this.vert_dimes&&kk<cols){
							if(this.vert_dimes==this.dimensions.length){
								if(kk==cols-1){
									key=this.mergeLongitude(oo,'');
								}
							}else{
								key=this.mergeLongitude(oo,this.colIDs[kk]);
							}
							this.updatecell[key]=cells[k];
						}
					}
				}
			}
		}
	}
};
MultidimensionbaseObject.prototype.emptyAllcells=function(){
	var dt={};
	for(var i=0,n=this.rowIDs.length;i<n;i++){
		var oo=this.getLatitude(this.rowIDs[i]);
		if(oo.length>2){
			if(this.vert_dimes==this.dimensions.length){
				var key=this.mergeLongitude(oo,'');
				dt[key]='';
			}else{
				for(var j=this.vert_dimes,m=this.colIDs.length;j<m;j++){
					var key=this.mergeLongitude(oo,this.colIDs[j]);
					dt[key]='';
				}
			}
		}
	}
	return dt;
};			
MultidimensionbaseObject.prototype.readAllcells=function(){
	var dt={};
	var data=this.PqGrid.pqGrid("option","dataModel.data");
	var data_rows=data.length;
	for(var i=0,n=this.rowIDs.length;i<n;i++){
		if(i<data_rows){
			var oo=this.getLatitude(this.rowIDs[i]);
			if(oo.length>2){
				var row=data[i];
				var row_cells=row.length;
				if(this.vert_dimes==this.dimensions.length){
					var key=this.mergeLongitude(oo,'');
					var value='';
					if(row_cells==(this.vert_dimes+1)){
						value=row[row_cells-1];
					}
					dt[key]=value;
				}else{
					var m=this.colIDs.length;
					for(var j=this.vert_dimes;j<m;j++){
						var key=this.mergeLongitude(oo,this.colIDs[j]);
						var value='';
						if(j<row_cells){	value=row[j];}
						dt[key]=value;
					}
				}
			}
		}
	}
	return dt;
};
MultidimensionbaseObject.prototype.setDimension=function(verts,dimes){//1,5,3,2
    var self=this;
    var thebox=this.element;
	self.horizontal=[];self.vertical=[];
	self.dim_ids=[];self.dim_idx={};
	self.vert_dimes=parseInt(verts);self.hori_dimes=0;
    if(dimes.length>0){
    		$.ajaxSettings.async = false;
	    $.getJSON(this.options.drawinstances_url,{idf:self.options.identifier,scene:self.options.dim_scene,lid:self.options.language,ids:dimes},function(m){
			if(m.Code=='100'){
				self.dimensions=JSON.parse(m.Instances_stringify);
				$.each(self.dimensions,function(i,o){
					self.dim_idx[o.id]=i;
				});
				var nd=self.dimensions.length;
				if(self.vert_dimes==0){
					if(nd>1){self.vert_dimes=nd-1;}else{self.vert_dimes=nd;}
				}
				self.hori_dimes=nd-self.vert_dimes;
				var vv=dimes.split(',');
				$.each(vv,function(ii,id){
					self.dim_ids.push(id);
					if(self.dim_idx.hasOwnProperty(id)){
						var idx=self.dim_idx[id];
						if(ii<self.vert_dimes){
							self.vertical.push(idx);
						}else{
							self.horizontal.push(idx);
						}
					}
				});
			}
		});
		$.ajaxSettings.async = true;
	}
	self.setGrid();
};
MultidimensionbaseObject.prototype.setVerticals=function(verts){
    var self=this;
    self.vertical=[];self.horizontal=[];
	self.vert_dimes=parseInt(verts);
    var n=self.dimensions.length;
	self.hori_dimes=n-self.vert_dimes;
	for(var i=0;i<n;i++){
		var id=self.dim_ids[i];
		if(self.dim_idx.hasOwnProperty(id)){
			var idx=self.dim_idx[id];
			if(i<self.vert_dimes){
				self.vertical.push(idx);
			}else{
				self.horizontal.push(idx);
			}
		}
	}
	self.setGrid();
};

MultidimensionbaseObject.prototype.compressex=function(){
}
MultidimensionbaseObject.prototype.compress=function(){
	var self=this;
	var thebox=this.element;
	thebox.find('#md_ec').removeClass('fa-compress').addClass('fa-expand');
	thebox.find('#pane').css(self.panecss);
	var height=self.options.height-self.toolbarheight;
	thebox.find('#cross_table').css({"height":height+"px"});
	try{
		self.PqGrid.pqGrid("option",{"width":"100%","height":"100%-"+self.toolbarheight});
	}catch(error){}
	self.PqGrid.pqGrid("refresh");
	self.compressex();
};
MultidimensionbaseObject.prototype.expandex=function(){
};
MultidimensionbaseObject.prototype.expand=function(){
	var self=this;
	var thebox=this.element;
	thebox.find('#md_ec').removeClass('fa-expand').addClass('fa-compress');
	self.resizeexpand();
	self.expandex();
};
MultidimensionbaseObject.prototype.resizeexpand=function(){
	var self=this;
    var thebox=this.element;
    var pane=thebox.find('#pane');
    var height=$(window).height();
    self.panecss['position']=pane.css('position');
    self.panecss['z-index']=pane.css('z-index');
    self.panecss['left']=pane.css('left');
    self.panecss['top']=pane.css('top');
    self.panecss['width']=pane.css('width');
    self.panecss['height']=pane.css('height');
    height-=self.toolbarheight;
	pane.css({"position":"fixed","z-index":self.options.zindex_expand,"left":"0","top":"0","width":$(window).width()+"px","height":height+"px"});
	try{
		self.PqGrid.pqGrid("option",{"width":"100%","height":"100%"});
	}catch(error){}
	self.PqGrid.pqGrid("refresh");
};
MultidimensionbaseObject.prototype.windowResize=function(){
	var self=this;
    var thebox=this.element;
	var ec=thebox.find('#md_ec');
	if(ec.hasClass('fa_compress')){
		self.resizeexpand();
	}
};
MultidimensionbaseObject.prototype.modified=function(){
	this.savedata();
	//this.isModified=true;
	//this.element.find('#tablesave').removeClass('unmodified').addClass('modified');
};

MultidimensionbaseObject.prototype.getNames=function(properties){
	var self=this;
	var names=[];
	var kvkv = properties.split(';');
	kvkv.forEach(function(item){
		var k_v=item.split('-');
		if(k_v.length==2){
			var did=k_v[0],vid=k_v[1];
			var dim=self.dimensions[self.dim_idx[did]];
			for(var i=0,n=dim.valueenum.length;i<n;i++){
				var v=dim.valueenum[i];
				if(v.id==vid){
					names.push(dim.name+':'+v.valuetext);
					break;
				}
			}
		}
	});
	return names.join(' ');
};

MultidimensionbaseObject.prototype.savedata=function(){//"_m_": "DEL/UPD/INS"
	var dt=[];
	for(var k in this.updatecell){
		var v=this.updatecell[k],vv='';
		switch(typeof(v)) {
			case 'string': vv=v; break;
			case 'number': vv=v.toString(); break;
			case 'undefined': vv=''; break;
			case 'object': vv=JSON.stringify(v); break;
		}
		var o={'properties':k};
		if(vv.length>0){
			o['propertynames']=this.getNames(k);
			o[this.valueproperty]=vv;
			if(this.celldata.hasOwnProperty(k)){
				if(this.celldata[k]!=vv){dt.push(o);}
			}else{dt.push(o);}
		}else{
			if(this.celldata.hasOwnProperty(k)){
				o['_m_']='DEL';dt.push(o);
			}
		}
	}
	this.new_dim_ids=this.dim_ids.join(',');
	if(this.new_dim_ids!=this.options.dim_ids){//release old dimension data
		for(var k in this.celldata){
			dt.push({'properties':k,'_m_':'DEL'}); 
		}
	}
	var nm=this.subentity+'dimension';
	var savedata={};
	savedata[nm]=this.new_dim_ids;
	savedata[this.subentity]=dt;
	this.options.onChange(JSON.stringify(savedata));
};
MultidimensionbaseObject.prototype.setupWidget=function(){
	/*var self=this;
	var thebox=this.element;
	thebox.empty();
	var tb_height=self.toolbarheight-1;
	var txt='<div id="pane">';
	txt+='<div id="a_toolbar" style="width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;background-color:#f9f9f9;">';
	txt+='<div style="float:left;">'+self.options.txt_subject+':&nbsp;&nbsp;</div>';
	txt+='<div id="bolt" style="width:500px;float:left;"></div>';
	txt+='<div style="width:100px;float:left;text-align:center">';
	txt+='<i id="tableempty" class="fa fa-lg fa-trash-o"></i>';
	txt+='</div>';
	txt+='<div id="ecbtn" style="float:right;width:24px;text-align:center">';
	txt+='<i id="md_ec" class="fa fa-expand" style="height:'+tb_height+'px;line-height:'+tb_height+'px;"></i>';
	txt+='</div>';
	txt+='</div>';
	var height=self.options.height-self.toolbarheight;
	txt+='<div id="cross_table" style="width:100%;height:'+height+'px;"></div>';
	txt+='</div>';
	thebox.append(txt);*/
};
MultidimensionbaseObject.prototype.initex=function(){
};
MultidimensionbaseObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
MultidimensionbaseObject.prototype.init=function(){
	this.i18n_options();
	var self=this;
	var thebox=this.element;
	if(self.options.mdt_scene.length>0){
		var dt=self.options.readMultidimensiondata(self.options.identifier,self.options.mdt_scene);
		/*{"subentity": "price",	"valueproperty": "price","cell": {"5-1;6-10;7-13;9-11":"123"}}*/
		if(JSON.stringify(dt).length>2){
			self.subentity=dt['subentity'];
			self.caption=dt['caption'];
			self.valueproperty=dt['valueproperty'];
			self.celldata={};
			self.cellview={};
			for(var k in dt.cell){
				self.celldata[k]=dt.cell[k];
				self.cellview[k]=dt.cell[k];
			}
			if(self.options.dim_ids.length==0 && dt.hasOwnProperty('cell')){
				if(dt.cell.hasOwnProperty('')){
					self.zerovalue=dt.cell[''];
				}
			}
		}
	}
	self.setupWidget();
	//thebox.find('#pane').on("mousewheel",function(e){return false;});
	self.PqGrid = thebox.find('#cross_table').pqGrid({
		width: '100%',
		height: '200',
		showTop: true,
		showTitle: false,
		showBottom: false,
		collapsible: false,
		dragColumns: { enabled: false },
		showHeader: true,
		roundCorners: false,
		rowBorders: true,
		columnBorders: true,                                    
		selectionModel: { type: 'cell' },
		numberCell: { show: false },
		stripeRows: false,
		colModel: {},
		dataModel: {},
		mergeCells: {},
		freezeCols: 0
	});
	self.PqGrid.pqGrid({	change: function( event, ui ){
		self.readRowlist(ui['rowList']);
		self.modified();
	}});
	self.bolt=thebox.find('#bolt').Bolt({
		identifier: self.options.identifier,
		roadmapids: self.options.roadmapids,
		onChangeVerticals: function(verts){
			var dt=self.readAllcells();
			self.cellview={}; for(var k in dt){self.cellview[k]=dt[k];}
			self.setVerticals(verts);		
		},
		onChange: function(verts,dim_ids){
			var dt=self.readAllcells();
			self.cellview={};self.updatecell={};
			for(var k in dt){self.cellview[k]=dt[k];self.updatecell[k]=dt[k];}
			self.setDimension(verts,dim_ids);
			self.modified();
	}}).setValue(self.options.dim_ids);//add before setDimension	
	self.setDimension(0,self.options.dim_ids);
	thebox.find('#tableempty').on('click',function(){
		$('body').YesnoAlert({
			yesText:self.options.txt_yes,noText:self.options.txt_no,
			doyes: function(id,action){
				var data=[];
				var dt=self.PqGrid.pqGrid("option","dataModel.data");
				for(var i=0,n=dt.length;i<n;i++){
					var rw=dt[i],row=[];
					var m=self.vertical.length;
					if(rw.length<m){m=rw.length;}
					for(var j=0;j<m;j++){row.push(rw[j]);}
					data.push(row);
				}
				self.PqGrid.pqGrid("option",{"dataModel":{"data":data}});
				self.PqGrid.pqGrid("refreshDataAndView");
				var dt=self.emptyAllcells();
				self.cellview={};self.updatecell={};
				for(var k in dt){self.cellview[k]=dt[k];self.updatecell[k]=dt[k];}
				self.modified();
			}
		}).show_alertpane('',self.options.txt_emptyornot+'?','empty');		
	});		
	thebox.find('#md_ec').off("click").on("click",function(event){
		event.stopPropagation();
		if($(this).hasClass('fa-expand')){self.expand();}else{self.compress();}
	});
	$(window).resize(function(){self.windowResize();});
	self.initex();
};
$.fn.Multidimensionbase=function(options){
	var mdb=new MultidimensionbaseObject(this,options);
	mdb.init();
	return mdb;
};