/*Dependence:<link rel="stylesheet" href="/css/jquery.datetimepicker.css">
<script type="text/javascript" src="/js/jquery.datetimepicker.full.min.js"></script>*/
	Date.prototype.Format = function(fmt) {
		var o = {
			"M+": this.getMonth() + 1,
			"d+": this.getDate(),
			"H+": this.getHours(),
			"m+": this.getMinutes(),
			"s+": this.getSeconds(),
			"q+": Math.floor((this.getMonth() + 3) / 3),
			"S": this.getMilliseconds()
		};
		if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
		for (var k in o)
			if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		return fmt;
	}
	/*usage: 
	var time1 = new Date().Format("yyyy-MM-dd");
	var time2 = new Date().Format("yyyy-MM-dd HH:mm:ss");
	*/

	function DateInputObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			width:440,
			height:136,
			zindex:1000,
			minLimit:'',//2024-01-01
			maxLimit:'',//2024-03-08
			language_code:'en',
			txt_ok:'OK',
			txt_cancel:'Cancel',
			txt_hint:'Please select a date:',
			txt_notlessthan:'Not less than',
			txt_notgreaterthan:'Not greater than',
			doOK: function(text,extra){return true;}
		};
		this.yn='dateinput_overlay';
		this.options=$.extend({},this.defaults,options);
    };
    DateInputObject.prototype.isValid=function(dt){
    	var flag=true;
		var dateInput = new Date(dt);
    	var self=this,so=this.options;
		if(so.minLimit.length==10){
			var dateLimit = new Date(so.minLimit);
			if(dateInput<dateLimit){
				alert(so.txt_notlessthan+':'+so.minLimit);
				flag=false;
			}
		}
		if(so.maxLimit.length==10){
			var dateLimit = new Date(so.maxLimit);
			if(dateInput>dateLimit){
				alert(so.txt_notgreaterthan+':'+so.maxLimit);
				flag=false;
			}
		}
		return flag;
	};
	DateInputObject.prototype.close_inputpane=function(){
		this.element.find('.'+this.yn).remove();
		this.element.find('.dateinput_pane').remove();
	};
	DateInputObject.prototype.pressenter=function(){
		var self=this;
		var thebox=this.element;
		var dt = thebox.find('#dtp').val();
		if(self.isValid(dt)){
			if(self.options.doOK(dt,thebox.find('#extra').val())){
				self.close_inputpane();
			}else{ self.focusinput();}
		}else{ self.focusinput();}
	};
	DateInputObject.prototype.focusinput=function(){
		var thebox=this.element;
		jQuery.datetimepicker.setLocale(this.options.language_code);
		var dt = new Date().Format("yyyy-MM-dd");
		thebox.find('#dtp').val(dt).datetimepicker({timepicker:false,format:'Y-m-d'});
	};
	DateInputObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){
				o[k]=o.i18n[k];
			}
		}
	};
	DateInputObject.prototype.showinput=function( initdate,extra ){
		this.i18n_options();
		var self=this;
		var thebox=this.element;
		thebox.append('<div class="'+self.yn+'" style="z-index: '+self.options.zindex+';"></div>');
		thebox.find('.'+self.yn).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div class="dateinput_pane" style="width:'+self.options.width+'px;height:'+self.options.height+'px;">';
		txt += '<div><span class="close_icon"></span></div>';
		txt += '<input type="hidden" id="extra" value="'+extra+'">';
		txt += '<div style="float:left;width:100%;font-size:24px;"><span style="padding-left:5px;">'+self.options.txt_hint+'</span></div>';
		txt += '<div style="float:left;width:100%;height: 10px"></div>';
		txt += '<div style="float:left;width:100%;text-align:center"><input id="dtp" style="font-size:200%;width:200px;" type="text" value="'+initdate+'"></div>';
		txt += '<div style="float:left;width:100%;height: 16px"></div>';
		txt += '<div style="float:left;width:40%;"><input style="float: right;" class="editor_button" id="btn_ok" value="'+self.options.txt_ok+'"></div>';
		txt += '<div style="float:right;width:40%;"><input style="float: left;" class="editor_button" id="btn_cancel" value="'+self.options.txt_cancel+'"></div>';
		txt += '</div>';
		thebox.append(txt); pane = thebox.find('.dateinput_pane');
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":30+"%"});
		pane.fadeTo(200,1);
		self.focusinput();
		thebox.find('#btn_ok').off("click").on("click",function(event){event.stopPropagation();	self.pressenter();});
		thebox.find('#btn_cancel').off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
		thebox.find('.'+self.yn).off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
		thebox.find('.close_icon').off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
	};
    $.fn.DateInputDialog=function(options){
		var adialog=new DateInputObject(this,options);
		return adialog;
    };