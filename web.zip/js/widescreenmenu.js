	function WidescreenMenuObject(element,options){
		this.element=element;
		this.defaults={
			readitems_url:'/drawnaviitems',
			codeset:'',
			language:2,
			rootvalue:'0',
			item_option:[]
		};
		this.options=$.extend({},this.defaults,options);
		this.pos=new Object();/*the item_option pos(array index) vs value*/
		this.childlist=new Object();
		this.timers={};
    };
	WidescreenMenuObject.prototype.extendHierarchyOption=function(){/*calculate option's isleaf,depth*/
		var myparent = new Object();
		var nchildren = new Object();
		var rv=this.options.rootvalue;
		nchildren[rv] = 0;
		this.childlist[rv]=new Array();
		var n=this.options.item_option.length;
		var txt='';
		for(var i=0;i<n;i++){
			var v=this.options.item_option[i].value;
			this.pos[v]=i;
			nchildren[v]=0;
			myparent[v]=this.options.item_option[i].parent;
			this.childlist[v]=new Array();
		}
		txt='';
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			var depth=1;
			var parent=o.parent;
			if(this.childlist.hasOwnProperty(parent)){
				this.childlist[parent].push(o.value);
			}
			nchildren[parent]+=1;
			while(parent!=rv&&myparent.hasOwnProperty(parent)){//parent not only digital
				depth++;
				parent=myparent[parent];
			}
			o.depth=depth;
			txt += o.label+'-'+o.depth+'\n';
			this.options.item_option[i]=o;
		}
		//alert(txt);
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			o.isleaf=(nchildren[o.value]==0);
			this.options.item_option[i]=o;
		}
	};
	WidescreenMenuObject.prototype.loadItem=function(box,val) {//recursive function
		if(this.childlist.hasOwnProperty(val)){
			var children = this.childlist[val];
			var n=children.length;
			for(var i=0;i<n;i++){
				var idx=this.pos[children[i]];
				var itm=this.options.item_option[idx];
				var txt=''; var ahref='#';
				switch(itm.depth){
				case 1:
					txt='<div id="m'+itm.value+'" class="navi-down-menu menu-'+itm.depth+'" style="display: none;" top_level="m'+itm.value+'">';
					txt+='<div class="navi-down-inner"><div style="display:inline-block;" id="i'+itm.value+'"></div></div></div>';
					box.append(txt);
					this.loadItem(box.find('#i'+itm.value),itm.value);
					break;
				case 2:
					if(itm.isleaf){
						if(itm.hasOwnProperty('url')){ahref=itm.url;}
						txt='<dl id="m'+itm.value+'"><dd> <a class="link" href="'+ahref+'">'+itm.label+'</a> </dd></dl>';
					}else{txt='<dl id="m'+itm.value+'"><dt>'+itm.label+'</dt></dl>';}
					box.append(txt);
					if(!itm.isleaf){this.loadItem(box.find('dl#m'+itm.value),itm.value);}
					break;
				case 3:
					if(itm.hasOwnProperty('url')){ahref=itm.url;}
					txt='<dd class="menu-'+itm.depth+'"> <a href="'+ahref+'">'+itm.label+'</a> </dd>';
					box.append(txt);
					break;
				}
			}
		}
	};
	WidescreenMenuObject.prototype.load=function() {
		var self=this.element;
		var txt='';
		if(this.childlist.hasOwnProperty(0)){
			var children = this.childlist[0];
			var n=children.length;
			for(var i=0;i<n;i++){
				var idx=this.pos[children[i]];
				var itm=this.options.item_option[idx];
				txt += '<li ';
				if(i==0){txt += 'class="navi-up-selected-inpage" ';}
				txt += 'top_level="m'+itm.value+'">';
				var ahref='#';if(itm.url.length>0){ahref=itm.url;}
				txt += '<h2> <a href="'+ahref+'">'+itm.label+'</a> </h2>';
				txt += '</li>';
			}
			txt='<div class="navi-up"><div class="navi-inner"><div class="navi-top"><div style="display:inline-block;"><ul>'+txt+'</ul></div></div></div></div>';
			txt+='<div class="navi-down"></div>';
			self.append(txt);
			this.loadItem(self.find('.navi-down'),0);
		}
	};
	WidescreenMenuObject.prototype.resetWidget=function(){
		var obj=this;
		var self=this.element;
		self.empty();
		obj.load();
		self.find('[top_level]').hover(function(){
			var TL = $(this).attr('top_level');
			clearTimeout( obj.timers[ TL + '_timer' ] );
			obj.timers[ TL + '_timer' ] = setTimeout(function(){
				self.find('[top_level]').each(function(){
					$(this)[ TL == $(this).attr('top_level') ? 'addClass':'removeClass' ]('navi-up-selected');
				});
				self.find('#'+TL).stop(true,true).slideDown(200);
			}, 150);
		},function(){
			var TL = $(this).attr('top_level');
			clearTimeout( obj.timers[ TL + '_timer' ] );
			obj.timers[ TL + '_timer' ] = setTimeout(function(){
				self.find('[top_level]').removeClass('navi-up-selected');
				self.find('#'+TL).stop(true,true).slideUp(200);
			}, 150);
		});
	};
	WidescreenMenuObject.prototype.setClassCSS=function(classname,cssvalue){//sample:setClassCSS('aclass','font-size:24px;color: green;');
		var id='wsm-'+classname;
		var cssContainer = $('#'+id);
	    if(cssContainer.length == 0){
	        cssContainer = $('<style id="'+id+'"></style>');
	        cssContainer.appendTo($('head'));
	    }
		cssContainer.empty().append('.'+classname+ ' {'+cssvalue+'}');
	};
    WidescreenMenuObject.prototype.init=function(){
		var self=this;
		if(self.options.codeset.length>0){
			$.ajaxSettings.async = false;
			$.getJSON(self.options.readitems_url,{cst:self.options.codeset,depth:3,lid:self.options.language},function(m){
				if(m.Code=="100"){
					$(m.Items).each(function(){
						var o = new Object();
						o['value']=this.ID;
						o['parent'] = this.PID;
						o['label'] = this.Name;
						o['url'] = this.Accesspath;
						self.options.item_option.push(o);
					});
				}else{alert(m.Code+' '+m.Msg);}
			});	
			$.ajaxSettings.async = true;
		}
		self.extendHierarchyOption();
		self.resetWidget();
		var top=self.element.offset().top+42;
		self.setClassCSS('navi-down','position:absolute;top:'+top+'px;left:0px;width:100%;z-index:10000');
    };
    $.fn.WidescreenMenu=function(options){
		var amenu=new WidescreenMenuObject(this,options);
		amenu.init();
		return amenu;
    };
/*
if( $ ){
	$(document).ready(
		function(){
			$('#wsm').WidescreenMenu({
				item_option:[
					{value:1,parent:0,label:"云产品",url:""},
					{value:2,parent:0,label:"深数据",url:"http://www.deepdata.cn"},
					{value:3,parent:0,label:"解决方案",url:""},
					{value:4,parent:0,label:"合作伙伴",url:""},
					{value:5,parent:0,label:"帮助支持",url:""},
					{value:6,parent:1,label:"主机与网络"},
					{value:7,parent:6,label:"云服务器"},
					{value:8,parent:6,label:"弹性Web引擎"},
					{value:9,parent:6,label:"负载均衡"},
					{value:10,parent:1,label:"存储与CDN"},
					{value:11,parent:10,label:"云数据库"},
					{value:12,parent:10,label:"NoSQL高速存储"},
					{value:13,parent:10,label:"对象存储服务"},
					{value:14,parent:10,label:"CDN"},
					{value:15,parent:1,label:"监控与安全"},
					{value:16,parent:15,label:"云监控"},
					{value:17,parent:15,label:"云安全"},
					{value:18,parent:15,label:"云拨测"},
					{value:19,parent:1,label:"数据分析"},
					{value:20,parent:19,label:"云分析"},
					{value:21,parent:19,label:"关键因子"},
					{value:22,parent:1,label:"开发者工具"},
					{value:23,parent:22,label:"移动加速"},
					{value:24,parent:22,label:"应用加固"},
					{value:25,parent:22,label:"信息推送"},
					{value:26,parent:1,label:"开发者服务"},
					{value:27,parent:26,label:"安全认证服务"},
					{value:28,parent:26,label:"域名备案"},
					{value:29,parent:2,label:"极深数据"},
					{value:30,parent:2,label:"DEEPEST"},
					{value:31,parent:2,label:"移动应用"},
					{value:32,parent:3,label:"资料库"},
					{value:33,parent:3,label:"论坛"},
					{value:34,parent:3,label:"扶持"},
					{value:35,parent:4,label:"代理商"},
					{value:36,parent:4,label:"服务商"},
					{value:37,parent:4,label:"孵化器"}
		        	]		
			});
		}
	);
}*/