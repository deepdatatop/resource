	function HierarchyObject(element,options){
		this.element=element;
		this.defaults={
			row_height:20,
			language:2,
			eid:0,/*entity_id*/
			codeset:'',
			show_code:false,
			dynamic_loading:true,
			self_hierarchy:false,
			expandall:false,
			focus_first:false,
			readall_url:'/readinferiors',
			readcodes_url:'/readcodes',
			paththrough_url:'/paththrough',
			onChange:function(id,val){},
			root_id:'0',
			item_option:[]
		};
		this.options=$.extend({},this.defaults,options);
		this.hierarchy=false;
		this.rootitem=new Object();
		this.rootchildbox=new Object();
		this.sequence=new Array();/*item sequence by tree order*/
		this.pos=new Object();/*the item_option pos(array index) vs value*/
		this.childlist=new Object();
		this.nleaves=0;
		this.maxdepth=0;
		this.noitemcaution=true;
    };
	HierarchyObject.prototype.setlanguage=function(lang){
		this.options.language = lang;
	};
    HierarchyObject.prototype.init=function(){
		this.hierarchy=this.options.self_hierarchy;
		this.resetWidget();
		this.ex_init();
    };
    HierarchyObject.prototype.refresh=function(){
    		this.resetWidget();
    	};
    HierarchyObject.prototype.setCodeset=function(cst,loading){/*0:dynamic,1:all*/
    		if(cst.length>0){
			this.options.codeset=cst;
			this.options.self_hierarchy=false;
			this.options.dynamic_loading=(loading==0);
			this.options.expandall=(loading==1);
			this.options.focus_first=false;
			this.resetWidget();			
		}
    };
	HierarchyObject.prototype.ex_init=function(){/*virtual function*/};
	HierarchyObject.prototype.rowsChange=function(){/*virtual function*/};
	HierarchyObject.prototype.extendHierarchyOption=function(){/*calculate option's isleaf,depth,pys: parent_younger_sibling*/
		var myparent = new Object();
		var nchildren = new Object();
		nchildren[0] = 0;
		this.childlist[0]=new Array();
		var n=this.options.item_option.length;
		for(var i=0;i<n;i++){
			var v=this.options.item_option[i].value;
			this.pos[v]=i;
			nchildren[v]=0;
			myparent[v]=this.options.item_option[i].parent;
			this.childlist[v]=new Array();/*use for calc parents_younger_sibling*/
		}
		this.maxdepth=0;
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			var depth=1;
			var parent=o.parent;
			if(this.childlist.hasOwnProperty(parent)){
				this.childlist[parent].push(o.value);
			}
			nchildren[parent]+=1;
			while(parent!=this.options.root_id&&myparent.hasOwnProperty(parent)){
				depth++;
				parent=myparent[parent];
			}
			o.depth=depth;
			this.options.item_option[i]=o;
			if(depth>this.maxdepth){this.maxdepth=depth;}
		}
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			o.isleaf=(nchildren[o.value]==0);
			o.nsiblings=nchildren[o.parent];//n siblings under the same parent - for itemflag
			o.isibling=0;
			var siblings=this.childlist[o.parent];
			for(var j=0;j<o.nsiblings;j++){
				if(siblings[j]==o.value){
					o.isibling=j;
					break;
				}
			}//the pos in siblings. - for itemflag
			var parent_younger_siblings=new Array();
			var parent=o.parent;
			while(parent!=this.options.root_id&&myparent.hasOwnProperty(parent)){
				pparent=myparent[parent];//high level parent
				if(this.childlist.hasOwnProperty(pparent)){
					var cl=this.childlist[pparent];
					parent_younger_siblings.unshift((cl[cl.length-1]==parent)?0:1);//parent at end of the list?
				}
				parent=pparent;
			}
			parent_younger_siblings.unshift(0);
			o.pys=parent_younger_siblings.join(',');
			this.options.item_option[i]=o;
		}
		this.sequence=[];
		this.nleaves=this.recursiveData(this.options.root_id);
	};
	HierarchyObject.prototype.recursiveData=function(val) {//recursive function
		var nn=0;
		if(this.childlist.hasOwnProperty(val)){
			var children = this.childlist[val];//[11,22,33,44]
			var n=children.length;
			for(var i=0;i<n;i++){
				var v=children[i];
				this.sequence.push(v);
				var m=this.recursiveData(v);
				nn+=m;
				var pos=this.pos[v];
				var o=this.options.item_option[pos];
				o['nleaves']=m;
				this.options.item_option[pos]=o;
			}
			if(n==0){nn=1;}
		}
		return nn;
	};
	HierarchyObject.prototype.collapseall=function() {
		var self=this;
		self.rootchildbox.find('div.children').hide();
		var allexpand=self.rootchildbox.find('div.expand');
		allexpand.each(function(){
			var hook=$(this);
			self.changeclass(hook,'expand','collapse');
			self.registerCollapseEvent(hook);
		});
	};
	HierarchyObject.prototype.expandall=function() {
		var self=this;
		self.rootchildbox.find('div.children').show();
		var allcollapse=self.rootchildbox.find('div.collapse');
		allcollapse.each(function(){
			var hook=$(this);
			self.changeclass(hook,'collapse','expand');
			self.registerExpandEvent(hook);
		});
	};
	HierarchyObject.prototype.resetWidget=function() {
		this.resetBox(this.element);
	};
	HierarchyObject.prototype.selectflag=function(id) {
		return '';
	};
	HierarchyObject.prototype.createroot=function(thebox) {
		var ss='<div class="item" id="'+this.options.root_id+'" code="" depth="0" style="height:0px"></div>';
		ss+='<div class="children" id="cld'+this.options.root_id+'">';
		thebox.append(ss);
		this.rootitem=thebox.find('#'+this.options.root_id);
		this.rootchildbox=thebox.find('#cld'+this.options.root_id);
	}
	
    HierarchyObject.prototype.resetBox=function(thebox) {
    		var so=this.options;
    		thebox.empty();
		thebox.bind('mousewheel DOMMouseScroll', function(e) {
		    var scrollTo = null;
		    if (e.type == 'mousewheel') {
		        scrollTo = (e.originalEvent.wheelDelta * -1); 
		    }else if (e.type == 'DOMMouseScroll') {
		        scrollTo = 40 * e.originalEvent.detail;
		    }
		    if (scrollTo) {
		        e.preventDefault();
		        $(this).scrollTop(scrollTo + $(this).scrollTop());
		    }
		});
		this.createroot(thebox);
		var n = so.item_option.length;
		if(n==0){
			if(so.codeset.length>0||this.options.eid>0){
				$.ajaxSettings.async = false;
				if(so.dynamic_loading){
					n=this.makechildblock(this.rootitem);//only first level
				}else{
					n=this.loadwholebranch(this.rootitem);//all data
				}
				$.ajaxSettings.async = true;
				if(n==0){this.noitem();}
			}else{
				
				if(this.noitemcaution){alert('no [codeset/eid] option!');}
			}
		}else{
			if(this.hierarchy){
				this.extendHierarchyOption();
				this.loadHierarchyOption();
			}else{
				for(var i=0;i<n;i++){
					var code='';
					var id=so.item_option[i].value;
					if(so.item_option[i].hasOwnProperty('code')){
						code=so.item_option[i].code;
					}
					var caption=so.item_option[i].label;
					if(so.show_code&&code.length>0){
						caption=code+'.'+caption;
					}
					var tt='<div class="item" id="'+id+'" code="'+code+'"><span class="blank"></span><span class="itemcaption">'+caption+'</span>';
					tt+=this.selectflag(id);
					tt+='</div>';
					thebox.append(tt);
				}
				this.registerItemcaptionEvent(thebox);
			}
		}
		if(this.hierarchy&&this.options.expandall){this.expandall();}
		
		if(so.focus_first&&n>0){
			var v=this.rootchildbox.children().first();
			this.focus(v.attr('id'));
		}
		return n;
	};
	HierarchyObject.prototype.noitem=function(){/*virtual function*/};
	HierarchyObject.prototype.beforeFocus=function(){return true;};
	HierarchyObject.prototype.clickitemcaption=function(ic){
		var itm=ic.parent();
		this.focusItem(itm);
	};
	HierarchyObject.prototype.focus=function(id){
		if(this.beforeFocus()){
			var itm=this.element.find('#'+id);
			if(itm.length>0){this.focusItem(itm);}
		}
	};
	HierarchyObject.prototype.focusSilent=function(id){
		if(this.beforeFocus()){
			var itm=this.element.find('#'+id);
			if(itm.length>0){this.focusOn(itm);}
		}
	};
	HierarchyObject.prototype.afterFocusRemoved=function(){
	};
	HierarchyObject.prototype.addFocusExtension=function(itm){
	};
	HierarchyObject.prototype.focusOn=function(itm){
		var checked=itm.find('div.item_focus');
		if(checked.length==0){
			this.element.find("div.item_focus").remove();
			this.afterFocusRemoved();
			if(itm.find('div.item_selected').length==0){
				if(this.hierarchy){
					itm.find('span.indent').children().first().append('<div class="item_focus"></div>');
				}else{
					itm.find('span.blank').append('<div class="item_focus"></div>');
				}
				this.addFocusExtension(itm);
			}
		}
	};
	HierarchyObject.prototype.focusItem=function(itm){
		this.focusOn(itm);
		this.options.onChange(itm.attr('id'),itm.find('span.itemcaption').text());
	};
	HierarchyObject.prototype.registerItemcaptionEvent=function(block){
		var self=this;
		block.find('span.itemcaption').off('click').on('click',function(event){
			event.stopPropagation();
			self.clickitemcaption($(this));
		});
	};
	HierarchyObject.prototype.registerFlagEvent=function(itm){/*virtual function*/};
	HierarchyObject.prototype.registerChildrenCollapseEvent=function(block){
		var self = this;
		block.find('div.collapse').off("click").on("click",function(event){
			event.stopPropagation();
			self.hookexpand($(this));
			self.rowsChange();
		});
	};
	HierarchyObject.prototype.registerCollapseEvent=function(itm){
		var self = this;
		itm.off("click").on("click",function(event){
			event.stopPropagation();
			self.hookexpand($(this));
			self.rowsChange();
		});
	};
	HierarchyObject.prototype.registerExpandEvent=function(itm){
		var self = this;
		itm.off("click").on("click",function(event){
			event.stopPropagation();
			self.changeclass($(this),'expand','collapse');
			self.registerCollapseEvent($(this));
			$(this).parent().next().hide();
			self.rowsChange();
		});
	};
	HierarchyObject.prototype.itemflag=function(id,depth,i,n,isleaf){return '';/*virtual function*/};
	HierarchyObject.prototype.setDowngradeFlag=function(itm){/*virtual function*/};
	HierarchyObject.prototype.loadwholebranch=function(itm){
		var nn=-1;
		var self=this,thebox=this.element,so=this.options;
		var o={iid:itm.attr('id'),lid:so.language}
		if(so.eid>0){o['eid']=so.eid;}else{o['cst']=so.codeset;}
		$.getJSON(this.options.readall_url,o,function(m){
			if(m.Code=="100"){
				nn=m.Nchildren;
				self.hierarchy=m.Self_hierarchy;
				if(m.Self_hierarchy){
					self.loadChildren(m,self.superiorEldersibling(itm.attr('id')));
				}else{
					var itmparent = itm.parent();
					if(nn>0){
						$(m.Children).each(function(){
							var caption=this.Name;
							var code='';
							if(this.hasOwnProperty('Code')){code=this.Code;}
							//if(code.length>0){caption+=' ['+code+']';}
							if(so.show_code&&code.length>0){caption=code+'.'+caption;}
							var tt='<div class="item" id="'+this.Id+'" code="'+code+'">';
							tt+='<span class="blank"></span><span class="itemcaption">'+caption+'</span>';
							tt+=self.selectflag(this.Id);
							tt+='</div>';
							itmparent.append(tt);
						});
					}
					self.registerItemcaptionEvent(thebox);
				}
			}else{alert(m.Code+' '+m.Msg+'@'+self.options.readall_url);}
		});
		return nn;
	};
	HierarchyObject.prototype.trimFocusText=function(txt){
		var newtxt=txt;
		if(newtxt.indexOf('item_focus')>0){
			newtxt=newtxt.replace(/<div class="item_focus"><\/div>/,'');
		}
		if(newtxt.indexOf('item_selected')>0){
			newtxt=newtxt.replace(/<div class="item_selected"><\/div>/,'');
		}
		return newtxt;
	};
	HierarchyObject.prototype.makechildblock=function(itm){
		var nn=-1;//readcodes_url error
		var self=this,so=this.options;
		//cst: codeset-identifier pid: the children's parent_id
		var o={pid:itm.attr('id'),lid:so.language};
		if(so.eid>0){o['eid']=so.eid;}else{o['cst']=so.codeset;}
		$.getJSON(so.readcodes_url,o,function(m){
			if(m.Code=="100"){
				nn=m.Nchildren;
				self.hierarchy=m.Self_hierarchy;
				if(m.Self_hierarchy){
					var ty='no';var indent='';
					if(itm.length>0){
						var idt = itm.children('span.indent');
						if( idt.length>0 ){indent = self.trimFocusText(idt.html());}
						var nxt = itm.next('.item');
						ty=(nxt.length>0)?'v':'no';
					}
					if( nn>0 ){
						var tt = '<div class="children" id="cld'+itm.attr('id')+'">';
						var i = 0; var n = m.Children.length;
						var depth = parseInt(itm.attr('depth'))+1;
						var mapSelect={},ns=0;
						$(m.Children).each(function(){//this.Id,this.Code,this.Name,this.Isleaf
							var code='';
							if(this.hasOwnProperty('Code')){code=this.Code;}
							var sf=self.selectflag(this.Id);
							if(sf.length>0){	mapSelect[this.Id]=sf;ns++;}
							tt += '<div class="item" id="'+this.Id+'" code="'+code+'" depth="'+depth+'">';
							tt += '<span class="indent">'+indent+'<div depth="'+depth+'" class="'+ty+'line"></div></span>';
							var linetype = (i==n-1)?'tr':'vr';
							var iclass = (this.Isleaf==1)?'leaf':'collapse';
							tt += '<div class="hook '+iclass+' '+linetype+iclass+'"></div>';
							tt += self.itemflag(this.Id,depth,i,n,this.Isleaf);
							var caption=this.Name;
							if(so.show_code&&code.length>0){caption=code+'.'+caption;}
							tt += '<span class="itemcaption'+self.colorClass(this.Id,depth)+'">'+caption+'</span>';
							tt += '</div>';
							i ++;
						});
						tt += '</div>';
						itm.after(tt);
						var nitm=itm.next();
						for(var id in mapSelect){
							var sitm=nitm.find('#'+id);
							if(sitm.length>0){
								sitm.find('span.indent').children().first().append(mapSelect[id]);
							}
						}
						self.setDowngradeFlag(nitm);//virtual
						self.registerFlagEvent(nitm);
						self.registerItemcaptionEvent(nitm);
						self.registerChildrenCollapseEvent(nitm);
					}
					//self.rowsChange();//add for sync mode 
				}else{
					var thebox = itm.parent();
					if(nn>0){
						$(m.Children).each(function(){
							var caption=this.Name;
							var code='';
							if(this.hasOwnProperty('Code')){code=this.Code;}
							//if(code.length>0){caption+=' ['+code+']';}
							if(so.show_code&&code.length>0){caption=code+'.'+caption;}
							var tt='<div class="item" id="'+this.Id+'" code="'+code+'"><span class="blank"></span><span class="itemcaption">'+caption+'</span>';
							tt+=self.selectflag(this.Id);
							tt+='</div>';
							thebox.append(tt);
						});
					}
					self.registerItemcaptionEvent(thebox);
				}
			}else{alert(m.Code+' '+m.Msg);}
		});
		return nn;
	};
	HierarchyObject.prototype.changeclass=function(hk,oldstr,newstr){
		var touched=false;
		var iclass=hk.attr('class');
		if(iclass.indexOf(oldstr)>=0){
			touched=true;
			hk.attr('class',iclass.replace(new RegExp(oldstr,'g'),newstr));
		}	
		return touched;	
	};
	HierarchyObject.prototype.changehook=function(itm,oldhook,newhook){
		var touched=false;
		var hk=itm.children('div.hook');
		if(hk.length>0){
			touched=this.changeclass(hk,oldhook,newhook);
		}
		return touched;
	};
	HierarchyObject.prototype.hookexpand=function(hk){
		this.changeclass(hk,'collapse','expand');
		this.registerExpandEvent(hk);
		var p = hk.parent();
		var nx = p.next();
		if( nx.length>0 && nx.attr('class')=='children' ){
			nx.show();
		}else{this.makechildblock(p);}
	};
	HierarchyObject.prototype.expandItem=function(itm){
		if(this.changehook(itm,'collapse','expand')){
			var ie = itm.children('div.expand');
			if(ie.length==1){this.registerExpandEvent(ie);itm.next().show();}
		}
	};
	HierarchyObject.prototype.expandPath=function(itm){
		var flag=true;var p=itm;
		while(flag){
			flag=false;
			var pitm=p.parent().prev();
			if(pitm.length>0){
				if(pitm.attr('id')!=this.options.root_id){
					this.expandItem(pitm);
					p = pitm;
					flag = true;
				}
			}
		}
	};	
	HierarchyObject.prototype.superiorEldersibling=function(id){
		var eldersibling=new Object();	//node has elder sibling: true / false
		eldersibling[0]=false;
		var thebox=this.element;
		var itm=thebox.find('.item#'+id);
		if(itm.length==1){
			var iid=id;
			while(iid!=this.options.root_id){
				eldersibling[iid]=(itm.nextAll('.item:first').length>0)
				var pcld=itm.parent();
				if(pcld.length>0){
					var pitm=pcld.prev();
					if(pitm.length>0){
						iid=pitm.attr('id');
						if(iid!=this.options.root_id){itm=pitm;}
					}else{iid=this.options.root_id;}
				}else{iid=this.options.root_id;}
			}
		}
		return eldersibling;
	};
	HierarchyObject.prototype.firstgradeEldersibling=function(){
		var eldersibling=new Object();	//node has elder sibling: true / false
		eldersibling[0] = false;	//0: root
		if(this.rootchildbox.length>0){
			var items=this.rootchildbox.children('.item'); 
			var i=0,n=items.length;
			items.each(function(){
				eldersibling[$(this).attr('id')]=(i<n-1);
				i++;
			});
		}
		return eldersibling;
	};
	HierarchyObject.prototype.loadChildren=function(m,eldersibling/*parents*/){
		var self=this,thebox=this.element,so=this.options;
		var mapSelect={},ns=0;
		var n=m.Nchildren;
		for(var i=0;i<n;i++){
			var node=m.Children[i];//Children struct {Id, Parentid int/Isleaf int/Depth int/Code, Name string}
			var flag=false;
			if(i<n-1){
				flag = (m.Children[i+1].Parentid==node.Parentid);
			}
			eldersibling[node.Id]=flag;
			var pitm=thebox.find('.item#'+node.Parentid);
			if(pitm.length==1){
				if(!eldersibling.hasOwnProperty(node.Parentid)){
					var nxt = pitm.next('.item');
					eldersibling[node.Parentid]=(nxt.length>0);
				}
				self.changehook(pitm,'collapse','expand');
				var ie=pitm.children('div.expand');
				if(ie.length==1){self.registerExpandEvent(ie);}
				var itm=thebox.find('.item#'+node.Id);
				if(itm.length==0){
					var sf=self.selectflag(node.Id);
					if(sf.length>0){	mapSelect[node.Id]=sf;ns++;}
					var indent = '';
					var idt = pitm.children('span.indent');
					if( idt.length>0 ){ indent = idt.html(); }
					var parenthasnextsibling=false;
					if(eldersibling.hasOwnProperty(node.Parentid)){
						parenthasnextsibling = eldersibling[node.Parentid];
					}
					indent += '<div depth="'+node.Depth+'" class="'+(parenthasnextsibling?'v':'no')+'line"></div>';
					var cld=pitm.siblings('#cld'+node.Parentid);
					if(cld.length==0){
						pitm.after('<div class="children" id="cld'+node.Parentid+'"></div>');
						cld=pitm.next();
					}else{
						itm = cld.children('.item:last');
						if(itm.length==1){self.changehook(itm,'tr','vr');	}
					}
					var code='';
					if(node.hasOwnProperty('Code')){code=node.Code;}
					var tt = '<div class="item" id="'+node.Id+'" code="'+code+'" depth="'+node.Depth+'">';
					tt += '<span class="indent">'+indent+'</span>';
					var linetype = 'tr';
					var iclass = (node.Isleaf==1) ? 'leaf':'collapse';
					tt += '<div class="hook '+iclass+' '+linetype+iclass+'"></div>';
					tt += self.itemflag(node.Id,node.Depth,i,n,node.Isleaf);
					var caption=node.Name;
					if(so.show_code&&code.length>0){caption=code+'.'+caption;}
					tt += '<span class="itemcaption'+self.colorClass(node.Id,node.Depth)+'">'+caption+'</span>';
					tt += '</div>';
					cld.append(tt);
					self.setDowngradeFlag(cld);
					self.registerFlagEvent(cld);//use for editor
					self.registerItemcaptionEvent(cld);
					self.registerChildrenCollapseEvent(cld);
				}else{
					thebox.find('#cld'+node.Parentid).show();
				}
			}
		}
		for(var id in mapSelect){
			var sitm=thebox.find('div#'+id);
			if(sitm.length>0){
				sitm.find('span.indent').children().first().append(mapSelect[id]);
			}
		}
	};
	HierarchyObject.prototype.GetItemCode=function(id){
		var thebox=this.element;
		return thebox.find('div#'+id).attr('code');
	};
	HierarchyObject.prototype.GetPathids=function(id){
		var thebox=this.element;
		return this.fullPathid(thebox.find('div#'+id));
	};
	HierarchyObject.prototype.fullPathid=function(itm){
		var pathid=itm.attr('id');
		var flag=true;var p=itm;
		while(flag){
			flag=false;
			var pitm=p.parent().prev();
			if(pitm.length>0){
				var pid=pitm.attr('id');
				if(pid!=this.options.root_id){
					pathid = pid+'.'+pathid;
					p = pitm;
					flag = true;
				}
			}
		}
		return pathid;
	};
	HierarchyObject.prototype.fullPathname=function(itm){
		var pathname=itm.text();
		var flag=true;var p=itm;
		while(flag){
			flag=false;
			var pitm=p.parent().prev();
			if(pitm.length>0){
				if(pitm.attr('id')!=this.options.root_id){
					pathname = pitm.text()+pathname;
					p = pitm;
					flag = true;
				}
			}
		}
		return pathname;
	};
	HierarchyObject.prototype.paththrough=function(thebox,id){
		this.through(thebox,id,false);
	};
	HierarchyObject.prototype.paththroughSilent=function(thebox,id){
		this.through(thebox,id,true);
	};
	HierarchyObject.prototype.through=function(thebox,id,keepsilent){
		var self=this;
		if(self.hierarchy){
			var itm=thebox.find(".item#"+id);
			if(itm.length==1){
				var iid=id;
				while(iid!=this.options.root_id){				
					if(itm.length>0){
						var pitm=itm.parent().prev();
						if(pitm.length>0){
							iid=pitm.attr('id');
							if(iid!=this.options.root_id){
								self.expandItem(pitm);
								itm=pitm;
							}
						}else{iid=this.options.root_id;}
					}else{iid=this.options.root_id;}
				}
				self.positem(thebox,id,keepsilent);	
			}else{
				var o={iid:id,lid:self.options.language};
				if(self.options.eid>0){
					o['eid']=self.options.eid;
				}else{
					o['cst']=self.options.codeset;
				}
				if(self.options.codeset.length>0){
					$.getJSON(self.options.paththrough_url,o,function(m){
						if(m.Code=="100"){
							self.loadChildren(m,self.firstgradeEldersibling());
							self.positem(thebox,id,keepsilent);
						}else{alert(m.Code+'['+id+'] '+m.Msg);}
					});
				}
			}
		}else{
			self.positem(thebox,id,keepsilent);
		}
	};
	HierarchyObject.prototype.positionItem=function(thebox,id){
		this.positem(thebox,id,false);
	};
	HierarchyObject.prototype.positem=function(thebox,id,keepsilent){
		var itm=thebox.find(".item#"+id);
		if(itm.length>0){
			var boxheight=thebox.height();
			var half_boxheight=parseInt(boxheight/2);
			var quarter_rowheight=parseInt(this.options.row_height/4);
			var ypos=itm.position().top;//-100, 0 , 100
			var yobj=itm.position().top+thebox.scrollTop();//the real top of the object,scrollTop may >=0
			if(ypos<0 || ypos>boxheight-quarter_rowheight){
				var yscroll = yobj-half_boxheight;
				if(yscroll<0){yscroll=0;}
				thebox.animate({scrollTop:yscroll},100);
			}
			if(!keepsilent){this.focusItem(itm);}else{this.focusOn(itm);}
		}
	};
	HierarchyObject.prototype.loadoption=function(value){/*virtual function*/};
	HierarchyObject.prototype.loadHierarchyOption=function(){
		var self=this;
		var thebox = this.element;
		var n=this.sequence.length;//equal to = this.options.item_option.length;
		for(var i=0;i<n;i++){
			var ii=this.pos[this.sequence[i]];
			var o=this.options.item_option[ii];
			this.loadoption(o.value);			
			var v=this.itemflag(o.value,o.depth,o.isibling,o.nsiblings,o.isleaf);
			var code='';
			if(o.hasOwnProperty('code')){code=o.code;}
			var itm=this.addItem(thebox,o.value,o.parent,code,o.label,o.isleaf,o.depth,o.pys,v);
			if(itm.length>0){
				this.setDowngradeFlag(itm);
				this.registerFlagEvent(itm);
				this.registerItemcaptionEvent(itm);
				this.registerChildrenCollapseEvent(itm);
			}
		}
		self.rootchildbox.children('div.item').each(function(){//expand first grade
			self.expandItem($(this));
		});
	};
	HierarchyObject.prototype.addItem=function(thebox,id,pid,code,label,isleaf,depth,pys,itmflag){
		var self=this,so=this.options;
		var itm=new Object();
		var pitm=thebox.find('#'+pid);
		if(pitm.length==1){
			itm=thebox.find('#'+id);
			if(itm.length==0){
				var indent = '';
				var pyss=pys.split(',');
				for(var i=0;i<pyss.length;i++){
					indent+='<div depth="'+(i+1)+'" class="'+((pyss[i]=='1')?'v':'no')+'line"></div>';
				}
				var cld=pitm.siblings('#cld'+pid);
				if(cld.length==0){
					pitm.after('<div class="children" id="cld'+pid+'"></div>');
					cld=pitm.next();
					if(pid!=this.options.root_id){cld.hide();}
				}else{
					var itmlst = cld.children('.item:last');
					if(itmlst.length==1){
						var ic = itmlst.find('div.leaf');
						if(ic.length==1){
							ic.removeClass('trleaf').addClass('vrleaf');
						}else{
							ic = itmlst.find('div.collapse');
							if(ic.length==1){
								ic.removeClass('trcollapse').addClass('vrcollapse');
							}
						}
					}
				}
				var tt = '<div class="item" id="'+id+'" code="'+code+'" depth="'+depth+'">';
				tt += '<span class="indent">'+indent+'</span>';
				var linetype = 'tr';
				var iclass = isleaf ? 'leaf':'collapse';
				tt += '<div class="hook '+iclass+' '+linetype+iclass+'"></div>';
				tt += itmflag;
				var caption=label;
				if(so.show_code&&code.length>0){caption=code+'.'+caption;}
				tt += '<span class="itemcaption'+self.colorClass(id,depth)+'">'+caption+'</span>';
				tt += self.selectflag(id);
				tt += '</div>';
				cld.append(tt);
				itm=cld.find('#'+id);
			}
		}
		return itm;		
	};
	HierarchyObject.prototype.colorClass=function(id,depth){
		return ' color'+(depth%6).toString();
	}
$.fn.Hierarchy=function(options){
	var hier=new HierarchyObject(this,options);
	hier.init();
	return hier;
};
/*
var H=$('#div').Hierarchy({
				self_hierarchy:true,
				item_option:[
					{value:1,parent:0,label:"中等教育"},
					{value:2,parent:1,label:"普通中学"},
					{value:3,parent:1,label:"职业高中"},
					{value:4,parent:3,label:"艺术学校"},
					{value:5,parent:0,label:"高等教育"},
					{value:6,parent:5,label:"985"},
					{value:7,parent:5,label:"211"},
					{value:8,parent:5,label:"普通大学"}
        		]
			});
*/