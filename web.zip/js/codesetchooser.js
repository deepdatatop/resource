	function CodesetchooserObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			width:400,
			height:560,
			zindex:20000,
			codeset:'',
			codeset_title:'',
			multiple_choice:false,
			language_id:1,
			okStr:'OK',
			cancelStr:'Cancel',
			onChoose: function(id){}
		};
		this.selected=0;
		this.bodyoverflow='';
		this.overlay='chooser_overlay';
		this.options=$.extend({},this.defaults,options);
    };
	CodesetchooserObject.prototype.close_chooserpane=function(){
		this.element.find('#'+this.overlay).remove();
		this.element.find('#ichooser_pane').remove();
		$('body').css('overflow',this.bodyoverflow);
	};
	CodesetchooserObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	CodesetchooserObject.prototype.show_chooserpane=function(){
		this.i18n_options();
		var self=this;
		var thebox=this.element;
		var body=$('body');
		self.bodyoverflow = body.css('overflow');
		body.css('overflow','hidden');
		var aos='z-index: '+self.options.zindex+';';
		thebox.append('<div id="'+self.overlay+'" class="overlay" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.overlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="ichooser_pane" class="chooser" style="display: none;';
		txt += 'width:'+self.options.width+'px;height:'+self.options.height+'px;">';
		txt += '<div class="chooser_header text_dark">';
		txt += '<span id="thetitle"></span>';
		txt += '<span class="close_icon"></span></div>';
		txt += '<div id="chooser" class="h_selector" tabindex="0" style="width:100%;height:480px;outline:none;"></div>';
		txt += '<div class="chooser_footer">';
		txt += '<span class="chooser_button" id="btn_ok"><i class="fa fa-check"></i>&nbsp;'+self.options.okStr+'</span>';
		txt += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
		txt += '<span class="chooser_button" id="btn_cancel"><i class="fa fa-times"></i>&nbsp;'+self.options.cancelStr+'</span>';
		txt += '</div>';
		txt += '</div>';
		thebox.append(txt);
		var pane = thebox.find("#ichooser_pane");
		if(self.options.codeset.length>0){
			pane.find('#chooser').Hierarchy({
				dynamic_loading:false,
				codeset:self.options.codeset,language:self.options.language_id,
				onChange:function(id,val){self.selected=id;}
			});
		}else{
			alert('not set codeset!');
		}
		pane.find('#thetitle').text(self.options.codeset_title);
		
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#btn_ok').off("click").on("click",function(event){
			event.stopPropagation();
			self.options.onChoose(self.selected);
			self.close_chooserpane();
		});
		thebox.find('#btn_cancel').off("click").on("click",function(event){self.close_chooserpane();});
		thebox.find('#'+self.overlay).off("click").on("click",function(event){self.close_chooserpane();});
		thebox.find('.close_icon').off("click").on("click",function(event){self.close_chooserpane();});
	};
    $.fn.Codesetchooser=function(options){
		var chooser=new CodesetchooserObject(this,options);
		return chooser;
    };