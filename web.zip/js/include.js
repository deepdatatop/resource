var _js=[],_css=[];
var _owner={},_ready={};
function include_exists(){
	$("script").each(function(i,e){
		_js.push(trim_host_random(e.src));
	});
	$("link").each(function(i,e){
		_css.push(trim_host_random(e.href));
	});
};
function trim_host_random(url){
	var ss=window.location.protocol+'//'+window.location.host;
	var i=url.indexOf(ss);
	if(i==0){
		url=url.substr(ss.length);
	}
	i=url.indexOf('?');
	if(i>0){
		url=url.substr(0,i);
	}
	return url;
};
function checkqueueready(){
	var flag=true;
	for(const fn in _ready) {
		if(!_ready[fn]){
			flag=false;
			break;
		}
	}
	if(flag){
		_ready={};
		_owner.include_callback();
	}
};
var include_callback = function(type,url) {
	if(type==1){
	    if(_css.indexOf(url)==-1){
			_css.push(url);
			if(_ready.hasOwnProperty(url)){
				_ready[url]=true;
			}
		}		
	}else{
	    if(_js.indexOf(url)==-1){
			_js.push(url);
			if(_ready.hasOwnProperty(url)){
				_ready[url]=true;
			}
		}
	}
	checkqueueready();
};
function include_queue(owner,queue){
	_owner = owner;
	_ready = {};
	var qq=queue.split(',');
	var n=qq.length;
	for(var i=0;i<n;i++){
		var fn=qq[i];
		var m=fn.length;
		if(m>0){
			_ready[fn]=false;
			if(fn.lastIndexOf('.css')==m-4){
				if(_css.indexOf(fn)==-1){
					include_css(fn);
				}else{
					_ready[fn]=true;
				}
			}else if(fn.lastIndexOf('.js')==m-3||fn.indexOf('http')==0){
				if(_js.indexOf(fn)==-1){
					include_js(fn);
				}else{
					_ready[fn]=true;
				}			
			}
		}
	}
	checkqueueready();
}
function include_js(url){
	var script = document.createElement('script');
	script.src = url;
	script.type = 'text/javascript';
	if(script.readyState) {
		if(script.readyState === 'loaded' || script.readyState === 'complete') {
			include_callback(2,url);
			script.onreadystatechange = null;
		}
	}else {
		script.onload = function () {
			include_callback(2,url);
		};
	}
	document.getElementsByTagName("head")[0].appendChild(script);
}
function include_css(url){
	var link = document.createElement('link');
	link.href = url;
	link.rel = 'stylesheet';
	link.type = 'text/css';
	if(link.readyState) {
		if(link.readyState === 'loaded' || link.readyState === 'complete') {
			include_callback(1,url);
			link.onreadystatechange = null;
		}
	}else {
		link.onload = function () {
			include_callback(1,url);
		};
	}
	document.getElementsByTagName("head")[0].appendChild(link);
}