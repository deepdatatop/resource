function ChooserObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		identifier: '',
		width: 400,
		roadmapids: '0',
		pop_scene: 'manage',
		txt_inputnsearch: 'input name and press enter key.',
		onChange: function(data){}
	};
	this.popchooser={};
	this.value='';
	this.optionVisiable=0;
	this.options=$.extend({},this.defaults,options);
};
ChooserObject.prototype.showInput=function(v){
    var thebox=this.element;
    thebox.find('.chooser_nameinput').css('display','inline-block').val(v).focus();
    thebox.find('.toggle_chooseoption').css('display','inline-block');
}
ChooserObject.prototype.hideInput=function(){
    var thebox=this.element;
    thebox.find('.chooser_nameinput').hide();
    thebox.find('.toggle_chooseoption').hide();
}
ChooserObject.prototype.showText=function(txt){
    var thebox=this.element;
    thebox.find('.chooser_txt').css('display','inline-block').text(txt);
    thebox.find('.chooser_clear').css('display','inline-block');
}
ChooserObject.prototype.hideText=function(){
    var thebox=this.element;
    thebox.find('.chooser_txt').hide();
    thebox.find('.chooser_clear').hide();
}
ChooserObject.prototype.setValue=function(val){
	this.value=val;
	var id=parseInt(val);
    var self=this;
    var thebox=this.element;
    if(id>0){
		$.getJSON('/id2name',{idf:self.options.identifier,iid:id},function(m){
			self.hideInput();
			var txt='';
			if(m.Code=='100'){
				txt=m.Name;
			}else{
				txt=m.Code+'.'+m.Msg;
			}
			self.showText(txt);
		});	  
	}else{
		self.hideText();self.showInput('');
	}
    return self;
};
ChooserObject.prototype.modified=function(){
	this.options.onChange(this.value);
};
ChooserObject.prototype.search=function(){
	var self=this;
	var thebox=this.element;
	var chooser_nameinput=thebox.find('.chooser_nameinput');
	var v=$.trim(chooser_nameinput.val());
	if(v.length>0){
		$.getJSON('/seekidname',{idf:self.options.identifier,kwd:v},function(m){
			if(m.Code=='100'){
				if(m.NItems==1){
					self.hideInput();
					self.value=m.Items[0].ID;
					self.showText(m.Items[0].Name);
					self.modified();
				}else{
					self.openChooseOption();
				}
			}else{
				alert(m.Code+'.'+m.Msg);
			}
		});
	}else{
		chooser_nameinput.focus();
	}
};
ChooserObject.prototype.resetWidget=function(){
	var self=this;
	var thebox=this.element;
	thebox.empty();
	var ss='<div class="chooserwrap"><span class="chooser_txt"></span>';
	ss+='<input type="text" class="chooser_nameinput" placeholder="'+self.options.txt_inputnsearch+'">';
	ss+='<span class="toggle_chooseoption"><i class="fa fa-list-alt"></i></span>';
	ss+='<span class="chooser_clear"><i class="fa fa-times-circle"></i></span>';
	ss+='</div>';
	thebox.append(ss);
	thebox.find(".chooser_clear").off("click").on("click",function(event){
		event.stopPropagation();
		self.value=0;self.hideText();self.showInput('');
		self.modified();
	});
	thebox.find(".chooser_nameinput").bind('keypress',function(event){
		if(event.keyCode == "13"){
			self.search();
			event.preventDefault();
		}
	});
	thebox.find(".toggle_chooseoption").off("click").on("click",function(event){
		event.stopPropagation();
		if(self.isclosedChooseOption()){
			self.openChooseOption();
		}else{
			self.closeChooseOption();
		}
	});
};
ChooserObject.prototype.isclosedChooseOption=function(){
	return (this.optionVisiable==0);
};
ChooserObject.prototype.openChooseOption=function(){
	var self=this,so=this.options;
	var thebox=this.element;
	self.optionVisiable=1;
	$.getJSON('/readgridchooserblock',{idf:so.identifier,scene:so.pop_scene},function(m){
		if(m.Code=="100"){
			var q='';
			var cname=thebox.find(".chooser_nameinput").val();
			if(cname.length>0){q+='"name":"'+cname+'"';}

			self.popchooser=$('body').Popchooser({
				i18n: so.i18n,
				identifier: so.identifier,
				caption: so.caption,
				entity_id: m.Entity_id,
				subentity: m.Subentity,
				scene: so.pop_scene,
				query: q,
				user_id: m.User_id,
				ip: m.Ip,
				roadmapids: so.roadmapids,
				filter_block_bs64: m.Filter_block_bs64,
				filter_inputs_bs64: m.Filter_inputs_bs64,
				grid_dependency_bs64: m.Grid_dependency_bs64,
				rows_per_page: m.Rows_per_page,
				column_block_bs64: m.Column_block_bs64,
				column_template_bs64: m.Column_template_bs64,
				view_scene: m.View_scene,
				view_dependency_bs64: m.View_dependency_bs64,
				form_scene: m.Form_scene,
				form_dependency_bs64: m.Form_dependency_bs64,
				onChoose: function(iid,name){
					self.value=iid;
					self.hideInput();self.showText(name);
					self.popchooser.close_pane();
					self.popchooser={};
					self.closeChooseOption();
					self.modified();
				}
			});
		}else{alert(m.Msg);}
	});
};
ChooserObject.prototype.closeChooseOption=function(){
	this.optionVisiable=0;
};
ChooserObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
ChooserObject.prototype.init=function(){
	this.i18n_options();
    this.resetWidget();
};
$.fn.Chooser=function(options){
	var achooser=new ChooserObject(this,options);
	achooser.init();
	return achooser;
};