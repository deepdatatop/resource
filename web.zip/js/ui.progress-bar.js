$.fn.animateProgress = function(progress, callback) { 
	return this.each(function() {
		$(this).animate({width: progress+'%'},{
				duration: 0,easing: 'swing',
				// this gets called every step of the animation, and updates the label
				step: function( progress ){
				var labelEl = $('.ui-label', this),valueEl = $('.value', labelEl);//overEl = $('.ui-over', this);
				if (Math.ceil(progress) < 10 && $('.ui-label', this).is(":visible")) {
					labelEl.hide();
				}else{
					if (labelEl.is(":hidden")) { labelEl.fadeIn(); };
				}
				if (Math.ceil(progress) == 100) {//overEl.show();//labelEl.hide();
					setTimeout(function() {labelEl.fadeOut();}, 1000);
				}else{valueEl.text(Math.ceil(progress) + '%');}
			},complete: function(scope, i, elem) {if (callback) { callback.call(this, i, elem ); };}
		});
	});
};