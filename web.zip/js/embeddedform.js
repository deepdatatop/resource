function EmbeddedformObject(element,options){
	this.element=element;
	this.defaults={
		title: 'abc',
		i18n: {},
		min_height: 200,
		identifier: 'product',
		interface_scene: 'propertyset',
		setgrid_scene: 'propertymanage',
		roadmapids: '1',
		initial_base64: '',
		onChange: function(val){}
	};
	this.toolbarheight=32;
	this.idnames={};
	this.form_data={};
	this.editor_objects={};/*same as userinterface.makeEditorJS*/
	this.editor_types={};
	this.options=$.extend({},this.defaults,options);
};
EmbeddedformObject.prototype.isempty=function(o){
	var flag=false;
	if(!o && typeof(o)!='undefined'){
		flag=true;
	}
	return flag;
};
EmbeddedformObject.prototype.propertymodified=function(property,dt){
	this.form_data[property]=$.trim(dt);
	var o={};
	for(var key in this.form_data) {
		if(this.idnames.hasOwnProperty(key)){
			o[key+'.'+this.idnames[key]]=this.form_data[key];
		}
	}
	this.options.onChange(JSON.stringify(o));
};
EmbeddedformObject.prototype.loadInitialdata=function(){
	var data=this.options.initial_base64;
	if(data.length>0){
		var o=JSON.parse($.base64.decode(data));
		for(var key in o){
			var ss=key.split('.');
			if(ss.length>0){this.form_data[ss[0]]=o[key];}
		}
	}
};
EmbeddedformObject.prototype.resetData=function(id_nms){
	//renew this.idname,this.form_data
	var o_nm_ids={};
	for(var id in this.idnames){o_nm_ids[this.idnames[id]]=id;}
	var o_form_data={};
	for(var id in this.form_data){o_form_data[id]=this.form_data[id];}
	this.form_data={};this.idnames={};
	for(var id in id_nms){
		var nm=id_nms[id]; this.idnames[id]=nm;
		if(o_nm_ids.hasOwnProperty(nm)){
			var o_id=o_nm_ids[nm];
			if(o_form_data.hasOwnProperty(o_id)){
				this.form_data[id]=o_form_data[o_id];
			}
		}
	}
};
EmbeddedformObject.prototype.reset=function(){
	this.setFormarea(1);
};
EmbeddedformObject.prototype.setFormarea=function(reset){
	var self=this,so=this.options;
	var thebox=this.element;
	var fa=thebox.find('#ef_area');
	fa.empty();
	$.getJSON('/readdynamicformblock',{idf:so.identifier,scene:so.interface_scene,pid:so.roadmapids},function(m){
		if(m.Code=='100'){
			//alert($.base64.decode(m.Form_block));
			fa.append($.base64.decode(m.Form_block));
			if(m.IDnames.length>0){
				var id_nms=JSON.parse($.base64.decode(m.IDnames));
				if(reset==1){
					self.resetData(id_nms);
				}else{
					self.idnames=id_nms;
				}
			}
			if(!self.isempty(m.Textinputs)){
				m.Textinputs.forEach(function(item){
					var ss='';
					if(self.form_data.hasOwnProperty(item.Property)){ss=self.form_data[item.Property];}
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).val(ss).on('input propertychange',function(e){
						self.propertymodified(item.Property,$(this).val());
						e.preventDefault();
					});
				});
			}
			if(!self.isempty(m.Selectors)){
				m.Selectors.forEach(function(item){
					var selected='';
					if(self.form_data.hasOwnProperty(item.Property)){
						var v=self.form_data[item.Property];
						var vv=v.split('.');
						if(vv.length>0){selected=vv[0];}
					}
					var cs='',op=[],nm='Codeset';
					if(item.hasOwnProperty(nm)){
						cs=item[nm];
					}
					nm='Options';
					if(item.hasOwnProperty(nm)){
						var i_o=item[nm];
						if(i_o.length>0){op=JSON.parse($.base64.decode(i_o));}
					}
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Selector({
						codeset:cs,item_option:op,multiple_choice:false,language:item.Clientlanguage,
						onChange: function(id,ids,codes,labels,dotids,pathnames){
							var rt='';
							switch(item.Result){
								case 'value.label':
									var vv=[];
									for(var i=0,n=ids.length;i<n;i++){
										vv.push(ids[i]+'.'+labels[i]);
									}
									rt=vv.join();
									break;
								case 'codes':rt=codes.join();break;
								case 'dotids':rt=dotids.join();break;
								default:rt=ids.join();break;
							}
							self.propertymodified(item.Property,rt);
						}
					}).setResult(selected);
				});
			}
		}
	});
};
EmbeddedformObject.prototype.setupWidget=function(){
	var self=this,so=this.options;
	var thebox=this.element;
	self.loadInitialdata();
	thebox.empty();
	var txt='';
	if(so.setgrid_scene.length>0){
		var tb_height=self.toolbarheight-1;
		txt+='<div id="ef_toolbar" style="width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;background-color:#f9f9f9;">';
		txt+='<span id="ef_speedbtn" style="float:right;width:48px;text-align:center">';
		txt+='<i id="ef_magic" class="fa fa-magic fa-flip-horizontal"></i>';
		txt+='&nbsp;&nbsp;<i id="ef_setup" class="fa fa-cog fa-lg"></i>';
		txt+='</span></div>';
	}
	txt+='<div id="ef_area" style="width:100%;"></div>';
	thebox.append(txt);
	self.setFormarea(0);
	if(so.setgrid_scene.length>0){
		thebox.find('#ef_setup').off("click").on("click",function(event){
			$.getJSON('/readgridblock',{idf:so.identifier,scene:so.setgrid_scene},function(m){
				if(m.Code=="100"){
					$('body').Popgrid({
						i18n: so.i18n,
						identifier: so.identifier,
						caption: m.Caption,
						entity_id: m.Entity_id,
						subentity: m.Subentity,
						scene: so.setgrid_scene,
						user_id: m.User_id,
						ip: m.Ip,
						roadmapids: so.roadmapids,
						filter_block_bs64: m.Filter_block_bs64,
						filter_inputs_bs64: m.Filter_inputs_bs64,
						grid_dependency_bs64: m.Grid_dependency_bs64,
						rows_per_page: m.Rows_per_page,
						column_block_bs64: m.Column_block_bs64,
						column_template_bs64: m.Column_template_bs64,
						view_scene: m.View_scene,
						view_dependency_bs64: m.View_dependency_bs64,
						form_scene: m.Form_scene,
						form_dependency_bs64: m.Form_dependency_bs64,
						onClose: function(ismodified){
							if(ismodified==1){self.setFormarea();}
						}
					});
				}else{alert(m.Msg);}
			});
		});
	}
};
EmbeddedformObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
EmbeddedformObject.prototype.init=function(){
	this.i18n_options();
	this.setupWidget();
};
$.fn.Embeddedform=function(options){
	var aform=new EmbeddedformObject(this,options);
	aform.init();
	return aform;
};