var i_up='fa-angle-up';var i_dn='fa-angle-down';
$('.ht_expand_all').on("click",function(){
var root=$('#cld0');
root.find('div.ht_item').show();
root.find('div.children').show();
root.find('.'+i_dn).removeClass(i_dn).addClass(i_up);
});
$('.ht_collapse_all').on("click",function(){
	var root=$('#cld0');
	root.find('div.ht_item').show();
	root.find('div.children').hide();
	root.find('.'+i_up).removeClass(i_up).addClass(i_dn);
});
$('.ht_expand_outline').on("click",function(){
	var root=$('#cld0');
	root.find('div.children').show();
				
	root.find('div.ht_item').each(function(){
		var itm=$(this);
		if(itm.find('span.ht_heading').length>0){
			itm.show();
			itm.find('.'+i_up).removeClass(i_up).addClass(i_dn);
		}else{
			itm.hide();
		}
	});
});
$('.ht_font_up').on("click",function(){incFontsize();});
$('.ht_font_dn').on("click",function(){decFontsize();});		
$('.e-c').on('click',function(){
	var self=$(this);
	var item=self.parent();
	var nxt=item.next();
	var flag=false;
	if(nxt.length>0 && nxt.hasClass('children')){flag = true;}
	if(self.hasClass(i_up)){
		if(flag){nxt.hide();}
		self.removeClass(i_up).addClass(i_dn);
	}else if(self.hasClass(i_dn)){
		if(flag){
			nxt.show();
			nxt.children('div.ht_item').show();
		}
		self.removeClass(i_dn).addClass(i_up);
	}
});