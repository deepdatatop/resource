	function ImageSliderObject(element,options){
		this.element=element;
		this.nItems=0;
		var defaults={
			marginright:8
		};
		this.options=$.extend({},defaults,options);
		this.iScale=0;
    };
	ImageSliderObject.prototype.init=function(){
		var obj=this;
		var self=this.element;
		var ss='<div class="slist"><ul class="simages" style="width:1000px;"></ul></div>';
		ss+='<div class="slideScrollBar"><div class="barL"></div>';
		ss+='<div class="barM"><div class="bar"><div class="l"></div><div class="r"></div></div></div>';
		ss+='<div class="barR"></div></div>';
		self.append(ss);
		this.loadImages();
		var oList=self.find('.slist');
		var oUl=self.find('.simages');
		var oBarL=self.find('.barL');
		var oBarM=self.find('.barM');
		var oBarR=self.find('.barR');
		var oBar=self.find('.bar');
		oBar.on('click',function(event){
			event.stopPropagation();event.cancelBubble = true;
		});
		oBar.on('mousedown',function(event){
			event.preventDefault();
			var disX = event.clientX - oBar.position().left;
			if(oBar.setCapture){
				oBar.setCapture();
				oBar.onmousemove=function(ev){mouseMove(ev || event);};
				oBar.onmouseup = mouseUp;
			}else{
				$(document).bind("mousemove", mouseMove).bind("mouseup", mouseUp);
			}
			function mouseMove(event){
				event.preventDefault();
				var maxL=parseInt(oBarM.outerWidth()-oBar.outerWidth());
				var xPos = event.clientX - disX;
				if(xPos <= 0){xPos = 0;}
				if(xPos >= maxL){xPos = maxL;}
				oBar.css('left',xPos + 'px');
				obj.iScale = xPos / maxL;
			}
			function mouseUp(event){
				event.preventDefault();
				if(oBar.releaseCapture){
					oBar.releaseCapture();
					oBar.onmousemove = oBar.onmouseup = null;
				}else{
					$(document).unbind("mousemove", mouseMove).unbind("mouseup", mouseUp);
				}
				obj.slide(oUl, parseInt((oList.outerWidth() + obj.options.marginright - oUl.outerWidth()) * obj.iScale));
				obj.setStop(oBar,oBarM,oBarL,oBarR);
			}
		});
		oBarL.on('mouseover',function(event){
			if(oBarL.timer){clearInterval(oBarL.timer);}
			oBarL.timer = setInterval(function(){
				obj.togetherMove(oBar.position().left-obj.options.marginright, 1,oList,oUl,oBar,oBarM,oBarL,oBarR);
			},30);		
		});
		oBarR.on('mouseover',function(event){
			if(oBarR.timer){clearInterval(oBarR.timer);}
			oBarR.timer = setInterval(function(){
				obj.togetherMove(oBar.position().left+obj.options.marginright, 1,oList,oUl,oBar,oBarM,oBarL,oBarR);
			},30);			
		});
		oBarL.on('mouseout',function(event){
			if(oBarL.timer){clearInterval(oBarL.timer);}
		});
		oBarR.on('mouseout',function(event){
			if(oBarR.timer){clearInterval(oBarR.timer);}
		});
		oBarM.on('click',function(event){
			event.stopPropagation();event.cancelBubble = true;
			var iTarget = event.clientX - $(this).offset().left - oBar.outerWidth()/2;
			obj.togetherMove(iTarget,0,oList,oUl,oBar,oBarM,oBarL,oBarR);
        });
		this.setStop(oBar,oBarM,oBarL,oBarR);
	};
	ImageSliderObject.prototype.setStop=function(oBar,oBarM,oBarL,oBarR){
		var maxL=parseInt(oBarM.outerWidth()-oBar.outerWidth());
		var lc='barL';
		var rc='barR';
		switch(oBar.position().left){
		case 0:
			// /(^|\s)barLStop(\s|$)/.test(oBarL.className) || (oBarL.className += " barLStop");
			lc='barLStop';
			break;
		case maxL:
			// /(^|\s)barRStop(\s|$)/.test(oBarR.className) || (oBarR.className += " barRStop");
			rc='barRStop';
			break;
		}
		oBarL.attr('class',lc);
		oBarR.attr('class',rc);
	};
	ImageSliderObject.prototype.togetherMove=function(iTarget, step,oList,oUl,oBar,oBarM,oBarL,oBarR){
		var obj=this;
		var self=this.element;
		var maxL=parseInt(oBarM.outerWidth()-oBar.outerWidth());
		if(iTarget <= 0){iTarget = 0;	}
		else if(iTarget >= maxL){iTarget	= maxL;}
		obj.iScale = iTarget / maxL;
		var uPos=parseInt((oList.outerWidth() + obj.options.marginright - oUl.outerWidth()) * obj.iScale);
		obj.slide(oUl, uPos, function(){obj.setStop(oBar,oBarM,oBarL,oBarR);}, step);
		obj.slide(oBar, iTarget, function(){obj.setStop(oBar,oBarM,oBarL,oBarR);}, step);
	};
	ImageSliderObject.prototype.slide=function(o, iTarget, fnEnd, step){
		var obj=this;
        if(o.timer){clearInterval(o.timer);}
        o.timer = setInterval(function(){
			var iLeft = parseInt(o.position().left);
			var iSpeed = (iTarget - iLeft) / (step || obj.options.marginright);
			iSpeed = iSpeed > 0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);		
			if(iLeft==iTarget){
				if(o.timer){clearInterval(o.timer);}
				if(fnEnd){fnEnd();}
			}else{
				o.css('left',(iLeft+iSpeed)+'px');
			}
		}, 25);
	};
	ImageSliderObject.prototype.loadImages=function(){
		var obj=this;
		var self=this.element;
		var images=self.find('.simages');//ul
		images.empty();
		var n=this.options.images.length;
		for(var i=0;i<n;i++){
			var img=this.options.images[i];
			var ss='<li><a id="'+i+'"><img src="'+img.src+'">';
			if(img.tag.length>0){ss+='<p>'+img.tag+'</p>';}
			ss+='<span class="plus"><img src="/img/plus.png"></span>';
			ss+='</a></li>';
			images.append(ss);
		}
		images.find('a').on('click',function(){
			var id =parseInt($(this).attr('id'));
			var img=obj.options.images[id];
			obj.options.onSelect(img.tag,img.src);
		});
		this.nItems=n;
		var aLI=images.children('li:first');
		if(aLI.length>0){
			images.css('width',(aLI.outerWidth()+this.options.marginright)*n+'px');
		}
	};
    $.fn.ImageSlider=function(options){
		var aslider=new ImageSliderObject(this,options);
		aslider.init();
		return aslider;
    };
