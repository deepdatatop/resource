var i18n={};
var grid_name='';
var grid_scene='';
var column_data=[];
var gridentity_id='0';
var gridsubentity='';
var roadmapids='0';
var rowids=[];/*use for popview*/
var form_scene='';
var form_dependency='';
var view_scene='';
var view_dependency='';
var popgrid_modified=0;
function do_action(dom,a_p){
	var self=$(dom);
	var action=self.attr('action');
	var instance_id=self.attr('iid');
	switch(action){
	case 'view':
		$('body').Popview({
			width:800,
			height:460,
			i18n:i18n,
			eid:gridentity_id,
			scene:view_scene,
			widget_dependency:view_dependency,
			iid:instance_id,
			iids:rowids
		}).show();
		break;
	case 'popform':
		$('body').Popform({
			i18n:i18n,
			eid:gridentity_id,rmi:roadmapids,scene:form_scene,widget_dependency:form_dependency,
			afterSave:function(instance_id){
				popgrid_modified=1;
				$.getJSON('/getgridrow',{wgt:'GM',eid:gridentity_id,iid:instance_id,scene:grid_scene},function(m){
					if(m.Code=='100'){
						GridManager.updateRowData(grid_name,'id',JSON.parse(m.Instance_stringify));
					}else{alert(m.Msg);}
				});
			}
		}).setInstance(instance_id);			
		break;
	case 'remove':
		removeInstance(instance_id);
		break;
	}
};

function removeInstance(instance_id){
	var txt_removeornot='Remove or not';
	if(i18n.hasOwnProperty('txt_removeornot')){txt_removeornot=i18n['txt_removeornot'];}
	var txt_yes='yes',txt_no='no';
	if(i18n.hasOwnProperty('txt_yes')){txt_yes=i18n['txt_yes'];}
	if(i18n.hasOwnProperty('txt_no')){txt_no=i18n['txt_no'];}
	$('body').YesnoAlert({
		yesText:txt_yes,noText:txt_no,
		doyes: function(id,action){
			$.ajaxSettings.async = false;
			$.getJSON('/instanceoperate',{eid:gridentity_id,sub:gridsubentity,iid:instance_id,act:action},function(m){
				if(m.Code=="100"){
					popgrid_modified=1;
					GridManager.refreshGrid(grid_name);
				}else{
					alert(m.Msg);
				}
			});
			$.ajaxSettings.async = true;
		}
	}).show_alertpane('',txt_removeornot+'?','remove');
}

function PopgridObject(element,options){
	this.element=element;
	this.defaults={
		width:800,
		height:600,
		zindex:200,
		i18n: {},
		closeText: 'Close',
		identifier: '',
		caption: '',
		entity_id: '0',
		user_id: '0',
		ip: '',
		scene: '',
		pagesize: 20,
		roadmapids: '',
		filter_block_bs64: '',
		filter_inputs_bs64: '',
		form_dependency_bs64: '',
		grid_dependency_bs64: '',
		column_block_bs64: '',
		column_template_bs64: '',
		onClose: function(modified){}
	};
	this.id='';
	this.instance_id=0;
	this.po='popgrid_overlay';
	this.pp='popgrid_pane';
	this.gridarea={};
	this.options=$.extend({},this.defaults,options);
};
PopgridObject.prototype.close_pane=function(){
	this.element.find('#grid_area').remove();
	this.element.find('#'+this.po).remove();
	this.element.find('#'+this.pp).remove();
	this.options.onClose(popgrid_modified);
};
PopgridObject.prototype.include_callback=function(){//call at include.js
	this.setWidget();
};

PopgridObject.prototype.setWidget=function(){
	var self=this,so=this.options;
	var thebox=this.element;
	var recommendremoved=false;
	var default_query='"wgt":"GM","scene":"'+so.scene+'",';
	if(so.roadmapids.length>0){
		default_query+='"rmi":"'+so.roadmapids+'",';
	}
	if(JSON.parse(so.entity_id)>0){
		default_query+='"eid":"'+so.entity_id+'"';
	}else{
		default_query+='"idf":"'+so.identifier+'"';
	}
	//^filter---
	var tf=thebox.find('#pop_filter');
	var dy=tf.outerHeight()+70;
	var thefilter=tf.Filter({
		user_id: so.user_id,
		ip: so.ip,
		entity_id: so.entity_id,
		i18n: so.i18n,
		htmblock: so.filter_block_bs64,
		inputs: so.filter_inputs_bs64,
		onSearch: function(q,p){//query,prompt
			var txt='{'+default_query;
			if(q.length>0){ txt+=','+q; }
			txt+='}';
			GridManager.setQuery(grid_name,JSON.parse(txt),true,function(){});
			if(q.length>0){$.getJSON('/savequery',{q:txt,p:p},function(m){});}
		}
	});
	var init_query='{'+default_query;
	var q=thefilter.getSieve();
	if(q.length>0){ init_query+=','+q; }
	init_query+='}';
	var gmHeight=(so.height-104)+'px';
	var g_m=thebox.find('#pop_grid').GM({gridManagerName: grid_name,
		height: gmHeight,
		supportAjaxPage:true,
		supportCheckbox:false,
		ajaxData: '/getdatagrid',
		ajaxType: 'POST',
		query: JSON.parse(init_query),
		pageSize: so.pagesize,
		columnData: column_data,
		summaryHandler: function(data){
			rowids.length=0;
			data.forEach(item => {rowids.push(item.id);});
			return;
		}/*rowids use for popview*/
	},function(){
		$('#'+grid_scene+'_popnew_btn').live('click',function(){
			$('body').Popform({
				eid:gridentity_id,rmi:roadmapids,
				scene:form_scene,i18n:i18n,
				afterSave:function(instance_id){
					GridManager.refreshGrid(grid_name);
				}
			}).setInstance(0);
		});
	});
};
PopgridObject.prototype.setpane=function(){
	var self=this,so=this.options;
	if(so.column_template_bs64.length==0){
		$.ajaxSettings.async = false;
		$.getJSON('/readgridblock',{idf:so.identifier,scene:so.scene},function(m){
			if(m.Code=="100"){
				so.filter_block_bs64 = m.Filter_block_bs64;
				so.filter_inputs_bs64 = m.Filter_inputs_bs64;
				so.grid_dependency_bs64 = m.Grid_dependency_bs64;
				so.column_template_bs64 = m.Column_template_bs64;
				so.column_block_bs64 = m.Column_block_bs64;
				so.pagesize = m.Rows_per_page;
			}
		});
		$.ajaxSettings.async = true;
	}
	var jscode=$.base64.decode(so.column_template_bs64);
	jscode+='column_data='+$.base64.decode(so.column_block_bs64)+';';
	eval(jscode);
	var gd='';
	if(so.grid_dependency_bs64.length>0){gd=$.base64.decode(so.grid_dependency_bs64);}
	include_queue(self,gd);
};
PopgridObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
PopgridObject.prototype.init=function(){
	this.i18n_options();
	i18n=this.options.i18n;
	var self=this,so=this.options;
	var thebox=this.element;
	grid_name='popgrid_'+so.identifier;
	gridentity_id = so.entity_id;
	gridsubentity = so.subentity;
	roadmapids = so.roadmapids;
	grid_scene = so.scene;
	form_scene = so.form_scene;
	form_dependency = so.form_dependency_bs64;
	view_scene = so.view_scene;
	view_dependency = so.view_dependency_bs64;
	thebox.append('<div id="'+self.po+'" style="z-index: '+so.zindex+';"></div>');
	var ao=thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.35);
	var dh=so.height;
	var txt= '<div id="'+self.pp+'" style="display: none;';
	txt += 'width:'+so.width+'px;height:'+dh+'px;">';
	txt += '<span id="pg_close_icon"><i class="fa fa-close"></i></span>';
	txt += '<div class="pg_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
	txt += '<div id="pop_filter" class="filter" style="width:100%;height:34px;margin-left:-1px"></div>';
	txt += '<table id="pop_grid" style="margin:0px;overflow: auto;width:100%;height:'+(dh-104)+'px;"></table>';
	txt += '<div class="pg_panebtm">';
	txt += '<span class="pg_button" id="pg_close"><i class="fa fa-times-circle-o">&nbsp;'+so.closeText+'</i></span>';
	txt += '</div>';
	txt += '</div>';
	thebox.append(txt);
	var pane = thebox.find('#'+self.pp);
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('#pg_close_icon').off("click").on("click",function(event){
		event.stopPropagation();	self.close_pane();
	});
	thebox.find('#pg_close').off("click").on("click",function(event){
		event.stopPropagation();	self.close_pane();
	});
	self.setpane();
};
$.fn.Popgrid=function(options){
	var apop=new PopgridObject(this,options);
	apop.init();
	return apop;
};