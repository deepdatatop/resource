/*Value offset object: Center on the average, and show the left and right deviations*/
function VOffsetObject(element,options){
	this.element=element;
	this.defaults={
	};
	this.options=$.extend({},this.defaults,options);
	this.value='';
};
VOffsetObject.prototype.init=function(){
    var self=this;
    var thebox=this.element;
    self.value=thebox.attr('v');
    var txt='<div class="voleft"><div class="lvalue"></div></div><div class="voright"><div class="rvalue"></div></div><div class="v">'+self.value+'</div>';
    thebox.append(txt);
};
VOffsetObject.prototype.getVal=function(){
	return parseFloat(this.value);
}
VOffsetObject.prototype.setScale=function(minv,maxv,avgv){
	var thebox=this.element;
	var v=this.getVal();
	var dl=avgv-minv,dr=maxv-avgv;
	var dd=Math.max(dl,dr);
	if(dd>0){
		if(v<=avgv){
			var start=Math.max(avgv-dd,0);
			var x=Math.round((v-start)*100/dd);
			thebox.find('.lvalue').width(x+'%');
			thebox.find('.rvalue').width('0%');
		}else{
			var x=Math.round((v-avgv)*100/dd);
			thebox.find('.lvalue').width('100%');
			thebox.find('.rvalue').width(x+'%');
		}
	}
}
$.fn.VOffset=function(options){
	var vo=new VOffsetObject(this,options);
	vo.init();
	return vo;
};