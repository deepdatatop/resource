function NeattextObject(element,options){
	this.element=element;
	this.defaults={
		txt_subject: '文本规整',
		height: 400,
		onChange: function(data){}
	};
	this.options=$.extend({},this.defaults,options);
	this.toolbarheight=32;
};
NeattextObject.prototype.init=function(){
	var self=this;
	var thebox=this.element;
    thebox.empty();
	var tb_height=self.toolbarheight-1;
	var txt='<div id="neat_toolbar" style="height:'+tb_height+'px;line-height:'+tb_height+'px;">';
	txt+='<div style="float:left;">'+self.options.txt_subject+':</div>';
	txt+='</div>';
	var height=self.options.height-tb_height;
	txt+='<textarea id="neat_ta" style="height:'+height+'px;"></textarea>';
	txt+='<div id="neat_screen"></div>';
    thebox.append(txt);
	thebox.find('#done').on("click",function(event){
		event.stopPropagation();
		alert('done');
	});
};
/*采用图形展示 TAB 中文空格、英文空格、回车*/
$.fn.Neattext=function(options){
	var atext=new NeattextObject(this,options);
	atext.init();
	return atext;
};