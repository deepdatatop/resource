function PopitemObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		eid:0,
		codeset:'',
		language:2,
		width:480,
		height:600,
		zindex:2000,
		onClose: function(){},
		txt_caption:'caption',
		txt_close:'close'
	};
	this.po='popitem_overlay';
	this.pp='popitem_pane';
	this.options=$.extend({},this.defaults,options);
};
PopitemObject.prototype.close_pane=function(){
	this.options.onClose();
	this.element.find('#'+this.po).remove();
	this.element.find('#'+this.pp).remove();
};
PopitemObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
PopitemObject.prototype.init=function(){
	this.i18n_options();
	var header_footer=70;
	var self=this,thebox=this.element,so=this.options;
	thebox.append('<div id="'+self.po+'" style="z-index: '+so.zindex+';"></div>');
	thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.35);
	var txt= '<div id="'+self.pp+'" style="width:'+so.width+'px;height:'+so.height+'px;">';
	txt += '<span class="pi_window_icon"><i class="fa fa-window-maximize"></i></span>';
	txt += '<span class="pi_window_icon pi_window_hide"><i class="fa fa-window-restore"></i></span>';
	txt += '<span id="pi_close_icon"><i class="fa fa-close"></i></span>';
	txt += '<div class="pi_paneheader"><span id="thetitle">'+so.txt_caption+'</span></div>';
	txt += '<div id="codeitems" style="height:'+(so.height-header_footer)+'px;">';
	txt += '</div>';
	txt += '<div class="pi_panebtm"><span class="pi_button" id="pi_close"><i class="fa fa-times-circle-o">&nbsp;'+so.txt_close+'</i></span></div>';
	txt += '</div>';
	thebox.append(txt);
	var pane = thebox.find('#'+self.pp);
	var modal_width=pane.outerWidth(),modal_height=pane.outerHeight(); 
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	//max-restore
	thebox.find('.pi_window_icon').off("click").on("click",function(event){
		thebox.find('.pi_window_icon').removeClass('pi_window_hide');
		event.stopPropagation();
		$(this).addClass('pi_window_hide');
		var bk = thebox.find('#'+self.po);
		var maxW=bk.outerWidth(),maxH=bk.outerHeight();
		if($(this).find('.fa-window-maximize').length>0){
			pane.css({"margin-left":-(maxW/2)+"px","margin-top":-(maxH/2)+"px","width":maxW+"px","height":maxH+"px"});
			thebox.find('#codeitems').css({"height":(maxH-header_footer)+"px"});
		}else{
			pane.css({"margin-left":-(modal_width/2)+"px","margin-top":-(modal_height/2)+"px","width":modal_width+"px","height":modal_height+"px"});
			thebox.find('#codeitems').css({"height":(modal_height-header_footer)+"px"});
		}
	});
	thebox.find("#codeitems").TreeEditor({
		i18n:so.i18n,
		editor_type:'popup',
		language:so.language,
		codeset:so.codeset,
		eid:so.eid,show_code:true
	});
	thebox.find('#pi_close').off("click").on("click",function(event){
			event.stopPropagation();	self.close_pane();
	});
	thebox.find('#'+self.po).off("click").on("click",function(event){});
	thebox.find('#pi_close_icon').off("click").on("click",function(event){self.close_pane();});

	/*var aos='position: fixed;z-index: '+so.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
	thebox.append('<div id="'+self.eo+'" style="'+aos+'"></div>');
	var ao=thebox.find('#'+self.eo).css({"display":"block",opacity:0}).fadeTo(200,0.2);
	var txt='<div id="'+self.pane+'" style="display: none;';
	txt+='width:'+so.width+'px;height:'+so.height+'px;';
	txt+='overflow:hidden;background:#FFFFFF;padding:10px;border:#b3b1b3 solid 1px">';
	txt+='<div style="width:100%;"><span>'+so.txt_caption+'</span></div>';
	var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
	ats+='background-repeat: no-repeat;right: 2px;top: 2px;cursor: pointer;';
	txt+='<span id="close_icon" style="'+ats+'"></span>';
	txt+='<div id="codeitems" style="overflow:hidden;border:solid 1px #dadada;width:100%;height:'+(self.options.height-50)+'px;"></div>';
	txt+='<div style="text-align:center;width:100%;margin-top:2px">';
	txt+='<button id="close">'+so.txt_close+'</button>';
	txt+='</div>';
	txt+='</div>';
	thebox.append(txt);
	
	pane = thebox.find('#'+self.pane);
	pane.find("#codeitems").TreeEditor({
		i18n:so.i18n,
		editor_type:'popup',
		language:so.language,
		codeset:so.codeset,
		eid:so.eid
	});
	var modal_width=pane.outerWidth(); var modal_height=pane.outerHeight();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,
			"left":"50%","margin-left":-(modal_width/2)+"px","top":"50%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('#close_icon').off('click').on('click',function(event){
		event.stopPropagation();
		self.close_pane();
	});
	thebox.find('#close').off('click').on('click',function(event){
		event.stopPropagation();
		self.close_pane();
	});*/
};

$.fn.Popitem=function(options){
	var apop=new PopitemObject(this,options);
	apop.init();
	return apop;
};