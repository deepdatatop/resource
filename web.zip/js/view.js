
function incFontsize(){
		var ht=[];
		var fontsizes=[150,200,150,150],lineheights=[50,40,50,50];
		var cssContainer = $('#ht_fontsize');
		if(cssContainer.length > 0){
			var base = parseFloat(cssContainer.attr('base'));
			base += (base/10);
			if(base<=300){
				var n=lineheights.length;
				for(var i=0;i<n;i++){
					var fontsize = Math.ceil(fontsizes[i]*base/100);
					var lineheight = Math.ceil(fontsize*(1+lineheights[i]/100));
					var classname='.ht_size';
					if(i>0){classname+=i.toString();}
					ht.push(classname+' {font-size:'+fontsize.toString()+'%;line-height:'+lineheight.toString()+'%;}');
				}
		    	cssContainer.empty().append(ht.join(''));
				cssContainer.attr('base',base.toString());
			}
		}
};
function decFontsize(){
		var ht=[];
		var fontsizes=[150,200,150,150],lineheights=[50,40,50,50];
		var cssContainer = $('#ht_fontsize');
		if(cssContainer.length > 0){
			var base = parseFloat(cssContainer.attr('base'));
			base -= (base/10);
			if(base>=40){
				var n=lineheights.length;
				for(var i=0;i<n;i++){
					var fontsize = Math.ceil(fontsizes[i]*base/100);
					var lineheight = Math.ceil(fontsize*(1+lineheights[i]/100));
					var classname='.ht_size';
					if(i>0){classname+=i.toString();}
					ht.push(classname+' {font-size:'+fontsize.toString()+'%;line-height:'+lineheight.toString()+'%;}');
				}
		    	cssContainer.empty().append(ht.join(''));
				cssContainer.attr('base',base.toString());
			}
		}
};

function thumbsup(src,dst,ss){/*tot:thumbsups, sub:thumbsup*/
		var txt = ss.replace(/`/g, '"');
		try{
			var obj= JSON.parse(txt);
			obj['tot'] = 'thumbsups';
			obj['sub'] = 'thumbsup'
			$.getJSON('/iptracking',obj,function(m){
				if(m.Code=='100'){
					$('#'+dst).text(m.Total);
					var osrc=$('#'+src);
					//---tipso
					osrc.attr('data-tipso',m.Msg);
					osrc.tipso({useTitle:false,delay:0,background:'#4682B4',color:'#ffffff'});
					osrc.off('mouseover mouseout');
					osrc.tipso('show');
					var tm=setInterval(function(){
						osrc.tipso('hide');osrc.removeAttr('data-tipso');
						clearInterval(tm);
					},1000);	
					//---tipso
				}
			});
		}catch(err){
			alert(err);
		}
}
	
