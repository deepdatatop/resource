	function TextImportObject(element,options){
		this.element=element;
		this.defaults={
			width:900,
			height:500,
			zindex:20000,
			identifyGBT9704:0,
			identifyContract:0,
			onRevise:function(pid,textareaid){},
			onImport:function(pid,fmt,val,rmvspace){},
			onCancel:function(id){}
		};
		this.id='';
		this.eo='ti_overlay';
		this.pane='ti_pane';
		this.options=$.extend({},this.defaults,options);
    };
	TextImportObject.prototype.close_pane=function(){
		this.element.find('#'+this.eo).remove();
		this.element.find('#'+this.pane).remove();
	};
	TextImportObject.prototype.show_pane=function(id){
		var self=this;
		var thebox=this.element;
		self.id=id;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.eo+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.eo).css({"display":"block",opacity:0}).fadeTo(200,0.2);
		var txt='<div id="'+self.pane+'" style="display: none;';
		txt+='width:'+self.options.width+'px;height:'+self.options.height+'px;';
		txt+='overflow:hidden;background:#FFFFFF;padding:18px;border:#000000 solid 1px">';
		txt+='<div style="width:100%;">';
		txt+='<span class="fa-stack" style="color:#84bbf3">';
		txt+='<i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-paste fa-stack-1x"></i></span>';
		txt+='<span style="font-size:20px">请输入需导入的文本：</span></div>';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 2px;top: 2px;cursor: pointer;';
		txt+='<span id="close_icon" style="'+ats+'"></span>';
		txt+='<div style="text-align:center;width:100%;height:430px;">';
		txt+='<textarea id="intext" style="outline:none;width:100%;height:100%">';
		txt+='</textarea></div>';
		txt+='<div style="width:100%;margin-top:4px;">'
		txt+='<div style="width:70%;display:inline-block">';
		var n=self.options.identifyGBT9704+self.options.identifyContract;
		if(n>0){
			txt+='<span style="margin-top:10px;font-size:20px;line-height:30px">内容格式：</span>';
			txt+='<select id="format"><option value="normal">普通文本</option>';
			if(self.options.identifyGBT9704>0){
				txt+='<option value="GBT9704" selected>党政公文</option>';
			}
			if(self.options.identifyContract>0){
				txt+='<option value="contract">合同</option>';
			}
			txt+='</select>';
		}
		//txt+='<span style="margin-top:10px;font-size:20px;line-height:30px">去空格？</span>';
		//txt+='<div id="switch" class="switch yesno"><input id="rmvspace" type="checkbox"><label><i></i></label></div>';
		txt+='</div>';
		txt+='<div style="width:30%;display:inline-block">';
		txt+='<button id="revise" class="ti_button">格式校正</button>';
		txt+='<button id="import" class="ti_button">导入</button></div>';
		txt+='</div>';
		txt+='</div>';
		thebox.append(txt); pane = thebox.find('#'+self.pane);
		var modal_width=pane.outerWidth(); var modal_height=pane.outerHeight();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,
				"left":"50%","margin-left":-(modal_width/2)+"px","top":"50%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		
		thebox.find('#close_icon').off('click').on('click',function(event){
			event.stopPropagation();
			self.close_pane();
			self.options.onCancel(self.id);
		});
		thebox.find('#revise').off('click').on('click',function(event){
			event.stopPropagation();
			self.options.onRevise(self.id,"intext");
		});
		thebox.find('#import').off('click').on('click',function(event){
			event.stopPropagation();
			var fmt='normal';
			var format=thebox.find('#format');
			if(format.length>0){fmt=format.val();};
			var v=thebox.find('#intext').val();
			//var rmvspace=thebox.find('#rmvspace').prop("checked");
			var rmvspace=false;
			self.close_pane();
			self.options.onImport(self.id,fmt,v,rmvspace);
		});
	};
    $.fn.TextImport=function(options){
		var aDialog=new TextImportObject(this,options);
		return aDialog;
    };