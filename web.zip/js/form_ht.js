/*HierarchyText interface function used for form html>> */
	function readTreetext(){
		var entity_id=$('#entity_id').val();
		var instance_id=$('#instance_id').val();
		var dt={Code:'200',Msg:'read tree text error!'};
		$.ajaxSettings.async = false;
		$.getJSON('/readtreetext',{eid:entity_id,iid:instance_id,obj:'paragraph'},function(m){dt=m;});
		$.ajaxSettings.async = true;
		return dt;
	}
	function saveHierarchytext(s_new,s_rmv,s_par,s_pos,s_pts,s_cts){
		var dt={Code:'200',Msg:'save hierarchy text error!'};
		var entity_id=$('#entity_id').val();
		var instance_id=$('#instance_id').val();
		var subentity='paragraph';
		$.ajaxSettings.async = false;
		$.getJSON('/savehierarchytext',{eid:entity_id,iid:instance_id,obj:subentity,
				new:s_new,rmv:s_rmv,par:s_par,pos:s_pos,pts:s_pts,cts:s_cts},
				function(m){
					dt=m;
				});
		$.ajaxSettings.async = true;
		return dt;					
	}
	function saveRecentAppendix(src,tag){
		var user_id=$('#user_id').val();
		var language_id=$('#language_id').val();
		var scene='appendix'; var data={scene:scene,src:src,tag:tag};
		$.getJSON('/saveinstance',{idf:'user',sub:'recent'+scene,rmi:user_id,dat:$.base64.encode(JSON.stringify(data)),lid:language_id},
				function(m){if(m.Code!='100'){alert(m.Msg);}});
	}
	function readRecentAppendix(){
		var user_id=$('#user_id').val();
		var recent_appendix=[];
		$.ajaxSettings.async = false;
		$.getJSON('/getdatagrid',{wgt:'RCNT',scene:'appendix',idf:'user',rmi:user_id},function(m){
			if(m.status=='success'){
				var allid=[];
				var n=m.data.length;
				for(var i=0;i<n;i++){
					var data=m.data[i];
					var mid=$.md5(data.src);
					if(allid.indexOf(mid)==-1){
						allid.push(mid);
						recent_appendix.push({src:data.src,tag:data.tag});
					}
				}
			}
		});
		$.ajaxSettings.async = true;
		return recent_appendix;
	}
	function saveRecentQRcode(code,tag){
		var user_id=$('#user_id').val();
		var language_id=$('#language_id').val();
		var scene='qrcode'; var data={scene:scene,code:code,tag:tag};
		$.getJSON('/saveinstance',{idf:'user',sub:'recent'+scene,rmi:user_id,dat:$.base64.encode(JSON.stringify(data)),lid:language_id},
				function(m){if(m.Code!='100'){alert(m.Msg);}});
	}
	function readRecentQRcode(){
		var user_id=$('#user_id').val();
		var recent_qrcode=[];
		$.ajaxSettings.async = false;
		$.getJSON('/getdatagrid',{wgt:'RCNT',scene:'qrcode',idf:'user',rmi:user_id},function(m){
			if(m.status=='success'){
				var allid=[];
				var n=m.data.length;
				for(var i=0;i<n;i++){
					var data=m.data[i];
					var mid=$.md5(data.code);
					if(allid.indexOf(mid)==-1){
						allid.push(mid);
						recent_qrcode.push({code:data.code,tag:data.tag});
					}
				}
			}
		});
		$.ajaxSettings.async = true;
		return recent_qrcode;
	}
/* << HierarchyText function*/