function StaticObject(element,options){
	this.element=element;
	this.defaults={
		value:'',
		visible: false
	};
	this.value='';
	this.options=$.extend({},this.defaults,options);
};
StaticObject.prototype.value=function(){
	return this.value;
};
StaticObject.prototype.setValue=function(val){
	this.value=val;
};
StaticObject.prototype.init=function(){
	var thebox=this.element,so=this.options;
	this.value=so.value;
	if(so.visible){
		thebox.append('<span>'+this.value+'</span>');
	}
};
$.fn.Static=function(options){
	var astatic=new StaticObject(this,options);
	astatic.init();
	return astatic;
};