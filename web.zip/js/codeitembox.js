	function CodeItemBoxWidget(element,options){
		this.element=element;
		this.defaults={
			codeitem_url: '/readcodeitem',
			codeset: '',
			language: 2,
			t_ordinalposition:'1-9',
			t_code: 'Code',
			t_name: 'Name',
			t_description: 'Description'
		};
		this.options=$.extend({},this.defaults,options);
    };
    CodeItemBoxWidget.prototype.refresh=function(){
    		this.load();
    	};
	CodeItemBoxWidget.prototype.load=function(){
		var self=this;
		var thebox=this.element;
		thebox.empty();
		var ss='<table id="codeitem" border="0" width="100%" cellspacing="0" cellpadding="0" align="center">';
		ss += '<tr bgColor="#E8F1FA">';
		ss += '<td width="10%" class="colcaption" align="center">'+self.options.t_ordinalposition+'</td>';
		ss += '<td width="20%" class="colcaption" align="center">'+self.options.t_code+'</td>';
		ss += '<td width="50%" class="colcaption" align="center">'+self.options.t_name+'</td>';
		ss += '<td width="20%" class="lastcol" align="center">'+self.options.t_description+'</td></tr>';
		ss += '</table>';
		thebox.append(ss);
		var table=thebox.find('#codeitem');
		$.getJSON(self.options.codeitem_url,{cst:self.options.codeset,lid:self.options.language},function(m){
			if(m.Code=="100"){
				var i=0;
				$(m.Items).each(function(){
					var rowback = 'zebrarow';
					if(i%2==0){rowback='whiterow';}
					ss='<tr class="row '+rowback+'" id="'+m.Id+'"><td class="datacol" align="center">'+(i+1)+'</td>';
					ss+='<td class="datacol">'+this.Code+'</td><td class="datacol">'+this.Name+'</td>';
					ss+='<td class="lastcol">'+this.Description+'</td></tr>'
					table.append(ss);
					i ++;
				});
			}else{alert(m.Code+' '+m.Msg);}
		});
		/*table.find('.row').on('click',function(event){
			event.stopPropagation();
		});*/
	};
    $.fn.CodeItemBox=function(options){
		var aBox=new CodeItemBoxWidget(this,options);
		aBox.load();
		return aBox;
    };
