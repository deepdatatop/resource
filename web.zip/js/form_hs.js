/*HierarchySet interface function used for form html>> */
	function readTreeset(){
		var entity_id=$('#entity_id').val();
		var instance_id=$('#instance_id').val();
		var dt={Code:'200',Msg:'read tree text error!'};
		$.ajaxSettings.async = false;
		$.getJSON('/readtreeset',{eid:entity_id,iid:instance_id,obj:'document'},function(m){dt=m;});
		$.ajaxSettings.async = true;
		return dt;
	}
	function saveHierarchyset(s_new,s_rmv,s_par,s_pos,s_nts,s_cts){
		var dt={Code:'200',Msg:'save hierarchy set error!'};
		var entity_id=$('#entity_id').val();
		var instance_id=$('#instance_id').val();
		var subentity='document';
		$.ajaxSettings.async = false;
		$.getJSON('/savehierarchyset',{eid:entity_id,iid:instance_id,obj:subentity,
				new:s_new,rmv:s_rmv,par:s_par,pos:s_pos,nts:s_nts,cts:s_cts},function(m){dt=m;});
		$.ajaxSettings.async = true;
		return dt;					
	}
/* << HierarchySet function*/