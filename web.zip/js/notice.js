function NoticeObject(element,options){
	this.element=element;
	this.defaults={
		identifier: 'backgroundtask',
		scene: 'notice',/*_list*/
		morelink_url: '/notices',
		height:200
	};
	this.options=$.extend({},this.defaults,options);
	this.data=[];
};
NoticeObject.prototype.setData=function(){
	var thebox=this.element,so=this.options;
	var link=so.morelink_url;
	var ss='<table id="ntctbl" style="width:100%;font-size:12px;"><tr>';
	ss += '<td><i class="fa fa-bullhorn horn"></i></td>'
	ss += '<td align="right">';
	if(link.length>0){
		ss+='<a href="'+link+'" class="more">...</a>&nbsp;';
	}
	ss+='</td></tr>';
	thebox.append(ss);
	var tbl=thebox.find('#ntctbl');
	var n=this.data.length;
	for(var i=0;i<n;i++){
		var row=this.data[i];
		ss='<tr><td>'+row['time']+'</td><td>'+row['message']+'</td></tr>';
		tbl.append(ss);
	}
}

NoticeObject.prototype.init=function(){
	var self=this,thebox=this.element,so=this.options;
	thebox.css({'height':so.height+'px','overflow':'hidden'});
	$.ajaxSettings.async = false;
	$.getJSON('/getdatalist',{idf:so.identifier,scene:so.scene},function(m){
		/*
		{"status":"success","subentity":"notice","listproperty":["time_created","message"],"totals":26,"data":[{"time":"2024-04-24T08:14:41Z","message":"2024-03-19 下载量：2"}]
		*/
		if(m.status=='success'){
			if(m.hasOwnProperty('data')){
				self.data=m['data'];
			}
		}
	});
	$.ajaxSettings.async = true;
	self.setData();
};
$.fn.Notice=function(options){
	var n=new NoticeObject(this,options);
	n.init();
	return n;
};