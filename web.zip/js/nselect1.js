/*
select one from multiple options
*/
function Nselect1Object(element,options){
	this.element=element;
	var defaults={
		selected: '',/*selected value*/
		language_id: 2,
		codeset: '',/*loopinterval*/
		codesetval: 'id',/*id,code*/
		item_option:[
/*			{value:'left',label:'<i class="fa fa-align-left"></i>'},
			{value:'center',label:'<i class="fa fa-align-center"></i>'},
			{value:'right',label:'<i class="fa fa-align-right"></i>'}*/
   		],
		optionitems: '',/*value1:label1,value2:label2,value3:label3*/
		onChange: function(val){}
	};
	this.options=$.extend({},defaults,options);
};
Nselect1Object.prototype.init=function(){
	var self=this,thebox=this.element,so=this.options;
	if(so.optionitems.length>0){
		var oo=so.optionitems.split(',');
		for(var i=0,n=oo.length;i<n;i++){
			var o=oo[i].split(':');
			if(o.length>0){
				so.item_option.push({value:o[0],label:o[1]});
			}
		}
	}else{
		if(so.codeset.length>0){
			$.ajaxSettings.async = false;
			$.getJSON('/readcodes',{lid:so.language_id,cst:so.codeset},function(m){
				if(m.Code=="100"){
					$(m.Children).each(function(){
						var o={label:this.Name};
						if(so.codesetval=='id'){
							o['value']=this.Id;
						}else{
							o['value']=this.Code;
						}
						so.item_option.push(o);
					});
					
				}else{alert(m.Code+m.Msg);}
			});
			$.ajaxSettings.async = true;
		}
	}
	thebox.empty();
	var n=so.item_option.length;
	for(var i=0;i<n;i++){
		var value=so.item_option[i].value;
		var label=so.item_option[i].label;
		var ss='<span class="nselect1_button nselect1_';
		if(value==so.selected){ss+='selected';}else{ss+='normal';}
		ss+='" id="'+value+'">'+label+'</span>';
		thebox.append(ss);
	}
	thebox.find('.nselect1_normal').on('click',function(event){
		var val=$(this).attr('id');
		self.Select(val);
		so.onChange(val);
	});
};
Nselect1Object.prototype.Select=function(val){
	var self=this,thebox=this.element;
	var s_class='nselect1_selected';
	var i=thebox.find('#'+val);
	if(i.length>0){
		if(!i.hasClass(s_class)){
			var n_class='nselect1_normal';
			thebox.find('.'+s_class).removeClass(s_class).addClass(n_class).on('click',function(event){
				var val=$(this).attr('id');
				self.Select(val);
				self.options.onChange(val);
			});
			i.removeClass(n_class).addClass(s_class);
			i.off('click');
		}
	}
};
Nselect1Object.prototype.Value=function(){
	return this.element.find('.nselect1_selected').attr('id');
}
$.fn.Nselect1=function(options){
	var a=new Nselect1Object(this,options);
	a.init();
	return a;
};