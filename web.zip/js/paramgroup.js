function ParamgroupObject(element,options){
	this.element=element;
	this.defaults={
		title: 'abc',
		i18n: {},
		min_height: 200,
		identifier: 'paymentgateway',
		interface_scene: 'param',
		roadmapids: '1',
		initial_base64: '',
		onChange: function(val){}
	};
	this.idnames={};
	this.nameids={};
	this.form_data={};
	this.editor_objects={};/*same as userinterface.makeEditorJS*/
	this.editor_types={};
	this.options=$.extend({},this.defaults,options);
};
ParamgroupObject.prototype.isempty=function(o){
	var flag=false;
	if(!o && typeof(o)!='undefined'){
		flag=true;
	}
	return flag;
};
ParamgroupObject.prototype.propertymodified=function(property,dt){
	this.form_data[property]=$.trim(dt);
	var o={};
	for(var key in this.form_data) {
		if(this.idnames.hasOwnProperty(key)){
			var nm=this.idnames[key];
			o[nm]=this.form_data[key];
		}
	}
	this.options.onChange(JSON.stringify(o));
};
ParamgroupObject.prototype.resetData=function(id_nms){
	//renew this.idname,this.form_data
	var o_nm_ids={};
	for(var id in this.idnames){
		var nm=this.idnames[id];
		o_nm_ids[nm]=id;
	}
	var o_form_data={};
	for(var id in this.form_data){o_form_data[id]=this.form_data[id];}
	this.form_data={};this.idnames={};
	for(var id in id_nms){
		var nm=id_nms[id]; this.idnames[id]=nm;
		if(o_nm_ids.hasOwnProperty(nm)){
			var o_id=o_nm_ids[nm];
			if(o_form_data.hasOwnProperty(o_id)){
				this.form_data[id]=o_form_data[o_id];
			}
		}
	}
};
ParamgroupObject.prototype.reset=function(){
	this.setBlock(1);
};
ParamgroupObject.prototype.setBlock=function(reset){
	var self=this,so=this.options;
	var thebox=this.element;
	$.getJSON('/readdynamicformblock',{idf:so.identifier,scene:so.interface_scene,pid:so.roadmapids},function(m){
		if(m.Code=='100'){
			thebox.append($.base64.decode(m.Form_block));
			if(m.IDnames.length>0){
				var id_nms=JSON.parse($.base64.decode(m.IDnames));
				if(reset==1){
					self.resetData(id_nms);
				}else{
					self.idnames=id_nms;
				}
				for(var id in self.idnames){
					var nm=self.idnames[id];
					self.nameids[nm]=id;
				}
				var data=so.initial_base64;
				if(data.length>0){
					var o=JSON.parse($.base64.decode(data));
					for(var nm in o){
						if(self.nameids.hasOwnProperty(nm)){
							var id=self.nameids[nm];
							self.form_data[id]=o[nm];
						}
					}
				}
			}
			if(!self.isempty(m.Textinputs)){
				m.Textinputs.forEach(function(item){
					var ss='';
					if(self.form_data.hasOwnProperty(item.Property)){ss=self.form_data[item.Property];}
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).val(ss).on('input propertychange',function(e){
						self.propertymodified(item.Property,$(this).val());
						e.preventDefault();
					});
				});
			}
			if(!self.isempty(m.Selectors)){
				m.Selectors.forEach(function(item){
					var selected='';
					if(self.form_data.hasOwnProperty(item.Property)){
						var v=self.form_data[item.Property];
						var vv=v.split('.');
						if(vv.length>0){selected=vv[0];}
					}
					var cs='',op=[],nm='Codeset';
					if(item.hasOwnProperty(nm)){
						cs=item[nm];
					}
					nm='Options';
					if(item.hasOwnProperty(nm)){
						var i_o=item[nm];
						if(i_o.length>0){op=JSON.parse($.base64.decode(i_o));}
					}
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Selector({
						codeset:cs,item_option:op,multiple_choice:false,language:item.Clientlanguage,
						onChange: function(id,ids,codes,labels,dotids,pathnames){
							var rt='';
							switch(item.Result){
								case 'value.label':
									var vv=[];
									for(var i=0,n=ids.length;i<n;i++){
										vv.push(ids[i]+'.'+labels[i]);
									}
									rt=vv.join();
									break;
								case 'codes':rt=codes.join();break;
								case 'dotids':rt=dotids.join();break;
								default:rt=ids.join();break;
							}
							self.propertymodified(item.Property,rt);
						}
					}).setResult(selected);
				});
			}
		}
	});
};
ParamgroupObject.prototype.setupWidget=function(){
	var self=this;
	var thebox=this.element;
	self.setBlock(0);
};
ParamgroupObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
ParamgroupObject.prototype.init=function(){
	this.i18n_options();
	this.setupWidget();
};
$.fn.Paramgroup=function(options){
	var agroup=new ParamgroupObject(this,options);
	agroup.init();
	return agroup;
};