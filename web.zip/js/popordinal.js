/*dependence:jquery-1.8.3.js, gm.js, gm.css*/
	function PopordinalObject(element,options){
		this.element=element;
		this.defaults={
			txt_caption:'Please adjust item position:',
			txt_close:'Close',
			entity_id:'28',
			entity_extension:'recommend',
			support_moverow:false,
			column_data:[],
			onClose: function(){},
			width:960,
			height:480,
			zindex:20000
		};
		this.eo='gridpopup_overlay';
		this.pane='gridpopup_pane';
		this.options=$.extend({},this.defaults,options);
    };
	PopordinalObject.prototype.close_pane=function(){
		this.options.onClose();
		this.element.find('#'+this.eo).remove();
		this.element.find('#'+this.pane).remove();
	};
	PopordinalObject.prototype.setClassCSS=function(classnames,cssvalues){//sample:setClassCSS('aclass','font-size:24px;color: green;');
		var id='gridpopup-class';
		var cssContainer = $('#'+id);
	    if(cssContainer.length == 0){
	        cssContainer = $('<style id="'+id+'"></style>');
	        cssContainer.appendTo($('head'));
	    }
		cssContainer.empty();
		for(var i=0,n=classnames.length;i<n;i++){
			cssContainer.append('.'+classnames[i]+ ' {'+cssvalues[i]+'}');
		}
	};
	PopordinalObject.prototype.init=function(){
		var self=this;
		//var classnames=['echo-success','echo-failure','echo-normal','echo-over'];
		//var cssvalues=['color:green;padding-left:20px;','color:maroon;padding-left:20px;','color:black;','color:red;font-weight:bold;'];
		//self.setClassCSS(classnames,cssvalues);
		var thebox=this.element;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.eo+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.eo).css({"display":"block",opacity:0}).fadeTo(200,0.2);
		var txt='<div id="'+self.pane+'" style="display: none;';
		txt+='width:'+self.options.width+'px;height:'+self.options.height+'px;';
		txt+='overflow:hidden;background:#FFFFFF;padding:10px;border:#b3b1b3 solid 1px">';
		txt+='<div style="width:100%;">';
		txt+='<span><i class="fa fa-thumb-tack" style="color:#8b0000"></i>&nbsp;'+self.options.txt_caption+'</span></div>';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 2px;top: 2px;cursor: pointer;';
		txt+='<span id="close_icon" style="'+ats+'"></span>';
		txt+='<table id="main" style="border:solid 1px #dadada;width:100%;height:'+(self.options.height-50)+'px;overflow-y:scroll;"></table>';
		txt+='<div style="text-align:center;width:100%;margin-top:2px">';
		txt+='<button id="close">'+self.options.txt_close+'</button>';
		txt+='</div>';
		txt+='</div>';
		thebox.append(txt);
		thebox.find('#main').GM({gridManagerName:'popupgrid',
			height: (self.options.height-50)+'px',
			supportAjaxPage:true,
			ajaxData: '/getdatagrid',
			ajaxType: 'POST',
			query: {wgt:'GM',scene:self.options.entity_extension,eid:self.options.entity_id},
			columnData: self.options.column_data,
			supportMoveRow: self.options.support_moverow,
			moveRowConfig: {
	      		handler: (list, tableData) => {
					var n=list.length;
					if(n>0){
						var ids=new Array();
						var minipos=-1;
						for(var i=0;i<n;i++){
							ids.push(list[i].id);
							var pos=parseInt(list[i].position);
							if(minipos<0){minipos = pos;}else{if(pos<minipos){minipos=pos;}}
						}
						/*update tableData position*/
						for(var i=0;i<n;i++){list[i].position=minipos+i;}
						$.getJSON('/batchsetpos',{eid:self.options.entity_id,ext:self.options.entity_extension,start:minipos,ids:ids.join()},
							function(m){
								if(m.Code!='100'){alert(m.Msg);}
							}
						);
					}
				}			
			}
		});
		pane = thebox.find('#'+self.pane);
		var modal_width=pane.outerWidth(); var modal_height=pane.outerHeight();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,
				"left":"50%","margin-left":-(modal_width/2)+"px","top":"50%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#close_icon').off('click').on('click',function(event){
			event.stopPropagation();
			self.close_pane();
		});
		thebox.find('#close').off('click').on('click',function(event){
			event.stopPropagation();
			self.close_pane();
		});
	};

    $.fn.Popordinal=function(options){
		var apop=new PopordinalObject(this,options);
		apop.init();
		return apop;
    };