function modifyAPXtag(dom,src){
	var self=$(dom);
	var mid=self.attr('mid');
	var text=self.text();
	$('body').SimpleInputDialog({
		//okText:'{{.t_ok}}',
		//cancelText:'{{.t_cancel}}',
		//hintText:'{{.t_inputemail}}',
		doOK:function(text,id){
			var te = new CustomEvent('apx_event',{ 
 				detail:{status:'modified',mid:id,src:src,tag:text}
			});
			window.dispatchEvent(te);
			return true;
		}
	}).textinput(text.trim(),mid);		
}
function removeAPX(dom,tag){
	var self=$(dom);
	var mid=self.attr('mid');
	$('body').YesnoAlert({
		//yesText:obj.options.txt_yes,noText:obj.options.txt_no,
		doyes: function(id,action){
			var te=new CustomEvent('apx_event',{detail:{status:'removed',mid:id}});
			window.dispatchEvent(te);					
		}
	}).show_alertpane(mid,'Remove this appendix'+'['+tag+']?','remove');
}
	function AppendixObject(element,options){
		this.outerID='';
		this.element=element;
		var defaults={
			i18n:{},
			focus_tab: 'history',/*history,link,upload*/
			appendix_capacity: 64,
			screen_columns: 1,
			max_columns: 1,
			cell_align: 'center',
			cell_valign: 'top',
			/*txt_removeornot: 'Remove',*/
			/*exceedcontainerlimit: 'appendix quantity exceed limit:',
			urlduplicated: 'appendix URL duplicated!',*/
			/*selectedStr: 'Selected',*/
			uploadStr: 'Upload file:',/*upload*/
			dragDropStr: '<span>Drag & Drop Files...</span>',/*upload*/
			multiDragErrorStr: 'Multiple File Drag & Drop is not allowed.',/*upload*/
			extErrorStr: 'is not allowed. Allowed extensions: ',/*upload*/
			duplicateErrorStr: 'is not allowed. File already exists.',/*upload*/
			sizeErrorStr: 'is not allowed. Allowed Max size: ',/*upload*/
			uploadErrorStr: 'Upload is not allowed',/*upload*/
			maxFileCountErrorStr: ' is not allowed. Maximum allowed files are:',/*upload*/
			historyStr: 'History',
			linkStr: 'PicURL',
			linkplaceholderStr: 'Input appendix URL and press enter key to submit',
			localStr: 'Local',
			txt_columns: 'cols per row:',
			txt_halign: 'horizontal align:',
			txt_valign: 'vertical align:',
			txt_tag: 'tag',
			txt_src: 'source',
			txt_size: 'size',
			txt_ext: 'extension',
			txt_operation: 'operation',
			txt_choose: 'choose',
			txt_remove: 'remove',
			txt_yes: 'Yes',
			txt_no: 'No',
			txt_emptylist: 'Empty list?',
			txt_srcduplicated: 'Duplicate appendix source, updated.',
			saveRecent:function(src,tag){},
			readRecent:function(){return [];},
			screen:{}/*the output windows for appendix list render*/
		};
		this.options=$.extend({},defaults,options);
		this.cell_align={};
		this.cell_valign={};
		this.column_spinner={};
		this.appendixes=new Array();/*[{"src":"/img/ok.zip","tag":"abc","size":"123K","extension":".png"}]*/
    };
	AppendixObject.prototype.getIndexbyid=function(id){
		var idx=-1;
		for(var i=0;i<this.appendixes.length;i++){
			if($.md5(this.appendixes[i].src)===id){idx=i;break;}
		}
		return idx;
	};
	AppendixObject.prototype.addNew=function(){
		this.showAppendixDialog();
	};
	AppendixObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){
				o[k]=o.i18n[k];
			}
		}
	};
	AppendixObject.prototype.init=function(){
		this.i18n_options();
		var obj=this;
		var self=this.element;
		window.addEventListener('apx_event', function(event){
			var ed=event.detail;
			switch(ed.status){
				case 'modified':
					var idx=obj.getIndexbyid(ed.mid);
					if(idx>=0){
						var o={src:ed.src,tag:ed.tag};
						GridManager.updateRowData(gridname,'src',o);
						obj.setScreenTag(ed.tag,ed.src)
						obj.appendixes[idx].tag=ed.tag;
						obj.modified();
					}
					break;
				case 'removed':
					var idx=obj.getIndexbyid(ed.mid);
					if(idx>=0){
						obj.rmvScreenAppendix(ed.mid);
						obj.appendixes.splice(idx,1);
						obj.modified();
						obj.refresh();
					}
					break;
			}
		});
		self.empty();
		/*var ss='<div style="height:100%;border:solid 1px #f00;"><span class="btn_add appendix_button" style=""><i class="fa fa-paperclip fa-3x"></i></span></div>';
		self.append(ss);*/
		var ss='<div id="a_toolbar" style="width:100%;height:36px;padding-top:2px;overflow:hidden;"><span id="apx" style="font-size:16px;display:inline-block"><i class="fa fa-paperclip"></i></span>';
		if(obj.options.max_columns>1){
			ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_columns+'</span><span id="column_number" style="display:inline-block"></span>';
		}
		if(obj.options.appendix_capacity>1){
			ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_halign+'</span><span id="cellalign" style="display:inline-block"></span>';
			if(obj.options.max_columns>1){
				ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_valign+'</span><span id="cellvalign" style="display:inline-block"></span>';
			}
		}
		ss+='<div style="display:inline-block;position:absolute;right:0px;width:64px;">';
		ss+='<i class="fa fa-2x fa-plus-square-o apx_add"></i>&nbsp;<i class="fa fa-2x fa-trash-o apx_empty apx_hide"></i>'
		ss+='</div>';
		ss+='</div>';
		if(obj.options.appendix_capacity>1){
			ss+='<table id="appendix_table" style="width:100%;"></table>';
		}
		self.append(ss);
		self.find('.apx_empty').on('click',function(){obj.empty();});
		self.find('.apx_add').on('click',function(){obj.addNew();});
		if(obj.options.max_columns>1){
			obj.column_spinner=self.find('#column_number').Spinner({width:60,value:obj.options.screen_columns,max:obj.options.max_columns,
				onChange: function(val){
					obj.options.screen_columns=val;
					obj.resetScreen();
				}
			});
		}
		if(obj.options.appendix_capacity>1){
			obj.cell_align=self.find('#cellalign').StateButton({
				onChange: function(val) {
					obj.options.cell_align=val;
					obj.modified();
					var box=obj.options.screen;
					if(JSON.stringify(box)!='{}'){box.find('td').css('text-align',val);}
				}
			}).Select(obj.options.cell_align);
			if(obj.options.max_columns>1){
				obj.cell_valign=self.find('#cellvalign').StateButton({
					item_option:[
						{value:'top',label:'<i class="fa fa-step-forward fa-rotate-270"></i>'},
						{value:'middle',label:'<i class="fa fa-columns fa-rotate-90"></i>'},
						{value:'bottom',label:'<i class="fa fa-step-forward fa-rotate-90"></i>'}
		        		],
					onChange: function(val) {
						obj.options.cell_valign=val;
						obj.modified();
						var box=obj.options.screen;
						if(JSON.stringify(box)!='{}'){box.find('td').css('vertical-align',val);}				
					}
				}).Select(obj.options.cell_valign);
			}
			var gridname='appendixes';
			self.find('#appendix_table').GM({
				gridManagerName: gridname,
				height: '100% - 36px',
				supportCheckbox: false,
				ajaxData: {totals:0,data:[]},
				columnData: [
					{key: 'tag',text: obj.options.txt_tag,
						template: function(tag, row){
							var ss='<span>';
							ss+='<i mid="'+$.md5(row.src)+'" class="apx_modifytag fa fa-edit"';
							ss+=' onclick="modifyAPXtag(this,\''+row.src+'\')"> '+tag+'</i>';
							ss+='</span>';
							return ss;
						}},
					{key: 'src',text: obj.options.txt_src},
					{key: 'size',text: obj.options.txt_size},
					{key: 'extension',text: obj.options.txt_ext},
					{key: 'operation',text: obj.options.txt_operation,
						template: function(operation, row){
							var ss='<span>';
							ss+='<i mid="'+$.md5(row.src)+'" order="'+row.gm_order+'"';
							ss+=' onclick="removeAPX(this,\''+row.tag+'\')"';
							ss+=' class="rmvapx fa fa-minus-square-o"> '+obj.options.txt_remove+'</i>';
							ss+='</span>';
							return ss;
						},align: 'center'
					}],
				supportMoveRow: true,
				moveRowConfig: {
					handler: (list, tableData) => {
						var n=obj.appendixes.length;
						if(n==tableData.length){
							var mapSrcIndex={};
							var old=[];
							var i_s=-1,i_e=-1;
							for(var i=0;i<n;i++){
								var apx=obj.appendixes[i];
								old.push(apx);
								mapSrcIndex[apx.src]=i;
								if(tableData[i].src!==apx.src){
									if(i_s==-1){i_s=i;}
									i_e=i;
								}
							}
							if(i_e>i_s){
								var id=$.md5(obj.appendixes[i_e].src);
								var ins='head';
								if(obj.appendixes[i_s+1].src==tableData[i_s].src){
									ins='end'; id=$.md5(obj.appendixes[i_s].src);
								}
								/*update screen td ordinal position*/
								var flag=false;
								if(ins=='head'){
									flag=obj.moveupNScreenAppendix(i_s,i_e);
								}else{
									flag=obj.movedownNScreenAppendix(i_s,i_e);
								}
								if(flag){
									obj.appendixes.length=0;
									for(var i=0;i<n;i++){
										var k=mapSrcIndex[tableData[i].src];
										obj.appendixes.push(old[k]);
									}
									obj.modified();
								}
							}
							old.length=0;mapSrcIndex={};
						}
					}
				}
			});
		}
	};
	AppendixObject.prototype.resize=function(){
	};
	AppendixObject.prototype.empty=function(){
		var obj=this;
		if(obj.appendixes.length>0){
			$('body').YesnoAlert({
				yesText:obj.options.txt_yes,noText:obj.options.txt_no,
				doyes: function(id,action){
					var box=obj.options.screen;
					if(JSON.stringify(box)!='{}'){box.find('table').empty();}
					obj.appendixes=[];
					obj.modified();
					obj.refresh();
				}
			}).show_alertpane('',obj.options.txt_emptylist,'empty');
		}		
	};
	AppendixObject.prototype.closeAppendixDialog=function(){
		$('body').find('#i_dialog').remove();
		$('body').find('#dialogbox').remove();
	};
	AppendixObject.prototype.showAppendixDialog=function(){
		var obj=this; var self=this.element; var zindex=20000;
		var thebox=$('body');
		var is='position:fixed;z-index:'+zindex+';top:0px;left:0px;height:100%;width:100%;background:#000;display:none;cursor:pointer;';
		var ds='width:80%;height:300px;z-index:'+(zindex+1)+';background-color:#fff;border:solid 1px #dadada;overflow:hidden;dispay:none;';
		ds+='border-radius:5px;';
		thebox.append('<div id="i_dialog" style="'+is+'"></div>');
		thebox.append('<div id="dialogbox" style="'+ds+'"></div>');
		var idialog=thebox.find('#i_dialog');
		idialog.css({"display":"block",opacity:0}).fadeTo(200,0.2);
		var dialogbox=thebox.find('#dialogbox');
		obj.setupDialog(dialogbox);
		var modal_width=dialogbox.outerWidth(); var modal_height=dialogbox.outerHeight();
		dialogbox.css({"display":"block","position":"fixed","opacity":0,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		dialogbox.fadeTo(200,1);
		idialog.off("click").on("click",function(event){
			obj.closeAppendixDialog();
		});
	};
	AppendixObject.prototype.setupDialog=function(dialogbox){
		var obj=this;
		var captionheight=36;
		var height=dialogbox.innerHeight()-captionheight-3;
		var cts='font:normal 20px/36px arial;'
		var ss='<div class="a_dialogcaption"><span style="'+cts+'"><i class="fa fa-paperclip"></i>添加附件</span><div class="a_dialogclose"><span style="font:normal 18px/24px;"><i class="fa fa-close"></i></span></div></div>';
		ss+='<div id="worktop" style="width:100%;height:'+height+'px;"></div>';
		dialogbox.append(ss);
		dialogbox.find('.a_dialogclose').on('click',function(){obj.closeAppendixDialog();});
		obj.setupWorktop(dialogbox.find('#worktop'));
	};
	AppendixObject.prototype.makeGM_data=function(){
		var gmData = {totals: this.appendixes.length};
		var data=[];//{tag:'123',src:'/img/abc.png',size:'7788',extension:'.png'}
		this.appendixes.forEach(function(appendix){
			data.push({tag:appendix.tag,src:appendix.src,size:appendix.size,extension:appendix.extension});
		});
		gmData['data']=data;
		this.showEmptyBtn();
		return gmData;	
	};
	AppendixObject.prototype.makeRecentGM_data=function(){
		var obj=this;
		var recentappendixes=this.options.readRecent();
		var gmData = {totals: recentappendixes.length};
		var data=[];
		recentappendixes.forEach(function(appendix){
			var tag=appendix.tag;
			if(tag.length==0){tag=obj.extractFilename(appendix.src)}
			data.push({tag:tag,src:appendix.src,extension:obj.fileExt(appendix.src)});
		});
		gmData['data']=data;
		return gmData;	
	};
	AppendixObject.prototype.setupWorktop=function(worktop){
		var obj=this;
		var self=this.element;
		var ss='<div id="a_worktop"><div>';
		ss+='<span class="a_tab_item'+(obj.options.focus_tab=='history'?'_selected':'')+'" id="tab_history">'+obj.options.historyStr+'&nbsp;<i class="fa fa-history"></i></span>';
		ss+='<span class="a_tab_item'+(obj.options.focus_tab=='link'?'_selected':'')+'" id="tab_link">'+obj.options.linkStr+'&nbsp;<i class="fa fa-link"></i></span>';
		ss+='<span class="a_tab_item'+(obj.options.focus_tab=='upload'?'_selected':'')+'" id="tab_upload">'+obj.options.localStr+'&nbsp;<i class="fa fa-upload"></i></span>';
		//ss+='</div><div style="float:right;width:'+obj.options.showcase_width+'px;font:bold 18px Arial;margin-top:5px">';
		//ss+='<i class="fa fa-arrow-down"></i>&nbsp;'+obj.options.selectedStr+'&nbsp;<i class="fa fa-picture-o"></i></div>';
		ss+='</div></div>';
		var tabtopheight=36;
		var height = worktop.innerHeight()-tabtopheight;
		//ss+='<div id="showcase" style="float:right;width:'+(obj.options.showcase_width-1)+'px;height:'+height+'px;';
		//ss+='overflow-x:hidden;overflow-y:scroll;background:#fff;border-left:1px solid #ccc;"></div>';
		ss+='<div id="blockcontainer" style="padding:0px;height:'+height+'px;"></div>';
		worktop.append(ss);
		var blockcontainer=worktop.find('#blockcontainer');
		ss='<div id="apx_grid" class="apx_block"'+(obj.options.focus_tab=='history'?'':' style="display:none"')+'>';
		ss+='<table id="recentapx_table"></table>';
		ss+='</div>';
		var style='width:100%;height:'+height+'px;overflow:hidden;';
		if(obj.options.focus_tab!='link'){style+='display:none;';}
		ss+='<div id="apx_link" style="'+style+'" class="apx_block">';
		var toolbarheight=36;
		ss+='<textarea class="a_hyperlink" style="width:'+(blockcontainer.innerWidth()-2)+'px;height:'+(height-toolbarheight)+'px;"></textarea>';
		ss+='<div style="width:100%;height:'+toolbarheight+'px;font:14px/30px arial;color:#ccc;text-align:right;border-top:solid 1px #ccc;"><span>↸&nbsp;'+obj.options.linkplaceholderStr+'</span>';
		ss+='<span class="a_enter_button" style="display:none"><i class="fa fa-level-down fa-lg fa-rotate-90"></i></span></div>';
		ss+='</div>';
		ss+='<div id="apx_upload" class="apx_block"'+(obj.options.focus_tab=='upload'?'':' style="display:none"')+' style="text-align:center;">';
		ss+='<div class="fileuploader"></div>';
		ss+='</div>';
		blockcontainer.append(ss);
		blockcontainer.find('#recentapx_table').GM({
			gridManagerName: 'recentappendixes',
			height: height+'px',
			disableMoveRow: false,
			supportCheckbox: false,
			ajaxData: obj.makeRecentGM_data(),
			columnData: [
				{key: 'tag',text: obj.options.txt_tag},
				{key: 'src',text: obj.options.txt_src},
				{key: 'extension',text: obj.options.txt_ext},
				{key: 'operation',text: obj.options.txt_choose,
					template: function(operation, row){
						var ss='';
						if(obj.getIndexbyid($.md5(row.src))==-1){
							ss+='<span>';
							ss+='<i class="recentadd fa fa-plus-circle fa-2x"></i>';
							ss+='</span>';
						}
						return ss;
					},align: 'center'
				}
			],
			cellClick: function(row,rowIndex,colIndex){
				var idx=obj.getIndexbyid($.md5(row.src));
				if(idx==-1){
					obj.addAppendix(row.tag,row.src);
					GridManager.updateRowData('recentappendixes','src',{src:row.src});
					obj.refresh();
				}
			}
		});
		var uploadobj=worktop.find(".fileuploader").uploadFile({
			//allowedTypes: at,
			fileCounterStyle: ". ",
			uploadStr: obj.options.uploadStr,
			dragDropStr: obj.options.dragDropStr,
			multiDragErrorStr: obj.options.multiDragErrorStr,
			extErrorStr: obj.options.extErrorStr,
			duplicateErrorStr: obj.options.duplicateErrorStr,
			sizeErrorStr: obj.options.sizeErrorStr,
			uploadErrorStr: obj.options.uploadErrorStr,
			maxFileCountErrorStr: obj.options.maxFileCountErrorStr,
			url:"/file-upload",
			showStatusAfterSuccess:false,
			showDelete:true,
			showDownload:false,
			multiple:(obj.options.appendix_capacity>1),
			dragDrop:true,
			fileName:"up",
			maxFileCount:obj.options.appendix_capacity,
			maxFileSize:36*1024*1024,
			formData: {owner: 'apx',token: obj.options.token},
			onLoad:function(theobj) {},
			onSuccess: function (files, data, xhr, pd) {//files:local name, data:remote_name
				setTimeout(function(){pd.statusbar.hide();},1500);
				var tag='';if(files.length>0){tag=obj.extractFilename(files[0]);}
				var msg=obj.addAppendix(tag,'/u?n='+data);
				if(msg.length==0){obj.refresh();}
				if(obj.options.appendix_capacity==1){
					uploadobj.selectedFiles=0;
				}
			},
			deleteCallback: function (fname, pd) {
				var filename='apx_'+obj.options.token+'-'+$.md5(fname)+obj.fileExt(fname);//same as server filename rule
				$.post("/file-delete",{name: filename},function (resp,textStatus,jqXHR) { 
					pd.statusbar.hide();
				});
			}
		});
		obj.registerWorktopEvent(worktop);
	};
	AppendixObject.prototype.registerWorktopEvent=function(worktop){
		var obj=this;
		worktop.find('span.a_tab_item').each(function(){obj.bindTabitemClick(worktop,$(this));});
		worktop.find('.a_hyperlink').on('input propertychange',function(e){
			$(this).next().find('.a_enter_button').show();
		});
		worktop.find('.a_hyperlink').on('keypress',function(event){
			if(event.keyCode == "13"){event.preventDefault();obj.hyperlinkSubmit($(this).val());}
		});
		worktop.find('.a_enter_button').on('click',function(){obj.hyperlinkSubmit(worktop.find('.a_hyperlink').val());});
	};
	AppendixObject.prototype.modified=function(){
		this.showEmptyBtn();
		this.options.onChange(this.outerID,this.getAppendixes());
	};
	AppendixObject.prototype.showEmptyBtn=function(){
		var self=this.element;
		if(this.appendixes.length>0){
			self.find('.apx_empty').removeClass('apx_hide');
		}else{
			self.find('.apx_empty').addClass('apx_hide');
		}
	};
	AppendixObject.prototype.resetScreen=function(){
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			box.empty();
			var n=this.appendixes.length;
			for(var i=0;i<n;i++){
				var apx=this.appendixes[i];
				this.addScreenAppendix(apx.tag,apx.src);
			}
			this.modified();
		}	
	};
	AppendixObject.prototype.addAppendix=function(tag,src){
		var txt=tag;
		if(txt.length==0){txt=this.extractFilename(src)}
		var msg='';
		if(src.length>0){
			var n=this.appendixes.length;
			for(var i=0;i<n;i++){
				var apx=this.appendixes[i];
				if(apx.src===src){
					if(apx.tag!==txt){
						apx.tag=txt;
						this.appendixes[i]=apx;
						this.modified();
					}
					msg=this.options.txt_srcduplicated;
					break;
				}
			}
			if(msg.length==0){
				this.appendixes.push({tag:txt,src:src,extension:this.fileExt(src)});
				this.addScreenAppendix(tag,src);
				this.options.saveRecent(src,tag);
				this.modified();
			}
		}
		return msg;
	};
	AppendixObject.prototype.hyperlinkSubmit=function(val){
		var ss=$.trim(val);
		if(ss.length>0){
			var msg=this.addAppendix('',ss);
			if(msg.length>0){alert(msg);}else{this.refresh();}
			this.element.find('.a_hyperlink').select().focus();
		}
	};
	AppendixObject.prototype.bindTabitemClick=function(dialogbox,itm){
		var obj=this;
		itm.on('click',function(){
			var itm_sel=itm.siblings('.a_tab_item_selected');
			itm_sel.removeClass('a_tab_item_selected').addClass('a_tab_item');
			obj.bindTabitemClick(dialogbox,itm_sel);
			$(this).removeClass('a_tab_item').addClass('a_tab_item_selected').off('click');
			var apx_grid=dialogbox.find('#apx_grid');
			var apx_link=dialogbox.find('#apx_link');
			var apx_upload=dialogbox.find('#apx_upload');
			switch($(this).attr('id')){
				case 'tab_history':apx_grid.show();apx_link.hide();apx_upload.hide();break;
				case 'tab_link':apx_grid.hide();apx_upload.hide();
					var hyperlink=apx_link.find('.a_hyperlink');
					//hyperlink.height(dialogbox.find('#showcase').height()-32).focus();
					apx_link.show();hyperlink.focus();
					break;
				case 'tab_upload':apx_grid.hide();apx_link.hide();apx_upload.show();break;
			}
		});
	};
	AppendixObject.prototype.appendTR=function(table){
		var n=this.options.screen_columns;
		if(n==0){n=1;}
		var tr='<tr>',width=100;
		var avg=parseInt(width/n);
		for(var i=0;i<n;i++){
			var colwidth=avg; if(i==n-1){colwidth=width-(n-1)*avg;}
			tr+='<td class="blank working" style="text-align:'+this.options.cell_align+';vertical-align:'+this.options.cell_valign+';width:'+colwidth+'%"></td>';		
		}
		tr+='</tr>';
		table.append(tr);	
	};
	AppendixObject.prototype.extractFilename=function(src){
		var filename=src;
		var ss=src.split('/');
		var n=ss.length;
		if(n>0){	filename=ss[n-1];}
		return filename;
	};
	AppendixObject.prototype.initGridblockText=function(){
		return '<div class="ht_gridblock"><table width="100%"></table></div>';
	};
	AppendixObject.prototype.addScreenAppendix=function(tag,src){//match with entity.go childBlock function
		var txt=tag;
		if(txt.length==0){txt=this.extractFilename(src)}
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var obj=this;
			var id=$.md5(src);
			if(box.find('#'+id).length==0){
				//box.find('i.ti').hide();
				var table=box.find('table');
				if(table.length==0){
					box.append(this.initGridblockText());table=box.find('table');
				}
				if(table.find('td.blank').length==0){obj.appendTR(table);}
				var td=table.find('td.blank:first');
				if(td.length==1){
					var apx='<a href="'+src+'" id="'+id+'" target="_blank">'+obj.filetypeIcon(obj.fileExt(src),1)+'&nbsp;'+txt+'</a>';
					td.append(apx);
					td.removeClass('blank').addClass('used');
				}
			}
		}
	};
	AppendixObject.prototype.setScreenTag=function(tag,src){
		var obj=this;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var id=$.md5(src);
			var apx=box.find('a#'+id);
			if(apx.length==1){
				apx.html(obj.filetypeIcon(obj.fileExt(src),1)+'&nbsp;'+tag);
			}
		}
	};
	AppendixObject.prototype.rmvScreenAppendix=function(id){
		var flag=false;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var apx=box.find('#'+id);
			if(apx.length==1){
				flag=true;
				var td=apx.parent();
				apx.remove();td.removeClass('used').addClass('blank');td.attr('style','');
				var nextids=[];
				td.nextAll('td.used').each(function(){nextids.push($(this).find('a').attr('id'));});
				var tr=td.parent();
				tr.nextAll().find('a').each(function(){nextids.push($(this).attr('id'));});
				var n=nextids.length;
				for(var i=0;i<n;i++){
					var nxt = box.find('#'+nextids[i]);
					if(nxt.length>0){
						var ntd = nxt.parent();
						nxt.appendTo(td);
						td.removeClass('blank').addClass('used');td.attr('style',ntd.attr('style'));
						ntd.removeClass('used').addClass('blank');ntd.attr('style','');
						td=ntd;
					}
				}
				tr.nextAll().each(function(){
					var atr=$(this);if(atr.find('.used').length==0){atr.remove();}
				});
				if(tr.find('.used').length==0){tr.remove();}
				if(box.find('a').length==0){box.find('i.ti').show();}
			}
		}
		return flag;
	};
	AppendixObject.prototype.moveupNScreenAppendix=function(i_s,i_e){
		var flag=false;
		var obj=this;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var tds=box.find('td.used');
			if(i_e<tds.length){
				box.append('<div id="space" style="display:none"></div>');
				var space=box.find('#space');
				var td=box.find('#'+$.md5(obj.appendixes[i_e].src)).parent();
				td.children().appendTo(space); var spacestyle=td.attr('style');
				for(var i=i_e;i>i_s;i--){
					var tdpre=box.find('#'+$.md5(obj.appendixes[i-1].src)).parent();
					tdpre.children().appendTo(td);
					td.attr('style',tdpre.attr('style'));
					td=tdpre;
				}
				space.children().appendTo(td);
				td.attr('style',spacestyle);
				space.remove();
				flag=true;
			}
		}
		return flag;
	};
	AppendixObject.prototype.movedownNScreenAppendix=function(i_s,i_e){
		var flag=false;
		var obj=this;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var tds=box.find('td.used');
			if(i_e<tds.length){
				box.append('<div id="space" style="display:none"></div>');
				var space=box.find('#space');
				var td=box.find('#'+$.md5(obj.appendixes[i_s].src)).parent();
				td.children().appendTo(space); var spacestyle=td.attr('style');
				for(var i=i_s;i<i_e;i++){
					var tdnxt=box.find('#'+$.md5(obj.appendixes[i+1].src)).parent();
					tdnxt.children().appendTo(td);
					td.attr('style',tdnxt.attr('style'));
					td=tdnxt;
				}
				space.children().appendTo(td);
				td.attr('style',spacestyle);
				space.remove();
				flag=true;
			}
		}
		return flag;
	};
	AppendixObject.prototype.setScreen=function(div_item){
		this.options.screen=div_item;	
		var table=div_item.find('table');
		if(table.length==0){
			div_item.append(this.initGridblockText());
		}/*fault-tolerant*/
	};
	AppendixObject.prototype.show=function(){
		this.element.show();		
	};
	AppendixObject.prototype.hide=function(){
		this.element.hide();		
	};
	AppendixObject.prototype.fileExt=function(filename){//use for fileuploader
		var extension = '';
		var ss = filename.split('.');
		if(ss.length>1){
			extension = '.'+ss[ss.length - 1];
		}
		return extension;	
	};
	AppendixObject.prototype.filetypeIcon=function(extension,times){//times: 1/2/3
		var icon='';/*class fti: file type icon*/
		var fat='';
		if(times>1){fat=' fa-'+times+'x';}
		var ext=extension.toLowerCase();
		switch(ext){
			case '.pages':
			case '.doc':
			case '.docx':
			case '.wps':icon = '<i class="fti fa fa-file-word-o'+fat+'"></i>';break;
			case '.numbers':
			case '.xls':
			case '.xlsx':icon = '<i class="fti fa fa-file-excel-o'+fat+'"></i>';break;
			case '.key':
			case '.ppt':
			case '.pptx':icon = '<i class="fti fa fa-file-powerpoint-o'+fat+'"></i>';break;
			case '.pdf':icon = '<i class="fti fa fa-file-pdf-o'+fat+'"></i>';break;
			case '.icns':
			case '.icon':
			case '.jpg':
			case '.jpeg':
			case '.gif':
			case '.png':
			case '.bmp':	icon = '<i class="fti fa fa-file-image-o'+fat+'"></i>';break;
			case '.zip':
			case '.rar':
			case '.7z':
			case '.tar':
			case '.gz':icon = '<i class="fti fa fa-file-archive-o'+fat+'"></i>';break;
			case '.wma':
			case '.mmf':
			case '.mp3':
			case '.mid':
			case '.rm':icon = '<i class="fti fa fa-file-audio-o'+fat+'"></i>';break;
			case '.avi':
			case '.rmvb':
			case '.mov':
			case '.qt':
			case '.asf':
			case '.flv':
			case '.ogg':
			case '.mpg':
			case '.mpe':
			case '.mpeg':
			case '.mlv':
			case '.m2v':
			case '.wmv':
			case '.mp4':	icon = '<i class="fti fa fa-file-video-o'+fat+'"></i>';break;
			default:icon = '<i class="fti fa fa-file-o'+fat+'"></i>';break;
		}
		return icon;		
	};
	AppendixObject.prototype.setOuterID=function(id){
		this.outerID = id;
	};
	AppendixObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	AppendixObject.prototype.parseTextAppendixes=function(txt){
		var obj=this;
		obj.appendixes=[];
		if(txt.length>0){
			var columns=1;
			var align='center',valign='top';
			/*format A: {"columns":1,"align":"center","valign":"top","appendixes":[{"src":"/img/ok.png","tag":""}]}*/
			/*format B: /u/ok.png,http://www.abc/do.png*/
			/*format C: base64(),base64()*/
			if(obj.isObjectText(txt)){
				var dt=JSON.parse(txt);
				if(dt.hasOwnProperty('columns')){if(dt.columns>0){columns=dt.columns;}}
				if(dt.hasOwnProperty('align')){if(dt.align.length>0){align=dt.align;}}
				if(dt.hasOwnProperty('valign')){if(dt.valign.length>0){valign=dt.valign;}}
				for(var i=0;i<dt.appendixes.length;i++){
					obj.appendixes.push(dt.appendixes[i]);
				}
			}else{
				var dtdt=txt.split(',');
				var n=dtdt.length;
				for(var i=0;i<n;i++){
					var dt=dtdt[i];
					if(dt.length>0){
						var src=dt;
						if(dt.indexOf('.')<0){/*base64 encode*/
							src=$.base64.decode(dt)
						}
						if(src.length>0){
							obj.appendixes.push({src:src});
						}
					}
				}
			}
			obj.options.screen_columns=columns;
			obj.options.cell_align=align;
			obj.options.cell_valign=valign;
		}
	};
	AppendixObject.prototype.refresh=function(){
		var obj=this;
		var self=this.element;
		var box=obj.options.screen;
		if(obj.options.max_columns>1){
			obj.column_spinner.setValue(obj.options.screen_columns);
		}
		obj.cell_align.Select(obj.options.cell_align);
		if(obj.options.appendix_capacity>1){
			if(obj.options.max_columns>1){
				obj.cell_valign.Select(obj.options.cell_valign);
			}
			setTimeout(function(){
				GridManager.setAjaxData('appendixes',obj.makeGM_data());
			},200);
		}
	};
	AppendixObject.prototype.getAppendixes=function(){
		var dt={columns:this.options.screen_columns,align:this.options.cell_align,valign:this.options.cell_valign,appendixes:this.appendixes};
		return JSON.stringify(dt);
	};				
	AppendixObject.prototype.setAppendixes=function(val){
		this.parseTextAppendixes(val);
		this.refresh();
		var obj=this;
		if(obj.options.init_screen){
			setTimeout(function(){
				var screen=obj.options.screen;
				if(JSON.stringify(screen)!='{}'){
					var n=obj.appendixes.length;
					for(var i=0;i<n;i++){
						var o=obj.appendixes[i];
						obj.addScreenAppendix(o.tag,o.src);
					}
				}		
			},100);			
		}
		this.showEmptyBtn();
		return this;
	};
    $.fn.Appendix=function(options){
		var anappendix=new AppendixObject(this,options);
		anappendix.init();
		return anappendix;
    };
