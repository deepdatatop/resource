/*inherit from HierarchyObject, dependence: tree.js*/
function inheritPrototype(subObject, superObject){
	var prototype = Object.create(superObject.prototype);
	prototype.constructor = subObject;
	subObject.prototype = prototype;
}
function TreeEditorObject(element,options){
	var exdefaults={
		i18n:{},
		editor_type:'popup',/*integrated,popup*/
		onDataChange:function(val){},
		saveitem_url:'/sveitem',
		removeitem_url:'/rmvitem',
		occurrencequery_url:'/codesetoccurrence',
		positionswap_url:'/swappos',
		setparent_url:'/setparent',
		okText:'OK',
		cancelText:'Cancel',
		hintText:'Please input text:',
		txt_count:'Count',
		txt_object:'Object',
		txt_table:'Table',
		txt_yes:'Yes',
		txt_no:'No',
		txt_new:'new',
		txt_buttonnew:'New',
		txt_inputlabel:'Please input label text',
		txt_removeornot:'Remove',
		txt_descendant:'and all descendant',
		txt_removeusage:'Please remove this item usage record first:',
		txt_modify:'modify',
		txt_itemtrash:'remove',
		txt_newitem:'new',
		txt_splititem:'split',
		txt_moveup:'move up',
		txt_movedown:'move down',
		txt_upgradeitem:'upgrade',
		txt_downgradeitem:'downgrade'
	};
	HierarchyObject.call(this,element,$.extend({},exdefaults,options));
	this.inputsource='';
	this.enable_labeledit=false;
	this.inEditing=false;
	this.maxid=0;//use for id generator
	this.headerCells=new Array();
	this.headerDatas=new Array();
};
inheritPrototype(TreeEditorObject,HierarchyObject);
TreeEditorObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
TreeEditorObject.prototype.afterFocusRemoved=function(){
	this.element.find('.popmenu').remove();
};
TreeEditorObject.prototype.trimFocusText=function(txt){
	var newtxt=txt;
	if(newtxt.indexOf('item_focus')>0){
		newtxt=newtxt.replace(/<div class="item_focus"><\/div>/,'');
	}
	if(newtxt.indexOf('item_selected')>0){
		newtxt=newtxt.replace(/<div class="item_selected"><\/div>/,'');
	}
	if(newtxt.indexOf('popmenu')>0){
		newtxt=newtxt.replace(/<div id="p_m" class="popmenu"><span>::<\/span><\/div>/,'');
	}
	return newtxt;
};
TreeEditorObject.prototype.resetExtension=function(itm){
	if(this.options.editor_type=='popup'){
		itm.find('.popmenu').remove();
		this.addFocusExtension(itm);
	}
};
TreeEditorObject.prototype.addFocusExtension=function(itm){
	if(this.options.editor_type=='popup'){
		var flags=[];
		itm.children('.flag').children('div').each(function(i,o) {
			var oclass=$(o).attr('class');
			oclass=oclass.replace(/popup/g, '');
			oclass=oclass.replace(/integrated/g, '');
			flags.push($.trim(oclass));
		});
		var ic=itm.find('span.itemcaption');
		if(ic.length>0){
			ic.after('<div id="p_m" class="popmenu"><span>::</span></div>');
			var pm=ic.next('#p_m');
			this.bindPopmenu(pm,itm.attr('id'),ic.text(),flags);
		}
	}
};
TreeEditorObject.prototype.bindPopmenu=function(pm,id,text,flags){
	var self=this;
	var itms=[],act='modify';
	itms.push({label:this.options.txt_modify,icon:'/img/edit_16.png',action:act});
	if(self.hierarchy){
		act='itemtrash';
		if($.inArray(act,flags)>=0){
			itms.push({label:this.options['txt_'+act],icon:'/img/trash_16.png',action:act});
		}
		itms.push(null);
		act='newitem';
		if($.inArray(act,flags)>=0){
			itms.push({label:this.options['txt_'+act],icon:'/img/newitem_16.png',action:act});
		}
		act='splititem';
		if($.inArray(act,flags)>=0){
			itms.push({label:this.options['txt_'+act],icon:'/img/splititem_16.png',action:act});
		}
		itms.push(null);
		act='moveup';
		if($.inArray(act,flags)>=0){
			itms.push({label:this.options['txt_'+act],icon:'/img/moveup_16.png',action:act});
		}
		act='movedown';
		if($.inArray(act,flags)>=0){
			itms.push({label:this.options['txt_'+act],icon:'/img/movedown_16.png',action:act});
		}
		itms.push(null);
		act='upgradeitem';
		if($.inArray(act,flags)>=0){
			itms.push({label:this.options['txt_'+act],icon:'/img/upgrade_16.png',action:act});
		}
		act='downgradeitem';
		if($.inArray(act,flags)>=0){
			itms.push({label:this.options['txt_'+act],icon:'/img/downgrade_16.png',action:act});
		}
	}else{
		act='itemtrash';
		itms.push({label:this.options['txt_'+act],icon:'/img/trash_16.png',action:act});
		act='newitem';
		itms.push({label:this.options['txt_'+act],icon:'/img/newitem_16.png',action:act});	
	}
	pm.contextPopup({custom_event:'treeaction_event',outerid: id,title: text,items: itms});
};
TreeEditorObject.prototype.noitem=function() {
	this.addnew();
};
TreeEditorObject.prototype.loadoption=function(value){
	var id=parseInt(value);
	if(id>this.maxid){this.maxid=id;}
};
TreeEditorObject.prototype.firstitem=function(){
	var self=this,thebox=this.element,so=this.options;
	var depth=1;
	var indent = '';
	if(self.rootchildbox.length>0){
		//var tt = '<div class="children" id="cld0">';
		var tt = '<div class="item" id="new" depth="'+depth+'">';
		tt += '<span class="indent"><div depth="'+depth+'" class="noline"></div></span>';
		var linetype = 'tr';
		var iclass = 'leaf';
		tt += '<div class="hook '+iclass+' '+linetype+iclass+'"></div>';
		tt += self.itemflag('new',depth,0,1,true);
		tt += '<span class="itemcaption color'+(depth%6).toString()+'"></span>';
		tt += '</div>';
		//tt += '</div>';
		self.rootchildbox.append( tt );
	}
		
	var newitm=thebox.find('#new');
	var ic=newitem.find('.itemcaption');
		
	self.registerFlagEvent(newitm);
	self.registerItemcaptionEvent(newitm);
	if(self.enable_labeledit){
		self.inEditing = true;
		ic.after(self.editorText('',ic.position().left));
		self.inputsource='';
		self.registerItemeditorEvent(newitm);
		newitm.find('input.nm').focus();
	}else{
		ic.text(so.txt_new);
		self.inputsource=so.txt_new;
	}	
};
TreeEditorObject.prototype.addnew=function(){
	var self=this,thebox=this.element,so=this.options;
	var tt='<div id="addnew" style="width:100%;height:100%;margin:0;padding:0;text-align:center">';
	tt+='<div style="position:relative;top:30%;" class="newbutton">'+so.txt_buttonnew+'+</div></div>';
	thebox.append(tt);
	thebox.find('.newbutton').off("click").on("click",function(event){
		event.stopPropagation();
		$(this).parent().remove();
		if(self.hierarchy){
			self.firstitem();
		}else{
			var tt='<div class="item" id="new"><span class="blank"></span><span class="itemcaption">'+so.txt_new+'</span>';
			tt+='</div>';
			thebox.append(tt);
			self.registerItemcaptionEvent(thebox);
		}
	});
};
/*direction: horizontal=0, vertical=1*/
TreeEditorObject.prototype.recursiveItem=function(direction,pid,left,top) {//recursive function
	if(this.childlist.hasOwnProperty(pid)){
		var children = this.childlist[pid];//[11,22,33,44]
		var c1=left,r1=top;
		var n=children.length;
		for(var i=0;i<n;i++){
			var v=children[i];
			var o=this.options.item_option[this.pos[v]];
			var cell={c1:c1,r1:r1,cc:1,rc:1};
			this.headerDatas[r1][c1]=o.label;
			if(o.isleaf){
				var m=this.maxdepth-o.depth+1;
				if(direction==0){cell['rc']=m;
				}else{cell['cc']=m;}
				this.headerCells.push(cell);
			}else{
				if(direction==0){cell['cc']=o.nleaves;r1++;
				}else{cell['rc']=o.nleaves;c1++;}
				this.headerCells.push(cell);
				this.recursiveItem(direction,v,c1,r1);
			}
			if(direction==0){c1+=o.nleaves;r1=top;
			}else{c1=left;r1+=o.nleaves;}
		}
	}
};
TreeEditorObject.prototype.tableHeader=function(){
	this.extendHierarchyOption();
	this.headerCells=[];
	var direction=0;
	var n=this.nleaves,m=this.maxdepth;
	if(direction==0){n=this.maxdepth;m=this.nleaves;}
	this.headerDatas=new Array();
	for(var i=0;i<n;i++){
		this.headerDatas[i]=new Array();
		for(var j=0;j<m;j++){this.headerDatas[i][j]='';}
	}
	this.recursiveItem(direction,0,0,0);//direction,value,left,top
	alert(JSON.stringify(this.headerCells));
	alert(JSON.stringify(this.headerDatas));
	//alert('this.nleaves:'+this.nleaves);
	//alert('this.maxdepth:'+this.maxdepth);
	//var data=JSON.stringify(this.options.item_option);
	//alert(data);		
};
TreeEditorObject.prototype.saveEditor=function(editor){
	var self=this;
	var txt=$.trim(editor.val());
	if(txt.length==0){
		alert(self.options.txt_inputlabel);
		editor.focus();
	}else{
		var p=editor.parent();
		var itm=p.parent();
		var pid=itm.parent().attr('id').replace('cld','');
		var ic=p.siblings('span.itemcaption');
		var codeset=this.options.codeset,eid=this.options.eid;
		if(codeset.length==0&&eid==0){
			this.maxid ++;
			itm.attr('id',this.maxid);
			ic.text(txt);
			p.remove();
			this.inEditing=false;
			this.options.item_option.push({"value": this.maxid,"parent": parseInt(pid),"label": txt});
				
			//this.tableHeader();//use for debug			
		}else{
			var pre_id='0';
			var pre = itm.prev();
			var prc = itm.prev();
			if( prc.length>0 ){
				if(prc.attr('class')=='children'){
					pre = prc.prev();
				}
			}
			if(pre.length>0){pre_id=pre.attr('id');}
			//var pid=itm.parent().attr('id').replace('cld','');
			var o={iid:itm.attr('id'),pid:pid,pre:pre_id,txt:txt,lid:this.options.language};
			if(eid>0){
				o['eid']=eid;
			}else{
				o['cst']=codeset;
			}
			$.getJSON(this.options.saveitem_url,o,
				function(m){
					if(m.Code=="100"){
						itm.attr('id',m.Id);
						ic.text(txt);
						p.remove();
						self.inEditing=false;
					}else{
						alert(m.Msg);
						editor.focus();
					}
				}
			);
		}
	}
};
TreeEditorObject.prototype.saveCaption=function(itm,txt){
	var so=this.options;
	var pid=itm.parent().attr('id').replace('cld','');
	var ic=itm.children('span.itemcaption');
	var codeset=so.codeset,eid=so.eid;
	if(codeset.length==0&&eid==0){
		this.maxid ++;
		itm.attr('id',this.maxid);
		ic.text(txt);
		so.item_option.push({"value": this.maxid,"parent": parseInt(pid),"label": txt});
	}else{
		var pre_id='0',pre = itm.prev(),prc = itm.prev();
		if( prc.length>0 ){
			if(prc.attr('class')=='children'){
				pre = prc.prev();
			}
		}
		if(pre.length>0){pre_id=pre.attr('id');}
		var o={iid:itm.attr('id'),pid:pid,pre:pre_id,txt:txt,lid:so.language};
		if(eid>0){o['eid']=eid;}else{o['cst']=codeset;}
		$.getJSON(so.saveitem_url,o,function(m){
			if(m.Code=="100"){ic.text(txt);}else{alert(m.Msg);}
		});
	}
};
TreeEditorObject.prototype.registerItemeditorEvent=function(block){
	var self=this;
	block.find('div.itemconfirm').off("click").on("click",function(event){
		event.stopPropagation();
		self.saveEditor($(this).siblings('input.nm'));
	});
	block.find('div.itemrecover').off("click").on("click",function(event){
		event.stopPropagation();
		$(this).siblings('input.nm').val(self.inputsource).focus();
		$(this).hide();
		$(this).siblings('div.itemconfirm').hide();
	});
	block.find('input.nm').on('keypress',function(event){
		if(event.keyCode == "13"){
			event.preventDefault();
			self.saveEditor($(this));
		}
	});
	block.find('input.nm').on('click',function(event){
		event.stopPropagation();
	});
	block.find('input.nm').on('input propertychange',function(event){
		event.preventDefault();
		var im=$(this).siblings('div.itemconfirm');
		var ic=$(this).siblings('div.itemrecover');
		if($(this).val()==self.inputsource){ic.hide();im.hide();}else{ic.show();im.show();}
	});
};
TreeEditorObject.prototype.setitemcaption=function(id,caption){
	var thebox=this.element;
	var itm=thebox.find('div#'+id);
	if(itm.length>0){
		var ic=itm.find('.itemcaption');
		ic.text(caption);
	}
}
TreeEditorObject.prototype.clickitemcaption=function(ic){
	var self=this,thebox=this.element,so=this.options;
	if(self.enable_labeledit){
		var editor=thebox.find('input.nm');var v='';var eitm = new Object();
		if(editor.length>0){v=$.trim(editor.val());eitm=editor.parent().parent();}
		if(self.inEditing&&v!=self.inputsource){
			if(eitm.length>0){
				self.expandPath(eitm);
				self.positionItem(thebox,eitm.attr('id'));
			}
			if(editor.length>0){editor.focus();}
		}else{
			if(self.inEditing&&editor.length>0){
				var p=editor.parent();
				p.siblings('span.itemcaption').text(self.inputsource);
				p.remove();
			}
			self.inputsource = ic.text();
			ic.after(self.editorText(self.inputsource,ic.position().left));
			editor=ic.next();
			self.registerItemeditorEvent(editor);
			editor.children('input.nm').focus();
			ic.text('');
			self.inEditing = true;
		}
	}else{
		var itm=ic.parent();
		self.focusItem(itm);
		so.onChange(itm.attr('id'),ic.text());
	}
};
TreeEditorObject.prototype.itemflag=function(id,depth,i,n,isleaf){
	/*var leaf='0';
	if(isleaf){leaf='1';}*/
	var tt='';
	tt += '<div class="flag '+this.options.editor_type+'">';
	if(depth>1){tt += '<div class="upgradeitem"></div>';}
	if(i>0){tt += '<div class="downgradeitem"></div>';}
	tt += '<div class="newitem"></div>';
	tt += '<div class="itemtrash"></div>';// leaf="'+leaf+'"></div>';
	if(n>1){
		if(i>0){tt += '<div class="moveup"></div>';}
		if(i<n-1){tt += '<div class="movedown"></div>';}
	}
	if(isleaf){tt += '<div class="splititem"></div>';}
	tt += '</div>';
	return tt;
};
TreeEditorObject.prototype.do_moveup=function(itm,cld,pre,prc,nxt){
	var self=this;
	var depth=parseInt(itm.attr('depth'));
	var ppre=pre.prev();
	self.insmoveup(pre);
	self.insdowngrade(pre);
	self.insmovedown(itm);
	itm.insertBefore(pre);
	if(nxt.length==0){
		self.rmvmovedown(pre);
		self.changehook(itm,'tr','vr');
		self.changehook(pre,'vr','tr');
	}
	if(cld.length>0){
		cld.insertBefore(pre);
		if(nxt.length==0){
			self.noline2vline(cld,depth+1);
		}
	}
	if(prc.length>0&&nxt.length==0){
		self.vline2noline(prc,depth+1);
	}
	if(ppre.length==0){
		self.rmvmoveup(itm);
		self.rmvdowngradeitem(itm);
	}
	self.resetExtension(itm);	
};
TreeEditorObject.prototype.moveup=function(itm){
	var self=this;
	var nxt = itm.next();
	var cld = itm.next();
	if( cld.length>0 ){
		if(cld.attr('class')=='children'){
			nxt = cld.next();
		}else{cld.length=0;}
	}
	var pre = itm.prev();
	var prc = itm.prev();
	if( prc.length>0 ){
		if(prc.attr('class')=='children'){
			pre = prc.prev();
		}else{prc.length=0;}
	}
	if(pre.length>0){
		var codeset=this.options.codeset,eid=this.options.eid;
		if(codeset.length==0&&eid==0){
			self.do_moveup(itm,cld,pre,prc,nxt);
		}else{
			var o={a:pre.attr('id'),b:itm.attr('id')};
			if(eid>0){
				o['eid']=eid;
			}else{
				o['cst']=codeset;
			}
			$.getJSON(this.options.positionswap_url,o,
				function(m){
					if(m.Code=="100"){
						self.do_moveup(itm,cld,pre,prc,nxt);
					}else{
						alert(m.Msg);
					}
				}
			);
		}
	}
};
TreeEditorObject.prototype.do_movedown=function(itm,cld,nxt){
	var self=this;
	var depth=parseInt(itm.attr('depth'));
	var ncld=nxt.next();
	var nnxt=nxt.next();
	if( ncld.length>0 ){
		if(ncld.attr('class')=='children'){
			nnxt = ncld.next();
		}else{ncld.length=0;}
	}
	self.insmovedown(nxt);
	if(itm.prev().length==0){self.rmvmoveup(nxt);self.rmvdowngradeitem(nxt);}
	var np=ncld;
	if(np.length==0){np=nxt;}
	if(cld.length>0){cld.insertAfter(np);}
	itm.insertAfter(np);
	self.insmoveup(itm);	
	self.insdowngrade(itm);
	if(nnxt.length==0){
		self.changehook(nxt,'tr','vr');
		self.rmvmovedown(itm);
		if(cld.length>0){self.vline2noline(cld,depth+1);}
		if(ncld.length>0){self.noline2vline(ncld,depth+1);}
		self.changehook(itm,'vr','tr');
	}
	self.resetExtension(itm);		
};
TreeEditorObject.prototype.movedown=function(itm){
	var self=this;
	var nxt = itm.next();
	var cld = itm.next();
	if( cld.length>0 ){
		if(cld.attr('class')=='children'){
			nxt = cld.next();
		}else{cld.length=0;}
	}
	if(nxt.length>0){
		var codeset=this.options.codeset,eid=this.options.eid;
		if(codeset.length==0&&eid==0){
			self.do_movedown(itm,cld,nxt);
		}else{
			var o={a:itm.attr('id'),b:nxt.attr('id')};
			if(eid>0){
				o['eid']=eid;
			}else{
				o['cst']=codeset;
			}
			$.getJSON(this.options.positionswap_url,o,
				function(m){
					if(m.Code=="100"){
						self.do_movedown(itm,cld,nxt);
					}else{
						alert(m.Msg);
					}
				}
			);
		}
	}
};
TreeEditorObject.prototype.splititem=function(itm){
	var self=this;
	var depth=parseInt(itm.attr('depth'))+1;
	var indent = '';
	var idt = itm.children('span.indent');
	if( idt.length>0 ){indent = self.trimFocusText(idt.html());}
	var nxt = itm.nextAll('.item:first');
	indent += '<div depth="'+depth+'" class="'+((nxt.length>0)?'v':'no')+'line"></div>';
	var tt = '<div class="children" id="cld'+itm.attr('id')+'">';
	tt += '<div class="item" id="new" depth="'+depth+'">';
	tt += '<span class="indent">'+indent+'</span>';
	var linetype = 'tr'; var iclass = 'leaf';
	tt += '<div class="hook '+iclass+' '+linetype+iclass+'"></div>';
	tt += self.itemflag('new',depth,0,1,true);
	tt += '<span class="itemcaption color'+(depth%6).toString()+'"></span>';
	tt += '</div></div>';
	itm.after( tt ); var newitm=itm.next().find('#new');
	var ic=newitm.find('.itemcaption');
	self.registerFlagEvent(newitm);
	self.registerItemcaptionEvent(newitm);
	if(self.enable_labeledit){
		self.inEditing = true;
		ic.text('');
		ic.after(self.editorText('',ic.position().left));
		self.inputsource='';
		self.registerItemeditorEvent(newitm);
		newitm.find('input.nm').focus();
	}else{
		ic.text(self.options.txt_new);
		self.inputsource=self.options.txt_new;
		self.saveNewitem(newitm);
	}
	self.rmvsplititem(itm);
	self.changehook(itm,'leaf','expand');
	var ie = itm.children('div.expand');
	if(ie.length==1){self.registerExpandEvent(ie);}
};
TreeEditorObject.prototype.do_upgrade=function(itm,cld,nxt,pre,pcd){
	var self=this;
	var depth=parseInt(itm.attr('depth'));
	var pcld=itm.parent();
	var pitm=pcld.prev();
	var pnxt=pcld.next();
	if(pre.length>0&&nxt.length==0){
		self.changehook(pre,'vr','tr');
		self.rmvmovedown(pre);
		if(pcd.length>0){self.vline2noline(pcd,parseInt(pre.attr('depth'))+1);}
	}
	self.rmvindent(itm,depth);
	if(cld.length>0){
		cld.insertAfter(pcld);
		self.rmvindent(cld,depth);
		if(pnxt.length==0){
			self.vline2noline(cld,depth);
		}else{
			if(nxt.length==0){self.noline2vline(cld,depth);}
		}
		self.decdepth(cld);
	}
	self.insmoveup(itm);
	self.insdowngrade(itm);
	if(pnxt.length>0){
		self.insmovedown(itm);
	}else{
		self.rmvmovedown(itm);self.insmovedown(pitm);self.changehook(pitm,'tr','vr');
	}
	if(depth==2){self.rmvupgradeitem(itm);}
	self.decitemdepth(itm);
	itm.insertAfter(pcld);
	if(pcld.children().length==0){
		pcld.remove();
		var ie=pitm.children('div.expand');if(ie.length==1){ie.off('click');}
		self.changehook(pitm,'expand','leaf');
		self.inssplititem(pitm);
	}else{
		if(pnxt.length==0){self.noline2vline(pcld,depth);}
	}
	self.bendhook(itm,pnxt.length>0);
	if(nxt.length>0){
		if(pre.length==0){self.rmvmoveup(nxt);self.rmvdowngradeitem(nxt);}
	}
	self.resetExtension(itm);	
};
TreeEditorObject.prototype.upgradeitem=function(itm){
	var self=this;
	var pre=itm.prev();
	var pcd=itm.prev();
	if( pcd.length>0 ){
		if( pcd.attr('class')=='children' ){
			pre = pcd.prev();
		}else{pcd.length=0;}
	}
	var cld=itm.next();
	var nxt=itm.next();
	if( cld.length>0 ){
		if( cld.attr('class')=='children' ){
			nxt = cld.next();
		}else{cld.length=0;}
	}
	var pid=0;var preid=0;
	var p=itm.parent().prev();
	if(p.length>0){
		preid = parseInt(p.attr('id'));
		if(preid>0){
			p=p.parent().prev();
			if(p.length>0){pid = parseInt(p.attr('id'));}
		}
	}
	var codeset=this.options.codeset,eid=this.options.eid;
	if(codeset.length==0&&eid==0){
		self.do_upgrade(itm,cld,nxt,pre,pcd);
	}else{
		var o={iid:itm.attr('id'),pid:pid,pre:preid};
		if(eid>0){
			o['eid']=eid;
		}else{
			o['cst']=codeset;
		}
		$.getJSON(this.options.setparent_url,o,
			function(m){
				if(m.Code=="100"){
					self.do_upgrade(itm,cld,nxt,pre,pcd);
				}else{
					alert(m.Msg);
				}
			}
		);				
	}
};
TreeEditorObject.prototype.do_downgrade=function(itm,pre,pcd){
	var self=this;
	var depth=parseInt(itm.attr('depth'));
	var cld=itm.next();
	var nxt=itm.next();
	if( cld.length>0 ){
		if( cld.attr('class')=='children' ){
			nxt = cld.next();
		}else{cld.length=0;}
	}
	if(pre.length>0){
		var npre = new Object();//new pre
		var npcd = new Object();//new pre child
		if(pcd.length==0){
			pre.after('<div class="children" id="cld'+pre.attr('id')+'"></div>');
			pcd=pre.next();
			self.rmvsplititem(pre);
			self.changehook(pre,'leaf','expand');
			var ie = pre.children('div.expand');
			if(ie.length==1){self.registerExpandEvent(ie);}
		}else{
			npcd = pcd.children('div').last();
			npre = pcd.children('div').last();
			if( npcd.attr('class')=='children' ){npre = npcd.prev();}else{npcd.length=0;}
		}
		if(npre.length>0){
			self.insmoveup(itm);
			self.insmovedown(npre);
			self.changehook(npre,'tr','vr');
			if(npcd.length>0){self.noline2vline(npcd,parseInt(npre.attr('depth'))+1);}
		}else{
			self.rmvmoveup(itm);
			self.rmvdowngradeitem(itm);
		}
		self.rmvmovedown(itm);
		if(nxt.length>0){
			self.changehook(itm,'vr','tr');
			if(pre.length==0){self.rmvmoveup(nxt);}
		}else{
			self.changehook(pre,'vr','tr');
			self.rmvmovedown(pre);
			self.vline2noline(pcd,depth+1);
		}
		self.incitemdepth(itm);
		var tp=(nxt.length>0)?'v':'no';
		self.insindent(itm,depth,tp);
		if(cld.length>0){
			self.incdepth(cld);
			self.insindent(cld,depth,tp);
			if(nxt.length>0){self.vline2noline(cld,depth+2);}
		}
		self.insupgrade(itm);
		self.expandItem(pre);
		itm.appendTo(pcd);
		if(cld.length>0){cld.appendTo(pcd);}
	}
	self.resetExtension(itm);		
};
TreeEditorObject.prototype.downgradeitem=function(itm){
	var self=this;
	var pre=itm.prev();
	var pcd=itm.prev();
	if( pcd.length>0 ){
		if( pcd.attr('class')=='children' ){
			pre = pcd.prev();
		}else{
			var iclass=pre.children('div.hook').attr('class');
			if(iclass.indexOf('leaf')>=0){
				pcd.length=0;
			}else{
				$.ajaxSettings.async = false;
				this.makechildblock(pre);
				$.ajaxSettings.async = true;
				pcd=pre.next();
			}
		}
	}
	var codeset=this.options.codeset,eid=this.options.eid;
	if(codeset.length==0&&eid==0){
		self.do_downgrade(itm,pre,pcd);
	}else{
		var pid=0; if(pre.length>0){pid=pre.attr('id');}	
		var o={iid:itm.attr('id'),pid:pid,pre:-1};
		if(eid>0){
			o['eid']=eid;
		}else{
			o['cst']=codeset;
		}
		$.getJSON(this.options.setparent_url,o,
			function(m){
				if(m.Code=="100"){
					self.do_downgrade(itm,pre,pcd);
				}else{
					alert(m.Msg);
				}
			}
		);				
	}
};
TreeEditorObject.prototype.insmoveup=function(itm){
	var self=this,flags=itm.children('.flag');
	var mu=flags.children('div.moveup');
	if(mu.length==0){
		var it=flags.children('div.itemtrash');
		if(it.length>0){
			it.after('<div class="moveup"></div>');
			self.registerMoveupEvent(it.next());
		}
	}
};
TreeEditorObject.prototype.insmovedown=function(itm){
	var self=this,flags=itm.children('.flag');
	var md=flags.children('div.movedown');
	if(md.length==0){
		var p=flags.children('div.moveup');
		if(p.length==0){p=flags.children('div.itemtrash');}
		if(p.length>0){	
			p.after('<div class="movedown"></div>');
			self.registerMovedownEvent(p.next());
		}
	}
};
TreeEditorObject.prototype.inssplititem=function(itm){
	var self=this,flags=itm.children('.flag');
	if(flags.children('div.splititem').length==0){
		flags.append('<div class="splititem"></div>');
		self.registerSplititemEvent(flags.find('.splititem'));
	}
};
TreeEditorObject.prototype.insupgrade=function(itm){
	var self=this,flags=itm.children('.flag');
	if(flags.children('div.upgradeitem').length==0){
		var it=flags.children('div.downgradeitem');
		if(it.length==0){it=flags.children('div.newitem');}
		it.before('<div class="upgradeitem"></div>');
		self.registerUpgradeitemEvent(it.prev());
	}
};
TreeEditorObject.prototype.insdowngrade=function(itm){
	var self=this,flags=itm.children('.flag');
	if(flags.children('div.downgradeitem').length==0){
		var ni=flags.children('div.newitem');
		if(ni.length>0){
			ni.before('<div class="downgradeitem"></div>');
			self.registerDowngradeitemEvent(ni.prev());
		}
	}
};
TreeEditorObject.prototype.rmvmoveup=function(itm){
	var mu=itm.children('.flag').children('div.moveup');
	if(mu.length>0){mu.remove();}
};
TreeEditorObject.prototype.rmvmovedown=function(itm){
	var md=itm.children('.flag').children('div.movedown');
	if(md.length>0){md.remove();}
};
TreeEditorObject.prototype.rmvupgradeitem=function(itm){
	var ui=itm.children('.flag').children('div.upgradeitem');
	if(ui.length>0){ui.remove();}
};
TreeEditorObject.prototype.rmvdowngradeitem=function(itm){
	var di=itm.children('.flag').children('div.downgradeitem');
	if(di.length>0){di.remove();}			
};
TreeEditorObject.prototype.rmvsplititem=function(itm){
	var si=itm.children('.flag').children('div.splititem');
	if(si.length>0){si.remove();}
};
TreeEditorObject.prototype.insindent=function(itm,depth,type){//no|v line
	itm.find('span.indent div[depth="'+depth+'"]').each(function(){
		$(this).nextAll().each(function(){
			var d=parseInt($(this).attr('depth'));
			if(d>depth){$(this).attr('depth',d+1);}
		});
		$(this).after('<div depth="'+(depth+1)+'" class="'+type+'line"></div>')
	});
};
TreeEditorObject.prototype.rmvindent=function(itm,depth){
	itm.find('span.indent div[depth="'+depth+'"]').each(function(){
		$(this).nextAll().each(function(){
			var d=parseInt($(this).attr('depth'));
			if(d>depth){$(this).attr('depth',d-1);}
		});
		$(this).remove();
	});
};
TreeEditorObject.prototype.vline2noline=function(block,depth){
	block.find('span.indent div[depth="'+depth+'"]').removeClass('vline').addClass('noline');	
};
TreeEditorObject.prototype.noline2vline=function(block,depth){
	block.find('span.indent div[depth="'+depth+'"]').removeClass('noline').addClass('vline');
};
TreeEditorObject.prototype.incitemdepth=function(itm){
	var d=parseInt(itm.attr('depth'));
	itm.attr('depth',d+1);
	var ic=itm.find('span.itemcaption');
	if(ic.length==1){
		var ocolor='color'+(d%6).toString();
		var ncolor='color'+((d+1)%6).toString();
		ic.attr('class',ic.attr('class').replace(ocolor,ncolor));
	}	
};
TreeEditorObject.prototype.incdepth=function(block){
	var self=this;
	block.find('div.item').each(function(){
		self.incitemdepth($(this));
	});
};
TreeEditorObject.prototype.decitemdepth=function(itm){
	var d=parseInt(itm.attr('depth'));
	itm.attr('depth',d-1);
	var ic=itm.find('span.itemcaption');
	if(ic.length==1){
		var ocolor='color'+(d%6).toString();
		var ncolor='color'+((d-1)%6).toString();
		ic.attr('class',ic.attr('class').replace(ocolor,ncolor));
	}			
};
TreeEditorObject.prototype.decdepth=function(block){
	var self=this;
	block.find('div.item').each(function(){
		self.decitemdepth($(this));
	});
};
TreeEditorObject.prototype.bendhook=function(itm,hasnext){
	var hk=itm.children('div.hook');
	if(hk.length>0){
		var iclass=hk.attr('class');
		if(iclass.indexOf('tr')>=0){
			if(hasnext){hk.attr('class',iclass.replace(new RegExp('tr','g'),'vr'));}
		}else if(iclass.indexOf('vr')>=0){
			if(!hasnext){hk.attr('class',iclass.replace(new RegExp('vr','g'),'tr'));}
		}
	}
};
TreeEditorObject.prototype.doAction=function(id,action){
	var self=this;
	var thebox=this.element;
	var itm=thebox.find('div#'+id);
	if(itm.length>0){
		switch(action){
			case 'modify':
				var ic=itm.children('span.itemcaption');
				$('body').SimpleInputDialog({
					okText:self.options.okText,
					cancelText:self.options.cancelText,
					hintText:self.options.hintText,
					doOK:function(txt,extra){
						self.saveCaption(itm,txt)
						return true;
					}
				}).textinput(ic.text(),'');
			break;
			case 'newitem':      self.newitem(itm); break;
			case 'splititem':    self.splititem(itm); break;
			case 'itemtrash':    self.removealert(itm);break;
			case 'moveup':       self.moveup(itm);break;
			case 'movedown':     self.movedown(itm);break;
			case 'upgradeitem':  self.upgradeitem(itm);break;
			case 'downgradeitem':self.downgradeitem(itm);break;
		}
	}
};
TreeEditorObject.prototype.editorText=function(val,left){
	var thebox=this.element;
	var w=thebox.width()-left;
	var tt = '<div class="editor" style="width:'+w+'">';
	tt += '<input type="text" class="nm" placeholder="'+this.options.txt_inputlabel+'"';
	tt += ' maxlength="255"; style="outline:none;width:'+(w-28)+'px"';//28=itemconfirm,itemrecover width
	if(val.length>0){tt += ' value="'+val+'"';}
	tt += '><div class="itemconfirm"></div><div class="itemrecover"></div>';
	tt += '</div>';
	return tt;
};
TreeEditorObject.prototype.saveNewitem=function(itm){
	var self=this;
	var pid=itm.parent().attr('id').replace('cld','');
	var newID=0;
	var codeset=this.options.codeset,eid=this.options.eid;
	if(codeset.length==0&&eid==0){
		self.maxid ++;
		newID=self.maxid;
		self.options.item_option.push({"value": newID,"parent": parseInt(pid),"label": self.options.txt_new});
		itm.attr('id',newID);
	}else{
		var pre_id='0';
		var pre = itm.prev();
		var prc = itm.prev();
		if( prc.length>0 ){
			if(prc.attr('class')=='children'){
				pre = prc.prev();
			}
		}
		if(pre.length>0){pre_id=pre.attr('id');}
		var o={iid:'0',pid:pid,pre:pre_id,txt:self.options.txt_new,lid:self.options.language};
		if(eid>0){
			o['eid']=eid;
		}else{
			o['cst']=codeset;
		}
		$.getJSON(self.options.saveitem_url,o,
			function(m){
				if(m.Code=="100"){
					itm.attr('id',m.Id);
				}else{
					alert(m.Msg);
				}
			}
		);
	}
};
TreeEditorObject.prototype.newitem=function(itm){
	var self=this;
	var depth=itm.attr('depth');
	var tt = self.trimFocusText(itm.html());
	var cld = itm.next();
	var nxt = itm.next();
	if( cld.length>0 ){
		if( cld.attr('class')=='children' ){
			nxt = cld.next();
		}else{cld.length=0;}
	}
	var nh="hook leaf";
	if(nxt.length==0){
		self.changehook(itm,'tr','vr');
		nh+=" trleaf";
	}else{
		nh+=" vrleaf";
	}
	tt = '<div class="item" id="new" depth="'+depth+'">'+tt+'</div>';
	if(cld.length>0){
		if(nxt.length==0){self.noline2vline(cld,parseInt(depth)+1);}
		cld.after(tt);
		nxt=cld.next();
	}else{itm.after(tt);nxt=itm.next();}
	self.insmoveup(nxt);
	self.insdowngrade(nxt);
	self.inssplititem(nxt);
	self.insmovedown(itm);
	var ic=nxt.children('span.itemcaption');
	if(ic.length>0){
		if(self.enable_labeledit){
			self.inEditing = true;
			ic.text('');
			self.inputsource='';
			ic.after(self.editorText('',ic.position().left));
			ic.next().find('input.nm').focus();
		}else{
			ic.text(self.options.txt_new);
			self.inputsource='';
			self.saveNewitem(nxt);
		}
	}
	var hk=nxt.children('div.hook');
	if(hk.length>0){ hk.attr('class',nh); }
	self.registerFlagEvent(nxt);
	self.registerItemcaptionEvent(nxt);
	if(self.enable_labeledit){self.registerItemeditorEvent(nxt);}
	//self.focusItem(nxt);
};
TreeEditorObject.prototype.removeitem=function(itm){
	var self=this;
	if(itm.find("div.editor").length>0){
		self.inEditing=false;
		self.inputsource='';
	}
	if(self.hierarchy){
		var depth=parseInt(itm.attr('depth'));
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		var pre = itm.prev();
		var prc = itm.prev();
		if( prc.length>0 ){
			if(prc.attr('class')=='children'){
				pre = prc.prev();
			}else{prc.length=0;}
		}
		var removed=false;
		if(nxt.length==0){//the last one
			if(pre.length==0){
				var pcld = itm.parent();//div children
				var pitm = pcld.prev();
				if(pcld.length>0){
					var totalempty=(pcld.attr('id')=='cld'+self.options.root_id);
					pcld.remove(); removed=true;
					if(totalempty){	self.addnew();}
				}
				if(pitm.length>0){
					var ie=pitm.children('div.expand');if(ie.length==1){ie.off('click');}
					self.changehook(pitm,'expand','leaf');
					self.inssplititem(pitm);
				}
			}else{
				self.changehook(pre,'vr','tr');
				self.rmvmovedown(pre);
				if(prc.length>0){self.vline2noline(prc,depth+1);}
			}					
		}else{
			if(pre.length==0){self.rmvmoveup(nxt);self.rmvdowngradeitem(nxt);}
		}
		if(!removed){
			if(cld.length>0){cld.remove();}
			itm.remove();
		}
	}else{					
		itm.remove();		
	}
	if(this.element.find('.itemcaption').length==0){
		this.noitem();
	}
};
TreeEditorObject.prototype.registerMoveupEvent=function(flag){
	var self=this;
	if(flag.length>0){
		flag.off("click").on("click",function(event){
			event.stopPropagation();
			self.moveup($(this).parent().parent());
		});
	}
};
TreeEditorObject.prototype.registerMovedownEvent=function(flag){
	var self=this;
	if(flag.length>0){
		flag.off("click").on("click",function(event){
			event.stopPropagation();
			self.movedown($(this).parent().parent());
		});
	}
};
TreeEditorObject.prototype.registerSplititemEvent=function(flag){
	var self=this;
	var thebox=this.element;
	if(flag.length>0){
		flag.off("click").on("click",function(event){
			event.stopPropagation();
			if(self.enable_labeledit){
				if(!self.inEditing){
					self.splititem($(this).parent().parent());
				}else{thebox.find('input.nm').focus();}
			}else{
				self.splititem($(this).parent().parent());
			}
		});
	}
};
TreeEditorObject.prototype.registerUpgradeitemEvent=function(flag){
	var self=this;
	if(flag.length>0){
		flag.off("click").on("click",function(event){
			event.stopPropagation();
			self.upgradeitem($(this).parent().parent());
		});
	}
};
TreeEditorObject.prototype.registerDowngradeitemEvent=function(flag){
	var self=this;
	if(flag.length>0){
		flag.off("click").on("click",function(event){
			event.stopPropagation();
			self.downgradeitem($(this).parent().parent());
		});
	}
};
TreeEditorObject.prototype.removealert=function(itm){
	var self=this;
	var txt=self.options.txt_removeornot;
	if(self.hierarchy){
		var flagdiv=itm.children('.flag');
		txt+=' [<font color="#f00">'+flagdiv.siblings('.itemcaption').text()+'</font>]';
		if(!flagdiv.siblings('.hook').hasClass('leaf')){txt+='<br>'+self.options.txt_descendant;}
	}else{
		txt+=' [<font color="#f00">'+itm.find('.itemcaption').text()+'</font>]';
	}
	self.show_alertpane(itm.attr('id'),txt+'?','trash');
};
TreeEditorObject.prototype.registerFlagEvent=function(block){
	var self=this,thebox=this.element;
	block.find('div.itemtrash').off("click").on("click",function(event){
		event.stopPropagation();
		self.removealert($(this).parent().parent());
	});
	block.find('div.newitem').off("click").on("click",function(event){
		event.stopPropagation();
		if(self.enable_labeledit){
			if(!self.inEditing){
				self.newitem($(this).closest('div.item'));
			}else{thebox.find('input.nm').focus();}
		}else{self.newitem($(this).closest('div.item'));}
	});
	self.registerUpgradeitemEvent(block.find('div.upgradeitem'));
	self.registerDowngradeitemEvent(block.find('div.downgradeitem'));
	self.registerSplititemEvent(block.find('div.splititem'));
	self.registerMoveupEvent(block.find('div.moveup'));
	self.registerMovedownEvent(block.find('div.movedown'));
};
TreeEditorObject.prototype.ex_init=function(){/*Inheritance extension*/
	this.i18n_options();
	var self=this,thebox=this.element,so=this.options;
	self.enable_labeledit=(so.editor_type!='popup');
	if(self.enable_labeledit){
		thebox.off("click").on("click",function(event){
			var editor=thebox.find('input.nm');
			if(editor.length>0){self.saveEditor(editor)}
		});
	}
	window.addEventListener('treeaction_event', function(event){
		var ed=event.detail;
		self.doAction(ed.id,ed.action);
	});
};
TreeEditorObject.prototype.close_alertpane=function(){$("#alert_overlay").fadeOut(200); $("#alert_pane").css({"display":"none"})};
TreeEditorObject.prototype.show_alertpane=function( id,msg,action ){
	var self=this,thebox=this.element;
	var ao=$('#alert_overlay');
	if(ao.length==0){ $("body").append('<div id="alert_overlay"></div>');ao=$('#alert_overlay'); }
	ao.css({"display":"block",opacity:0}).fadeTo(200,0.5);
	var width=330,height=130,btm=32;
	var txt='<div id="alert_pane" style="display: none; width: '+width+'px; height: '+height+'px; overflow: hidden; background:#fff; padding: 8px;">';
	txt += '<div><span class="at_close_icon"></span></div><input type="hidden" id="apath"><input type="hidden" id="action">';
	txt += '<div style="float:left;width:64px;height:'+(height-btm)+'px;background: url(/img/question.png) center center no-repeat;"></div>';
	txt += '<div style="float:left;display:table;overflow:hidden;width:'+(width-64)+'px;height:'+(height-btm)+'px">';
	txt += '<span style="display:table-cell;text-align:center;vertical-align:middle;" id="alert_msg"></span>';
	txt += '</div>';
	txt += '<div style="float:left;width:40%;"><span style="float:right;cursor:pointer;" class="ysbutton" id="btn_yes"><i class="fa fa-check"></i>&nbsp;'+self.options.txt_yes+'</span></div>';
	txt += '<div style="float:right;width:40%;"><span style="float:left;cursor:pointer;" class="ysbutton" id="btn_no"><i class="fa fa-ban"></i>&nbsp;'+self.options.txt_no+'</span></div>';
	txt += '</div>';
	var pane = $("#alert_pane");
	if(pane.length==0){$("body").append(txt); pane = $("#alert_pane");}
	$('#apath').val(id);
	$('#action').val(action);
	$('#alert_msg').html('<font size="+1">'+msg+'</font>');
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":11000,"left":50+"%","margin-left":-(modal_width/2)+"px","top":30+"%"});
	pane.fadeTo(200,1);
	$('#btn_yes').off("click").on("click",function(event){
		event.stopPropagation();
		self.close_alertpane();
		if(action=='trash'){
			var iid=$('#apath').val();
			var itm=thebox.find('#'+iid);
			if(itm.length>0){
				var codeset=self.options.codeset,eid=self.options.eid;
				if(codeset.length==0&&eid==0){
					self.removeitem(itm);
				}else{
					if(iid=='new'){
						self.removeitem(itm);	
					}else{//occurrencequery_url
						var o={iid:iid};
						if(eid>0){
							o['eid']=eid;
						}else{
							o['cst']=codeset;
						}
						$.getJSON(self.options.occurrencequery_url,o,function(m){
							if(m.Code=="100"){
								if(m.Occurrences==0){
									$.getJSON(self.options.removeitem_url,{eid:m.Entity_id,iid:m.Instance_id},function(m){
										if(m.Code=="100"){
											self.removeitem(itm);
										}else{
											alert(m.Msg);
										}
									});
								}else{
									var ss=self.options.txt_removeusage+'\n';
									var n=m.Occurrences;
									for(var i=0;i<m.Occurrences;i++){
										var o=m.Occurrencee[i];
										ss += self.options.txt_count+':'+o.Count;
										ss += '\t'+self.options.txt_object+':'+o.Objectcaption;
										ss += '\t'+self.options.txt_table+':'+o.Tablename+'\n';
									}
									alert(ss);
								}
							}else{
								alert(m.Msg);
							}
						});
					}
				}
			}
		}
	});
	$('#btn_no').off("click").on("click",function(event){self.close_alertpane();});
	$('#alert_overlay').off("click").on("click",function(event){self.close_alertpane();});
	$('.at_close_icon').off("click").on("click",function(event){self.close_alertpane();});
};
$.fn.TreeEditor=function(options){
	var aneditor=new TreeEditorObject(this,options);
	aneditor.init();
	return aneditor;
};