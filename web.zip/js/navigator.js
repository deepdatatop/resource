	//dependence: "/css/navigator.css", "/js/superslide2.1.3.js"<!--used by carousel-->, "/js/superslide2.1.3.js"
	function NavigatorObject(element,options){
		this.element=element;
		this.defaults={
			zindex:10000,
			width:1200,
			height:460,
			access_url:'/cascade?catalog_id=#value#',/*sample*/
			txt_title:'category',
			txt_home:'home',
			carousel:{instance_name:'home',interface_name:'public_export'},/*in param*/
			readitems_url:'/drawhieritems',
			readinstance_url:'/drawinstance',
			codeset:'',
			language:2,
			item_option:[]
		};
		this.options=$.extend({},this.defaults,options);
		this.pos=new Object();/*the item_option pos(array index) vs value*/
		this.childlist=new Object();
		this.carousel=new Object();
    };
	NavigatorObject.prototype.extendHierarchyOption=function(){/*calculate option's isleaf,depth*/
		var myparent = new Object();
		var nchildren = new Object();
		var rv=this.options.root_id;
		nchildren[rv] = 0;
		this.childlist[rv]=new Array();
		var n=this.options.item_option.length;
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			var v=o.value;
			this.pos[v]=i;
			nchildren[v]=0;
			myparent[v]=o.parent;
			this.childlist[v]=new Array();
		}
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			var depth=1;
			var parent=o.parent;
			if(this.childlist.hasOwnProperty(parent)){
				this.childlist[parent].push(o.value);
			}
			nchildren[parent]+=1;
			while(parent!=rv&&myparent.hasOwnProperty(parent)){
				depth++;
				parent=myparent[parent];
			}
			o.depth=depth;
			this.options.item_option[i]=o;
		}
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			o.isleaf=(nchildren[o.value]==0);
			this.options.item_option[i]=o;
		}
	};
    NavigatorObject.prototype.init=function(){
		var self=this;
		$.ajaxSettings.async = false;
		$.getJSON(self.options.readitems_url,{cst:this.options.codeset,depth:3,lid:this.options.language,ico:1},function(m){
			if(m.Code=="100"){
				$(m.Items).each(function(){
					var o = new Object();
					o['value']=this.ID;
					o['parent'] = this.PID;
					o['label'] = this.Name;
					o['icon'] = this.Icon;
					self.options.item_option.push(o);
				});
			}else{alert(m.Code+' '+m.Msg);}
		});
		var o={idf:'carousel',inm:this.options.carousel.instance_name,jin:this.options.carousel.interface_name,lid:this.options.language};
		$.getJSON(self.options.readinstance_url,o,function(m){
			if(m.Code=="100"){
				self.carousel=JSON.parse(m.Json_text);
			}else{alert('read carousel:'+m.Code+' '+m.Msg);}
		});
			
		$.ajaxSettings.async = true;
		self.extendHierarchyOption();
		self.load();
    };
	NavigatorObject.prototype.loadnode=function(box,parent){
		var self=this;
		if(self.childlist.hasOwnProperty(parent)){
			var children = self.childlist[parent];
			var n=children.length;
			for(var i=0;i<n;i++){
				var idx=self.pos[children[i]];
				var itm=self.options.item_option[idx];
				var url=self.options.access_url.replace(/#value#/,itm.value);
				var txt='';
				switch(itm.depth){
				case 1:
					txt+='<li class="category-item';
					if(i==0){txt+=' top-cat';}
					txt+='">';
					txt+='<div class="sub-cat clearfix"><div class="sub-cat-links Left">';
					txt+='<ul id="n'+itm.value+'" class="sub-group clearfix"></ul></div></div>';
					if(itm.icon.length>0){
						if(itm.icon.indexOf('fa-')==0){txt+='<i class="fa fa-fw '+itm.icon+' txt"></i>';}
					}
					txt+='<a class="txt" href="'+url+'">'+itm.label+'</a></li>';
					box.append(txt);
					self.loadnode(box.find('#n'+itm.value),itm.value);
					break;
				case 2:
					txt+='<li class="Left sub-title">	<a href="'+url+'"><i class="i-t"></i>'+itm.label+'</a></li>';
					if(!itm.isleaf){txt+='<li id="n'+itm.value+'" class="Left sub-content"></li>';}
					box.append(txt);
					if(!itm.isleaf){self.loadnode(box.find('#n'+itm.value),itm.value);}
					break;
				case 3:
					txt+='<a href="'+url+'">'+itm.label+'</a>';
					box.append(txt);
					break;
				}
			}
		}		
	}
	NavigatorObject.prototype.load=function(){
		var self=this;
		var n=self.options.item_option.length;
		var thebox=this.element;
		thebox.width('100%');
		thebox.height(this.options.height);
		if(n>0){
			var ss='<div class="navigator"><div class="menu-bar"><div class="main-view"><div class="category">';
			ss+='<h2>'+this.options.txt_title+'</h2><ul id="firstlevel" class="category-option"></ul></div>';
			ss+='<ul class="shortcut"><li class="current"><a href="/">'+this.options.txt_home+'</a></li>';
			//'<li><a href="#">快捷链接</a></li>
			ss+='</ul>';
			ss+='</div></div></div>';
			thebox.append(ss);
			/*carousel*/
			var nn=self.carousel.bannergroup.length;
			ss='<div class="scroll-banner" style="background:';
			if(nn>0){ss+=self.carousel.bannergroup[0].background;}else{ss+='#ffffff';}
			ss+='">';
			ss+='<ul class="scroll-content">';
			for(var i=0;i<nn;i++){
				var banner=self.carousel.bannergroup[i];
				ss+='<li class="scroll-item" style="background:'+banner.background+';';
				if(i==0){ss+='display: block;';}
				ss+='">';
				ss+='<div class="scroll-index">';
				ss+='<a href="'+banner.hyperlink+'"><img class="sc-big fadeInR" src="'+banner.imagesrc+'"></a>';
				ss+='</div></li>';
			}
			ss+='</ul><div class="scroll-btn">';
			for(var i=0;i<nn;i++){
				ss+='<span';
				if(i==0){ss+=' class="current"';}
				ss+='></span>';
			}
			ss+='</div></div>';
			thebox.append(ss);
			$(".scroll-banner").slide({mainCell:".scroll-content",titCell:".scroll-btn span",
				titOnClassName:"current",effect:"fold",autoPlay:true,delayTime:self.carousel.delay,
				interTime:self.carousel.interval});
			var firstlevel=thebox.find('#firstlevel');
			self.loadnode(firstlevel,self.options.root_id);
			$('.category-option .category-item').hover(function(){$(this).toggleClass('hover')});
		}
	};
    $.fn.Navigator=function(options){
		var theNavigator=new NavigatorObject(this,options);
		theNavigator.init();
		return theNavigator;
    };