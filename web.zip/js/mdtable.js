/*Multiple Dimension table*/
function MDtableObject(element,options){
	this.element=element;
	this.defaults={
		width: 600,
		min_height: 200,
  		identifier: 'product',
		dim_scene: 'dimension',/*dimension_export*/
		dim_ids: '',/*1,3,7,5*/
		mdt_scene: 'skuprice',/*skuprice_list*/
		celltype: 'TXT',/*TXT or PIC*/
      	language: '',
      	drawinstances_url: '/drawinstances',
		readMultidimensiondata: function(identifier,mdt_scene){return {};}
	};
	this.toolbarheight=32;
	this.subentity='price';
	this.caption='price';
	this.valueproperty='price';
	this.dimensions=[];
	this.horizontal=[];
	this.vertical=[];
	this.hori_dimes=0;
	this.vert_dimes=0;
	this.celldata={};
	this.colIDs=[];
	this.rowIDs=[];
	this.dim_ids=[];/*dimension property id array*/
	this.dim_idx={};/*[id]=0..n*/
	this.options=$.extend({},this.defaults,options);
};
MDtableObject.prototype.setDimension=function(dimes){//1,5,3,2
    var self=this;
    var thebox=this.element;
    if(dimes.length>0){
	    $.getJSON(this.options.drawinstances_url,{idf:self.options.identifier,scene:self.options.dim_scene,lid:self.options.language,ids:dimes},function(m){
			if(m.Code=='100'){
				self.horizontal=[];self.vertical=[];
				self.dim_ids=[];self.dim_idx={};
				self.dimensions=JSON.parse(m.Instances_stringify);
				$.each(self.dimensions,function(i,o){self.dim_idx[o.id]=i;});
				
				var nd=self.dimensions.length;
				if(nd>1){self.vert_dimes=nd-1;}else{self.vert_dimes=nd;}
				self.hori_dimes=nd-self.vert_dimes;
				
				var vv=dimes.split(',');
				$.each(vv,function(ii,id){
					self.dim_ids.push(id);
					if(self.dim_idx.hasOwnProperty(id)){
						var idx=self.dim_idx[id];
						if(ii<self.vert_dimes){
							self.vertical.push(idx);
						}else{
							self.horizontal.push(idx);
						}
					}
				});
				self.setTable();
			}
		});
	}
	return self;
};
MDtableObject.prototype.getLatitude=function(rowpath){
	var o={};
	var rowids=rowpath.split('-');
	var n=this.vertical.length;
	if(n==rowids.length){
		for(var i=0;i<n;i++){
			var v=this.vertical[i];
			o[this.dimensions[v].id]=rowids[i];
		}
	}
	return JSON.stringify(o);
};
MDtableObject.prototype.mergeLongitude=function(olatitude,colpath){
	var kvkv=[];
	var o=JSON.parse(olatitude);
	if(colpath.length==0){
		for(let k in o){kvkv.push(k+'-'+o[k]);}
	}else{
		var colids=colpath.split('-');
		var n=this.horizontal.length;
		if(n==colids.length){
			for(var i=0;i<n;i++){
				var h=this.horizontal[i];
				o[this.dimensions[h].id]=colids[i];
			}				
			for(let k in o){kvkv.push(k+'-'+o[k]);}
		}
	}
	return kvkv.sort().join(';');
};
MDtableObject.prototype.cellBlock=function(val){
	var text=val;
	switch(this.options.celltype){
		case 'TXT':break;
		case 'PIC':
			text='<div class="md_image_cell"><img class="md_pic" src="'+val+'">';
			text+='<div class="md_pic_mask">';
			text+='<i class="md_pic_zoomin fa fa-arrows-alt fa-2x" src="'+val+'"></i>';
			text+='</div></div>';
			break;
	}
	return text;
};
MDtableObject.prototype.setTable=function(){
	var self=this;
	self.colIDs=[];self.rowIDs=[];
	var thebox=this.element;
	var first_row='';
	var rs='';
	if(self.hori_dimes>1){rs=' rowspan="'+self.hori_dimes+'"';}
	for(var i=0;i<self.vert_dimes;i++){
		var idx=self.vertical[i];
		first_row+='<td'+rs+' align="center" class="md_normal_cell">'+self.dimensions[idx].name+'</td>';
		self.colIDs.push('');
	}
	var dt_cells=self.colIDs.length;
	if(self.hori_dimes==0){
		first_row+='<td align="center" class="md_last_cell">'+self.caption+'</td>';
		self.colIDs.push('');
	}else{
		first_row+=self.horiTDs(0);
	}
	var txt='<tr class="md_normal_row">'+first_row+'</tr>';
	for(var i=1;i<self.hori_dimes;i++){
		txt+='<tr class="md_normal_row">'+self.horiTDs(i)+'</tr>';
	}
	dt_cells=self.colIDs.length-dt_cells;
	self.rowIDs=[''];
	for(var i=0;i<self.vert_dimes;i++){
		var idx=self.vertical[i];
		var oo=self.multiply(self.rowIDs,self.dimensions[idx].valueenum);
		self.rowIDs=oo.split(',');
	}
	var vspans=[];
	for(var i=0,n=self.rowIDs.length;i<n;i++){
		vspans[i]=new Array(self.vert_dimes).fill(1);
	}
	for(var i=0;i<self.vert_dimes;i++){
		var idx=self.vertical[i];
		var mm=1;
		if(i<self.vert_dimes-1){
			for(var j=i+1;j<self.vert_dimes;j++){
				idx=self.vertical[j];
				mm*=self.dimensions[idx].valueenum.length;
			}
		}
		if(mm>1){
			var m=self.rowIDs.length/mm;
			var ii=0;
			for(var k=0;k<m;k++){
				for(var kk=0;kk<mm;kk++){
					if(kk==0){vspans[ii][i]=mm;}else{vspans[ii][i]=0;}
					ii ++;
				}
			}
		}
	}
	var dttable=thebox.find('.md_dt_table');
	dttable.empty().append(txt);
	for(var i=0;i<self.rowIDs.length;i++){
		var cellclass='md_normal_cell';
		var rowclass='md_normal_row';
		if(i==self.rowIDs.length-1){rowclass='md_last_row';}
		var row='<tr class="'+rowclass+'">';
		var rsrs=vspans[i];
		var rowid=self.rowIDs[i];
		var idid=rowid.split('-');
		if(rsrs.length==idid.length){
			for(var j=0;j<self.vert_dimes;j++){
				var r_s=rsrs[j];
				if(r_s>0){
					var idx=self.vertical[j];
					var rs='';
					if(r_s>1){rs=' rowspan="'+r_s+'"';}
					row+='<td'+rs+' align="center" class="md_normal_cell">';
					var oo=self.dimensions[idx].valueenum,vt='';
					for(var k=0,n=oo.length;k<n;k++){
						var o=oo[k];
						if(o.id==idid[j]){
							vt=o.valuetext;
							break;
						}
					}
					row+=vt;
					row+='</td>';
				}
			}
			var oo=self.getLatitude(rowid);
			if(oo.length>2){
				if(self.vert_dimes==self.dimensions.length){
					cellclass='md_last_cell';
					var key=self.mergeLongitude(oo,'');
					var val='';
					if(self.celldata.hasOwnProperty(key)){
						val=self.celldata[key];
					}
					row+='<td class="'+cellclass+'">'+self.cellBlock(val)+'</td>';
				}else{
					for(var j=0;j<dt_cells;j++){
						if(j==dt_cells-1){cellclass='md_last_cell';}
						var key=self.mergeLongitude(oo,self.colIDs[j+self.vert_dimes]);
						var val='';
						if(self.celldata.hasOwnProperty(key)){
							val=self.celldata[key];
						}
						row+='<td class="'+cellclass+'">'+self.cellBlock(val)+'</td>';
					}
				}
			}
		}
		row+='</tr>';
		dttable.append(row);
	}
	var classname='md_transparent';
	var container=thebox.find('.md_tbldiv');
	var realheight=dttable.prop('scrollHeight')+self.toolbarheight;
	
	if(realheight>container.prop('scrollHeight')){
		if(!container.hasClass(classname)){
			container.addClass(classname);
		}
		self.showMorebutton();
	}else{
		container.css('height',realheight+'px');
		if(container.hasClass(classname)){
			container.removeClass(classname);
		}
		thebox.find('#md_more').hide();
	}
	thebox.find('.md_pic_zoomin').on('click',function(){
		$('body').Poppic({}).showPop('',$(this).attr('src'));
	});
};
MDtableObject.prototype.showMorebutton=function(){
	var self=this;
	var thebox=this.element;
	var total_height=thebox.find('.md_dt_table').prop('scrollHeight');
	if(total_height>this.options.min_height){
		var more=thebox.find('#md_more');
		more.css('display','block');
		more.off("click").on("click",function(event){
			var container=thebox.find('.md_tbldiv');
			total_height+=self.toolbarheight;
			container.css('height',total_height+'px');
			more.hide();
			container.removeClass('md_transparent');
		});
	}else{
		total_height+=self.toolbarheight;
		thebox.find('.md_tbldiv').css('height',total_height+'px');
	}
};
MDtableObject.prototype.multiply=function(pds,enums){
	var pdimes=[];
	var n=pds.length,m=enums.length;
	for(var i=0;i<n;i++){
		for(var j=0;j<m;j++){
			var id=pds[i];
			if(id.length>0){id+='-';}
			pdimes.push(id+enums[j].id);
		}
	}
	return pdimes.join();
};
MDtableObject.prototype.horiTDs=function(ihori){
	var self=this;
	var tds='';
	var c_s=1;
	for(var i=ihori+1;i<self.hori_dimes;i++){
		var idx=self.horizontal[i];
		c_s *= self.dimensions[idx].valueenum.length;
	}
	var pdimes=[''];
	for(var i=0;i<ihori;i++){
		var idx=self.horizontal[i];
		var oo=self.multiply(pdimes,self.dimensions[idx].valueenum);
		pdimes=oo.split(',');
	}
	var cellclass='md_normal_cell';
	var n=pdimes.length;
	for(var i=0;i<n;i++){
		var oo=self.dimensions[self.horizontal[ihori]].valueenum;
		for(var j=0,m=oo.length;j<m;j++){
			var o=oo[j];
			if(i==n-1&&j==m-1){cellclass='md_last_cell';}
			var cs='';
			if(c_s>1){cs=' colspan="'+c_s+'"';}
			tds+='<td'+cs+' align="center" class="'+cellclass+'">'+o.valuetext+'</td>';
			if(self.hori_dimes==(ihori+1)){
				var id=pdimes[i];
				if(id.length>0){id+="-";}
				id+=o.id;
				self.colIDs.push(id);
			}
		}
	}
	return tds;
};
MDtableObject.prototype.nodimension=function(){

};
MDtableObject.prototype.nodim_ids=function(cell){

};
MDtableObject.prototype.init=function(){
	var self=this;
	var thebox=this.element;
	if(self.options.mdt_scene.length>0){
		var dt=self.options.readMultidimensiondata(self.options.identifier,self.options.mdt_scene);
		/*{"subentity": "price",	"valueproperty": "price","cell": {"5-1;6-10;7-13;9-11":"123"}}*/
		self.subentity=dt['subentity'];
		self.caption=dt['caption'];
		self.valueproperty=dt['valueproperty'];
		if(self.options.dim_ids.length>0){
			self.celldata=dt.cell;
		}else{self.nodim_ids(dt.cell);}
	}
	thebox.empty();
	if(self.options.dim_ids.length==0){
		self.nodimension();
	}else{
		var tb_height=self.toolbarheight-1;
		var txt='<div id="md_toolbar" style="width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;">';
		txt+='<div id="bv"></div>';
		txt+='</div>';
		txt+='<div class="md_tbldiv" style="height:'+self.options.min_height+'px">';
		txt+='<table class="md_dt_table"></table>';
		txt+='</div>';
		txt+='<div id="md_more"><span class="md_seemore">查看更多 <i class="fa fa-lg fa-angle-down"></i></span></div>';
		thebox.append(txt);

		self.setDimension(self.options.dim_ids);
		if(self.dimensions.length>1){
			thebox.find('#bv').Boltview({onChange: function(verts){
				self.horizontal=[];self.vertical=[];
				var k=parseInt(verts);
				self.vert_dimes=k;
				self.hori_dimes=self.dimensions.length-k;
				for(var i=0,n=self.dim_ids.length;i<n;i++){
					var idx=self.dim_idx[self.dim_ids[i]];
					if(i<k){	self.vertical.push(idx);	}else{self.horizontal.push(idx);}
				}
				self.setTable();
		    }}).setValue(self.options.dim_ids);			
		}
	}
};
$.fn.MDtable=function(options){
	var md=new MDtableObject(this,options);
	md.init();
	return md;
};