/*inherit from Multidimensionbase, need load mdb.js first*/
function inheritPrototype(subObject, superObject){
	var prototype = Object.create(superObject.prototype);
	prototype.constructor = subObject;
	subObject.prototype = prototype;
}

function MultidimensionObject(element,options){
	var defaults={
		cell_format: ''
	};
	MultidimensionbaseObject.call(this,element,$.extend({},defaults,options));
};
inheritPrototype(MultidimensionObject,MultidimensionbaseObject);
MultidimensionObject.prototype.setupWidget=function(){
	var self=this;
	var thebox=this.element;
	thebox.empty();
	var tb_height=self.toolbarheight-1;
	var txt='<div id="pane">';
	txt+='<div id="a_toolbar" style="width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;background-color:#f9f9f9;">';
	txt+='<div id="mdsubject" style="float:left;">'+self.caption+':&nbsp;&nbsp;</div>';
	txt+='<div id="bolt" style="width:500px;float:left;"></div>';
	txt+='<div style="width:100px;float:left;text-align:center">';
	txt+='<i id="tableempty" class="fa fa-lg fa-trash-o"></i>';
	txt+='&nbsp;&nbsp;<i id="magic" class="fa fa-magic fa-flip-horizontal"></i>';
	txt+='</div>';
	txt+='<div id="ecbtn" style="float:right;width:24px;text-align:center">';
	txt+='<i id="md_ec" class="fa fa-expand" style="height:'+tb_height+'px;line-height:'+tb_height+'px;"></i>';
	txt+='</div>';
	txt+='</div>';
	var height=self.options.height-self.toolbarheight;
	txt+='<div id="cross_table" style="width:100%;height:'+height+'px;"></div>';
	txt+='</div>';
	thebox.append(txt);	
};
MultidimensionObject.prototype.makeDimensionCodes=function(){
	var self=this;
	var dt=[];
	var data=self.PqGrid.pqGrid("option","dataModel.data");
	var data_rows=data.length;
	for(var i=0,n=self.rowIDs.length;i<n;i++){
		if(i<data_rows){
			var rcode='';
			var d_ids=self.rowIDs[i].split('-');
			var rw=data[i],row=[];
			for(var j=0,m=self.vertical.length;j<m;j++){
				var idx=self.vertical[j];
				var o=self.dimensions[idx];
				var padwidth=o.padwidth;
				var vv=o.valueenum;
				var id=d_ids[j];
				for(var ii=0,nn=vv.length;ii<nn;ii++){
					if(id==vv[ii].id){
						var kk=ii+1;
						var v=kk.toString();
						rcode+=v.padStart(padwidth,'0');
						break;
					}
				}
				if(j<rw.length){row.push(rw[j]);}else{row.push('');}
			}
			if(self.vert_dimes==self.dimensions.length){
				row.push(rcode);
			}else{
				for(var j=self.vert_dimes,m=self.colIDs.length;j<m;j++){
					var ccode='';
					var c_ids=self.colIDs[j].split('-');
					for(var ii=0,nn=self.horizontal.length;ii<nn;ii++){
						var idx=self.horizontal[ii];
						var o=self.dimensions[idx];
						var padwidth=o.padwidth;
						var vv=o.valueenum;
						var id=c_ids[ii];
						for(var jj=0,mm=vv.length;jj<mm;jj++){
							if(id==vv[jj].id){
								var kk=jj+1;
								var v=kk.toString();
								ccode+=v.padStart(padwidth,'0');
								break;
							}
						}
					}
					row.push(rcode+ccode);
				}
			}	
			dt.push(row);
		}
	}
	self.PqGrid.pqGrid("option",{"dataModel":{"data":dt}});
	self.PqGrid.pqGrid("refreshDataAndView");
	self.modified();
};
MultidimensionObject.prototype.initex=function(){
	var self=this;
	var thebox=this.element;
		thebox.find('#magic').on('click',function(){
		$('body').YesnoAlert({
			yesText:self.options.txt_yes,noText:self.options.txt_no,
			doyes: function(id,action){
				self.makeDimensionCodes();
				var dt=self.readAllcells();
				self.updatecell={};for(var k in dt){self.updatecell[k]=dt[k];}
				self.modified();
			}
		}).show_alertpane('','是否按属性值顺序组合编码?','magic');
	});
};
$.fn.Multidimension=function(options){
	var md=new MultidimensionObject(this,options);
	md.init();
	return md;
};