	function TextEditorObject(element,options){
		this.outerID='';
		this.originText='';
		this.resultText='';
		this.element=element;
		var defaults={
			gistchars: 80,
			/*barwidth: 50,*/
			headingset: true,/*use for leaf node*/
			heading: false,
			cell_align: 'left',
			noindent: false,
			hintStr: 'ctrl+enter save text.',
			onAppend:function(){},
			onChange:function(id,gist,val){},
			screen:{}/*the output windows for text render*/
		};
		this.options=$.extend({},defaults,options);
		this.cell_align={};
    };
	TextEditorObject.prototype.setindent=function(){
		var indent=this.element.find('#indent');
		if(indent.length>0){
			var alignleft=(this.options.cell_align=='left');
			indent.css('display',alignleft?'inline-block':'none');
			if(alignleft){
				indent.find('#lnindent').prop('checked',!this.options.noindent);
			}
		}
	};
	TextEditorObject.prototype.init=function(){
		var obj=this;
		var self=this.element;
		self.empty();
		var ss='<div style="width:100%;height:36px;padding-top:2px;overflow:hidden;border-bottom:solid 1px #ccc;"><span id="te" style="font-size:24px;display:inline-block"><i class="fa fa-font"></i></span>';
		ss+='<span style="padding-left:3px;display:inline-block">文本标题：</span><input id="heading" type="checkbox">&nbsp;&nbsp;';
		ss+='<span style="padding-left:3px;display:inline-block">左右对齐：</span><span id="cellalign" style="display:inline-block"></span>';
		ss+='<span style="padding-left:13px;display:none;" id="indent">行首缩进：<input id="lnindent" type="checkbox"></span>';
		ss+='<div style="display:inline-block;position:absolute;right:0px;width:32px;">';
		ss+='<i class="fa fa-2x fa-trash-o te_empty"></i>';
		ss+='</div>';
		ss+='</div>';
		var toolbarheight=36;
		ss+='<textarea id="atext" style="width:100%;height:100px;outline:none;font-size:16px;line-height:20px;overflow-y:auto;border:none;resize:none"></textarea>';
		ss+='<div style="width:100%;height:'+toolbarheight+'px;font:14px/30px arial;color:#ccc;text-align:right;border-top:solid 1px #ccc;">';
		ss+='<span class="te_enter_button" id="undo" style="display:none"><i class="fa fa-undo"></i></span>';
		ss+='<span>&nbsp;↸&nbsp;'+obj.options.hintStr+'&nbsp;</span>';
		ss+='<span class="te_enter_button" id="enter" style="display:none"><i class="fa fa-level-down fa-lg fa-rotate-90"></i></span></div>';
		ss+='</div>';
		self.append(ss);
		obj.cell_align=self.find('#cellalign').StateButton({
			onChange: function(val) {
				obj.options.cell_align=val;
				obj.modified();
				obj.setindent();
				var box=obj.options.screen;
				if(JSON.stringify(box)!='{}'){
					var spantext=box.find('span.text');
					if(spantext.length>0){
						var aligns=['ht_left','ht_center','ht_right'];
						var classes=spantext.attr('class').split(' ');
						var ht_align='ht_'+val;
						if($.inArray(ht_align,classes)==-1){
							var i=$.inArray(ht_align,aligns);
							if(i>=0){aligns.splice(i,1);}
							$.each(aligns,function(i,align){
								if($.inArray(align,classes)>=0){
									spantext.removeClass(align);
								}
							});
							spantext.addClass(ht_align);
						}
					}
				}
			}
		}).Select(obj.options.cell_align);
		obj.setindent();
		self.find('#atext').on('keypress',function(e){
			if((e.keyCode == "13" || e.keyCode=="108") && e.ctrlKey){e.preventDefault();obj.clickEnter();}//ctrl+enter
			//alert(e.keyCode+'='+e.ctrlKey);
			//if(e.keyCode == "26" && e.ctrlKey){//ctrl+Z  同级新增item
			//	obj.options.onAppend();
			//}
		});
		self.find('#atext').on('input propertychange',function(e){
			self.find('#undo').show();self.find('#enter').show();
			obj.resultText = $(this).val();
		});
		self.find('#undo').on('click',function(){
			obj.setText(obj.originText);
		});
		self.find('.te_empty').on('click',function(){obj.empty();});
		self.find('#enter').on('click',function(){obj.clickEnter();});
		self.find('#lnindent').on('change',function(){obj.options.noindent=!$(this).prop('checked');obj.textindent();});
		self.find('#heading').on('change',function(){obj.options.heading=$(this).prop('checked');obj.textheading();});
	};
	TextEditorObject.prototype.textindent=function(){
		var obj=this;
		var box=obj.options.screen;
		if(JSON.stringify(box)!='{}'){
			var spantext=box.find('span.text');
			if(spantext.length>0){
				if(obj.options.noindent){
					spantext.removeClass('ht_indent');
				}else{
					spantext.addClass('ht_indent');
				}
			}
		}
		obj.modified();		
	};
	TextEditorObject.prototype.textheading=function(){
		var obj=this;
		var box=obj.options.screen;
		if(JSON.stringify(box)!='{}'){
			var spantext=box.find('span.text');
			if(spantext.length>0){
				if(obj.options.heading){
					spantext.removeClass('ht_text');
					spantext.addClass('ht_heading');
				}else{
					spantext.removeClass('ht_heading');
					spantext.addClass('ht_text');
				}
			}
		}
		obj.modified();		
	};
	TextEditorObject.prototype.resize=function(){
		var self=this.element;
		var toolbarheight=36;
		var height=self.innerHeight()-toolbarheight*2;
		self.find('#atext').css('height',height+'px');	
	};
	TextEditorObject.prototype.modified=function(){
		var gist='';
		var ss=this.resultText.split('\n');
		if(ss.length>0){
			gist=ss[0];
			if(gist.length>this.options.gistchars){
				gist=gist.substring(0,this.options.gistchars);
			}
		}
		this.options.onChange(this.outerID,gist,this.getText());
	};
	TextEditorObject.prototype.clickEnter=function(){
		var obj=this;
		this.element.find('#enter').hide();
		var box=obj.options.screen;
		if(JSON.stringify(box)!='{}'){
			var spantext=box.find('span.text');
			if(spantext.length>0){
				var ss = obj.resultText.replace(/\r\n/g,'<br>');
				spantext.html(ss.replace(/\n/g,'<br>'));
				//obj.options.cell_align --- need deal
			}
		}
		obj.modified();
	};
	TextEditorObject.prototype.empty=function(){
		var obj=this;
		if(obj.resultText.length>0){
			var box=obj.options.screen;
			if(JSON.stringify(box)!='{}'){box.find('span.text').empty();}//div.text
			obj.resultText='';
			if(obj.originText!==obj.resultText){obj.modified();}
			obj.refresh();
		}		
	};
	TextEditorObject.prototype.setScreen=function(div_item){
		this.options.screen=div_item;	
		if(div_item.children('span.text').length==0){
			div_item.append('<span class="text ht_text ht_indent ht_size"></span>');/*fault-tolerant*/
		}
	};
	TextEditorObject.prototype.show=function(){
		this.element.show();
	};
	TextEditorObject.prototype.hide=function(){
		this.element.hide();
	};
	TextEditorObject.prototype.setOuterID=function(id){
		this.outerID = id;
	};
	TextEditorObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	TextEditorObject.prototype.parseText=function(txt){
		var obj=this;
		obj.options.heading = false;
		obj.originText = '';
		obj.resultText = '';
		if(txt.length>0){
			var align='left';
			var ni=false;
			/*format: {"heading":false,"align":"left","noindent":true,"text":"abcd"}*/
			if(obj.isObjectText(txt)){
				var dt=JSON.parse(txt);
				if(dt.hasOwnProperty('heading')){obj.options.heading=dt.heading;}
				if(dt.hasOwnProperty('align')){
					if(dt.align.length>0){align=dt.align;}
				}
				if(dt.hasOwnProperty('text')){
					obj.originText=dt.text;
					obj.resultText=dt.text;
				}
				if(dt.hasOwnProperty('noindent')){
					if(align=='left'){ni=dt.noindent;}
				}
			}
			obj.options.noindent=ni;
			obj.options.cell_align=align;
		}
	};
	TextEditorObject.prototype.refresh=function(){
		var obj=this;
		var self=this.element;
		//var box=obj.options.screen;
		//if(JSON.stringify(box)!='{}'){
		//	if(obj.resultText.length==0){box.find('p.editorflag').show();}
		//}
		//add heading checkbox
		
		obj.setindent();
		self.find('#undo').hide();self.find('#enter').hide();
		self.find('#atext').val(obj.resultText).focus();
		obj.cell_align.Select(obj.options.cell_align);
		self.find('#heading').prop('checked',obj.options.heading);
	};
	TextEditorObject.prototype.setText=function(val){
		this.parseText(val);
		this.refresh();
		return this;
	};
	TextEditorObject.prototype.getText=function(){
		var dt={heading:this.options.heading,align:this.options.cell_align,text:this.resultText};
		if(this.options.cell_align=='left'){
			if(this.options.noindent){dt['noindent']=true;}/*default is auto_indent*/
		}
		return JSON.stringify(dt);
	};
    $.fn.TextEditor=function(options){
		var aneditor=new TextEditorObject(this,options);
		aneditor.init();
		return aneditor;
    };
