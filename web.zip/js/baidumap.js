function BaidumapObject(element,options){
	this.element=element;
	this.defaults={
		container:'map',
		longitude: 0,
		latitude: 0
	};
	this.options=$.extend({},this.defaults,options);
};
BaidumapObject.prototype.setmapaddress=function(){
	var self = this;
	var thebox = this.element;
	var theaddress = thebox.find('#address');
	theaddress.text(self.options.address);
	var map = new BMapGL.Map(self.options.container);
	if(self.options.longitude>0){
		var point=new BMapGL.Point(self.options.longitude,self.options.latitude);
		map.centerAndZoom(point, 16);
	}else{
		var gc = new BMapGL.Geocoder();
		gc.getPoint(self.options.address, function(point){
		    if(point){
		        map.centerAndZoom(point, 16);
		        map.addOverlay(new BMapGL.Marker(point, {title: self.options.address}));
		    }else{ theaddress.text('地址有误！'); }
		}, '中国');
	}
	map.enableScrollWheelZoom(true);
	map.addControl(new BMapGL.ZoomControl());
	map.addEventListener('click', function(e){
		map.clearOverlays();
		var pt = e.latlng;
		var marker = new BMapGL.Marker(new BMapGL.Point(pt.lng, pt.lat));
		map.addOverlay(marker);
		gc.getLocation(pt, function(rs){
			var ac = rs.addressComponents;
			theaddress.text(ac.province+ac.city+ac.district+' '+ac.street+ac.streetNumber);
		});
	});
};
BaidumapObject.prototype.init=function(){
	var self = this;
	var thebox = this.element;
	var container=thebox.find('#'+self.options.container);
	container.after('<div id="mappop"><span id="address"></span></div>');
	var offset=container.offset();
	var mappop=container.siblings('#mappop');
	mappop.css({'left':(offset.left+container.width()-mappop.width())+'px','top':(offset.top+1)+'px'});
	self.setmapaddress();
};
$.fn.Baidumap=function(options){
	var amap=new BaidumapObject(this,options);
	amap.init();
	return amap;
};