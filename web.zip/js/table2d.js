function Table2dObject(element,options){
	this.element=element;
	this.defaults={
		identifier: '',
		grid_scene: '',
		roadmapids: '0',
		onCopy: function(id, val){}
	};
	this.options=$.extend({},this.defaults,options);
};
Table2dObject.prototype.init=function(){
	var self=this,thebox=this.element,so=this.options;
	var scene=so.grid_scene;
	if(scene.indexOf('_grid')>0){
		scene=scene.replace('_grid','');
	}
	$.ajaxSettings.async = false;
	$.getJSON('/get2dtable',{idf:so.identifier,scene:scene,rmi:so.roadmapids},function(m){
		if(m.status=='success'){
			if(m.totals>0){
				var txt='<tr>'
				var names=m.names,nn=names.length;
				for(var i=0;i<nn;i++){
					txt+='<th>'+m.captions[i]+'</th>';
				}
				txt+='</tr>';
				for(var i=0,n=m.totals;i<n;i++){
					var dt=m.data[i],cla='white';
					if(i%2!=0){cla='emphasize';}
					txt+='<tr class="'+cla+'">';
					for(var j=0;j<nn;j++){
						var name=m.names[j];
						var render=m.renders[j];
						var style='text-align:'+m.aligns[j]+';width:'+m.widths[j];
						txt+='<td style="'+style+'">';
						var d_t='';
						if(dt.hasOwnProperty(name)){d_t=dt[name];}
						if(render.length>0){
							if(d_t.length>0&&render=='decoder'){
								txt+='<div uid="'+(i*nn+j)+'" class="decoder" dt="'+d_t+'">';
							}
						}else{
							txt+=d_t;
						}
						txt+='</td>';
					}
					txt+='</tr>';
				}
				thebox.append(txt);
			}
		}
	});
	$.ajaxSettings.async = true;
	thebox.find('.decoder').each(function() {
    	$(this).Decoder({
        	uniqueid: $(this).attr('uid'),
            encodedtext: $(this).attr('dt'),
            onCopy: function(id, val){so.onCopy(id, val);}
        });
    });
};
$.fn.Table2d=function(options){
	var t2d=new Table2dObject(this,options);
	t2d.init();
	return t2d;
};