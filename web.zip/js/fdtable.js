/*inherit from MDtable, need load mdtable.js first*/
function inheritPrototype(subObject, superObject){
	var prototype = Object.create(superObject.prototype);
	prototype.constructor = subObject;
	subObject.prototype = prototype;
}

function FDtableObject(element,options){
	var defaults={

	};
	MDtableObject.call(this,element,$.extend({},defaults,options));
	this.zerovalue='';
};
inheritPrototype(FDtableObject,MDtableObject);

FDtableObject.prototype.nodim_ids=function(cell){
	if(cell.hasOwnProperty('')){
		this.zerovalue=cell[''];
	}
};
FDtableObject.prototype.nodimension=function(){
	var self=this;
	var thebox=this.element;
	var tb_height=self.toolbarheight-1;
	var txt='<div style="width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;">';
	txt+='<span id="zerovalue">'+self.zerovalue+'</span>';
	txt+='</div>';
	thebox.append(txt);
};
$.fn.FDtable=function(options){
	var fd=new FDtableObject(this,options);
	fd.init();
	return fd;
};