function MDpictureObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		width: 600,
		min_height: 200,
		token: '',
  		identifier: 'product',
		dim_scene: 'dimension',/*dimension_export*/
		dim_ids: '',/*1,3*/
		mdt_scene: 'picture',/*picture_list*/
      	language: '',
      	drawinstances_url: '/drawinstances',
		txt_emptyornot: 'Empty or not?',
		txt_yes: 'Yes',
		txt_no: 'no',
		onChange: function(val){},
		saveRecent: function(src,tag){},
		readRecent: function(){return [];},
		readMultidimensiondata: function(identifier,mdt_scene){return {};}
	};
	this.toolbarheight=32;
	this.subentity='picture';
	this.caption='picture';
	this.valueproperty='src';
	this.new_dim_ids='';
	this.dimensions=[];
	this.horizontal=[];
	this.vertical=[];
	this.hori_dimes=0;
	this.vert_dimes=0;
	this.cellinit={};
	this.celldata={};
	this.colIDs=[];
	this.rowIDs=[];
	this.dim_ids=[];/*dimension property id array*/
	this.dim_idx={};/*[id]=0..n*/
	this.bolt=new Object();
	this.options=$.extend({},this.defaults,options);
};
MDpictureObject.prototype.modified=function(){
	var dt=[];
	for(var k in this.celldata){
		var v=this.celldata[k];
		var o={'properties':k};
		if(v.length>0){
			o[this.valueproperty]=v;
			if(this.cellinit.hasOwnProperty(k)){
				if(this.cellinit[k]!=v){dt.push(o);}
			}else{dt.push(o);}
		}else{
			if(this.cellinit.hasOwnProperty(k)){
				o['_m_']='DEL';dt.push(o);
			}
		}
	}
	this.new_dim_ids=this.dim_ids.join(',');
	if(this.new_dim_ids!=this.options.dim_ids){//release old dimension data
		for(var k in this.cellinit){
			dt.push({'properties':k,'_m_':'DEL'}); 
		}
	}	
	var nm=this.subentity+'dimension';
	var savedata={};
	savedata[nm]=this.new_dim_ids;
	savedata[this.subentity]=dt;
	this.options.onChange(JSON.stringify(savedata));
};
MDpictureObject.prototype.setDimension=function(dimes){//1,3
    var self=this;
    var thebox=this.element;
    if(dimes.length>0){
	    $.getJSON(this.options.drawinstances_url,{idf:self.options.identifier,scene:self.options.dim_scene,lid:self.options.language,ids:dimes},function(m){
			if(m.Code=='100'){
				self.horizontal=[];self.vertical=[];
				self.dim_ids=[];self.dim_idx={};
				self.dimensions=JSON.parse(m.Instances_stringify);
				$.each(self.dimensions,function(i,o){self.dim_idx[o.id]=i;});
				self.vert_dimes = self.dimensions.length;
				self.hori_dimes = 0;
				
				var vv=dimes.split(',');
				$.each(vv,function(ii,id){
					self.dim_ids.push(id);
					if(self.dim_idx.hasOwnProperty(id)){
						var idx=self.dim_idx[id];
						self.vertical.push(idx);
						//if(ii<self.vert_dimes){self.vertical.push(idx);}else{self.horizontal.push(idx);}
					}
				});
				self.setTable();
			}
		});
	}else{self.clearTable();}
	return self;
};
MDpictureObject.prototype.getLatitude=function(rowpath){
	var o={};
	var rowids=rowpath.split('-');
	var n=this.vertical.length;
	if(n==rowids.length){
		for(var i=0;i<n;i++){
			var v=this.vertical[i];
			o[this.dimensions[v].id]=rowids[i];
		}
	}
	return JSON.stringify(o);
};
MDpictureObject.prototype.mergeLongitude=function(olatitude,colpath){
	var kvkv=[];
	var o=JSON.parse(olatitude);
	if(colpath.length==0){
		for(let k in o){kvkv.push(k+'-'+o[k]);}
	}/*else{
		var colids=colpath.split('-');
		var n=this.horizontal.length;
		if(n==colids.length){
			for(var i=0;i<n;i++){
				var h=this.horizontal[i];
				o[this.dimensions[h].id]=colids[i];
			}				
			for(let k in o){kvkv.push(k+'-'+o[k]);}
		}
	}*/
	return kvkv.sort().join(';');
};
MDpictureObject.prototype.clearTable=function(){
	var dttable=this.element.find('#dt_table');
	dttable.empty();
};
MDpictureObject.prototype.setTable=function(){
	var self=this;
	self.colIDs=[];self.rowIDs=[];
	var thebox=this.element;
	var first_row='';
	var rs='';//if(self.hori_dimes>1){rs=' rowspan="'+self.hori_dimes+'"';}
	for(var i=0;i<self.vert_dimes;i++){
		var idx=self.vertical[i];
		first_row+='<td'+rs+' align="center" class="mdp_normal_cell">'+self.dimensions[idx].name+'</td>';
		self.colIDs.push('');
	}
	var dt_cells=self.colIDs.length;
	if(self.hori_dimes==0){
		first_row+='<td align="center" class="mdp_last_cell">'+self.caption+'</td>';
		self.colIDs.push('');
	}
	var txt='<tr class="mdp_normal_row">'+first_row+'</tr>';
	dt_cells=self.colIDs.length-dt_cells;
	self.rowIDs=[''];
	for(var i=0;i<self.vert_dimes;i++){
		var idx=self.vertical[i];
		var oo=self.multiply(self.rowIDs,self.dimensions[idx].valueenum);
		self.rowIDs=oo.split(',');
	}
	var vspans=[];
	for(var i=0,n=self.rowIDs.length;i<n;i++){
		vspans[i]=new Array(self.vert_dimes).fill(1);
	}
	for(var i=0;i<self.vert_dimes;i++){
		var idx=self.vertical[i];
		var mm=1;
		if(i<self.vert_dimes-1){
			for(var j=i+1;j<self.vert_dimes;j++){
				idx=self.vertical[j];
				mm*=self.dimensions[idx].valueenum.length;
			}
		}
		if(mm>1){
			var m=self.rowIDs.length/mm;
			var ii=0;
			for(var k=0;k<m;k++){
				for(var kk=0;kk<mm;kk++){
					if(kk==0){vspans[ii][i]=mm;}else{vspans[ii][i]=0;}
					ii ++;
				}
			}
		}
	}
	var dttable=thebox.find('#dt_table');
	dttable.empty().append(txt);
	for(var i=0;i<self.rowIDs.length;i++){
		var cellclass='mdp_normal_cell';
		var rowclass='mdp_normal_row';
		if(i==self.rowIDs.length-1){rowclass='mdp_last_row';}
		var row='<tr class="'+rowclass+'">';
		var rsrs=vspans[i];
		var rowid=self.rowIDs[i];
		var idid=rowid.split('-');
		if(rsrs.length==idid.length){
			for(var j=0;j<self.vert_dimes;j++){
				var r_s=rsrs[j];
				if(r_s>0){
					var idx=self.vertical[j];
					var rs='';
					if(r_s>1){rs=' rowspan="'+r_s+'"';}
					row+='<td'+rs+' align="center" class="mdp_normal_cell">';
					var oo=self.dimensions[idx].valueenum,vt='';
					for(var k=0,n=oo.length;k<n;k++){
						var o=oo[k];
						if(o.id==idid[j]){
							vt=o.valuetext;
							break;
						}
					}
					row+=vt;
					row+='</td>';
				}
			}
			var oo=self.getLatitude(rowid);
			if(oo.length>2){
				if(self.vert_dimes==self.dimensions.length){
					cellclass='mdp_last_cell';
					var key=self.mergeLongitude(oo,'');
					var val='';
					if(self.celldata.hasOwnProperty(key)){
						val=self.celldata[key];
					}
					if(val.length==0){
						val=self.imageaddBlock(key);
					}else{
						val=self.imageBlock(key,val);
					}
					row+='<td class="'+cellclass+'">'+val+'</td>';//val
				}
			}
		}
		row+='</tr>';
		dttable.append(row);
	}
	self.addActionListener(dttable);
};
MDpictureObject.prototype.imageaddBlock=function(key){
	var ss='<span class="image_add" key="'+key+'"><i class="fa fa-image fa-2x"></i></span>';
	return ss;
};
MDpictureObject.prototype.imageBlock=function(key,src){
	var ss='<div class="cell_image"><img src="'+src+'" style="max-width:100%;">';
	ss+='<div class="img_mask">';
	ss+='<i class="img_remove fa fa-times-circle-o fa-2x" key="'+key+'"></i>&nbsp;&nbsp;';
	ss+='<i class="img_zoomin fa fa-arrows-alt fa-lg" key="'+key+'"></i>';
	ss+='</div></div>';
	return ss;
}
MDpictureObject.prototype.addActionListener=function(thebox){
	var self=this;
	thebox.find('.image_add').off('click').on('click',function(event){
		var key=$(this).attr('key');
		var pbox=$(this).parent();
		$('body').Picpane({
			token: self.options.token,
			image_capacity: 1,
			onAdded: function(tag,src){
				self.celldata[key]=src;
				pbox.empty();
				pbox.append(self.imageBlock(key,src));
				self.addActionListener(pbox);
				self.modified();
			},
			readRecent: self.options.readRecent
		});		
	});
	thebox.find('.img_remove').off('click').on('click',function(event){
		var key=$(this).attr('key');
		var td=$(this).parents('td');
		$('body').YesnoAlert({
			yesText:self.options.txt_yes,noText:self.options.txt_no,
			doyes: function(id,action){
				self.celldata[key]='';//not use delete
				td.empty().append(self.imageaddBlock(key));
				self.addActionListener(td);
				self.modified();
			}
		}).show_alertpane('',self.options.txt_removeornot+'?','remove');
	});
	thebox.find('.img_zoomin').off('click').on('click',function(event){
		var src=self.celldata[$(this).attr('key')];
		$('body').Poppic({}).showPop('',src);
	});
};
MDpictureObject.prototype.multiply=function(pds,enums){
	var pdimes=[];
	var n=pds.length,m=enums.length;
	for(var i=0;i<n;i++){
		for(var j=0;j<m;j++){
			var id=pds[i];
			if(id.length>0){id+='-';}
			pdimes.push(id+enums[j].id);
		}
	}
	return pdimes.join();
};
MDpictureObject.prototype.nodimension=function(){

};
MDpictureObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){	o[k]=o.i18n[k];}
	}
};
MDpictureObject.prototype.init=function(){
	this.i18n_options();
	var self=this,so=this.options;
	this.new_dim_ids=so.dim_ids;
	var thebox=this.element;
	if(self.options.mdt_scene.length>0){
		var dt=self.options.readMultidimensiondata(so.identifier,so.mdt_scene);
		//{"subentity": "picture","valueproperty": "src","cell": {"5-1;6-10":"/abc.png"}}
		self.subentity=dt['subentity'];
		self.caption=dt['caption'];
		self.valueproperty=dt['valueproperty'];
		if(so.dim_ids.length>0){
			self.celldata={};
			self.cellinit={};
			for(var k in dt.cell){
				self.celldata[k]=dt.cell[k];
				self.cellinit[k]=dt.cell[k];
			}
		}
	}
	thebox.empty();
	var tb_height=self.toolbarheight;
	var txt='<div id="mdp_toolbar" style="width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;">';
	txt+='<div id="mdp_bolt"></div>';
	txt+='<div style="width:100px;float:left;text-align:center">';
	txt+='<i id="tableempty" class="fa fa-lg fa-trash-o"></i>';
	txt+='</div>';
	txt+='</div>';
	txt+='<table id="dt_table" style="width:100%;" class="mdp_normal_table"></table>';
	thebox.append(txt);
	self.bolt=thebox.find('#mdp_bolt').Bolt({
		i18n:so.i18n,
		usespinner: false,
		onChange: function(verts,dim_ids){
			self.setDimension(dim_ids);
		}
	}).setValue(so.dim_ids);//add before setDimension
	thebox.find('#tableempty').on('click',function(){
		$('body').YesnoAlert({
			yesText:so.txt_yes,noText:so.txt_no,
			doyes: function(id,action){
				var n=0;
				thebox.find('.img_remove').each(function(index,element){
					var ie=$(element);
					var key=ie.attr('key');
					if(self.celldata.hasOwnProperty(key)){
						self.celldata[key]='';
						n++;
					}
					ie.parents('td').empty().append(self.imageaddBlock(key));
				});
				if(n>0){
					self.addActionListener(thebox.find('#dt_table'));
					self.modified();
				}
			}
		}).show_alertpane('',so.txt_emptyornot+'?','empty');				
	});
	self.setDimension(so.dim_ids);
};
$.fn.MDpicture=function(options){
	var md=new MDpictureObject(this,options);
	md.init();
	return md;
};