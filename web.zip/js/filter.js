	function FilterObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			scene:'normal',
			option_width:300,
			tab_height:21,
			user_id:0,
			ip:0,
			entity_id:0,
			url_sequence:'/getdatalist?idf=searchhistory&scene=sequence',
			url_frequency:'/getdatalist?idf=searchhistory&scene=frequency',
			language_code:'en',
			txt_search:'Search',
			txt_reset:'Reset',
			txt_recent:'Recent',
			txt_bysequence:'by sequence',
			txt_byfrequency:'by frequency',
			txt_ok:'OK',
			txt_close:'Close',
			txt_today:'Today',
			txt_chooseperiod:'Choose period',
			txt_fullscreen:'Open fullscreen',
			txt_moveselect:'Move to select the desired period',
			txt_periodchooser:'Common used date periods:',
			/*txt_today:'Today',*/
			txt_yesterday:'Yesterday',
			txt_thisweek:'This week',
			txt_lastweek:'Last week',
			txt_last7days:'Last 7 days',
			txt_last14days:'Last 14 days',
			txt_thismonth:'This month',
			txt_lastmonth:'Last month',
			txt_last30days:'Last 30 days',
			txt_last60days:'Last 60 days',
			txt_last3months:'Last 3 months',
			txt_last6months:'Last 6 months',
			txt_thisyear:'This year',
			txt_lastyear:'Last year',
			htmblock:'',/*base64*/
			inputs:'',/*base64*/
			advanced:false,
			//readdefinition_url:'/readfilter',
			onSearch:function(q,p){}
		};
		this.options=$.extend({},this.defaults,options);
		this.content={};
		this.label={};
		this.editors={};
		this.mapProperty={};
		this.mapLabel={};
		this.mapDefault={};
		this.mapType={};
		this.inputss=[];
    };
	FilterObject.prototype.resetWidget=function(){
		var obj=this;
		var self=this.element;
		self.empty();
		if(this.options.htmblock.length>0){
			self.append($.base64.decode(this.options.htmblock));
    			var ss='<div class="f-element">';
			ss+='<button id="search" class="action"><i class="fa fa-search"></i>&nbsp;'+obj.options.txt_search+'</button>';
			ss+='<button id="reset" class="action"><i class="fa fa-remove"></i>&nbsp;'+obj.options.txt_reset+'</button>';
			ss+='<button id="history" class="action"><i class="fa fa-history"></i>&nbsp;'+obj.options.txt_recent+'</button>';
			ss+='</div>';
			ss+='<div id="so" class="history-option closed">';
			ss+='<span id="ho_close"><i class="fa fa-times-circle"></i></span>';
			ss+='<span class="tab_item_selected" id="sequence">'+obj.options.txt_bysequence+'</span>';
			ss+='<span class="tab_item" id="frequency">'+obj.options.txt_byfrequency+'</span>';
			var style='margin-top:'+obj.options.tab_height+'px;';
			style+='height:calc(100% - '+obj.options.tab_height+'px);';
			style+='background:#fff;border-top:1px solid #ccc;';
			ss+='<div id="histroymain" style="'+style+'"></div></div>';
			self.append(ss);
			self.find('#search').on('click',function(e){
				obj.options.onSearch(obj.getSieve(),obj.getPrompt());
				obj.closeHistoryOption();
				e.stopPropagation();
			});
			self.find('#reset').on('click',function(e){
				obj.closeHistoryOption();
				e.stopPropagation(); obj.set(''); obj.options.onSearch('','');
			});
			self.find('#history').on('click',function(e){
				e.stopPropagation(); obj.history();
			});
			self.find('#ho_close').on('click',function(e){
				obj.closeHistoryOption();
			});
			obj.bindTabclick();
		}
	};
	FilterObject.prototype.bindTabclick=function(){
		var obj=this;
		$('span.tab_item').bind('click',function(e){
			$(this).siblings('span.tab_item_selected').removeClass('tab_item_selected').addClass('tab_item');	
			$(this).removeClass('tab_item').addClass('tab_item_selected').unbind();	
			obj.bindTabclick();
			obj.setHistoryData();
		});
	};
	FilterObject.prototype.isclosedHistoryOption=function(){
		return this.element.find(".history-option").hasClass("closed");
	};
	FilterObject.prototype.openHistoryOption=function(){
		var obj=this;
		var self=this.element;
		if(obj.isclosedHistoryOption()){
			self.find(".history-option").removeClass("closed");
			var left,height;
			var theheight=self.height();
			var tt=self.offset().top+theheight;
			var top=tt+'px';
			var width=obj.options.option_width+'px';
			if(obj.options.scene=='top'){
				//alert(self.offset().left);
				//left=($(window).width()-obj.options.option_width)+'px';
				//height=($(window).height()-self.offset().top)+'px';
				//alert(left+'-'+top+'-'+width+'-'+height);
				left='100px';
				height='500px';
			}else{
				left=(self.offset().left+self.width()-obj.options.option_width-2)+'px';
				height=($(document).height()-tt)+'px';
			}
			self.find("#so").css({"left":left,"top":top,"width":width,"height":height});
			obj.setHistoryData();
		}
	};
	FilterObject.prototype.closeHistoryOption=function(){
		if(!this.isclosedHistoryOption()){
			var theoption=this.element.find(".history-option");
			theoption.addClass("closed");
		}
	};
	FilterObject.prototype.setHistoryData=function(){
		var obj=this;
		var self=this.element;
		var id=self.find('.tab_item_selected').attr('id');
		var main=self.find('#histroymain');
		main.empty();
		var url=this.options['url_'+id];
		$.getJSON(url,{},function(m){
			if(m.status=="success"){//{"status":"success","totals":1,"data":[{"id":1,"query":"name=abc","prompt":"","frequency":1}]}
				$(m.data).each(function(){
					var ss='<div class="historyitem" q="'+encodeURIComponent(this.query)+'">';
					var prompts=JSON.parse('{'+this.prompt+'}');
					var tt='';
					$.each(prompts,function(k,v){
						tt+='<span class="prompt_name">'+k+':</span><span class="prompt_value">'+v+'</span>';
					});
					ss+='<div class="prompt">'+tt+'</div>';
					ss+='<div style="color:#ccc;"><span><i class="fa fa-clock-o"></i>&nbsp;'+this.lasttime+'</span>';
					ss+='<span style="float:right;margin-right:2px">'+this.frequency+'&nbsp;<i class="fa fa-search-plus"></i></span>';
					ss+='</div></div>';
					main.append(ss);
				});
				$('.historyitem').on('click',function(e){
					var q='{'+decodeURIComponent($(this).attr('q'))+'}';
					obj.set(q);
					//obj.options.onSearch();
				});
			}
		});
	}
	FilterObject.prototype.history=function(){
		if(this.isclosedHistoryOption()){
			this.openHistoryOption();
		}else{
			this.closeHistoryOption();
		}
	};
	FilterObject.prototype.set=function(q){//'{"title":"abc","articlecategory":"2,3"}'
		var obj=this;
		var self=this.element;
		obj.content={};
		obj.label={};
		var qq=q;if(q.length==0){qq='{'+q+'}';}
		var query=JSON.parse(qq);
		//var inputs_block=this.options.inputs;
		//if(inputs_block.length>0){inputs_block=$.base64.decode(inputs_block);	}
		//var inputs=JSON.parse(inputs_block);
		for(var i in obj.inputss){
			var a = obj.inputss[i];
			var property=obj.mapProperty[a.id];
			var caption=obj.mapLabel[a.id];
			var value='';
			if(query.hasOwnProperty(property)){
				value=query[property];
				obj.content[property]=value;
			}else{
				if(obj.mapDefault.hasOwnProperty(a.id)){
					value=obj.mapDefault[a.id];
				}
			}
			switch(a.type){
			case 'selector':
				obj.label[caption]=obj.editors[a.id].setResult(value);
				break;
			case 'input':
				self.find('#'+a.id).val(value);
				obj.label[caption]=value;
				break;
			case 'daterange':
				var start='',end='';
				var ss=value.split(',');
				if(ss.length==2){start=ss[0];end=ss[1];}
				obj.editors[a.id].setRange(start,end);
				obj.label[caption]=value;
				break;
			}
		}
	};
	FilterObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
    FilterObject.prototype.init=function(){
    	this.i18n_options();
		this.setFilter();
	}
    FilterObject.prototype.reset=function(entity_id,htmblock_bs64,inputs_bs64){
    	this.options.entity_id=entity_id;
		this.options.htmblock=htmblock_bs64;
		this.options.inputs=inputs_bs64;
		this.setFilter();
	}	
	FilterObject.prototype.setFilter=function(){	
		var uie='&user_id='+this.options.user_id+'&ip='+this.options.ip+'&_eid_='+this.options.entity_id;
		this.options.url_sequence += uie;
		this.options.url_frequency += uie;
		var obj=this;
		var self=this.element;
		obj.resetWidget();
		if(obj.options.inputs.length>0){
			obj.inputss=JSON.parse($.base64.decode(this.options.inputs));
		}
		for(var i in obj.inputss){
			var a = obj.inputss[i];
			obj.mapProperty[a.id]=a.property;
			obj.mapLabel[a.id]=a.caption;
			var def='';if(a.hasOwnProperty('default')){def=a.default;}
			obj.mapDefault[a.id]=def;
			var ele=self.find('#'+a.id);
			if(ele.length>0){
				switch(a.type){
					case 'daterange':
						var sdate='',edate='';
						if(a.default.length>0){
							obj.content[a.property]=a.default;
							var ss=a.default.split(',');
							if(ss.length==2){sdate=ss[0];edate=ss[1];}
						}
						obj.editors[a.id]=ele.Daterange({
							i18n: obj.options.i18n,
							outerid: a.id,
							onChange: function(id,start,end){
								var property=obj.mapProperty[id];
								var val=start+','+end;
								if(val==','){val='';}
								obj.content[property]=val;
								var caption=obj.mapLabel[id];
								obj.label[caption]=val;
							},
							startDate: sdate,
							endDate: edate,
							language_code:obj.options.language_code,
							txt_ok:obj.options.txt_ok,
							txt_close:obj.options.txt_close,
							txt_today:obj.options.txt_today,
							txt_chooseperiod:obj.options.txt_chooseperiod,
							txt_fullscreen:obj.options.txt_fullscreen,
							txt_moveselect:obj.options.txt_moveselect,
							txt_periodchooser:obj.options.txt_periodchooser,
							txt_yesterday:obj.options.txt_yesterday,
							txt_thisweek:obj.options.txt_thisweek,
							txt_lastweek:obj.options.txt_lastweek,
							txt_last7days:obj.options.txt_last7days,
							txt_last14days:obj.options.txt_last14days,
							txt_thismonth:obj.options.txt_thismonth,
							txt_lastmonth:obj.options.txt_lastmonth,
							txt_last30days:obj.options.txt_last30days,
							txt_last60days:obj.options.txt_last60days,
							txt_last3months:obj.options.txt_last3months,
							txt_last6months:obj.options.txt_last6months,
							txt_thisyear:obj.options.txt_thisyear,
							txt_lastyear:obj.options.txt_lastyear
						});
					break;
					case 'selector':
						var r_type='ids',rt='result_type';
						if(a.param.hasOwnProperty(rt)){r_type=a.param[rt];}
						obj.mapType[a.id]=r_type;
						var m_c=false,mc='multiple_choice';
						if(a.param.hasOwnProperty(mc)){
							m_c=a.param[mc];
						}
						obj.editors[a.id]=ele.Selector({
							property:a.property,
							codeset:a.param['codeset'],
							result_type:r_type,
							multiple_choice:m_c,
							language:a.param['language'],
							onChange: function(aid,ids,codes,labs,pathids,pathnames){
								var property=obj.mapProperty[aid];
								switch(obj.mapType[aid]){
									case 'ids':obj.content[property]=ids.join();break;
									case 'dotids':obj.content[property]=pathids.join();break;
									case 'codes':obj.content[property]=codes.join();break;
								}
								var caption=obj.mapLabel[aid];
								obj.label[caption]=labs.join();
							}
						});
					break;
					case 'input':
						ele.on('input propertychange',function(e){
							var id=$(this).attr('id');
							var property=obj.mapProperty[id];
							obj.content[property]=$(this).val();
							var caption=obj.mapLabel[id];
							obj.label[caption]=$(this).val();
							e.preventDefault();
						});
					break;
				}
			}
		}
    };
	FilterObject.prototype.getSieve=function(){
		var obj=this;
		var vv=new Array();
		for(var k in obj.content){
			var v=$.trim(obj.content[k]);
			v=v.replaceAll('"','');
			if(v.length>0){
				vv.push('"'+k+'":"'+v+'"');
			}
		}
		return vv.join();
	};
	FilterObject.prototype.getPrompt=function(){
		var obj=this;
		var vv=new Array();
		for(var k in obj.label){
			var v=$.trim(obj.label[k]);
			if(v.length>0){
				vv.push('"'+k+'":"'+v+'"');
			}
		}
		return vv.join();
	};
    $.fn.Filter=function(options){
		var afilter=new FilterObject(this,options);
		afilter.init();
		return afilter;
    };
