function BoltObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		width: 400,
		checkbox: true,
		usespinner: true,
		caption:'dimension',
  		identifier: 'product',
		roadmapids: '1',
		bolt_scene: 'bolt',
		sortlist_scene: 'issales',
      	language: '',
		pop_zindex: 20000,
		pop_width: 500,
		pop_height: 650,
		txt_hint: 'Click ⇳ press and move item up-down',
		txt_ok: 'Confirm',
      	drawinstances_url: '/drawinstances',
		onChange: function(verts,data){},
		onChangeVerticals: function(verts){}
	};
	this.popoverlay='bolt_popoverlay';
	this.poppane='bolt_poppane';
	this.value='';
	this.verticals=0;
	this.dimensions=0;
	this.spinner=new Object();
	this.options=$.extend({},this.defaults,options);
};
BoltObject.prototype.setValue=function(val){//val: 1,5,3
    this.value=val;
    var n=0;
    if(val.length>0){
    		var vv=val.split(',');
		n=vv.length;this.dimensions=n;
		if(this.options.usespinner){
			if(n>1){n-=1;}
		}
    }
    this.verticals=n;
    var di=this.element.find('#dimes');
    if(this.dimensions>1){
    		di.show();
		if(this.options.usespinner){
			this.spinner.setMax(this.dimensions).setValue(this.verticals);
		}
    }else{di.hide();}
    this.refreshBolt();
    return this;
};
BoltObject.prototype.setVerticals=function(nn){
	this.verticals=nn;
	var thebox=this.element;
	var bolts=thebox.find('.bolt-lnk');
	var lv='lnk-vert',lh='lnk-hori';
	bolts.each(function(i,a){
		var bolt=$(a);
		if(i<nn){
        		if(bolt.hasClass(lh)){
				bolt.removeClass(lh).addClass(lv);
			}
        }else{
        		if(bolt.hasClass(lv)){
				bolt.removeClass(lv).addClass(lh);
			}
        }
	});
};
BoltObject.prototype.refreshBolt=function(){
    var self=this;
    var thebox=this.element;
    if(self.value.length>0){
    		$.getJSON(this.options.drawinstances_url,{idf:self.options.identifier,scene:self.options.bolt_scene,lid:self.options.language,ids:self.value},function(m){
			if(m.Code=='100'){
				var tt={};
				if(m.Instances_stringify.length>0){
					var oo=JSON.parse(m.Instances_stringify);
					$.each(oo,function(i,o){
						tt[o.id]='<i class="fa fa-chevron-circle-right bolt-lnk lnk-hori"></i><span class="bolt-cap">'+o.name+'</span>';
					});
				}
				var txt='';
				var vv=self.value.split(',');
				var n=vv.length;
				if(self.verticals>n){self.verticals=n;}
				for(var i=0;i<n;i++){
					v = vv[i];
					if(tt.hasOwnProperty(v)){
						var t=tt[v];
						if(i<self.verticals){
							t=t.replace(/lnk-hori/g, 'lnk-vert');
						}
						txt+=t;
					}
				}
				thebox.find('#bolt_left').empty().append(txt);
			}
		});
	}else{
		thebox.find('#bolt_left').empty();
	}	
};
BoltObject.prototype.closePop=function(){
	this.element.find('#'+this.popoverlay).remove();
	this.element.find('#'+this.poppane).remove();	
};
BoltObject.prototype.showPop=function(){
    var self=this,so=this.options;
    var thebox=this.element;
	thebox.append('<div id="'+self.popoverlay+'" style="z-index: '+so.pop_zindex+';"></div>');
	var ao=thebox.find('#'+self.popoverlay).css({"display":"block",opacity:0}).fadeTo(200,0.35);
	var txt='<div id="'+self.poppane+'" style="display: none;';
	txt += 'width:'+so.pop_width+'px;height:'+so.pop_height+'px;"">';
	txt += '<span id="pl_close_icon"><i class="fa fa-close"></i></span>';
	txt += '<div class="pl_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
	txt += '<div id="pl_hint"><span>'+so.txt_hint+'<i class="fa fa-level-down"></i></span></div>';
	txt += '<div style="margin:0 auto;width:'+(so.pop_width-20)+'px;height:'+(so.pop_height-90)+'px;" id="sort_list"></div>';
	txt += '<div class="pl_panebtm">';
	txt += '<span class="pl_button" id="btn_ok"><i class="fa fa-times-circle-o">&nbsp;'+so.txt_ok+'</i></span></div>';
	txt += '</div>';
	txt += '</div>';
	thebox.append(txt);
	thebox.find('#sort_list').Sortlist({identifier:self.options.identifier,scene:self.options.sortlist_scene,checkbox:true,onChange:function(data){
		/*{"checked":"3","items":[{"id":"3","ordinalposition":1}]}*/
		var dt=JSON.parse(data);
		self.setValue(dt.checked);
	}}).setValue(so.roadmapids,self.value);
	var pane = thebox.find('#'+self.poppane);
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.pop_zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('#btn_ok').off("click").on("click",function(event){
		event.stopPropagation();
		self.closePop();
		self.refreshBolt();
		self.modified();
	});
	thebox.find('#'+self.popoverlay).off("click").on("click",function(event){self.closePop();});
	thebox.find('#pl_close_icon').off("click").on("click",function(event){self.closePop();});
}
BoltObject.prototype.modified=function(){
    this.options.onChange(this.verticals,this.value);
};
BoltObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){	o[k]=o.i18n[k];}
	}
};
BoltObject.prototype.init=function(){
	this.i18n_options();
    var self=this;
    var thebox=this.element;
    thebox.css({position:'relative',height:'30px',border:'solid 1px #ccc','border-radius':'3px'});
    var txt='<div id="bolt_left"></div>';
    txt+='<div id="bolt_right"><span class="bolt-set"><i class="fa fa-list-ol"></i></span>';
    txt+='<div id="dimes" style="float:right"></div>';
    txt+='</div>';
    thebox.append(txt);
	thebox.find('.bolt-set').off("click").on("click",function(event){
		event.stopPropagation();
		self.showPop();
	});
	if(self.options.usespinner){
		self.spinner=thebox.find('#dimes').Simplespinner({width:25,min:1,max:self.dimensions,onChange: function(val){
			self.setVerticals(val);
			self.options.onChangeVerticals(self.verticals);
		}}).setValue(self.verticals);
	}
};
$.fn.Bolt=function(options){
	var abolt=new BoltObject(this,options);
	abolt.init();
	return abolt;
};