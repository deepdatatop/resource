/*inherit from HierarchyObject, need load h+tree.js first*/
	function inheritPrototype(subObject, superObject){
		var prototype = Object.create(superObject.prototype);
		prototype.constructor = subObject;
		subObject.prototype = prototype;
	}
	function TreeTextObject(element,options){
		var defaults={
			i18n:{},
			gistsize:40,
			txt_yes:'Yes',
			txt_no:'No',
			txt_removeornot:'Remove',
			txt_descendant:'and all descendant',
			onEmpty:function(){},
			onTextImport:function(pid){}
		};
		HierarchyObject.call(this,element,$.extend({},defaults,options));
		this.newIDs=new Array();
		this.rmvIDs=new Array();
		this.maxid=0;//use for id generator
		this.noitemcaution=false;
    };
	inheritPrototype(TreeTextObject,HierarchyObject);
	TreeTextObject.prototype.getNewIDs=function(){
		return this.newIDs.join();
	};
	TreeTextObject.prototype.getRmvIDs=function(){
		return this.rmvIDs.join();
	};
	TreeTextObject.prototype.loadoption=function(value){
		var id=parseInt(value);
		if(id>this.maxid){this.maxid=id;}
	};
	TreeTextObject.prototype.refreshID=function(mapID){
		var oids=Object.keys(mapID);
		var rcb=this.rootchildbox;
		$.each(oids,function(i,oid){
			var nid=mapID[oid];
			rcb.find('.item#'+oid).attr('id',nid);
			rcb.find('.children#cld'+oid).attr('id','cld'+nid);
		});
		this.newIDs.length=0;
		this.rmvIDs.length=0;
	};
	TreeTextObject.prototype.emptyitem=function(){
		var self=this;
		self.newIDs.length=0;
		self.rootchildbox.find('.item').each(function(){
			var id=$(this).attr('id');
			if(id.substr(0,1)!='n'){
				self.rmvIDs.push(id);
			}
		});
		self.options.onEmpty();
		self.maxid=0;
		self.rootchildbox.empty();
	};
	TreeTextObject.prototype.defaultFocus=function(){
		var thebox=this.element;
		var no_item=true;
		if(this.rootchildbox.length>0){
			var itm=this.rootchildbox.children('.item:first-child');
			if(itm.length>0){
				no_item=false;
				this.focusItem(itm);
				var id=itm.attr('id');
				this.options.onChange(id,itm.find('.itemcaption').text());
			}
		}
		if(no_item){
			this.firsttextimport();
		}
	};
	TreeTextObject.prototype.firsttextimport=function(){
		this.options.onTextImport(this.options.root_id);
	};
	TreeTextObject.prototype.firstitem=function(){
		var self=this;
		var thebox=this.element;
		var rcb=self.rootchildbox;
		if(rcb.length>0){
			var depth=1;
			var indent = '';
			self.maxid++;
			var newID='n'+self.maxid; self.newIDs.push(newID);
			self.options.onParentChange(newID,self.options.root_id);
			var tt = '<div class="item" id="'+newID+'" depth="'+depth+'">';
			tt += '<span class="indent"><div depth="'+depth+'" class="noline"></div></span>';
			var linetype = 'tr';
			var iclass = 'leaf';
			tt += '<div class="hook '+iclass+' '+linetype+iclass+'"></div>';
			tt += self.itemflag(newID,depth,0,1,true);
			tt += '<span class="itemcaption color'+(depth%6).toString()+'">';
			tt += '<i class="fa fa-magic fa-flip-horizontal blank"></i>';
			tt += '</span>';
			tt += '</div>';
			rcb.append( tt ); var newitm=cld0.find('div#'+newID);
			self.savePosition(newitm.parent());
			self.registerFlagEvent(newitm);
			self.registerItemcaptionEvent(newitm);
			self.focusItem(newitm);/*item_focus flag*/
			self.options.onNewItem(self.options.root_id,newID);/*bodyview.append*/
		}else{
			alert('no root child box');
		}
	};
	TreeTextObject.prototype.focusitemid=function(){
		var thebox=this.element;
		var focusid=this.options.root_id;
		var itm=thebox.find('.item_focus');
		if(itm.length>0){
			focusid=itm.parents('div.item').attr('id');
		}
		return focusid;
	};
	TreeTextObject.prototype.setItemCaption=function(id,caption){
		var thebox=this.element;
		thebox.find('#'+id).children('.itemcaption').html(caption);
	};
	TreeTextObject.prototype.itemflag=function(id,depth,i,n,isleaf){
		/*var leaf='0';
		if(isleaf){leaf='1';}*/
		var tt = '';
		if(depth>1){tt += '<div class="upgradeitem"></div>';}
		if(i>0){tt += '<div class="downgradeitem"></div>';}
		tt += '<div class="newitem"></div>';
		tt += '<div class="itemtrash"></div>';//' leaf="'+leaf+'"></div>';
		if(n>1){
			if(i>0){tt += '<div class="moveup"></div>';}
			if(i<n-1){tt += '<div class="movedown"></div>';}
		}
		if(isleaf){tt += '<div class="splititem"></div>';}
		return tt;
	};
	TreeTextObject.prototype.do_moveup=function(itm,cld,pre,prc,nxt){
		var self=this;
		var depth=parseInt(itm.attr('depth'));
		var ppre=pre.prev();
		self.insmoveup(pre);
		self.insdowngrade(pre);
		self.insmovedown(itm);
		itm.insertBefore(pre);
		if(nxt.length==0){
			self.rmvmovedown(pre);
			self.changehook(itm,'tr','vr');
			self.changehook(pre,'vr','tr');
		}
		if(cld.length>0){
			cld.insertBefore(pre);
			if(nxt.length==0){
				self.noline2vline(cld,depth+1);
			}
		}
		if(prc.length>0&&nxt.length==0){
			self.vline2noline(prc,depth+1);
		}
		if(ppre.length==0){
			self.rmvmoveup(itm);
			self.rmvdowngradeitem(itm);
		}
		var id=itm.attr('id');
		self.options.onMoveup(id);
		self.savePosition(itm.parent());	
		self.options.onChange(id,itm.find('.itemcaption').text());
	};
	TreeTextObject.prototype.moveup=function(itm){
		var self=this;
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		var pre = itm.prev();
		var prc = itm.prev();
		if( prc.length>0 ){
			if(prc.attr('class')=='children'){
				pre = prc.prev();
			}else{prc.length=0;}
		}
		if(pre.length>0){
			var codeset=this.options.codeset;
			if(codeset.length==0){
				self.do_moveup(itm,cld,pre,prc,nxt);
			}
		}
	};
	TreeTextObject.prototype.do_movedown=function(itm,cld,nxt){
		var self=this;
		var depth=parseInt(itm.attr('depth'));
		var ncld=nxt.next();
		var nnxt=nxt.next();
		if( ncld.length>0 ){
			if(ncld.attr('class')=='children'){
				nnxt = ncld.next();
			}else{ncld.length=0;}
		}
		self.insmovedown(nxt);
		if(itm.prev().length==0){self.rmvmoveup(nxt);self.rmvdowngradeitem(nxt);}
		var np=ncld;
		if(np.length==0){np=nxt;}
		if(cld.length>0){cld.insertAfter(np);}
		itm.insertAfter(np);
		self.insmoveup(itm);
		self.insdowngrade(itm);
		if(nnxt.length==0){
			self.changehook(nxt,'tr','vr');
			self.rmvmovedown(itm);
			if(cld.length>0){self.vline2noline(cld,depth+1);}
			if(ncld.length>0){self.noline2vline(ncld,depth+1);}
			self.changehook(itm,'vr','tr');
		}
		var id=itm.attr('id');
		self.options.onMovedown(id);
		self.savePosition(itm.parent());
		self.options.onChange(id,itm.find('.itemcaption').text());	
	};
	TreeTextObject.prototype.movedown=function(itm){
		var self=this;
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		if(nxt.length>0){
			var codeset=this.options.codeset;
			if(codeset.length==0){
				self.do_movedown(itm,cld,nxt);
			}
		}
	};
	TreeTextObject.prototype.splititem=function(itm){
		var self=this;
		var depth=parseInt(itm.attr('depth'))+1;
		var id=itm.attr('id');
		var indent = '';
		var idt = itm.children('span.indent');
		if( idt.length>0 ){idt.find('.item_focus').remove();indent=idt.html();}
		var nxt = itm.nextAll('.item:first');
		indent += '<div depth="'+depth+'" class="'+((nxt.length>0)?'v':'no')+'line"></div>';
		this.maxid++;
		var newID='n'+this.maxid; this.newIDs.push(newID);
		this.options.onParentChange(newID,id);
		this.options.onSplitItem(id,newID);
		var tt = '<div class="children" id="cld'+id+'">';
		tt += '<div class="item" id="'+newID+'" depth="'+depth+'">';
		tt += '<span class="indent">'+indent+'</span>';
		var linetype = 'tr'; var iclass = 'leaf';
		tt += '<div class="hook '+iclass+' '+linetype+iclass+'"></div>';
		tt += self.itemflag(newID,depth,0,1,true);
		tt += '<span class="itemcaption color'+(depth%6).toString()+'">';
		tt += '<i class="fa fa-magic fa-flip-horizontal blank"></i>';
		tt += '</span>';
		tt += '</div></div>';
		itm.after( tt ); var newitm=itm.next().find('#'+newID);
		self.savePosition(newitm.parent());
		self.registerFlagEvent(newitm);
		self.registerItemcaptionEvent(newitm);
		self.rmvsplititem(itm);
		self.changehook(itm,'leaf','expand');
		var ie = itm.children('div.expand');
		if(ie.length==1){self.registerExpandEvent(ie);}
		self.focusItem(newitm);
		self.options.onChange(newID,newitm.find('.itemcaption').text());
	};
	TreeTextObject.prototype.do_upgrade=function(itm,cld,nxt,pre,pcd){
		var self=this;
		var depth=parseInt(itm.attr('depth'));
		var pcld=itm.parent();
		var pitm=pcld.prev();
		var pnxt=pcld.next();
		if(pre.length>0&&nxt.length==0){
			self.changehook(pre,'vr','tr');
			self.rmvmovedown(pre);
			if(pcd.length>0){self.vline2noline(pcd,parseInt(pre.attr('depth'))+1);}
		}
		self.rmvindent(itm,depth);
		if(cld.length>0){
			cld.insertAfter(pcld);
			self.rmvindent(cld,depth);
			if(pnxt.length==0){
				self.vline2noline(cld,depth);
			}else{
				if(nxt.length==0){self.noline2vline(cld,depth);}
			}
			self.decdepth(cld);
		}
		self.insmoveup(itm);
		self.insdowngrade(itm);
		if(pnxt.length>0){
			self.insmovedown(itm);
		}else{
			self.rmvmovedown(itm);self.insmovedown(pitm);self.changehook(pitm,'tr','vr');
		}
		if(depth==2){self.rmvupgradeitem(itm);}
		self.decitemdepth(itm);
		itm.insertAfter(pcld);
		if(pcld.children().length==0){
			var pid=pcld.attr('id').replace('cld','');
			self.options.onPositionChange(pid,'');
			pcld.remove();
			var ie=pitm.children('div.expand');if(ie.length==1){ie.off('click');}
			self.changehook(pitm,'expand','leaf');
			self.inssplititem(pitm);
		}else{
			if(pnxt.length==0){self.noline2vline(pcld,depth);}
			self.savePosition(pcld);
		}
		self.bendhook(itm,pnxt.length>0);
		if(nxt.length>0){
			if(pre.length==0){self.rmvmoveup(nxt);self.rmvdowngradeitem(nxt);}
		}
		self.savePosition(pitm.parent());	
		self.options.onChange(itm.attr('id'),itm.find('.itemcaption').text());
	};
	TreeTextObject.prototype.upgradeitem=function(itm){
		var self=this;
		var pre=itm.prev();
		var pcd=itm.prev();
		if( pcd.length>0 ){
			if( pcd.attr('class')=='children' ){
				pre = pcd.prev();
			}else{pcd.length=0;}
		}
		var cld=itm.next();
		var nxt=itm.next();
		if( cld.length>0 ){
			if( cld.attr('class')=='children' ){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		var pid=0;var preid=0;
		var p=itm.parent().prev();
		if(p.length>0){
			preid = parseInt(p.attr('id'));
			if(preid>0){
				p=p.parent().prev();
				if(p.length>0){pid = parseInt(p.attr('id'));}
			}
		}
		var codeset=this.options.codeset;
		if(codeset.length==0){
			self.options.onUpgrade(itm.attr('id'));
			self.do_upgrade(itm,cld,nxt,pre,pcd);
		}
	};
	TreeTextObject.prototype.do_downgrade=function(itm,pre,pcd){
		var self=this;
		var depth=parseInt(itm.attr('depth'));
		var cld=itm.next();
		var nxt=itm.next();
		if( cld.length>0 ){
			if( cld.attr('class')=='children' ){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		if(pre.length>0){
			var npre = new Object();//new pre
			var npcd = new Object();//new pre child
			if(pcd.length==0){
				pre.after('<div class="children" id="cld'+pre.attr('id')+'"></div>');
				pcd=pre.next();
				self.rmvsplititem(pre);
				self.changehook(pre,'leaf','expand');
				var ie = pre.children('div.expand');
				if(ie.length==1){self.registerExpandEvent(ie);}
			}else{
				npcd = pcd.children('div').last();
				npre = pcd.children('div').last();
				if( npcd.attr('class')=='children' ){npre = npcd.prev();}else{npcd.length=0;}
			}
			if(npre.length>0){
				self.insmoveup(itm);
				self.insmovedown(npre);
				self.changehook(npre,'tr','vr');
				if(npcd.length>0){self.noline2vline(npcd,parseInt(npre.attr('depth'))+1);}
			}else{
				self.rmvmoveup(itm);
				self.rmvdowngradeitem(itm);
			}
			self.rmvmovedown(itm);
			if(nxt.length>0){
				self.changehook(itm,'vr','tr');
				if(pre.length==0){self.rmvmoveup(nxt);}
			}else{
				self.changehook(pre,'vr','tr');
				self.rmvmovedown(pre);
				self.vline2noline(pcd,depth+1);
			}
			self.incitemdepth(itm);
			var tp=(nxt.length>0)?'v':'no';
			self.insindent(itm,depth,tp);
			if(cld.length>0){
				self.incdepth(cld);
				self.insindent(cld,depth,tp);
				if(nxt.length>0){self.vline2noline(cld,depth+2);}
			}
			self.insupgrade(itm);
			self.expandItem(pre);
			itm.appendTo(pcd);
			if(cld.length>0){cld.appendTo(pcd);}
			self.savePosition(pcd);
		}
		self.savePosition(itm.parent());
		self.options.onChange(itm.attr('id'),itm.find('.itemcaption').text());
	};
	TreeTextObject.prototype.downgradeitem=function(itm){
		var self=this;
		var pre=itm.prev();
		var pcd=itm.prev();
		if( pcd.length>0 ){
			if( pcd.attr('class')=='children' ){
				pre = pcd.prev();
			}else{pcd.length=0;}
		}
		var codeset=this.options.codeset;
		if(codeset.length==0){
			self.options.onDowngrade(itm.attr('id'));
			self.do_downgrade(itm,pre,pcd);
		}
	};
	TreeTextObject.prototype.insmoveup=function(itm){
		var self=this;
		var mu=itm.children('div.moveup');
		if(mu.length==0){
			var it=itm.children('div.itemtrash');
			if(it.length>0){
				it.after('<div class="moveup"></div>');
				self.registerMoveupEvent(it.next());
			}
		}
	};
	TreeTextObject.prototype.insmovedown=function(itm){
		var self=this;
		var md=itm.children('div.movedown');
		if(md.length==0){
			var p=itm.children('div.moveup');
			if(p.length==0){p=itm.children('div.itemtrash');}
			if(p.length>0){	
				p.after('<div class="movedown"></div>');
				self.registerMovedownEvent(p.next());
			}
		}
	};
	TreeTextObject.prototype.inssplititem=function(itm){
		var self=this;
		if(itm.children('div.splititem').length==0){
			var ic=itm.children('span.itemcaption');
			if(ic.length>0){
				ic.before('<div class="splititem"></div>');
				self.registerSplititemEvent(ic.prev());
			}
		}
	};
	TreeTextObject.prototype.insupgrade=function(itm){
		var self=this;
		if(itm.children('div.upgradeitem').length==0){
			var it=itm.children('div.downgradeitem');
			if(it.length==0){it=itm.children('div.newitem');}
			it.before('<div class="upgradeitem"></div>');
			self.registerUpgradeitemEvent(it.prev());
		}
	};
	TreeTextObject.prototype.insdowngrade=function(itm){
		var self=this;
		if(itm.children('div.downgradeitem').length==0){
			var ni=itm.children('div.newitem');
			if(ni.length>0){
				ni.before('<div class="downgradeitem"></div>');
				self.registerDowngradeitemEvent(ni.prev());
			}
		}
	};
	TreeTextObject.prototype.rmvmoveup=function(itm){
		var mu=itm.children('div.moveup');
		if(mu.length>0){mu.remove();}
	};
	TreeTextObject.prototype.rmvmovedown=function(itm){
		var md=itm.children('div.movedown');
		if(md.length>0){md.remove();}
	};
	TreeTextObject.prototype.rmvupgradeitem=function(itm){
		var ui=itm.children('div.upgradeitem');
		if(ui.length>0){ui.remove();}
	};
	TreeTextObject.prototype.rmvdowngradeitem=function(itm){
		var di=itm.children('div.downgradeitem');
		if(di.length>0){di.remove();}			
	};
	TreeTextObject.prototype.rmvsplititem=function(itm){
		var si=itm.children('div.splititem');
		if(si.length>0){si.remove();}
	};
	TreeTextObject.prototype.insindent=function(itm,depth,type){//no|v line
		itm.find('span.indent div[depth="'+depth+'"]').each(function(){
			$(this).nextAll().each(function(){
				var d=parseInt($(this).attr('depth'));
				if(d>depth){$(this).attr('depth',d+1);}
			});
			$(this).after('<div depth="'+(depth+1)+'" class="'+type+'line"></div>')
		});
	};
	TreeTextObject.prototype.rmvindent=function(itm,depth){
		itm.find('span.indent div[depth="'+depth+'"]').each(function(){
			$(this).nextAll().each(function(){
				var d=parseInt($(this).attr('depth'));
				if(d>depth){$(this).attr('depth',d-1);}
			});
			$(this).remove();
		});
	};
	TreeTextObject.prototype.vline2noline=function(block,depth){
		block.find('span.indent div[depth="'+depth+'"]').removeClass('vline').addClass('noline');	
	};
	TreeTextObject.prototype.noline2vline=function(block,depth){
		block.find('span.indent div[depth="'+depth+'"]').removeClass('noline').addClass('vline');
	};
	TreeTextObject.prototype.incitemdepth=function(itm){
		var d=parseInt(itm.attr('depth'));
		itm.attr('depth',d+1);
		var ic=itm.find('span.itemcaption');
		if(ic.length==1){
			var ocolor='color'+(d%6).toString();
			var ncolor='color'+((d+1)%6).toString();
			ic.attr('class',ic.attr('class').replace(ocolor,ncolor));
		}	
	};
	TreeTextObject.prototype.incdepth=function(block){
		var self=this;
		block.find('div.item').each(function(){
			self.incitemdepth($(this));
		});
	};
	TreeTextObject.prototype.decitemdepth=function(itm){
		var d=parseInt(itm.attr('depth'));
		itm.attr('depth',d-1);
		var ic=itm.find('span.itemcaption');
		if(ic.length==1){
			var ocolor='color'+(d%6).toString();
			var ncolor='color'+((d-1)%6).toString();
			ic.attr('class',ic.attr('class').replace(ocolor,ncolor));
		}			
	};
	TreeTextObject.prototype.decdepth=function(block){
		var self=this;
		block.find('div.item').each(function(){
			self.decitemdepth($(this));
		});
	};
	TreeTextObject.prototype.bendhook=function(itm,hasnext){
		var hk=itm.children('div.hook');
		if(hk.length>0){
			var iclass=hk.attr('class');
			if(iclass.indexOf('tr')>=0){
				if(hasnext){hk.attr('class',iclass.replace(new RegExp('tr','g'),'vr'));}
			}else if(iclass.indexOf('vr')>=0){
				if(!hasnext){hk.attr('class',iclass.replace(new RegExp('vr','g'),'tr'));}
			}
		}
	};
	TreeTextObject.prototype.savePosition=function(pcld){
		var pid=pcld.attr('id').replace('cld','');
		var ids=new Array();
		pcld.children('.item').each(function(){
			ids.push($(this).attr('id'));
		});
		this.options.onPositionChange(pid,ids.join());
	};
	TreeTextObject.prototype.drawGist=function(str){
		var gist='';
		var ss=str.split('');
		var n=ss.length;
		for(var i=0;i<n;i++){
			var s=ss[i];
			var tt=gist+s;
			if(tt.length>this.options.gistsize){
				gist+='...';
				break;
			}else{gist+=s;}
		}
		return gist;
	};
	TreeTextObject.prototype.appendTree=function(parentid,nodes){
		var pitm=this.element.find('.item#'+parentid);
		if(pitm.length>0){
			var firstnewid='';
			var firstnewitem;
			var mapID={}; mapID[0]=parentid;//[int]=string
			var n=nodes.length;
			for(var i=0;i<n;i++){
				var node=nodes[i];
				if(mapID.hasOwnProperty(node.Parent)){
					var pid = mapID[node.Parent];
					pitm=this.element.find('.item#'+pid);
					if(pitm.length>0){
					var depth=parseInt(pitm.attr('depth'))+1;
					var indent = '';
					var idt = pitm.children('span.indent');
					if(idt.length>0){idt.find('.item_focus').remove();indent = idt.html();}
					var nxt = pitm.nextAll('.item:first');
					indent += '<div depth="'+depth+'" class="'+((nxt.length>0)?'v':'no')+'line"></div>';
					var pcld=pitm.siblings('#cld'+pid);
					if(pcld.length==0){
						pitm.after('<div class="children" id="cld'+pid+'"></div>');
						pcld=pitm.next();
						this.changehook(pitm,'leaf','expand');
						var ie = pitm.children('div.expand');
						if(ie.length==1){this.registerExpandEvent(ie);}
					}else{
						var prev = pcld.children('.item:last');
						if(prev.length==1){
							this.insmovedown(prev);
							this.changehook(prev,'tr','vr');
							var cld=prev.next()
							if(cld.length>0){this.noline2vline(cld,depth+1);}
						}
						this.expandItem(pitm);
					}//---以上考虑复用
					
					var nn=pcld.children('.item').length+1;
					
					var gist=this.drawGist(node.Data);
					var linetype='tr'; 
					this.maxid++;
					var newID='n'+this.maxid; this.newIDs.push(newID);
					mapID[node.Value]=newID;
					
					var tt = '<span class="indent">'+indent+'</span>';
					tt += '<div class="hook leaf '+linetype+'leaf"></div>';
					tt += this.itemflag(newID,depth,nn-1,nn,true);
					tt += '<span class="itemcaption color'+(depth%6).toString()+'">';
					tt += '<span class="ti fa-stack" style="font-size:7px;"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-font fa-stack-1x"></i></span>&nbsp;'+gist;
					tt += '</span>';
					tt = '<div class="item" id="'+newID+'" depth="'+depth+'">'+tt+'</div>';
					pcld.append(tt);
					var newitm = pcld.children('.item:last');
					if(firstnewid==''){firstnewitem=newitm;firstnewid=newID;}
					this.registerFlagEvent(newitm);
					this.registerItemcaptionEvent(newitm);
					this.options.onAppendText(pid,newID,node.Data);
					this.savePosition(pcld);
					}else{
						alert('no--item:'+pid);
					}
					
				}
			}
			if(firstnewid!=''){
				this.focusItem(firstnewitem);
				this.options.onChange(firstnewid,firstnewitem.find('.itemcaption').text());
			}
		}else{
			alert('no item:'+pid);
		}
	};
	TreeTextObject.prototype.appendTexts=function(pid,lines){//append multi-lines to pid's children list
		var n=lines.length;
		if(n>0){
			var pitm=this.element.find('.item#'+pid);
			if(pitm.length>0){		
				var depth=parseInt(pitm.attr('depth'))+1;
				var indent = '';
				var idt = pitm.children('span.indent');
				if(idt.length>0){idt.find('.item_focus').remove();indent = idt.html();}
				var nxt = pitm.nextAll('.item:first');
				indent += '<div depth="'+depth+'" class="'+((nxt.length>0)?'v':'no')+'line"></div>';
				var es=0;/*elder siblings*/
				var pcld=pitm.siblings('#cld'+pid);
				if(pcld.length==0){
					pitm.after('<div class="children" id="cld'+pid+'"></div>');
					pcld=pitm.next();
					this.changehook(pitm,'leaf','expand');
					var ie = pitm.children('div.expand');
					if(ie.length==1){this.registerExpandEvent(ie);}
				}else{
					var prev = pcld.children('.item:last');
					if(prev.length==1){
						this.insmovedown(prev);
						es+=1;/*only add one,update for real numbers*/
						this.changehook(prev,'tr','vr');
						var cld=prev.next()
						if(cld.length>0){this.noline2vline(cld,depth+1);}
					}
					this.expandItem(pitm);
				}
				var firstnewitem,firstnewid;
				for(var i=0;i<n;i++){
					var gist=this.drawGist(lines[i]);
					var linetype='vr'; if(i==n-1){linetype='tr';}					
					this.maxid++;
					var newID='n'+this.maxid; this.newIDs.push(newID);
					var tt = '<span class="indent">'+indent+'</span>';
					tt += '<div class="hook leaf '+linetype+'leaf"></div>';
					tt += this.itemflag(newID,depth,i+es,n+es,true);
					tt += '<span class="itemcaption color'+(depth%6).toString()+'">';
					tt += '<span class="ti fa-stack" style="font-size:7px;"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-font fa-stack-1x"></i></span>&nbsp;'+gist;
					tt += '</span>';
					tt = '<div class="item" id="'+newID+'" depth="'+depth+'">'+tt+'</div>';
					pcld.append(tt);
					var newitm = pcld.children('.item:last');
					if(i==0){firstnewitem=newitm;firstnewid=newID;}
					this.registerFlagEvent(newitm);
					this.registerItemcaptionEvent(newitm);
					this.options.onAppendText(pid,newID,lines[i]);
				}
				this.savePosition(pcld);
				this.focusItem(firstnewitem);
				this.options.onChange(firstnewid,firstnewitem.find('.itemcaption').text());/*sel change*/
			}else{
				alert('no item:'+pid);
			}
		}
	};
	TreeTextObject.prototype.appenditem=function(){
		if(this.rootchildbox.length>0){
			var itm=this.rootchildbox.children('.item:last');
			if(itm.length>0){
				this.newitem(itm);
			}else{
				this.firstitem();
			}
		}else{
			alert('no root child box');
		}
	};
	TreeTextObject.prototype.newitem=function(itm){
		var parentID=itm.parent().attr('id').replace('cld','');
		var self=this;
		var depth=itm.attr('depth');
		itm.find('.item_focus').remove();
		var tt = itm.html();
		var cld = itm.next();
		var nxt = itm.next();
		if( cld.length>0 ){
			if( cld.attr('class')=='children' ){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		var nh="hook leaf";
		if(nxt.length==0){
			self.changehook(itm,'tr','vr');
			nh+=" trleaf";
		}else{
			nh+=" vrleaf";
		}
		self.maxid++;
		var newID='n'+self.maxid; self.newIDs.push(newID);
		self.options.onParentChange(newID,parentID);
		self.options.onAddItem(itm.attr('id'),newID);
		tt = '<div class="item" id="'+newID+'" depth="'+depth+'">'+tt+'</div>';
		if(cld.length>0){
			if(nxt.length==0){self.noline2vline(cld,parseInt(depth)+1);}
			cld.after(tt);
			nxt=cld.next();
		}else{itm.after(tt);nxt=itm.next();}
		self.insmoveup(nxt);
		self.insdowngrade(nxt);
		self.inssplititem(nxt);
		self.insmovedown(itm);
		var ic=nxt.children('span.itemcaption');
		if(ic.length>0){
			ic.html('<i class="fa fa-magic fa-flip-horizontal blank"></i>');
		}
		var hk=nxt.children('div.hook');
		if(hk.length>0){hk.attr('class',nh);}
		self.registerFlagEvent(nxt);
		self.registerItemcaptionEvent(nxt);
		self.savePosition(itm.parent());
		self.focusItem(nxt);
		self.options.onChange(newID,nxt.find('.itemcaption').text());
	};
	TreeTextObject.prototype.RemoveitemByID=function(id){
		var self=this;
		var theitem=this.element.find('#'+id);
		if(theitem.length>0){self.removeitem(theitem);}
	};
	TreeTextObject.prototype.removeitem=function(itm){
		var self=this;
		var id=itm.attr('id');
		var idx=$.inArray(id,self.newIDs);
		if(idx>=0){self.newIDs.splice(idx,1);}else{self.rmvIDs.push(id);}
		self.options.onRemoveItem(id);
		var depth=parseInt(itm.attr('depth'));
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				cld.find('.item').each(function(){//all the sub-items
					id=$(this).attr('id');
					idx=$.inArray(id,self.newIDs);
					if(idx>=0){self.newIDs.splice(idx,1);}else{self.rmvIDs.push(id);}
				});
				nxt = cld.next();
			}else{cld.length=0;}
		}
		var pre = itm.prev();
		var prc = itm.prev();
		if( prc.length>0 ){
			if(prc.attr('class')=='children'){
				pre = prc.prev();
			}else{prc.length=0;}
		}
		var alreadyremoved=false;
		if(nxt.length==0){//the last one
			if(pre.length==0){
				var pcld = itm.parent();//div children
				var pitm = pcld.prev();
				if(pcld.length>0){
					var pid=pcld.attr('id').replace('cld','');
					if(pid!=self.options.root_id){
						self.options.onPositionChange(pid,'');
						pcld.remove(); 
						alreadyremoved=true;
					}
					//if(pid==self.options.root_id){self.firstitem();}
				}
				if(pitm.length>0){
					var pid=pitm.attr('id');
					if(pid!=self.options.root_id){
						var ie=pitm.children('div.expand');if(ie.length==1){ie.off('click');}
						self.changehook(pitm,'expand','leaf');
						self.inssplititem(pitm);
					}
				}
			}else{
				self.changehook(pre,'vr','tr');
				self.rmvmovedown(pre);
				if(prc.length>0){self.vline2noline(prc,depth+1);}
			}					
		}else{
			if(pre.length==0){self.rmvmoveup(nxt);self.rmvdowngradeitem(nxt);}
		}
		if(!alreadyremoved){
			var pcld=itm.parent();
			if(cld.length>0){cld.remove();}
			itm.remove();
			self.savePosition(pcld);
		}
	};
	TreeTextObject.prototype.registerMoveupEvent=function(flag){
		var self=this;
		if(flag.length>0){
			flag.off("click").on("click",function(event){
				event.stopPropagation();
				self.moveup($(this).parent());
			});
		}
	};
	TreeTextObject.prototype.registerMovedownEvent=function(flag){
		var self=this;
		if(flag.length>0){
			flag.off("click").on("click",function(event){
				event.stopPropagation();
				self.movedown($(this).parent());
			});
		}
	};
	TreeTextObject.prototype.registerSplititemEvent=function(flag){
		var self=this;
		var thebox=this.element;
		if(flag.length>0){
			flag.off("click").on("click",function(event){
				event.stopPropagation();
				self.splititem($(this).parent());
			});
		}
	};
	TreeTextObject.prototype.registerUpgradeitemEvent=function(flag){
		var self=this;
		if(flag.length>0){
			flag.off("click").on("click",function(event){
				event.stopPropagation();
				self.upgradeitem($(this).parent());
			});
		}
	};
	TreeTextObject.prototype.registerDowngradeitemEvent=function(flag){
		var self=this;
		if(flag.length>0){
			flag.off("click").on("click",function(event){
				event.stopPropagation();
				self.downgradeitem($(this).parent());
			});
		}
	};
	TreeTextObject.prototype.registerFlagEvent=function(block){
		var self=this;
		var thebox=this.element;
		block.find('div.itemtrash').off("click").on("click",function(event){
			event.stopPropagation();
			var itm=$(this);var theid=itm.parent().attr('id');
			var caption=itm.siblings('.itemcaption').html();
			var txt=self.options.txt_removeornot+'[<font color="#f00">'+caption+'</font>]';
			if(!itm.siblings('.hook').hasClass('leaf')){txt+='<br>'+self.options.txt_descendant;}
			//if(itm.attr('leaf')=='0'){txt+='<br>'+self.options.txt_descendant;}
			txt+='?';
			var yn=thebox.YesnoAlert({
				yesText:self.options.txt_yes,noText:self.options.txt_no,
				doyes: function(id,action){
					var theitem=thebox.find('#'+id);
					if(theitem.length>0){
						self.removeitem(theitem);
					}
				}
			}).show_alertpane(theid,txt,'trash');
		});
		block.find('div.newitem').off("click").on("click",function(event){
			event.stopPropagation();
			self.newitem($(this).parent());
		});
		self.registerUpgradeitemEvent(block.find('div.upgradeitem'));
		self.registerDowngradeitemEvent(block.find('div.downgradeitem'));
		self.registerSplititemEvent(block.find('div.splititem'));
		self.registerMoveupEvent(block.find('div.moveup'));
		self.registerMovedownEvent(block.find('div.movedown'));
	};
	TreeTextObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	TreeTextObject.prototype.ex_init=function(){
		this.i18n_options();
	};
	TreeTextObject.prototype.onChange=function(itm){
		this.options.onChange(itm.attr('id'),itm.find('span.itemcaption').text());
	};
    $.fn.TreeText=function(options){
		var tto=new TreeTextObject(this,options);
		tto.init();
		return tto;
    };