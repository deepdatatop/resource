	function SpinnerInputObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			width:440,
			height:136,
			zindex:1000,
			language_code:'en',
			txt_ok:'OK',
			txt_cancel:'Cancel',
			txt_hint:'Please input an integer:',
			doOK: function(val,extra){return true;}
		};
		this.min=0;
		this.max=100;
		this.ratio=1;
		this.interval=1;
		this.theval=1;
		this.ioverlay='spinnerinput_overlay';
		this.ipane='spinnerinput_pane';
		this.thespinner={};
		this.options=$.extend({},this.defaults,options);
    };
	SpinnerInputObject.prototype.close_inputpane=function(){
		this.element.find('.'+this.ioverlay).remove();
		this.element.find('.'+this.ipane).remove();
	};
	SpinnerInputObject.prototype.pressenter=function(){
		if(this.thespinner.Revise()){
			this.options.doOK(this.thespinner.getValue(),this.element.find('#extra').val());
			this.close_inputpane();
		}else{
			thespinner.setFocus();
		}
	};
	SpinnerInputObject.prototype.focusinput=function(){
		var self=this;
		var thebox=this.element;
		self.thespinner=thebox.find('#thespinner').Spinner({width:80,ratio:self.ratio,
			value:self.theval,min:self.min,max:self.max,interval:self.interval,
				onChange: function(val){	self.theval=val;}
			}).setFocus();
	};
	SpinnerInputObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){
				o[k]=o.i18n[k];
			}
		}
	};
	SpinnerInputObject.prototype.showinput=function( initval,extra,min,max,step ){
		this.i18n_options();
		var self=this,thebox=this.element;
		self.theval=initval;
		self.min=min;
		self.max=max;
		self.interval=step;
		thebox.append('<div class="'+self.ioverlay+'" style="z-index: '+self.options.zindex+';"></div>');
		thebox.find('.'+self.ioverlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div class="'+self.ipane+'" style="width:'+self.options.width+'px;height:'+self.options.height+'px;">';
		txt += '<div><span class="close_icon"></span></div>';
		txt += '<input type="hidden" id="extra" value="'+extra+'">';
		txt += '<div style="float:left;width:100%;font-size:24px;"><span style="padding-left:5px;">'+self.options.txt_hint+'</span></div>';
		txt += '<div style="float:left;width:100%;height: 10px"></div>';
		txt += '<div style="float:left;width:100%;text-align:center"><span id="thespinner"></span></div>';
		txt += '<div style="float:left;width:100%;height: 16px"></div>';
		txt += '<div style="float:left;width:40%;"><input style="float: right;" class="editor_button" id="btn_ok" value="'+self.options.txt_ok+'"></div>';
		txt += '<div style="float:right;width:40%;"><input style="float: left;" class="editor_button" id="btn_cancel" value="'+self.options.txt_cancel+'"></div>';
		txt += '</div>';
		thebox.append(txt); pane = thebox.find('.'+self.ipane);
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":30+"%"});
		pane.fadeTo(200,1);
		self.focusinput();
		thebox.find('#btn_ok').off("click").on("click",function(event){event.stopPropagation();self.pressenter();});
		thebox.find('#btn_cancel').off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
		thebox.find('.'+self.ioverlay).off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
		thebox.find('.close_icon').off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
	};
    $.fn.SpinnerInputDialog=function(options){
		var adialog=new SpinnerInputObject(this,options);
		return adialog;
    };