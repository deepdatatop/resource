	function YesnoObject(element,options){
		this.element=element;
		this.defaults={
			width:330,
			height:130,
			zindex:20000,
			title:'',
			yesText:'Yes',
			noText:'No',
			doyes: function(){}
		};
		this.id='';
		this.action='';
		this.yn='yesno_overlay';
		this.options=$.extend({},this.defaults,options);
    };
	YesnoObject.prototype.close_alertpane=function(){
		this.element.find('#alert_pane').remove();
		this.element.find('#'+this.yn).remove();
	};
	YesnoObject.prototype.show_alertpane=function( id,msg,action ){
		var self=this;
		var thebox=this.element;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.yn+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.yn).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="alert_pane" style="display: none;';
		txt += 'width:'+self.options.width+'px;height:'+self.options.height+'px;';
		txt += 'overflow:hidden;background:#fff;padding:8px;border:#dadada solid 1px">';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 0px;top: 0px;cursor: pointer;';
		txt += '<div><span id="yesno_close_icon" style="'+ats+'"></span></div>';
		txt += '<div style="float:left;width:64px;height:'+(self.options.height-32)+'px;background: url(/img/question.png) center center no-repeat;"></div>';
		txt += '<div style="float:left;display:table;overflow:hidden;width:'+(self.options.width-64)+'px;height:'+(self.options.height-32)+'px">';
		txt += '<span style="display:table-cell;text-align:center;vertical-align:middle;" id="alert_msg"></span>';
		txt += '</div>';
		txt += '<div style="float:left;width:40%;"><span style="float:right;cursor:pointer;" class="ysbutton" id="btn_yes"><i class="fa fa-check"></i>&nbsp;'+self.options.yesText+'</span></div>';
		txt += '<div style="float:right;width:40%;"><span style="float:left;cursor:pointer;" class="ysbutton" id="btn_no"><i class="fa fa-ban"></i>&nbsp;'+self.options.noText+'</span></div>';
		txt += '</div>';
		thebox.append(txt);
		var pane = thebox.find('#alert_pane');
		self.id=id;
		self.action=action;
		thebox.find('#alert_msg').html('<font size="+1">'+msg+'</font>');
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#btn_yes').off("click").on("click",function(event){
			event.stopPropagation();
			self.close_alertpane();
			var tm=setInterval(function(){
				self.options.doyes(self.id,self.action);
				clearInterval(tm);
			},50);
		});
		thebox.find('#btn_no').off("click").on("click",function(event){self.close_alertpane();});
		thebox.find('#'+self.yn).off("click").on("click",function(event){self.close_alertpane();});
		thebox.find('#yesno_close_icon').off("click").on("click",function(event){self.close_alertpane();});
	};
    $.fn.YesnoAlert=function(options){
		var analert=new YesnoObject(this,options);
		return analert;
    };