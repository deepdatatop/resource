	function DaterangeObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			name:'daterange',
			startDate:'',
			endDate:'',
			outerid:'',
			language_code:'en',
			txt_ok:'OK',
			txt_close:'Close',
			txt_today:'Today',
			txt_chooseperiod:'Choose period',
			txt_fullscreen:'Open fullscreen',
			txt_moveselect:'Move to select the desired period',
			txt_periodchooser:'Common used date periods:',
			/*txt_today:'Today',*/
			txt_yesterday:'Yesterday',
			txt_thisweek:'This week',
			txt_lastweek:'Last week',
			txt_last7days:'Last 7 days',
			txt_last14days:'Last 14 days',
			txt_thismonth:'This month',
			txt_lastmonth:'Last month',
			txt_last30days:'Last 30 days',
			txt_last60days:'Last 60 days',
			txt_last3months:'Last 3 months',
			txt_last6months:'Last 6 months',
			txt_thisyear:'This year',
			txt_lastyear:'Last year',
			onChange: function(id,start,end){}
		};
		this.picker=new Object();
		this.sid='';/*start id*/
		this.eid='';/*end id*/
		this.lang='en';
		this.param=new Object();
		this.options=$.extend({},this.defaults,options);
    };
    DaterangeObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	DaterangeObject.prototype.init=function(){
		this.i18n_options();
		var self=this;
		var thebox=this.element;
		self.sid=self.options.name+'start';
		self.eid=self.options.name+'end';
		if(self.options.language_code.length>0){
			self.lang=self.options.language_code;
		}
		if(self.lang=='zh'){self.lang='zh-cn';}
		var periodpicker_i18n={};
		periodpicker_i18n[self.lang]={
					'Choose period':self.options.txt_chooseperiod,
					'Open fullscreen':self.options.txt_fullscreen,
					'Move to select the desired period':self.options.txt_moveselect,
					'Today':self.options.txt_today,
					'OK':self.options.txt_ok,
					'Close':self.options.txt_close
				};
		self.param={
			end:'#'+self.eid,lang:self.lang,i18n:periodpicker_i18n,/*fullsize:true,*/
			mouseWheel: false,
			title:false,todayButton:true,clearButtonInButton:true,
			formatDate:'YYYY-MM-DD',formatDecoreDateWithYear:'YYYY-MM-DD'			
		};
		var dtStart='',dtEnd='';
		if(self.options.startDate.length>0){dtStart=self.options.startDate;}
		if(self.options.endDate.length>0){dtEnd=self.options.endDate;}
		var ss='<span class="periods fa-stack"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-reorder fa-stack-1x"></i></span>';
		ss+='<input id="'+self.sid+'" type="text" value="'+dtStart+'">';
		ss+='<input id="'+self.eid+'" type="text" value="'+dtEnd+'">';
		thebox.append(ss);
		self.picker=thebox.find('#'+self.sid).periodpicker(self.param).on('change',function(){
			self.options.onChange(self.options.outerid,thebox.find('#'+self.sid).val(),thebox.find('#'+self.eid).val());
		});
		thebox.find('.periods').off("click").on("click",function(event){
			event.stopPropagation();
			$('body').Periodchooser({
				i18n:self.options.i18n,
				txt_periodchooser:self.options.txt_periodchooser,
				txt_today:self.options.txt_today,
				txt_yesterday:self.options.txt_yesterday,
				txt_thisweek:self.options.txt_thisweek,
				txt_lastweek:self.options.txt_lastweek,
				txt_last7days:self.options.txt_last7days,
				txt_last14days:self.options.txt_last14days,
				txt_thismonth:self.options.txt_thismonth,
				txt_lastmonth:self.options.txt_lastmonth,
				txt_last30days:self.options.txt_last30days,
				txt_last60days:self.options.txt_last60days,
				txt_last3months:self.options.txt_last3months,
				txt_last6months:self.options.txt_last6months,
				txt_thisyear:self.options.txt_thisyear,
				txt_lastyear:self.options.txt_lastyear,
				onChoose:function(start,end){self.setRange(start,end);}
			}).show_pane();
		});
	};
	DaterangeObject.prototype.setRange=function(start,end){
		var self=this;
		var thebox=this.element;
		self.picker.periodpicker('destroy');
		thebox.find('#'+self.sid).val(start);
		thebox.find('#'+self.eid).val(end);
		self.picker=thebox.find('#'+self.sid).periodpicker(self.param).on('change',function(){
			self.options.onChange(self.options.outerid,thebox.find('#'+self.sid).val(),thebox.find('#'+self.eid).val());
		});
	};
    $.fn.Daterange=function(options){
		var dtrange=new DaterangeObject(this,options);
		dtrange.init();
		return dtrange;
    };
