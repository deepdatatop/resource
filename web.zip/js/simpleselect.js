function SimpleSelectObject(element,options){
	this.element=element;
	this.defaults={
		width:440,
		height:144,
		zindex:20000,
		prompt:'',
		selected:'',
		optionitems:'',
		okText:'OK',
		cancelText:'Cancel',
		hintText:'Please select:',
		onChange: function(val){},
		onOK: function(val){}
	};
	this.newselected='',
	this.yn='simpleselect_overlay';
	this.options=$.extend({},this.defaults,options);
};
SimpleSelectObject.prototype.close_selectpane=function(){
	this.element.find('.'+this.yn).remove();
	this.element.find('.select_pane').remove();
};
SimpleSelectObject.prototype.show=function(msg){
	var self=this,so=this.options;
	self.newselected=so.selected;
	var thebox=this.element;
	thebox.append('<div class="'+self.yn+'" style="z-index: '+so.zindex+';"></div>');
	thebox.find('.'+self.yn).css({"display":"block",opacity:0}).fadeTo(200,0.5);
	var txt='<div class="select_pane" style="width:'+so.width+'px;height:'+so.height+'px;">';
	txt += '<div><span class="close_icon"></span></div>';
	txt += '<div style="width:100%;font-size:24px;"><span style="padding-left:5px;">'+so.hintText+'</span>';
	txt += '<span class="prompt">('+so.prompt+')</span></div>';
	txt += '<div style="width:100%;height: 14px"></div>';
	txt += '<div style="width:100%;text-align:center" id="selector"></div>';
	txt += '<div style="width:100%;height: 20px"></div>';
	txt += '<div style="float:left;width:40%;"><span style="float: right;" class="editor_button" id="btn_ok"><i class="fa fa-check"></i>&nbsp;'+so.okText+'</span></div>';
	txt += '<div style="float:right;width:40%;"><span style="float: left;" class="editor_button" id="btn_cancel"><i class="fa fa-ban"></i>&nbsp;'+so.cancelText+'</span></div>';
	txt += '</div>';
	thebox.append(txt); pane = thebox.find('.select_pane');
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":30+"%"});
	pane.fadeTo(200,1);
	thebox.find('#selector').Nselect1({
		'selected': so.selected,
		'optionitems': so.optionitems,
		onChange: function(val){self.newselected=val;}
	});
	thebox.find('#btn_ok').off("click").on("click",function(event){
		event.stopPropagation();
		if(so.selected!=self.newselected){
			so.onChange(self.newselected);
		}
		so.onOK(self.newselected);
		self.close_selectpane();
	});
	thebox.find('#btn_cancel').off("click").on("click",function(event){event.stopPropagation();self.close_selectpane();});
	thebox.find('.'+self.yn).off("click").on("click",function(event){event.stopPropagation();self.close_selectpane();});
	thebox.find('.close_icon').off("click").on("click",function(event){event.stopPropagation();self.close_selectpane();});
};
$.fn.SimpleSelect=function(options){
	var adialog=new SimpleSelectObject(this,options);
	return adialog;
};