	function HierarchyTextObject(element,options){
		this.element=element;
		var defaults={
			name:'ht',
			i18n:{},
			txt_yes: 'Yes',
			txt_no: 'no',
			txt_emptyornot: 'Empty all content?',
			txt_outline: 'Outline:',
			txt_text: 'Text',
			txt_image: 'Image',
			txt_appendix: 'Appendix',
			txt_qrcode: 'QRcode',
			txt_task: 'Task',
			txt_map: 'Map',
			txt_table: 'Table',
			txt_chart: 'Chart',
			txt_code: 'Sourcecode',
			txt_video: 'Video',
			exceedcontainerlimit: 'quantity exceed limit:',
			urlduplicated: 'image URL duplicated!',
			codeduplicated: 'code text duplicated!',
			historyStr: 'History',
			linkStr: 'PicURL',
			frequentStr: 'frequent',
			textStr: 'code',
			linkplaceholderStr: 'Input text and press enter key to submit',
			localStr: 'Local',
			selectedStr: 'Selected',
			uploadStr: 'Upload file:',
			dragDropStr: '<span>Drag & Drop Files...</span>',
			multiDragErrorStr: 'Multiple File Drag & Drop is not allowed.',
			extErrorStr: 'is not allowed. Allowed extensions: ',
			duplicateErrorStr: 'is not allowed. File already exists.',
			sizeErrorStr: 'is not allowed. Allowed Max size: ',
			uploadErrorStr: 'Upload is not allowed',
			maxFileCountErrorStr: ' is not allowed. Maximum allowed files are:',
			txt_tag: 'tag',
			txt_src: 'source',
			txt_size: 'size',
			txt_ext: 'extension',
			txt_operation: 'operation',
			txt_choose: 'choose',
			txt_remove: 'remove',
			txt_emptylist: 'Empty list?',
			txt_srcduplicated: 'Duplicate appendix source, updated.',
			txt_removeornot:'Remove',
			txt_descendant:'and all descendant',
			onChange:function(){},
			readTreetext:function(){return {Code:'200',Msg:'no data'};},
			saveHierarchytext: function(s_new,s_rmv,s_par,s_pos,s_pts,s_cts){return {Code:'200',Msg:'not save'};},
			token:'',
			lr_splitter_width:5,
			tb_splitter_height:5,
			min_left_width:300,
			min_bottom_height:240
		};
		this.options=$.extend({},defaults,options);
		this.isModified=false;
		this.inEditing=false;
		this.newFlag=false;
		this.NU_parent=new Object();/*new and update id parent NU_parent[id]=parentid*/
		this.NU_position=new Object();/*children id list NU_position[id]=childid1,childid2,childid3*/
		this.NU_type=new Array();/*new and update ParagraphType id*/
		this.NU_content=new Array();/*new and update Content id, along with NU_type*/
		this.editortype=0;
		this.TreeText=new Object();
		this.TextEditor=new Object();
		this.CodeEditor=new Object();
		this.Illustrator=new Object();
		this.AppendixEditor=new Object();
		this.QREditor=new Object();
		this.TableEditor=new Object();
		this.ParagraphType=new Object();
		this.Content=new Object();
    };
	HierarchyTextObject.prototype.string2Json=function(s){   
	    var newstr = "";  
	    for (var i=0; i<s.length; i++) {  
	        c = s.charAt(i);       
	        switch (c) {       
	            /*case '\"':       
	                newstr+="\\\"";       
	                break;*/   
	            case '\\':       
	                newstr+="\\\\";       
	                break;       
	            case '/':       
	                newstr+="\\/";       
	                break;       
	            case '\b':       
	                newstr+="\\b";       
	                break;       
	            case '\f':       
	                newstr+="\\f";       
	                break;       
	            case '\n':       
	                newstr+="\\n";       
	                break;       
	            case '\r':       
	                newstr+="\\r";       
	                break;       
	            case '\t':       
	                newstr+="\\t";       
	                break;       
	            default:       
	                newstr+=c;       
	        }  
	   }  
	   return newstr;       
	};
	HierarchyTextObject.prototype.isPlainText=function(id){
		var flag=false;
		if(this.ParagraphType.hasOwnProperty(id)){
			if(this.ParagraphType[id]==1){flag=true;}
		}
		return flag;
	};
	HierarchyTextObject.prototype.headingFlag=function(id){
		var flag=false;
		if(this.Content.hasOwnProperty(id)){
			var content=this.Content[id];
			var key='heading'
			if(content.hasOwnProperty(key)){
				flag=content[key];
			}
		}
		return flag;
	};
	/*HierarchyTextObject.prototype.noindent=function(id){
		var flag=false;
		if(this.Content.hasOwnProperty(id)){
			var content=this.Content[id];
			var key='noindent'
			if(content.hasOwnProperty(key)){
				flag=content[key];
			}
		}
		return flag;
	};*/
	HierarchyTextObject.prototype.createEditor=function(){
		var obj=this;
		var self=this.element;
		var ss = '<div id="hierarchytoolbar">';
			ss += '<div style="width:90%;display:inline-block;">';
			ss += '<span>&nbsp;'+obj.options.txt_outline+'</span>';
			ss += '<span class="fa-stack ht_empty"><i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x"></i></span>';
			ss += '<span>&nbsp;&nbsp;</span><i class="fa fa-angle-double-left fa-2x ht_collapseall"></i>';
			ss += '<span>&nbsp;</span><i class="fa fa-angle-double-right fa-2x ht_expandall"></i>';
			ss += '<span>&nbsp;&nbsp;</span><span class="fa-stack ht_import"><i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-paste fa-stack-1x"></i></span>';
			ss += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
			ss += '<span class="title">'+$('.unique_input').val()+'</span>';
			ss += '</div>';
			ss += '<div style="float:right;display:inline-block;">';
			ss += '<span><i class="fa fa-angle-double-up fa-2x ht_collapse_all"></i></span>';
			ss += '<span>&nbsp;<i class="fa fa-angle-double-down fa-2x ht_expand_all"></i></span>';
			ss += '<span>&nbsp;<i class="fa fa-sitemap fa-rotate-270 fa-lg ht_expand_outline"></i></span>';
			ss += '<span>&nbsp;&nbsp;&nbsp;<i class="fa fa-floppy-o fa-2x dt_save"></i></span>';/*control in form.js*/
			ss += '<span>&nbsp;<i class="fa fa-compress fa-2x ht_close"></i>&nbsp;&nbsp;</span>';
			ss += '</div>';
			ss += '</div>';//--hierarchytoolbar
			ss += '<div id="popup"><i class="fa fa-plus-circle fa-3x addicon"></i>';
			ss += '<div class="left_block"></div>';
			ss += '<div id="lr_splitter"></div>';
			ss += '<div class="right_block">';
			ss += '<div class="top_block"></div>';
			ss += '<div id="tb_splitter"></div>';
			ss += '<div class="bottom_block"></div>';
			ss += '</div></div>';//--popup
		self.append(ss);
		var i_o=new Array();
		var pt=new Object();
		var ct=new Object();
		var m=obj.options.readTreetext();
		if(m.Code=="100"){
			for(var i=0;i<m.Nitem;i++){
				var v=m.Items[i];/*type itemT struct {Id int,Pid int,Ptype int,Gist string,Text string}*/
				pt[v.Id]=v.Ptype;
				var data='';
				if(v.Text.length>0){data=$.base64.decode(v.Text);}
				ct[v.Id]=data;
				var label=obj.typeIcon('ti',v.Ptype);
				if(v.Gist.length>0){
					label+='&nbsp;'+$.base64.decode(v.Gist);
				}
				i_o.push({value:v.Id,parent:v.Pid,label:label});/*i_o.push({value:1,parent:0,label:"high"});*/
			}
		}else{
			alert(m.Msg);
		}
		obj.ParagraphType=pt;
		obj.Content=ct;
		obj.TreeText=$('.left_block').TreeText({
			i18n:obj.options.i18n,
			self_hierarchy:true,
			item_option:i_o,
			txt_yes:obj.options.txt_yes,
			txt_no:obj.options.txt_no,
			txt_removeornot:obj.options.txt_removeornot,
			txt_descendant:obj.options.txt_descendant,			
			onEmpty: function(){obj.resetbuffer();},
			onChange: function(id,val){obj.focusParagraph(id);},/*onSelChange*/
			onParentChange: function(id,pid){obj.setParent(id,pid);},
			onPositionChange: function(id,children){obj.setPosition(id,children);},
			onRemoveItem: function(id){obj.removeItem(id);},
			onNewItem: function(id,newid){obj.newItem(id,newid);},
			onTextImport: function(pid){obj.textimportDialog(pid);},
			onAddItem: function(id,newid){obj.addItem(id,newid);},
			onSplitItem: function(id,newid){obj.splitItem(id,newid);},
			onUpgrade: function(id){obj.upgradeItem(id);},
			onDowngrade: function(id){obj.downgradeItem(id);},
			onMoveup: function(id){obj.moveupItem(id);},
			onMovedown: function(id){obj.movedownItem(id);},
			onAppendText: function(pid,newid,text){obj.appendText(pid,newid,text);}
		});
		obj.bindLRSplitter(document.getElementById('lr_splitter'));
		obj.bindTBSplitter(document.getElementById('tb_splitter'));
		obj.bindToolBarEvent();
		obj.bindResizeEvent();
		obj.bindAddiconEvent();
		var bottom_block=$('.bottom_block');
		obj.initTexteditor(bottom_block);
		obj.initCodeeditor(bottom_block);
		obj.initIllustrator(bottom_block);
		obj.initAppendixeditor(bottom_block);
		obj.initQReditor(bottom_block);
		obj.initTableeditor(bottom_block);
		self.find('.bodyview').addClass('editorloaded');	
	};
	HierarchyTextObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	HierarchyTextObject.prototype.init=function(){
		this.i18n_options();
		var obj=this;
		var self=this.element;
		self.empty();
		var ss = '<div class="hierarchyviewbar">';
		ss += '<i class="fa fa-pencil-square-o fa-2x ht_edit"></i>';
		ss += '<span>&nbsp;</span>';
		ss += '<i class="fa fa-angle-double-up fa-2x ht_collapse_all"></i>';
		ss += '<span>&nbsp;</span>';
		ss += '<i class="fa fa-angle-double-down fa-2x ht_expand_all"></i>';
		ss += '<span>&nbsp;</span>';
		ss += '<i class="fa fa-sitemap fa-rotate-270 fa-lg ht_expand_outline"></i>';
		ss += '<span>&nbsp;</span>';
		ss += '</div>';
		ss += '<div class="bodyview">';
		ss += '</div>';
		self.append(ss);
		obj.bindExpandCollapseEvent();
		self.find('.ht_edit').on('click',function(){
			obj.inEditing=true;
			var flag=false;
			if(self.find('.bodyview').hasClass('editorloaded')){
				self.find('#hierarchytoolbar').show();
				self.find('#popup').show();	
			}else{
				obj.createEditor();
				flag=true;
			}
			obj.windowSet();
			if(flag){
				obj.TreeText.defaultFocus();
			}
		});
    };
	HierarchyTextObject.prototype.resetbuffer=function(){
		this.NU_parent={};
		this.NU_position={};
		this.NU_type.length=0;
		this.NU_content.length=0;
		this.modified();
	};
	HierarchyTextObject.prototype.moveupItem=function(id){
		var self=this.element;
		var itm=self.find('.bodyview').find('#'+id);
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		var pre = itm.prev();
		var prc = itm.prev();
		if( prc.length>0 ){
			if(prc.attr('class')=='children'){
				pre = prc.prev();
			}else{prc.length=0;}
		}
		if(pre.length>0){
			var ppre=pre.prev();
			itm.insertBefore(pre);
			if(cld.length>0){
				cld.insertBefore(pre);
			}
		}
		this.modified();
	};
	HierarchyTextObject.prototype.movedownItem=function(id){
		var self=this.element;
		var itm=self.find('.bodyview').find('#'+id);
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		if(nxt.length>0){
			var ncld=nxt.next();
			var nnxt=nxt.next();
			if( ncld.length>0 ){
				if(ncld.attr('class')=='children'){
					nnxt = ncld.next();
				}else{ncld.length=0;}
			}
			var np=ncld;
			if(np.length==0){np=nxt;}
			if(cld.length>0){cld.insertAfter(np);}
			itm.insertAfter(np);
		}
		this.modified();
	};
	HierarchyTextObject.prototype.incitemdepth=function(itm){
		var d=parseInt(itm.attr('depth'));
		var osize='ht_size';
		if(d<4){osize+=d.toString();}
		var nsize='ht_size'; d++;
		if(d<4){nsize+=d.toString();}
		itm.attr('depth',d);
		itm.find('p').each(function(){
			var ic=$(this);
			if(ic.hasClass(osize)){
				if(osize!=nsize){ic.attr('class',ic.attr('class').replace(osize,nsize));}
			}else{ic.addClass(nsize);}
		});		
	};
	HierarchyTextObject.prototype.incdepth=function(block){
		var self=this;
		block.find('div.ht_item').each(function(){
			self.incitemdepth($(this));
		});
	};
	HierarchyTextObject.prototype.decitemdepth=function(itm){
		var d=parseInt(itm.attr('depth'));
		var osize='ht_size';
		if(d<4){osize+=d.toString();}
		var nsize='ht_size'; d--;
		if(d<4){nsize+=d.toString();}
		itm.attr('depth',d);
		itm.find('p').each(function(){
			var ic=$(this);
			if(ic.hasClass(osize)){
				if(osize!=nsize){ic.attr('class',ic.attr('class').replace(osize,nsize));}
			}else{ic.addClass(nsize);}
		});		
	};
	HierarchyTextObject.prototype.decdepth=function(block){
		var self=this;
		block.find('div.ht_item').each(function(){
			self.decitemdepth($(this));
		});
	};
	HierarchyTextObject.prototype.text2heading=function(itm){
		var depth=itm.attr('depth');
		var spantext=itm.children('span.text');
		if(spantext.length>0){
			if(depth<4){
				var ht_size='ht_size';
				spantext.removeClass(ht_size).addClass(ht_size+depth);
			}
			spantext.removeClass('ht_text').addClass('ht_heading');
		}
	};
	HierarchyTextObject.prototype.heading2text=function(itm){
		var depth=itm.attr('depth');
		var spantext=itm.children('span.text');
		if(spantext.length>0){
			if(depth<4){
				var ht_size='ht_size';
				spantext.removeClass(ht_size+depth).addClass(ht_size);
			}
			spantext.removeClass('ht_heading').addClass('ht_text');
		}
	};
	HierarchyTextObject.prototype.upgradeItem=function(id){
		var obj=this;
		var self=this.element;
		var itm=self.find('.bodyview').find('#'+id);
		var cld=itm.next();
		if( cld.length>0 ){
			if( cld.attr('class')!='children' ){
				cld.length=0;
			}
		}
		var pcld=itm.parent();
		obj.setParent(id,pcld.parent().attr('id').replace('cld',''));
		if(cld.length>0){
			cld.insertAfter(pcld);
			obj.decdepth(cld);
		}
		obj.decitemdepth(itm);
		itm.insertAfter(pcld);
		if(pcld.children().length==0){
			var pitm=pcld.prev();
			if(pitm.length>0){
				if(obj.isPlainText(id)){
					if(!obj.headingFlag(id)){
						obj.heading2text(pitm);
						//pitm.children('span.text').removeClass('ht_heading').addClass('ht_text');
					}
				}
				pitm.find('i.e-c').remove();
			}
			pcld.remove();
		}
		this.modified();
	};	
	HierarchyTextObject.prototype.downgradeItem=function(id){
		var obj=this;
		var self=this.element;
		var itm=self.find('.bodyview').find('#'+id);
		var pre=itm.prev();
		var pcd=itm.prev();
		if( pcd.length>0 ){
			if( pcd.attr('class')=='children' ){
				pre = pcd.prev();
			}else{pcd.length=0;}
		}
		var cld=itm.next();
		if( cld.length>0 ){
			if( cld.attr('class')!='children' ){cld.length=0;}
		}
		if(pre.length>0){
			if(pcd.length==0){
				if(obj.isPlainText(id)){
					//alert('depth:'+pre.attr('depth'));
					//alert('span.text:'+pre.children('span.text').length);
					//alert('class:'+pre.children('span.text').attr('class'));
					//pre.children('span.text').removeClass('ht_text').addClass('ht_heading');
					obj.text2heading(pre);
				}
				if(pre.find('i.e-c').length==0){pre.append('<i class="fa fa-angle-up e-c"></i>');obj.bindItemECEvent(pre);}
				pre.after('<div class="children" id="cld'+pre.attr('id')+'"></div>');
				pcd=pre.next();
			}
			obj.incitemdepth(itm);
			itm.appendTo(pcd);
			if(cld.length>0){obj.incdepth(cld);cld.appendTo(pcd);}
			obj.setParent(id,pre.attr('id'));
		}
		this.modified();
	};
	HierarchyTextObject.prototype.typeMagic=function(cls){
		/*class ti: type icon*/
		return '<i class="'+cls+' fa fa-magic fa-flip-horizontal"></i>';//blank class if needed
	};
	HierarchyTextObject.prototype.typeIcon=function(cls,editortype){
		var icon='';
		switch(editortype){/*1:plain text/2:illustration/3:appendix/4:qrcode/5:task/6:map/7:table/8:chart/9:source code/10:video*/
			case 1:icon = '<span class="'+cls+' fa-stack" style="font-size:7px;"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-font fa-stack-1x"></i></span>';break;
			case 2:icon = '<i class="'+cls+' fa fa-picture-o"></i>';break;
			case 3:icon = '<i class="'+cls+' fa fa-paperclip"></i>';break;
			case 4:icon = '<i class="'+cls+' fa fa-qrcode"></i>';break;
			case 5:icon = '<i class="'+cls+' fa fa-tasks"></i>';break;
			case 6:icon = '<i class="'+cls+' fa fa-map-marker"></i>';break;
			case 7:icon = '<i class="'+cls+' fa fa-table"></i>';break;
			case 8:icon = '<i class="'+cls+' fa fa-line-chart"></i>';break;
			case 9:icon = '<i class="'+cls+' fa fa-code"></i>';break;
			case 10:icon = '<i class="'+cls+' fa fa-video-camera"></i>';break;
			default:icon = this.typeMagic(cls);break;
		}
		return icon;		
	};
	HierarchyTextObject.prototype.textimportDialog=function(id){
		var obj=this;
		var self=this.element;
		$('body').TextImport({
			onCancel: function(id){},
			onRevise: function(id,textareaid){
				var ta=$('#'+textareaid);
				var dt={'type':'GBT9704','data':$.base64.encode(ta.val())};
				$.getJSON('/hierarchyrevise',dt,function(m){
					if(m.Code=='100'){
						ta.val($.base64.decode(m.Data));
					}else{alert(m.Msg);}
				});
			},
			onImport: function(id,fmt,val,rmvspace){
				switch(fmt){
					case 'GBT9704':
						var dt={'type':fmt,'data':$.base64.encode(val)};
						$.getJSON('/hierarchyshape',dt,function(m){
							if(m.Code=='100' && m.Count>0){
								var data=$.base64.decode(m.Data);
								var nodes=JSON.parse(data);
								obj.TreeText.appendTree(id,nodes);
							}else{alert(m.Msg);}
						});
						break;
					case 'contract': break;
					default:
						var lines=new Array();
						var vv=val.split('\n');
						for(var i=0,n=vv.length;i<n;i++){
							var v=$.trim(vv[i]);
							if(rmvspace){v=v.replace(/ /g,'');}
							if(v.length>0){lines.push(v);}
						}
						obj.TreeText.appendTexts(id,lines);
						break;
				}
			}
		}).show_pane(id);
	};
	HierarchyTextObject.prototype.entranceDialog=function(id){
		var obj=this;
		var self=this.element;
		$('body').EntranceDialog({
			txt_text: obj.options.txt_text,
			txt_image: obj.options.txt_image,
			txt_appendix: obj.options.txt_appendix,
			txt_qrcode: obj.options.txt_qrcode,
			txt_task: obj.options.txt_task,
			txt_map: obj.options.txt_map,
			txt_table: obj.options.txt_table,
			txt_chart: obj.options.txt_chart,
			txt_code: obj.options.txt_code,
			txt_video: obj.options.txt_video,
			onCancel: function(id){obj.TreeText.RemoveitemByID(id);},
			onEnter: function(id,editortype){
				obj.newFlag=true;
				obj.setParagraphtype(id,editortype);
				obj.TreeText.setItemCaption(id,obj.typeIcon('ti',editortype));
				obj.modified();
				var itm=self.find('.bodyview').find('#'+id);
				itm.children('.ef').remove();
				itm.prepend(obj.typeIcon('ef',editortype));
				obj.focusParagraph(id);
			}
		}).show_pane(id);
	};
	HierarchyTextObject.prototype.splitItem=function(id,newid){
		var obj=this;
		var self=this.element;
		var itm=self.find('.bodyview').find('#'+id);
		if(itm.length>0){
			var depth=parseInt(itm.attr('depth'))+1;
			var tt = '<div class="children" id="cld'+id+'">';
			tt += '<div class="ht_item" id="'+newid+'" depth="'+depth+'">';
			tt += obj.typeMagic('ef')+'<span></span></div></div>';
			itm.after( tt );
			if(itm.find('i.e-c').length==0){itm.append('<i class="fa fa-angle-up e-c"></i>');obj.bindItemECEvent(itm);}
			if(obj.isPlainText(id)){
				obj.text2heading(itm);
				//itm.children('span.text').removeClass('ht_text').addClass('ht_heading');
			}
			itm.next().find('#'+newid).on('click',function(){
				obj.clickItem($(this));
			});
			obj.modified();
			obj.entranceDialog(newid);
		}
	};
	HierarchyTextObject.prototype.initBodyview=function(){
		var self=this.element;
		var bodyview=self.find('.bodyview');
		var itm=bodyview.find('#0');
		if(itm.length==0){
			var tt='<div class="ht_item" id="0" depth="0" style="height:0px"></div>';
			tt+='<div class="children" id="cld0"></div>';
			bodyview.append(tt);
		}
		return bodyview;
	};
	HierarchyTextObject.prototype.newItem=function(id,newid){
		var obj=this;
		var self=this.element;
		var bodyview=obj.initBodyview();
		var itm=bodyview.find('#'+id);
		if(itm.length>0){
			var depth=parseInt(itm.attr('depth'))+1;
			var cld = itm.next();
			if( cld.length>0 ){
				if(!cld.hasClass('children')){cld.length=0;}
			}
			if(cld.length==0){
				itm.after('<div class="children" id="cld'+id+'"></div>');
				cld=itm.next();
			}
			var tt = '<div class="ht_item" id="'+newid+'" depth="'+depth+'">';
			tt += obj.typeMagic('ef')+'<span></span></div>';
			cld.append(tt);
			self.find('#'+newid).on('click',function(){obj.clickItem($(this));});
			obj.modified();
			obj.entranceDialog(newid);
		}
	};
	HierarchyTextObject.prototype.addItem=function(id,newid){
		var obj=this;
		var self=this.element;
		var itm=self.find('.bodyview').find('#'+id);
		if(itm.length>0){
			var depth=itm.attr('depth');
			var cld = itm.next();
			if( cld.length>0 ){
				if(!cld.hasClass('children')){cld.length=0;}
			}
			var tt = '<div class="ht_item" id="'+newid+'" depth="'+depth+'">';
			tt += obj.typeMagic('ef')+'<span></span></div>';
			if(cld.length>0){cld.after(tt);}else{itm.after(tt);}
			self.find('#'+newid).on('click',function(){obj.clickItem($(this));});
			obj.modified();
			obj.entranceDialog(newid);
		}
	};
	HierarchyTextObject.prototype.appendText=function(pid,newid,text){
		var obj=this;
		var self=this.element;
		var bodyview=obj.initBodyview();
		var pitm=bodyview.find('#'+pid);
		if(pitm.length>0){
			var depth=parseInt(pitm.attr('depth'))+1;
			var addcld=true;
			var pcld = pitm.next();
			if( pcld.length>0 && pcld.hasClass('children') ){addcld=false;}
			if(addcld){
				pitm.after('<div class="children" id="cld'+pid+'"></div>');
				pcld=pitm.next();
			}
			var tt = '<div class="ht_item" id="'+newid+'" depth="'+depth+'">';
			tt += '<span class="ef fa-stack" style="font-size:7px;"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-font fa-stack-1x"></i></span>';
			tt += '<span class="text ht_text ht_indent ht_size">'+text+'</span>';
			tt += '</div>';
			if(pcld.length>0){
				pcld.append(tt);
				pcld.find('#'+newid).on('click',function(){obj.clickItem($(this));});
			}
			if(pitm.find('i.e-c').length==0){pitm.append('<i class="fa fa-angle-up e-c"></i>');obj.bindItemECEvent(pitm);}
			if(obj.isPlainText(pid)){
				obj.text2heading(pitm);
			}
			obj.setParent(newid,pid);
			obj.setParagraphtype(newid,1);
			var dt={heading:false,align:'left',noindent:false,text:text};
			obj.Content[newid]=JSON.stringify(dt);
			if($.inArray(newid,obj.NU_content)==-1){obj.NU_content.push(newid);}
			obj.modified();
		}
	};
	HierarchyTextObject.prototype.removeItem=function(id){
		var obj=this;
		var self=this.element;
		self.find('.ht_editor').hide();
		var itm=self.find('.bodyview').find('#'+id);
		if(itm.length>0){
			var nxt = itm.next();
			var cld = itm.next();
			if( cld.length>0 ){
				if(cld.attr('class')=='children'){
					nxt = cld.next();
				}else{cld.length=0;}
			}
			var pre = itm.prev();
			var prc = itm.prev();
			if( prc.length>0 ){
				if(prc.attr('class')=='children'){
					pre = prc.prev();
				}else{prc.length=0;}
			}
			var removed=false;
			if(nxt.length==0){//the last one
				if(pre.length==0){
					var pcld = itm.parent();//div children
					var pitm = pcld.prev();
					if(pcld.length>0&&pitm.length>0){
						removed=true;
						var pid=pitm.attr('id');
						if(pid!='0'){
							if(this.isPlainText(pid)){
								if(!this.headingFlag(pid)){
									obj.heading2text(pitm);
									//pitm.children('span.text').removeClass('ht_heading').addClass('ht_text');
								}
							}
							pcld.remove();
							pitm.find('i.e-c').remove();
						}else{pcld.empty();}
					}
					if(pitm.length>0){
						pitm.find('.e-c').remove();
					}
				}
			}
			if(!removed){
				if(cld.length>0){cld.remove();}
				itm.remove();
			}
			this.modified();
		}else{
			alert('already removed');
		}
	};
	HierarchyTextObject.prototype.setParent=function(id,pid){
		this.NU_parent[id]=pid;
	};
	HierarchyTextObject.prototype.setParagraphtype=function(id,ptype){
		this.ParagraphType[id]=ptype;
		if($.inArray(id,this.NU_type)==-1){this.NU_type.push(id);}	
	};
	HierarchyTextObject.prototype.setPosition=function(id,children){
		var obj=this;
		if(children.length==0){
			if(obj.NU_position.hasOwnProperty(id)){
				delete obj.NU_position[id];
			}
		}else{
			obj.NU_position[id]=children;
		}
	};
	HierarchyTextObject.prototype.initTexteditor=function(container){
		var self=this.element;
		var obj=this;
		var ss='<div id="texteditor" class="ht_editor"></div>';
		container.append(ss);
		obj.TextEditor=container.find('#texteditor').TextEditor({
			onAppend: function() {
				obj.TreeText.appenditem();//ctrl+z
			},
			onChange: function(id,gist,val) {
				var ptype=1;
				obj.TreeText.setItemCaption(id,obj.typeIcon('ti',ptype)+'&nbsp;'+gist);
				obj.setParagraphtype(id,ptype);
				obj.Content[id]=val;
				if($.inArray(id,obj.NU_content)==-1){obj.NU_content.push(id);}			
				obj.modified();
				/*obj.ParagraphType[id]=ptype;
				var align=obj.defaultAlign(ptype);
				var content={align:align,heading:false,text:''};
				if(obj.Content.hasOwnProperty(id)){
					var ct=obj.Content[id];
					if(ct.length>0){content=JSON.parse(ct);}
				}
				content['text']=text;
				obj.Content[id]=JSON.stringify(content);
				if($.inArray(id,obj.NU_content)==-1){obj.NU_content.push(id);}
				
				var itm=self.find('.bodyview').find('#'+id);
				itm.children('p').remove();
				var ht_type='ht_text';
				var depth=parseInt(itm.attr('depth'));
				var ht_size='ht_size';
				if(depth<4){ht_size += depth.toString();}
				var cld=itm.next('#cld'+id);
				if(cld.length>0){ht_type='ht_heading';}else{
					if(ht_type=='ht_text' && content['heading']){ht_type='ht_heading';}
				}
				
				var istyle=new Array();
				if(content.hasOwnProperty('align')){align=content['align'];}
				istyle.push('text-align:'+align);
				
				var txt='';
				$.each(text.split('\n'),function(i,val){
					txt+='<p class="'+ht_type+' '+ht_size+'" style="'+istyle.join(';')+'">'+$.trim(val)+'</p>';
				});
				itm.append(txt);*/
			}
		});
	};
	HierarchyTextObject.prototype.initCodeeditor=function(container){
		var self=this.element;
		var obj=this;
		var ss='<div id="codeeditor" class="ht_editor"></div>';
		container.append(ss);
		obj.CodeEditor=container.find('#codeeditor').CodeEditor({
			i18n: obj.options.i18n,
			onAppend: function() {
				obj.TreeText.appenditem();//ctrl+z
			},
			onChange: function(id,gist,val) {
				var ptype=9;
				obj.TreeText.setItemCaption(id,obj.typeIcon('ti',ptype)+'&nbsp;'+gist);
				obj.setParagraphtype(id,ptype);
				obj.Content[id]=val;
				if($.inArray(id,obj.NU_content)==-1){obj.NU_content.push(id);}			
				obj.modified();
			}
		});
	};
	HierarchyTextObject.prototype.drawIllustrationGist=function(images){
		var gist='';
		var dt=JSON.parse(images);
		for(var i=0;i<dt.images.length;i++){
			var o=dt.images[i];
			if(o.tag.length>0){
				gist += o.tag;
			}else{
				gist += o.src;
			}
			if(gist.length>80){break;}
			if(gist.length>0){gist+=' ';}
		}
		return gist;
	};
	HierarchyTextObject.prototype.initIllustrator=function(container){
		var obj=this;
		var self=this.element;
		var ss='<div id="illustrator" class="ht_editor"></div>';
		container.append(ss);
		obj.Illustrator=container.find('#illustrator').Illustrator({
			name:obj.options.name+'_illu',
			/*layout_mode:'embed',*/
			show_border:false,
			image_capacity:32,
			max_columns: 24,
			i18n:obj.options.i18n,
			token:obj.options.token,
			exceedcontainerlimit:obj.options.exceedcontainerlimit,
			urlduplicated:obj.options.urlduplicated,
			historyStr:obj.options.historyStr,linkStr:obj.options.linkStr,
			linkplaceholderStr:obj.options.linkplaceholderStr,
			localStr:obj.options.localStr,selectedStr:obj.options.selectedStr,
			txt_tag:obj.options.txt_tag,txt_src:obj.options.txt_src,
			txt_ext:obj.options.txt_ext,txt_operation:obj.options.txt_operation,
			txt_remove:obj.options.txt_remove,
			txt_yes:obj.options.txt_yes,txt_no:obj.options.txt_no,
			txt_removeornot:obj.options.txt_removeornot,
			txt_emptylist:obj.options.txt_emptylist,txt_srcduplicated:obj.options.txt_srcduplicated,
			uploadStr:obj.options.uploadStr,	dragDropStr:obj.options.dragDropStr,
			multiDragErrorStr:obj.options.multiDragErrorStr,
			extErrorStr:obj.options.extErrorStr,	duplicateErrorStr:obj.options.duplicateErrorStr,
			sizeErrorStr:obj.options.sizeErrorStr, uploadErrorStr:obj.options.uploadErrorStr,
			maxFileCountErrorStr:obj.options.maxFileCountErrorStr,
			readRecent: obj.options.readRecentIllustration,
			saveRecent: function(src,tag){obj.options.saveRecentIllustration(src,tag);},
			onChange: function(id,val) {/*val:{column:3,align:left,valign:top,images:[{tag,src},{tag,src}]}*/
				var ptype=2;
				obj.TreeText.setItemCaption(id,obj.typeIcon('ti',ptype)+'&nbsp;'+obj.drawIllustrationGist(val));
				obj.setParagraphtype(id,ptype);
				obj.Content[id]=val;
				if($.inArray(id,obj.NU_content)==-1){obj.NU_content.push(id);}			
				obj.modified();
			}
		});
	};
	HierarchyTextObject.prototype.drawAppendixGist=function(appendixes){
		var gist='';
		var dt=JSON.parse(appendixes);
		for(var i=0;i<dt.appendixes.length;i++){
			var o=dt.appendixes[i];
			if(o.tag.length>0){
				gist += o.tag;
			}else{
				gist += o.src;
			}
			if(gist.length>80){break;}
			if(gist.length>0){gist+=' ';}
		}
		return gist;
	};
	HierarchyTextObject.prototype.initAppendixeditor=function(container){
		var obj=this;
		var self=this.element;
		var ss='<div id="appendixeditor" class="ht_editor"></div>';
		container.append(ss);
		this.AppendixEditor=container.find('#appendixeditor').Appendix({
			max_columns: 10,
			i18n: obj.options.i18n,
			txt_tag: obj.options.txt_tag,
			txt_src: obj.options.txt_src,
			txt_size: obj.options.txt_size,
			txt_ext: obj.options.txt_ext,
			txt_operation: obj.options.txt_operation,
			txt_choose: obj.options.txt_choose,
			txt_remove: obj.options.txt_remove,
			txt_yes: obj.options.txt_yes,
			txt_no: obj.options.txt_no,
			txt_removeornot: obj.options.txt_removeornot,
			txt_emptylist: obj.options.txt_emptylist,
			txt_srcduplicated: obj.options.txt_srcduplicated,
			historyStr:obj.options.historyStr,linkStr:obj.options.linkStr,
			linkplaceholderStr:obj.options.linkplaceholderStr,
			localStr:obj.options.localStr,selectedStr:obj.options.selectedStr,
			uploadStr: obj.options.uploadStr,	dragDropStr:obj.options.dragDropStr,
			multiDragErrorStr:obj.options.multiDragErrorStr,
			extErrorStr:obj.options.extErrorStr,	duplicateErrorStr:obj.options.duplicateErrorStr,
			sizeErrorStr: obj.options.sizeErrorStr, uploadErrorStr:obj.options.uploadErrorStr,
			maxFileCountErrorStr:obj.options.maxFileCountErrorStr,
			token: obj.options.token,
			readRecent: obj.options.readRecentAppendix,
			saveRecent: function(src,tag){obj.options.saveRecentAppendix(src,tag);},
			onChange: function(id,val) {/*val:{column:3,align:center,valign:top,appendixes:[{tag,src},{tag,src}]}*/
				var ptype=3;
				obj.TreeText.setItemCaption(id,obj.typeIcon('ti',ptype)+'&nbsp;'+obj.drawAppendixGist(val));
				obj.setParagraphtype(id,ptype);
				obj.Content[id]=val;
				if($.inArray(id,obj.NU_content)==-1){obj.NU_content.push(id);}			
				obj.modified();
			}
		});
	}
	HierarchyTextObject.prototype.drawQRcodeGist=function(qrcodes){
		var gist='';
		var dt=JSON.parse(qrcodes);
		for(var i=0;i<dt.qrcodes.length;i++){
			var o=dt.qrcodes[i];
			if(o.tag.length>0){
				gist += o.tag;
			}else{
				gist += o.code;
			}
			if(gist.length>80){break;}
			if(gist.length>0){gist+=' ';}
		}
		return gist;
	};
	HierarchyTextObject.prototype.initQReditor=function(container){
		var obj=this;
		var self=this.element;
		var ss='<div id="qreditor" class="ht_editor"></div>';
		container.append(ss);
		this.QREditor=container.find('#qreditor').QRcoder({
			i18n: obj.options.i18n,
			txt_tag: obj.options.txt_tag,
			txt_src: obj.options.txt_src,
			txt_operation: obj.options.txt_operation,
			txt_choose: obj.options.txt_choose,
			txt_remove: obj.options.txt_remove,
			txt_yes: obj.options.txt_yes,
			txt_no: obj.options.txt_no,
			txt_removeornot: obj.options.txt_removeornot,
			txt_emptylist: obj.options.txt_emptylist,
			txt_codeduplicated: obj.options.txt_codeduplicated,
			exceedcontainerlimit: obj.options.exceedcontainerlimit,
			codeduplicated: obj.options.codeduplicated,
			frequentStr: obj.options.frequentStr,
			textStr: obj.options.textStr,
			historyStr:obj.options.historyStr,linkStr:obj.options.linkStr,
			readRecent: obj.options.readRecentQRcode,
			saveRecent: function(code,tag){obj.options.saveRecentQRcode(code,tag);},
			onChange: function(id,val) {/*val:{column:3,width:240,align:center,valign:top,qrcodes:[{tag,code},{tag,code}]}*/
				var ptype=4;
				obj.TreeText.setItemCaption(id,obj.typeIcon('ti',ptype)+'&nbsp;'+obj.drawQRcodeGist(val));
				obj.setParagraphtype(id,ptype);
				obj.Content[id]=val;
				if($.inArray(id,obj.NU_content)==-1){obj.NU_content.push(id);}			
				obj.modified();
			}
		});
	};
	HierarchyTextObject.prototype.initTableeditor=function(container){
		var obj=this;
		var self=this.element;
		var ss='<div id="tableeditor" class="ht_editor"></div>';
		container.append(ss);
		obj.TableEditor=container.find('#tableeditor').Gridex({
			onTitleChange: function(id,title) {
				var ptype=7;
				obj.TreeText.setItemCaption(id,obj.typeIcon('ti',ptype)+'&nbsp;'+title);
				obj.setParagraphtype(id,ptype);
			},
			onChange: function(id,val) {
				var ptype=7;
				obj.setParagraphtype(id,ptype);	
				obj.Content[id]=val;
				if($.inArray(id,obj.NU_content)==-1){obj.NU_content.push(id);}	
				obj.modified();
			}
		});
	};
	HierarchyTextObject.prototype.setText=function(base64val){
		var self=this.element;
		self.find('.bodyview').empty().append($.base64.decode(base64val));
		this.bindTextEvent();
		return this;
	};
	HierarchyTextObject.prototype.modified=function(){
		this.isModified=true;
		this.options.onChange('---');//only warning, real changed in the save method
	};
	HierarchyTextObject.prototype.save=function(){
		if(this.isModified){
			var obj=this;
			var self=this.element;
			var ptpt=new Array();
			$.each(obj.NU_type,function(i,id){
				if(obj.ParagraphType.hasOwnProperty(id)){
					ptpt.push(id+'='+obj.ParagraphType[id]);
				}
			});
			var ct=new Object();
			$.each(obj.NU_content,function(i,id){
				if(obj.Content.hasOwnProperty(id)){
					ct[id]=$.base64.encode(obj.Content[id]);
					if($.inArray(id,obj.NU_type)==-1){//along with paragraph type
						if(obj.ParagraphType.hasOwnProperty(id)){
							ptpt.push(id+'='+obj.ParagraphType[id]);
						}
					}
				}
			});
			var m=obj.options.saveHierarchytext(obj.TreeText.getNewIDs(),obj.TreeText.getRmvIDs(),
					JSON.stringify(obj.NU_parent),JSON.stringify(obj.NU_position),ptpt.join(),JSON.stringify(ct));
			if(m.Code=="100"){
				var mapID=m.NewIDs;
				obj.TreeText.refreshID(mapID);
				var oids=Object.keys(mapID);
				$.each(oids,function(i,oid){
					var nid=mapID[oid];
					if(obj.ParagraphType.hasOwnProperty(oid)){
						obj.ParagraphType[nid]=obj.ParagraphType[oid];
						delete obj.ParagraphType[oid];
					}
					if(obj.Content.hasOwnProperty(oid)){
						obj.Content[nid]=obj.Content[oid];
						delete obj.Content[oid];
					}
				});
				
				var box=self.find('.bodyview').find('#cld0');
				var oids=Object.keys(m.NewIDs);
				$.each(oids,function(i,oid){
					var nid=m.NewIDs[oid];
					box.find('#'+oid).attr('id',nid);
					box.find('#cld'+oid).attr('id','cld'+nid);	
				});
				obj.NU_parent={};
				obj.NU_position={};
				obj.NU_type.length=0;
				obj.NU_content.length=0;
				//set editor id or refresh it.
			}else{
				alert(m.Msg);
			}
			var solidify=self.find('.bodyview').html();
			obj.options.onChange(solidify.replace(' htitem_focus',''));
			this.isModified=false;
		}	
	};
	HierarchyTextObject.prototype.focusParagraph=function(id){
		var self=this.element;
		var bodyview=self.find('.bodyview');
		var viewitem=bodyview.find('#'+id);
		if(viewitem.length>0){
			var itm=viewitem;
			var iid=parseInt(id);
			while(iid>0){
				var pitm=itm.parent().prev();
				if(pitm.length>0){
					iid=parseInt(pitm.attr('id'));
					if(iid>0){
						var i_up='fa-angle-up';var i_dn='fa-angle-down';
						var ii=pitm.find('.e-c');
						if(ii.length>0){
							if(ii.hasClass(i_dn)){
								var nxt=pitm.next();
								if(nxt.length>0 && nxt.hasClass('children')){nxt.show();}
								ii.removeClass(i_dn).addClass(i_up);
							}
						}
						itm=pitm;
					}
				}else{iid=0;}
			}			
			this.focusItem(bodyview,viewitem);
			var top_block=$('.top_block');
			var boxheight=top_block.height();
			var half_boxheight=parseInt(boxheight/2);
			var ypos=viewitem.position().top;
			var yobj=ypos+top_block.scrollTop();
			if(ypos<0 || ypos>boxheight-viewitem.height()){
				var yscroll = yobj-half_boxheight;
				if(yscroll<0){yscroll=0;}
				top_block.animate({scrollTop:yscroll},100);
			}
			if(this.inEditing){this.setEditor(id);}
		}
	};
	HierarchyTextObject.prototype.defaultAlign=function(ptype){
		var align='center';
		/*1:plain text/2:illustration/3:appendix/4:qrcode/5:task/6:map/7:table/8:chart/9:source code/10:video*/
		if(ptype==1 || ptype==3 || ptype==9){
			align='left';
		}
		return align;
	};
	HierarchyTextObject.prototype.focusItem=function(bodyview,itm){
		/*var boxheight=bodyview.height();
		var half_boxheight=parseInt(boxheight/2);
		var ypos=itm.position().top;
		var yobj=ypos+bodyview.scrollTop();
		alert('ypos:'+ypos+' yobj:'+yobj+' boxheight:'+boxheight);
		if(ypos<0 || ypos>boxheight){
			
			var yscroll = yobj-half_boxheight;
			if(yscroll<0){yscroll=0;}
			bodyview.animate({scrollTop:yscroll},100);
		}*/
		var tf='htitem_focus';
		if(!itm.hasClass(tf)){
			var ef='ef_focus';
			bodyview.find('.'+tf).removeClass(tf);
			bodyview.find('.'+ef).removeClass(ef);
			itm.addClass(tf);
			itm.children('.ef').addClass(ef);			
		}
		var id=itm.attr('id');
		var ptype=0;
		if(this.ParagraphType.hasOwnProperty(id)){ptype=this.ParagraphType[id];}
		var align=this.defaultAlign(ptype);
		var content={};
		if(this.Content.hasOwnProperty(id)){content=this.Content[id];}
		if(content.hasOwnProperty('align')){align=content['align'];}
		if(this.inEditing){
			//this.ItemAlign.Select(align);
		}
	};
	HierarchyTextObject.prototype.setEditor=function(id){
		var self=this.element;
		self.find('.ht_editor').hide();
		var viewitem=$('.bodyview').find('#'+id);
		/*1:plain text/2:illustration/3:appendix/4:qrcode/5:task/6:map/7:table/8:chart/9:source code/10:video*/
		this.editortype=0;
		var val='';
		if(this.ParagraphType.hasOwnProperty(id)){ this.editortype=this.ParagraphType[id]; }
		if(this.Content.hasOwnProperty(id)){ val=this.Content[id]; }
		switch(this.editortype){
			case 0:
				this.entranceDialog(id);
				break;
			case 1:
				this.TextEditor.show();
				this.TextEditor.setOuterID(id);
				this.TextEditor.setScreen(viewitem);
				this.TextEditor.setText(val);
				break;
			case 2:
				this.Illustrator.show();
				this.Illustrator.setOuterID(id);
				this.Illustrator.setScreen(viewitem);
				this.Illustrator.setImages(val);
				if(this.newFlag){this.Illustrator.addNew();}
				break;
			case 3:
				this.AppendixEditor.show();
				this.AppendixEditor.setOuterID(id);
				this.AppendixEditor.setScreen(viewitem);
				this.AppendixEditor.setAppendixes(val);
				if(this.newFlag){this.AppendixEditor.addNew();}
				break;
			case 4:
				this.QREditor.show();
				this.QREditor.setOuterID(id);
				this.QREditor.setScreen(viewitem);
				this.QREditor.setQRcodes(val);
				if(this.newFlag){this.QREditor.addNew();}
				break;
			case 7:
				this.TableEditor.show();
				this.TableEditor.setOuterID(id);
				this.TableEditor.setScreen(viewitem);
				this.TableEditor.setTable(val);
				break;
			case 9:
				this.CodeEditor.show();
				this.CodeEditor.setOuterID(id);
				this.CodeEditor.setScreen(viewitem);
				this.CodeEditor.setText(val);
				break;
			default:
				break;
		}
		this.EditorResize();
		this.newFlag=false;
	};
	HierarchyTextObject.prototype.EditorResize=function(){
		switch(this.editortype){
			case 1:
				this.TextEditor.resize();
				break;
			case 2:
				this.Illustrator.resize();
				break;
			case 3:
				this.AppendixEditor.resize();
				break;
			case 4:
				this.QREditor.resize();
				break;
			case 7:
				this.TableEditor.resize();
			case 9:
				this.CodeEditor.resize();
				break;
		}
	};
	HierarchyTextObject.prototype.windowSet=function(){
		var self=this.element;
		var popup=self.find('#popup');
		var left_block=popup.find('.left_block');
		var lr_splitter=popup.find('#lr_splitter');
		var right_block=popup.find('.right_block');
		var top_block=popup.find('.top_block');
		var tb_splitter=popup.find('#tb_splitter');
		var bottom_block=popup.find('.bottom_block');
		self.find('.bodyview').appendTo(top_block);
		var toolbar=self.find('#hierarchytoolbar');
		var toolbarheight=toolbar.height();
		var windowheight=$(window).height();
		var dy=windowheight-toolbarheight;
		toolbar.css({"display":"block","position":"fixed","z-index":11000,"top":"0px","left":"0px","width":"100%","height":toolbarheight+"px"});
		popup.css({"display":"block","position":"fixed","background":"#fff","z-index":11000,"top":toolbarheight+"px","left":"0px","width":"100%","height":dy+"px"});
		left_block.css("height",dy+"px");
		right_block.css("height",dy+"px");
		top_block.css("height",(dy-this.options.min_bottom_height-this.options.tb_splitter_height)+"px");
		bottom_block.css("height",this.options.min_bottom_height+"px");
		var addicon=popup.find('.addicon');
		addicon.css("left",(lr_splitter.position().left-addicon.width()-8)+"px");	
		this.EditorResize();
	};
	HierarchyTextObject.prototype.bindResizeEvent=function(){
		var obj=this;
		$(window).resize(function() {
			if(obj.inEditing){obj.windowSet();}
		});
	};
	HierarchyTextObject.prototype.bindAddiconEvent=function(){
		var obj=this;
		var self=this.element;
		self.find('.addicon').on('click',function(){
			obj.TreeText.appenditem();/*append at first grade*/
		});		
	};
	HierarchyTextObject.prototype.emptybodyview=function(){
		var obj=this;
		var self=this.element;
		self.find('.bodyview').find('#cld0').empty();
		obj.TreeText.emptyitem();
		self.find('.ht_editor').hide();		
		obj.modified();
	};
	HierarchyTextObject.prototype.hidepopup=function(){
		this.inEditing=false;
		var self=this.element;
		var bodyview=self.find('.bodyview');
		bodyview.appendTo(self);
		self.find('#popup').hide();	
		self.find('#hierarchytoolbar').hide();
	};
	HierarchyTextObject.prototype.bindToolBarEvent=function(){
		var self=this.element;
		var obj=this;
		self.find('.ht_empty').on('click',function(){
			self.YesnoAlert({width:300,height:100,yesText:obj.options.txt_yes,noText:obj.options.txt_no,
				doyes:function(id,action){
					obj.emptybodyview();
				}
			}).show_alertpane( '',obj.options.txt_emptyornot,'empty' );
		});
		self.find('.ht_import').on('click',function(){
			obj.textimportDialog(obj.TreeText.focusitemid());
		});
		self.find('.ht_collapseall').on('click',function(){
			obj.TreeText.collapseall();
		});
		self.find('.ht_expandall').on('click',function(){
			obj.TreeText.expandall();
		});
		self.find('.ht_close').on('click',function(){
			obj.hidepopup();
		});
		obj.bindExpandCollapseEvent();
	};
	HierarchyTextObject.prototype.bindExpandCollapseEvent=function(){
		var self=this.element;
		var i_up='fa-angle-up';var i_dn='fa-angle-down';
		self.find('.ht_expand_all').off('click').on('click',function(){
			var root=self.find('.bodyview').find('#cld0');
			root.find('div.children').show();
			root.find('.'+i_dn).removeClass(i_dn).addClass(i_up);
		});
		self.find('.ht_collapse_all').off('click').on('click',function(){
			var root=self.find('.bodyview').find('#cld0');
			root.find('div.children').hide();
			root.find('.'+i_up).removeClass(i_up).addClass(i_dn);
		});
	};
	HierarchyTextObject.prototype.clickItem=function(itm){
		var obj=this;
		var self=this.element;
		var bodyview=self.find('.bodyview');
		obj.focusItem(bodyview,itm);
		var id=itm.attr('id');
		if(id.length>0 && obj.inEditing){
			obj.TreeText.paththroughSilent(self.find('.left_block'),id);
			obj.TreeText.focusSilent(id);
			obj.setEditor(id);
		}		
	};
	HierarchyTextObject.prototype.bindTextEvent=function(){
		var obj=this;
		var self=this.element;
		var bodyview=self.find('.bodyview');
		bodyview.find('.ht_item').on('click',function(){
			obj.clickItem($(this));
		});
		bodyview.find('.ln_codearea').on('scroll',function(){
			var ca=$(this);
	  		ca.parent().find('.codearea-ino').css('margin-top', '-'+ca.scrollTop()+'px');
		});
		obj.bindItemECEvent(bodyview);
	};
	HierarchyTextObject.prototype.bindItemECEvent=function(block){
		block.find('.e-c').on('click',function(){
			var i_up='fa-angle-up';var i_dn='fa-angle-down';
			var item=$(this);
			var pitm=item.parent();
			var nxt=pitm.next();
			var flag=false;
			if(nxt.length>0 && nxt.hasClass('children')){flag = true;}
			if(item.hasClass(i_up)){
				if(flag){nxt.hide();}
				item.removeClass(i_up).addClass(i_dn);
			}else if(item.hasClass(i_dn)){
				if(flag){nxt.show();}
				item.removeClass(i_dn).addClass(i_up);
			}
		});
	};
	HierarchyTextObject.prototype.bindLRSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var x=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var left_block=self.find('.left_block');
			x=e.clientX-splitter.offsetWidth-left_block.width();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){mouseMove(ev || event);};
				splitter.onmouseup = mouseUp;
			}else{
				left_block.css('cursor','col-resize');
				self.find('.right_block').css('cursor','col-resize');
				$(document).bind("mousemove", mouseMove).bind("mouseup", mouseUp);
			}
		});
		function mouseMove(e){
			e.preventDefault();
			var left_block=self.find('.left_block');
			if((e.clientX/document.body.clientWidth)<0.8){
				left_block.css('width',e.clientX - x + 'px');
				var addicon=self.find('.addicon');
				addicon.css("left",(self.find('#lr_splitter').position().left-addicon.width()-8)+"px");
			}
			if(e.clientX<obj.options.lr_splitter_width){left_block.hide();}else{left_block.show();}
		}
		function mouseUp(){
			self.find('.left_block').css('cursor','default');
			self.find('.right_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", mouseMove).unbind("mouseup", mouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var left_block=self.find('.left_block');
			left_block.show();
			left_block.css('width',obj.options.min_left_width+'px');
			var addicon=self.find('.addicon');
			addicon.css("left",(self.find('#lr_splitter').position().left-addicon.width()-8)+"px");
			e.preventDefault();
		});
	};
	HierarchyTextObject.prototype.bindTBSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var y=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var top_block=self.find('.top_block');
			y=e.clientY-splitter.offsetHeight-top_block.height();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){tbmouseMove(ev || event);};
				splitter.onmouseup = tbmouseUp;
			}else{
				top_block.css('cursor','row-resize');
				self.find('#bottom_block').css('cursor','row-resize');
				$(document).bind("mousemove", tbmouseMove).bind("mouseup", tbmouseUp);
			}
		});
		function tbmouseMove(e){
			e.preventDefault();
			var top_block=self.find('.top_block');
			var bottom_block=self.find('.bottom_block');
			var max_height=self.find('.right_block').height();
			var dy=e.clientY - y;
			var by=max_height-dy-obj.options.tb_splitter_height;
			if(by>=0){
				top_block.css('height',dy + 'px');
				var h=max_height-dy-obj.options.tb_splitter_height;
				bottom_block.css('height',h+'px');
				//self.find('.addicon').css("bottom",(h+4)+'px');
				obj.EditorResize();
			}
			if(e.clientY<obj.options.tb_splitter_height){
				top_block.hide();
				var h=max_height-obj.options.tb_splitter_height;
				bottom_block.css('height',h+'px');
				//self.find('.addicon').css("bottom",(h+2)+'px');
				obj.EditorResize();
			}else{top_block.show();}
		}
		function tbmouseUp(){
			self.find('.top_block').css('cursor','default');
			self.find('.bottom_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", tbmouseMove).unbind("mouseup", tbmouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var max_height=self.find('.right_block').height();
			self.find('.bottom_block').css('height',obj.options.min_bottom_height+'px');
			var top_block=self.find('.top_block');
			top_block.show();
			top_block.css('height',(max_height-obj.options.min_bottom_height-obj.options.tb_splitter_height)+'px');
			//self.find('.addicon').css("bottom",(obj.options.min_bottom_height+4)+'px');
			e.preventDefault();
		});
	};
    $.fn.HierarchyText=function(options){
		var hto=new HierarchyTextObject(this,options);
		hto.init();
		return hto;
    };