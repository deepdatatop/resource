function BoltViewObject(element,options){
	this.element=element;
	this.defaults={
		width: 400,
		checkbox: true,
  		identifier: 'product',
		bolt_scene: 'bolt',
		//sortlist_scene: 'issales',
      	language: '',
      	drawinstances_url: '/drawinstances',
		onChange: function(verts){}
	};
	this.value='';
	this.verticals=0;
	this.dimensions=0;
	this.spinner=new Object();
	this.options=$.extend({},this.defaults,options);
};
BoltViewObject.prototype.setValue=function(val){//val: 1,5,3
    this.value=val;
    var n=0;
    if(val.length>0){
    		var vv=val.split(',');
		n=vv.length;this.dimensions=n;
		if(n>1){n-=1;}
    }
    this.verticals=n;
    var di=this.element.find('#dimes');
    if(this.dimensions>1){
    		di.show();
		this.spinner.setMax(this.dimensions).setValue(this.verticals);
    }else{di.hide();}
    this.refreshBolt();
    return this;
};
BoltViewObject.prototype.setVerticals=function(nn){
	this.verticals=nn;
	var thebox=this.element;
	var bolts=thebox.find('.bolt-lnk');
	var lv='lnk-vert',lh='lnk-hori';
	bolts.each(function(i,a){
		var bolt=$(a);
		if(i<nn){
        		if(bolt.hasClass(lh)){
				bolt.removeClass(lh).addClass(lv);
			}
        }else{
        		if(bolt.hasClass(lv)){
				bolt.removeClass(lv).addClass(lh);
			}
        }
	});
};
BoltViewObject.prototype.refreshBolt=function(){
    var self=this;
    var thebox=this.element;
    if(self.value.length>0){
	    $.getJSON(this.options.drawinstances_url,{idf:self.options.identifier,scene:self.options.bolt_scene,lid:self.options.language,ids:self.value},function(m){
			if(m.Code=='100'){
				var oo=JSON.parse(m.Instances_stringify);
				var tt={};
				$.each(oo,function(i,o){
					tt[o.id]='<i class="fa fa-chevron-circle-right bolt-lnk lnk-hori"></i><span class="bolt-cap">'+o.name+'</span>';
				});
				var txt='';
				var vv=self.value.split(',');
				for(var i=0,n=vv.length;i<n;i++){
					v = vv[i];
					if(tt.hasOwnProperty(v)){
						var t=tt[v];
						if(i<self.verticals){
							t=t.replace(/lnk-hori/g, 'lnk-vert');
						}
						txt+=t;
					}
				}
				thebox.find('#bolt_left').empty().append(txt);
			}
		});
	}else{
		thebox.find('#bolt_left').empty();
	}	
};
BoltViewObject.prototype.init=function(){
    var self=this;
    var thebox=this.element;
    thebox.css({position:'relative',height:'30px',border:'solid 1px #ccc','border-radius':'3px','overflow':'hidden'});
    var txt='<div id="bolt_left"></div><div id="bolt_right"></div>';
    thebox.append(txt);
	self.spinner=thebox.find('#bolt_right').Simplespinner({width:25,min:1,max:self.dimensions,onChange: function(val){
		self.setVerticals(val);
		self.options.onChange(val);
	}}).setValue(self.verticals);
};
$.fn.Boltview=function(options){
	var bv=new BoltViewObject(this,options);
	bv.init();
	return bv;
};