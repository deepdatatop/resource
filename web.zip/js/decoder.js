function DecoderObject(element,options){
	this.element=element;
	this.defaults={
		uniqueid: '',
		action: 'L2NsaWNrZGVjb2Rl',
		encodedtext: '',
		method: 'SM2',
		onCopy: function(id,val){}
	};
	this.value='';
	this.options=$.extend({},this.defaults,options);
};
DecoderObject.prototype.decode=function(){
	var self=this,thebox=this.element,so=this.options;
	var flag=false;
	$.ajaxSettings.async = false;
	$.getJSON($.base64.decode(so.action),{encoded:so.encodedtext,method:so.method},function(m){
		if(m.Code=='100'){
			self.value=m.Plaintext;
			thebox.find('#result').text(m.Plaintext).css('color','#f00');
			flag = true;
		}else{
			alert(m.Code+m.Msg);
		}
	});
	$.ajaxSettings.async = true;
	return flag;
};
DecoderObject.prototype.init=function(){
	var self=this,thebox=this.element,so=this.options;
	if(so.encodedtext.length>0){
		thebox.css('position','relative');
		thebox.css('overflow-x','hidden');
		var txt='<span id="result" class="result">**********</span>';
		txt+='<span class="unlock action_button"><i class="fa fa-unlock"></i></span>';
		txt+='<span id="copy'+so.uniqueid+'" class="copy action_button" style="display:none"><i class="fa fa-copy"></i></span>';
		thebox.append(txt);
		thebox.find(".unlock").off("click").on("click",function(event){
			event.stopPropagation();
			if(self.decode()){
				$(this).hide();
				thebox.find(".copy").css('display','inline-block');
			}
		});
		thebox.find(".copy").off("click").on("click",function(event){
			event.stopPropagation();
			so.onCopy($(this).attr('id'),self.value);
		});
	}
};
$.fn.Decoder=function(options){
	var o=new DecoderObject(this,options);
	o.init();
	return o;
};