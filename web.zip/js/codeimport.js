function CodeimportObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		clientlanguage_id: '2',
		instance_id: '',
		viewblock_bs64: '',
		t_codeimportcaption: 'Code item import',
		t_yes: 'Yes',
		t_no: 'No',
		t_emptyornot: 'whether to ',
		t_removeornot: 'whether remove property column: ',
		t_separator_caption: 'COMMA,@TAB@SEMICOLON;@HASH#@SLASH/@VERTICALBAR|',
		t_prevtext: 'Previous',
		t_nexttext: 'Next',
		t_closetext: 'Close',
		t_pleaseinput: 'Please enter or paste the text line to import!',
		t_omit: 'omit',
		t_nodata: 'no import data',
		t_instance: 'object instance quantity',
		t_instances: 'instances:',
		t_property_hint: 'Object property description:<br>Import data text can be composed of one or more data instances, between instances by the line feed LF (ASCII 0x0A).<br>Each instance of the attribute value between characters such as TAB TAB, comma, asterisk, etc.<a href="/html?n=instanceimport" target="_blank">Object instance sample</a>',
		t_property: 'property column',
		t_propertychoosed: 'choose',
		t_propertyname: 'Property name',
		t_propertycaption: 'Caption',
		t_propertyunique: 'Unique?',
		t_propertytype: 'Type',
		t_propertysize: 'Limit',
		t_propertypattern: 'Validate rule',
		t_propertypadformat: 'Coding 0 pad',
		t_propertylanguage: 'Multiple language',
		t_import_hint: '1.The first line is title line, please ensure that the title items are corresponding to the order of data columns; <br>2. If there are extra data columns in the data, please add corresponding blank column titles. When importing, they will be ignored automatically. <br>The imported data text can be composed of one or multiple data instances, and each instance is separated by a line feed LF (ASCII 0x0A). <br>The maximum length of the imported text is 65535 bytes.',
		t_import_placeholder: 'Please enter or paste the data text here...',
		t_input: 'input data',
		t_columnseparator: 'Column separator:',
		t_preview: 'preview',
		t_validate_hint: 'Data validation',
		t_validating: 'validating',
		t_validatecomplete: 'validate complete',
		t_validate: 'validate',
		t_importing: 'importing',
		t_importcomplete: 'import complete',
		t_process: 'import',
		t_finish: 'finish',
		t_lengthexceed: 'length exceed limit:',
		t_notmatch: 'RegExp not match',
		t_hierarchy_indent: 'Hierarchy indent',
		t_linex: 'line %d:',
		t_toomany: 'too many errors!',
		t_dataok: 'Data format validatation is correct!',
		t_clearall: 'clear all',
		t_singleclear: 'single clear',
		t_instance_hint: 'Number of existing instances:',
		t_remove: 'remove',
		onClose: function(modified){},
		afterSave: function(){}
	};
	this.options=$.extend({},this.defaults,options);
	this.ismodified=false;
	this.importlanguage_id='2';
	this.stepwizard={};
	this.separators=[',','\t',';','/','|'];
	this.data_include_header_row=false;
	this.properties=[];
	this.choosed_properties=[];
	this.columnMproperty={};/*name0:i0,name1:i1,...*/
	this.title_line='';
	this.data_linee=[];
	this.extracted_separator='';
	this.extracted_fields=[];
	this.all_processlines = 0;//used for processprogress
	this.exe_processlines = 0;//used for processprogress
	this.all_validatelines = 0;//used for validateprogress
	this.chk_validatelines = 0;//used for validateprogress
	this.pos_validate=0;
	this.error_lines=0;
	this.is_hierarchy_code=false;
	this.hierarchy_property={};
};
CodeimportObject.prototype.checkvalue=function(ptype,psize,ppattern,value){
	var so=this.options;
	var result={code:0,msg:''}
	var flag=true;
	if(value.length>0){
		if(ppattern.length>0){
			var pattern=new RegExp(ppattern);
			flag=pattern.test(value);
		}
		if(flag){
			switch(ptype){
				case 'string':
					var size=Number(psize);
					if(size>0){
						if(value.length>size){
							flag=false;
							result.msg=' '+so.t_lengthexceed+psize;
						}
					}
					break;
			}	
		}else{
			result.msg=ppattern+' '+so.t_notmatch;
		}
	}
	if(flag){result.code=100;}
	return result;
}
CodeimportObject.prototype.validateNext=function(){
	var self=this,so=this.options,thebox=this.element;
	var container=thebox.find('#validate_progress_container');
	if(self.chk_validatelines<self.all_validatelines){
		var valid=true;
		var view=thebox.find('#validate_text');
		var r=splitfield(self.data_linee[self.chk_validatelines],self.extracted_separator);
		for(var j=0;j<r.fields.length;j++){
			if(self.columnMproperty.hasOwnProperty(j)){
				var i=self.columnMproperty[j];
				var property=self.properties[i];
				var v=r.fields[j];
				var rc=self.checkvalue(property.Type,property.Size,property.Pattern,v);
				if(rc.code!=100){
					var format=so.t_linex;
					var msg=format.replace('%d',(self.chk_validatelines+1))+' '+property.Name+' ';
					view.append('<div class="error_line">'+msg+rc.msg+': '+v+'</div>');
					valid=false;
				}
			}
		}
		if(!valid){
			self.error_lines++;
		}
		if(self.error_lines>10){
			container.hide();
			view.append('<div class="error_line">'+so.t_toomany+'</div>');
		}else{
			self.chk_validatelines ++;
			setTimeout(function(){
				var cursor = Math.round(self.chk_validatelines/self.all_validatelines*100);
				if(self.chk_validatelines<self.all_validatelines){
					if(cursor>self.pos_validate){
						self.pos_validate = cursor;
						var progress=thebox.find('#validate_progress_bar .ui-progress');
						progress.animateProgress(cursor, function(){self.validateNext();});	
					}else{self.validateNext();}	
				}else{
					container.hide();
					if(self.error_lines==0){
						view.append('<div class="validate_success">'+so.t_dataok+'</div>');
						self.stepwizard.shownextbutton();
					}
				}		
			},0);
		}
	}else{container.hide();}
};
CodeimportObject.prototype.exeNextSQL=function(pos,fname){
	var self=this,thebox=this.element;
	$.getJSON('/executetableimport',{ipos: pos,file:fname},function(m){
		thebox.find('#comment').text(m.Comment);
		thebox.find('#sqltext').text(m.SQL_text);
		if(m.Code=='100'){
			self.exe_processlines+=1;
			var cursor = 5+Math.round(self.exe_processlines/self.all_processlines*95);
			var progress=thebox.find('#process_progress_bar .ui-progress');
			progress.animateProgress(cursor, function(){});
			if(m.Next_filepos>0){ 
				self.exeNextSQL(m.Next_filepos,m.SQL_file);
			}else{
				self.ismodified=true;
				thebox.find('#comment').text('');
				thebox.find('#sqltext').text('');
				progress.animateProgress(0, function(){});
				self.stepwizard.showNext();
				self.stepwizard.hideprevbutton();
			}	
		}else{
			alert('error:'+m.SQL_text);
			thebox.find('#exemesg').text(m.Msg);
		}
	});	
};
CodeimportObject.prototype.setinstanceview=function(thebox){
	var so=this.options;
	$.ajaxSettings.async = false;
	var instance_intro=thebox.find('#instance_intro');
	if(instance_intro.length>0){
		if(so.viewblock_bs64.length==0){
			$.getJSON('/readviewblock',{idf:'entity',iid:so.instance_id,scene:'intro'},function(m){
				if(m.Code=='100'){so.viewblock_bs64=m.Block_bs64;}
			});			
		}
		instance_intro.empty();
		if(so.viewblock_bs64.length>0){
			instance_intro.append($.base64.decode(so.viewblock_bs64));
		}
	}
	var instance_view=thebox.find('#instance_view');
	if(instance_view.length>0){
		instance_view.empty();
		$.getJSON('/languageversions',{eid:so.instance_id},function(m){
			var ss='';
			if(m.Code=='100'){
				ss='<table style="margin:0 auto;position:relative;top:50%;transform:translateY(-50%);">'
				ss+='<tr><td class="instance_text" align="right">'+so.t_instances+'</td><td class="instance_value">'+m.Instances+'</td>';
				ss+='<td>';
				if(m.Instances>0){
					ss+='<span id="0" class="empty_button"><i class="fa fa-trash-o"></i>&nbsp;'+so.t_clearall+'</span>';
				}
				ss+='</td></tr>';
				if(m.Languageversions!==null){
					for(var i=0;i<m.Languageversions.length;i++){
						var v=m.Languageversions[i];
						ss+='<tr><td align="right"><img src="'+v.Language_flag+'"><span class="instance_text">'+v.Language_tag+'：</span></td>';
						ss+='<td class="instance_value">'+v.Instances+'</td>';
						ss+='<td>';
						if(v.Instances>0){
							ss+='<span id="'+v.Language_id+'" class="empty_button"><i class="fa fa-trash-o"></i>&nbsp;'+so.t_singleclear+'</span>';
						}
						ss+='</td></tr>';	
					}
				}
				ss+='<tr><td colspan="3" align="center">'+so.t_instance_hint+'</td></tr>';
				ss+='</table>';
			}else{ss='<span class="error_msg">'+m.Msg+'</span>';}
			instance_view.append(ss);
		});
	}
	$.ajaxSettings.async = true;
};
CodeimportObject.prototype.makeGM_data=function(){
	var self=this;
	var gmData = {totals: self.choosed_properties.length};
	var data=[];
	for(var i=0,n=self.properties.length;i<n;i++){
		var property = self.properties[i];
		data.push({name:property.Name,
			caption:property.Caption,
			unique:property.Unique,
			type:property.Type,
			size:property.Size,
			pattern:property.Pattern,
			padformat:property.Padformat,
			language:property.Language_adaptive
		});
	}
	gmData['data']=data;
	return gmData;	
};
CodeimportObject.prototype.close_pane=function(){
	this.options.onClose(this.ismodified);
};
CodeimportObject.prototype.set_pane=function(){
	this.i18n_options();
	var self=this,thebox=this.element,so=this.options;
	self.hierarchy_property={Name:'_indent_',Caption:'['+so.t_hierarchy_indent+']',Unique:'',Type:'string',Size:16,Pattern:'^#*$',Padformat:'<i class="fa fa-sitemap"></i>&nbsp;',Language_adaptive:false};
	var scs=so.t_separator_caption.split('@');
	var topbody=$(top.document.body);
	var panewidth=$(window).width()*9/10;
	var paneheight=$(window).height()*9/10;
	self.stepwizard=topbody.Stepwizard({
		width: panewidth,height: paneheight,caption:so.t_codeimportcaption,
		lockatLast: true,
		prevText: '<i class="fa fa-arrow-circle-o-left"></i>&nbsp;'+so.t_prevtext,
		nextText: '<i class="fa fa-arrow-circle-o-right"></i>&nbsp;'+so.t_nexttext,
		closeText: '<i class="fa fa-times"></i>&nbsp;'+so.t_closetext,
		onClose: function(){self.close_pane();},
		nextbuttonvisible: function(i){
			var flag=true;
			if(i==4 || i==5){flag=false;}
			return flag;
		},
		beforeNext: function(i) {
			var flag=true;
			var thebox=self.stepwizard.element;
			switch(i){
				case 2:
					var it=thebox.find('#import_text');
					var itv=it.val();
					if(itv.length==0){
						alert(so.t_pleaseinput);
						it.focus();
						flag=false;
					}else{
						var ss=itv.split('\n',1);
						var result=splitfield(ss[0],'');
						if(result.error.length>0){
							alert(result.error);
							it.focus();
							flag=false;
						}else{
							self.extracted_separator=result.separator;
							self.extracted_fields=result.fields;
							var i=self.separators.indexOf(self.extracted_separator);
							if(i>=0){
								var radiobutton=thebox.find('#s_'+i);
								radiobutton.attr('checked','checked');
								self.columnMproperty={};
								var k=0;
								for(i=0;i<self.extracted_fields.length;i++){
									var v=self.extracted_fields[i];
									for(var j=0;j<self.properties.length;j++){
										if(v==self.properties[j].Name||v==self.properties[j].Caption){
											if($.inArray(self.properties[j].Name,self.choosed_properties)>=0){
												self.columnMproperty[k]=j;
												k++;
											}
											break;
										}
									}
								}
								if(Object.keys(self.columnMproperty).length>0){
									self.data_include_header_row=true;	
								}else{
									k=0;
									for(var i=0;i<self.properties.length;i++){
										var property=self.properties[i];
										if($.inArray(property.Name,self.choosed_properties)>=0){
											self.columnMproperty[k]=i;
											k++;
										}
									}
								}
							}
						}
					}
					break;
				case 3:
					break;
			}
			return flag;
		},
		goNext: function(i) {
			var thebox=self.stepwizard.element;
			switch(i){
				case 2:
					var names=[];
					var n=self.properties.length;
					for(var i=0;i<n;i++){
						var v=self.properties[i];
						if($.inArray(v.Name,self.choosed_properties)>=0){
							if(v.Caption.length>0){names.push(v.Caption);}
							else{names.push(v.Name);}
						}
					}
					var txt=names.join(',')+'\n';
					var editor=thebox.find('#import_text');
					editor.val(txt);
					editor.focus();
					break;
				case 3:
					var preview_table=thebox.find('#preview_table');
					if(preview_table.length>0){
						preview_table.empty();
						var itv=thebox.find('#import_text').val();
						self.data_linee=itv.split('\n');
						if(self.data_include_header_row){self.data_linee.shift();}
						var ncols=Math.max(self.properties.length,self.extracted_fields.length);
						var ss='<tr>'; var titles=[];
						for(var i=0;i<ncols;i++){
							if(self.columnMproperty.hasOwnProperty(i)){
								var property=self.properties[self.columnMproperty[i]];
								ss+='<td class="title">'+property.Name+'</td>';
								titles.push(property.Name);
							}else{
								ss+='<td class="title"><i class="fa fa-ban"></i>'+so.t_omit+'</td>';
								titles.push('');
							}
						}
						ss+='</tr>';
						preview_table.append(ss);
						self.title_line=titles.join(',');
						var n=Math.min(self.data_linee.length,20);
						var nn=0;
						for(var i=0;i<n;i++){
							var ln=$.trim(self.data_linee[i]);
							if(ln.length>0){
								var r=splitfield(ln,self.extracted_separator);
								var ss='<tr class="preview_row">';
								for(var j=0;j<r.fields.length;j++){
									var sclass='cell'; if(self.columnMproperty.hasOwnProperty(j)){sclass='matchedcell';}
									ss+='<td class="'+sclass+'">'+r.fields[j]+'</td>';
								}
								for(var j=r.fields.length;j<ncols;j++){
									var sclass='cell'; if(self.columnMproperty.hasOwnProperty(j)){sclass='matchedcell';}
									ss+='<td class="'+sclass+'">&nbsp;</td>';
								}
								ss+='</tr>';
								preview_table.append(ss);
								nn++;
							}
						}
						if(nn==0){
							var ss='<tr style="height:300px;"><td colspan="'+ncols+'" align="center" style="font-size:200%;color:#f00;">';
							ss+='<i class="fa fa-info-circle"></i>'+so.t_nodata+'</td></tr>';
							preview_table.append(ss);
							self.stepwizard.hidenextbutton();
						}
					}
					break;
				case 4:
					var progress=thebox.find('#validate_progress_bar .ui-progress');
					progress.find('.ui-label').hide();//hide the label at start
					progress.find('.ui-over').hide();
					progress.css('width', '0%');//set initial value
					$('#validate_progress_container').show();
					setTimeout(function(){
						progress.animateProgress(0, function(){
							self.all_validatelines=self.data_linee.length;
							self.chk_validatelines=0;self.pos_validate=0;self.error_lines=0;
							thebox.find('#validate_text').empty();
							self.validateNext();
						});									
					},0);
					break;
				case 5:
					var 	lines=self.title_line+'\n'+self.data_linee.join('\n');
					var progress=thebox.find('#process_progress_bar .ui-progress');
					progress.find('.ui-label').hide();//hide the label at start
					progress.find('.ui-over').hide();
					progress.css('width', '0%');//set initial value
					thebox.find('#process_progress_container').show();
					$.getJSON('/tableimport',{eid:so.instance_id,txt:lines,lid:self.importlanguage_id},function(m){
						if(m.Code=='100'){
							self.all_processlines = m.SQL_lines; self.exe_processlines = 0;
							progress.animateProgress(5, function(){
								self.exeNextSQL(0,m.SQL_file);
							});
						}else{
							alert(m.Msg);
						}
					});
					break;
				}
			}
		});
	var ss='<div id="instance_hint"></div>';
	ss+='<div id="instance_container"><div id="instance_intro"></div><div id="instance_view"></div></div>';
	self.stepwizard.addStep(so.t_instance,ss);
	self.setinstanceview(self.stepwizard.element);
	ss='<div id="property_hint">'+so.t_property_hint+'</div>';
	ss+='<div id="property_container"><table id="property_table">';
	ss+='</table></div>';
	var flag=true;
	self.stepwizard.addStep(so.t_property,ss);
	var multiple_language=false,self_hierarchy=false,is_codeset=false;
	$.ajaxSettings.async = false;
	$.getJSON('/inputproperty',{eid:so.instance_id},function(m){
		if(m.Code=='100'){
			self.properties = m.Properties;
			for(var i=0,n=self.properties.length;i<n;i++){
				var property=self.properties[i];
				if(property.Name=='code'||property.Name=='name'){
					self.choosed_properties.push(property.Name);
				}
			}
			multiple_language=m.Multi_language;
			self_hierarchy=m.Self_hierarchy;
			is_codeset=m.Is_codeset;
			if(m.Self_hierarchy){
				if(is_codeset&&m.Coding_type==1){self.is_hierarchy_code=true;
				}else{
					self.properties.unshift(self.hierarchy_property);
					self.choosed_properties.push(self.hierarchy_property.Name);
				}
			}
		}else{
			flag=false;
			ss='<tr><td colspan="6" style="text-align:center;" class="error_msg">'+m.Msg+'</td></tr>';
			thebox.find('#property_table').append(ss);
		}
	});
	$.ajaxSettings.async = true;
	$('#property_table').GM({
		gridManagerName: 'entityproperty',
		height: '100%',
		supportCheckbox: false,
		ajaxData: self.makeGM_data(),
		columnData: [{key: 'name',text: so.t_propertyname},
			{key: 'caption',text: so.t_propertycaption},
			{key: 'unique',text: so.t_propertyunique},
			{key: 'type',text: so.t_propertytype},
			{key: 'size',text: so.t_propertysize},
			{key: 'pattern',text: so.t_propertypattern},
			{key: 'padformat',text: so.t_propertypadformat,isShow: is_codeset&&self_hierarchy},
			{key: 'language',text: so.t_propertylanguage,align: 'center',
			isShow: multiple_language,
			template: function(language, row){
				var ss='';
				if(language){ss='<span><i class="fa fa-lg fa-check-circle"></i></span>';}
				return ss;
			}
		},
		{key: 'operation',text: '<span>'+so.t_propertychoosed+'</span>',
			template: function(operation, row){
				var ss='<input class="chooser" type="checkbox" key="'+row.name+'"';
				if($.inArray(row.name,self.choosed_properties)>=0){
					ss+=' checked="checked"';
				}
				ss+='>';
				return ss;
			},align: 'center'
		}],
		supportMoveRow: true,
		moveRowConfig: {
			handler: (list, tableData) => {
				var n=self.properties.length;
				if(n==tableData.length){
					var mapNameIndex={};
					var moved=false;
					var old=[];
					for(var i=0;i<n;i++){
						old.push(self.properties[i]);
						mapNameIndex[self.properties[i].Name]=i;
						if(tableData[i].name!=self.properties[i].Name){
							moved=true;
						}
					}
					if(moved){
						self.properties.length=0;
						for(var i=0;i<n;i++){
							var k=mapNameIndex[tableData[i].name];
							self.properties.push(old[k]);
						}
					}
					old.length=0;
				}
			}
		}
	});
	if(flag){
		ss='<div id="import_hint">'+so.t_import_hint+'</div>';
		ss+='<div id="worktop">';
		$.ajaxSettings.async = false;
		$.getJSON('/acceptlanguages',{eid:so.instance_id},function(m){
            if(m.Code=="100"){
				self.importlanguage_id = m.Baselanguage_id;
				if(m.Acceptlanguages!==null){
					for(var i=0;i<m.Acceptlanguages.length;i++){
						var v=m.Acceptlanguages[i];
						ss+='<span class="tab_item';
						if(v.Selected){ss+='_selected';}
						ss+='" id="'+v.Language_id+'">'+v.Language_tag;
						ss+='&nbsp;<span class="flag" style="background: url('+v.Language_flag+');"></span></span>';
					}
				}
			}else{ss+=m.Msg;}
		});
		$.ajaxSettings.async = true;
		ss+='</div>';
		ss+='<div id="import_container"><textarea id="import_text" wrap="off" spellcheck="false" placeholder="'+so.t_import_placeholder+'"></textarea></div>';
		self.stepwizard.addStep(so.t_input,ss);
		ss='<div id="perview_title">'+so.t_columnseparator+'<br>';
		for(var i=0;i<self.separators.length;i++){
			ss+='&nbsp;<input type="radio" id="s_'+i+'" name="seperator" value="'+i+'">'+scs[i];
		}
		ss+='</div>';
		ss+='<div id="preview_tableview"><table id="preview_table">';
		ss+='</table></div>';
		self.stepwizard.addStep(so.t_preview,ss);
		ss ='<div id="validate_title">'+so.t_validate_hint+'</div>';
		ss+='<div id="validate_progress_container" class="progress_container" style="display: none;">';
		ss+='<div id="validate_progress_bar" class="ui-progress-bar">';
		ss+='<div class="ui-progress" style="width:0%;">';
		ss+='<span class="ui-label" style="display:none;">'+so.t_validating+'<b class="value">0%</b></span>';
		ss+='<span class="ui-over" style="display:none;">'+so.t_validatecomplete+'</span>';
		ss+='</div></div></div>';
		ss+='<div style="width:100%" id="validate_text"></div>';
		self.stepwizard.addStep(so.t_validate,ss);
		ss='<div id="process_progress_container" class="progress_container" style="display: none;">';
		ss+='<div id="process_progress_bar" class="ui-progress-bar">';
		ss+='<div class="ui-progress" style="width:0%;">';
		ss+='<span class="ui-label" style="display:none;">'+so.t_importing+'<b class="value">0%</b></span>';
		ss+='<span class="ui-over" style="display:none;">'+so.t_importcomplete+'</span>';
		ss+='</div></div>';
		ss+='<div style="width:100%"><span id="comment"></span></div>';
		ss+='<div style="width:100%;height:50px;overflow:hidden;"><span id="sqltext"></span></div>';
		ss+='<div style="width:100%"><span id="exemesg" style="color:#F00;"></span></div>';
		ss+='<div id="main_content" style="display:none;text-align:center">';
		ss+='</div></div>';
		self.stepwizard.addStep(so.t_process,ss);
		ss='<div style="width:100%;height:100%;text-align:center;display:table">';
		ss+='<div style="display:table-cell;vertical-align:middle;color:#080;">';
		ss+='<span style="font-size:80px"><i class="fa fa-check-circle"></i></span><br>';
		ss+='<span style="font-size:32px">'+so.t_importcomplete+'</span>';
		ss+='</div></div>';
		self.stepwizard.addStep(so.t_finish,ss);
	}
	self.stepwizard.showpane();
	thebox.find('.empty_button').live('click',function(){//jquery-1.8.3 use live
		var lid=$(this).attr('id');
		$('#step_pane').YesnoAlert({
			yesText:so.t_yes,noText:so.t_no,
			doyes: function(id,action){
				$.getJSON('/emptyinstance',{eid:so.instance_id,lid:lid},function(m){
					if(m.Code=="100"){
						self.setinstanceview($(top.document.body));
						self.ismodified=true;
					}else{alert(m.Msg);}
				});
			}
		}).show_alertpane('',so.t_emptyornot+'['+$(this).text()+']?','empty');
	});
	thebox.find('span.tab_item').live('click',function(){//jquery-1.8.3 use live
		$(this).siblings('span.tab_item_selected').removeClass('tab_item_selected').addClass('tab_item');
		self.importlanguage_id = $(this).attr('id');
		$(this).removeClass('tab_item').addClass('tab_item_selected');
	});
	thebox.find('.chooser').live('click',function(){
		var key=$(this).attr('key');
		var i=$.inArray(key,self.choosed_properties);
		if($(this).prop('checked')){
			if(i<0){self.choosed_properties.push(key);}
		}else{
			if(i>=0){self.choosed_properties.splice(i,1);}
		}
	});
	/*thebox.find('#refreshproperty').live('click',function(){
		$.getJSON('/inputproperty',{eid:so.instance_id},function(m){
			if(m.Code=='100'){
				self.properties = m.Properties;
				if(m.Self_hierarchy){self.properties.unshift(self.hierarchy_property);}
				GridManager.setAjaxData('entityproperty',self.makeGM_data());
			}
		});
	});*/
	/*thebox.find('.rmvproperty').live('click',function(){
		var key=$(this).attr('key');
		$('body').YesnoAlert({
			yesText:so.t_yes,noText:so.t_no,
			doyes: function(key,action){
				var removed=false;
				var n=self.properties.length;
				for(var i=0;i<n;i++){
					if(self.properties[i].Name==key){
						self.properties.splice(i,1);
						removed=true;
						break;	
					}
				}
				if(removed){
					GridManager.setAjaxData('entityproperty',self.makeGM_data());
				}
			}
		}).show_alertpane(key,so.t_removeornot+'['+key+']?','remove');
	});*/
};
CodeimportObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}}
};
$.fn.Codeimport=function(options){
	var acodeimport=new CodeimportObject(this,options);
	return acodeimport;
};