	function openpage(id,url){
		var thecaret=$('.fa-caret-right');
		if(thecaret.length>0){
			thecaret.remove();
		}
		$('#page').attr('src',url);
		$('#itm'+id).append('<i class="fa fa-fw fa-caret-right"></i>');
	}
	function FoldingEntranceObject(element,options){
		this.element=element;
		this.defaults={
			item_option:[]
		};
		this.options=$.extend({},this.defaults,options);
		this.pos=new Object();/*the item_option pos(array index) vs value*/
		this.childlist=new Object();
    };
	FoldingEntranceObject.prototype.extendHierarchyOption=function(){/*calculate option's isleaf,depth*/
		var myparent = new Object();
		var nchildren = new Object();
		nchildren[0] = 0;
		this.childlist[0]=new Array();
		var n=this.options.item_option.length;
		for(var i=0;i<n;i++){
			var v=this.options.item_option[i].value;
			this.pos[v]=i;
			nchildren[v]=0;
			myparent[v]=this.options.item_option[i].parent;
			this.childlist[v]=new Array();
		}
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			var depth=1;
			var parent=o.parent;
			if(this.childlist.hasOwnProperty(parent)){
				this.childlist[parent].push(o.value);
			}
			nchildren[parent]+=1;
			while(parent>0&&myparent.hasOwnProperty(parent)){
				depth++;
				parent=myparent[parent];
			}
			o.depth=depth;
			this.options.item_option[i]=o;
		}
		for(var i=0;i<n;i++){
			var o=this.options.item_option[i];
			o.isleaf=(nchildren[o.value]==0);
			this.options.item_option[i]=o;
		}
	};
	FoldingEntranceObject.prototype.loadItem=function(box,val) {//recursive function
		if(this.childlist.hasOwnProperty(val)){
			var children = this.childlist[val];
			var n=children.length;
			for(var i=0;i<n;i++){
				var idx=this.pos[children[i]];
				var itm=this.options.item_option[idx];
				var txt=''; var ahref='javascript:;'; var icon='';
				if(itm.hasOwnProperty('url')){ahref="javascript:openpage("+itm.value+",'"+itm.url+"');";}
				switch(itm.depth){
				case 1:
					if(itm.hasOwnProperty('icon')){icon=itm.icon;}
					txt='<li class="nav-item"><a href="'+ahref+'">'+icon+'<span id="itm'+itm.value+'">'+itm.label+'</span>';
					var ncs=this.childlist[children[i]].length;
					if(ncs>0){txt+='<i class="nav-more"></i>';}
					txt+='</a>';
					if(ncs>0){txt+='<ul id="i'+itm.value+'"></ul>';}
					txt+='</li>';
					box.append(txt);
					if(ncs>0){this.loadItem(box.find('#i'+itm.value),itm.value);}
					break;
				case 2:
					txt='<li class="nav-leaf"><a href="'+ahref+'"><span id="itm'+itm.value+'" style="margin-left:30px;">'+itm.label+'</span></a></li>';
					box.append(txt);
					break;
				}
			}
		}
	};
	FoldingEntranceObject.prototype.resetWidget=function(){
		var obj=this;
		var self=this.element;
		self.empty();
		var ss='<div class="nav">';
        //ss+='<div class="nav-top">';
        ss+='<div id="thin" style="cursor:pointer;text-align:right;border-bottom:1px solid rgba(255,255,255,.1)"><i class="fa fa-compress fa-lg ec"></i></div>';
        //ss+='</div>';
        ss+='<ul id="items"></ul></div>';
		ss+='<div id="rightblock" style="margin-left:150px;height:100%;">';
		ss+='<iframe id="page" style="width:100%;height:100%;margin:0px;padding:0px;border:none;"></iframe></div>';
		self.append(ss);
		obj.loadItem(self.find('#items'),0);
		self.find('.nav-item>a').on('click',function(){
			if (!$('.nav').hasClass('nav-thin')) {
				if ($(this).next().css('display') == "none") {//expand
					$('.nav-item').children('ul').slideUp(300);
					$(this).next('ul').slideDown(300);
					$(this).parent('li').addClass('nav-expand').siblings('li').removeClass('nav-expand');
				}else{//collapse
					$(this).next('ul').slideUp(300);
					$('.nav-item.nav-expand').removeClass('nav-expand');
				}
			}
		});
		
		self.find('#thin').on('click',function(){//nav-thin switch
			if (!$('.nav').hasClass('nav-thin')) {
				$('#rightblock').css('margin-left','50px');
				$('.nav-item.nav-expand').removeClass('nav-expand');
				$('.nav-item').children('ul').removeAttr('style');
				$('.nav').addClass('nav-thin');
				$('.ec').removeClass('fa-compress').addClass('fa-expand').removeClass('ec').addClass('ce');
			}else{
				$('.nav').removeClass('nav-thin');
				$('.ce').removeClass('fa-expand').addClass('fa-compress').removeClass('ce').addClass('ec');
				$('#rightblock').css('margin-left','150px');
			}
		});
	};
    FoldingEntranceObject.prototype.init=function(){
		this.extendHierarchyOption();
		this.resetWidget();
		if(this.options.hasOwnProperty('default_url')){
			if(this.options.default_url.length>0){this.element.find('#page').attr('src',this.options.default_url);}
		}
    };
    $.fn.FoldingEntrance=function(options){
		var anentrance=new FoldingEntranceObject(this,options);
		anentrance.init();
		return anentrance;
    };
