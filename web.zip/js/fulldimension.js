/*inherit from Multidimensionbase, need load mdb.js first*/
function inheritPrototype(subObject, superObject){
	var prototype = Object.create(superObject.prototype);
	prototype.constructor = subObject;
	subObject.prototype = prototype;
}
function FulldimensionObject(element,options){
	var defaults={
	};
	MultidimensionbaseObject.call(this,element,$.extend({},defaults,options));
};
inheritPrototype(FulldimensionObject,MultidimensionbaseObject);

FulldimensionObject.prototype.compressex=function(){
	this.element.find('#zeroradio').show();
};
FulldimensionObject.prototype.expandex=function(){
	this.element.find('#zeroradio').hide();
};
FulldimensionObject.prototype.saveinput=function(val){
	var nm=this.subentity+'dimension';
	var dt={};
	dt[nm]='';
	var o={properties:''};o[this.valueproperty]=val;
	dt[this.subentity]=[o];
	this.options.onChange(JSON.stringify(dt));
};
FulldimensionObject.prototype.initex=function(){
	var self=this;
	var thebox=this.element;
	thebox.find(':radio').on('click',function(event){
		var fdtype=$(this).val();
		if(fdtype=='zero'){
			thebox.find('#zeroinput').css('display','inline-block').focus();
			thebox.find('#moreinput').hide();
			thebox.find('#cross_table').hide();
			thebox.find('#ecbtn').hide();
		}else{
			thebox.find('#zeroinput').hide();
			thebox.find('#moreinput').css('display','inline-block');
			thebox.find('#cross_table').css('display','inline-block');
			thebox.find('#ecbtn').css('display','inline-block');
			self.PqGrid.pqGrid("refreshDataAndView");
		}
	});
	thebox.find('#zeroinput').on('input propertychange',function(e){
		self.saveinput($(this).val());
	});		
}
FulldimensionObject.prototype.setupWidget=function(){
	var self=this;
	var thebox=this.element;
	thebox.empty();
	var fdtype='zero';
	if(self.options.dim_ids.length>0){fdtype='more';}
	var tb_height=self.toolbarheight-1;
	var txt='<div id="pane">';
	//txt+='<div id="a_toolbar" style="width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;background-color:#f9f9f9;">';
	txt+='<div id="a_toolbar" style="width:100%;background-color:#f9f9f9;">';
	txt+='<div style="float:left;">'+self.caption+':&nbsp;&nbsp;';
	txt+='<input id="zeroinput" type="text" value="'+self.zerovalue+'"';
	if(fdtype=='more'){txt+=' style="display:none"';}
	txt+='>';
	txt+='<span id="zeroradio"><input type="radio" name="fdtype" value="zero"';
	if(fdtype=='zero'){txt+=' checked="checked"';}
	txt+='>单一</span>';
	txt+='<input type="radio" name="fdtype" value="more"';
	if(fdtype=='more'){txt+=' checked="checked"';}
	txt+='>组合</div>';
	txt+='<div id="moreinput" style="float:left;';
	if(fdtype=='zero'){txt+='display:none;';}
	txt+='">';
	txt+='<div id="bolt" style="width:500px;float:left;"></div>';
	txt+='<div style="width:100px;float:left;text-align:center">';
	txt+='<i id="tableempty" class="fa fa-lg fa-trash-o"></i>';
	txt+='</div>';
	txt+='</div>';
	txt+='<div id="ecbtn" style="float:right;';
	if(fdtype=='zero'){txt+='display:none;';}
	txt+='width:24px;text-align:center">';
	txt+='<i id="md_ec" class="fa fa-expand" style="height:'+tb_height+'px;line-height:'+tb_height+'px;"></i>';
	txt+='</div>';
	txt+='</div>';
	var height=self.options.height-self.toolbarheight;
	txt+='<div id="cross_table" style="width:100%;height:'+height+'px;';
	if(fdtype=='zero'){txt+='display:none;';}
	txt+='"></div>';
	txt+='</div>';
	thebox.append(txt);	
}
$.fn.Fulldimension=function(options){
	var fd=new FulldimensionObject(this,options);
	fd.init();
	return fd;
};