function PopintersectObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		caption:'',
		width:1000,
		height:560,
		zindex:200,
		txt_save: 'Save',
		txt_close: 'Close',
		txt_clear: 'Clear',
		txt_clearornot:'Clear all?',
		t_yes:'Yes',
		t_no:'No',
		widget_dependency_bs64: '',
		entity_id: '',
        identifier: '',
		subentity: '',
		vert_codeset: '',//appmodule
		hori_codeset: '',//application
		vertcodeset_bs64: '',
		horicodeset_bs64: '',
		data_bs64: '',//[{"application_id":"1","id":"1","appmodule_id":"1"},{"id":"2","appmodule_id":"2","application_id":"2"},{"id":"3","appmodule_id":"3","application_id":"3"},{"id":"4","appmodule_id":"4","application_id":"4"}]	
		onClose: function(){}
	};
	this.header_footer=80;
	this.id='';
	this.IS={};
	this.po='popis_overlay';
	this.pp='popis_pane';
	this.default_languageid='2';
	this.accept_languageids='';
	this.accept_languages={};
	this.mapkeyid={};
	this.kvcells={};
	this.vertical={};
	this.horizontal={};
	this.vertcodeset=[];
	this.horicodeset=[];//[{"Id":1,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"customer","Name":"客户"},{"Id":8,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"staffer","Name":"职员"},{"Id":9,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"director","Name":"部门主管"},{"Id":99,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"master","Name":"业务总管"},{"Id":100,"Parentid":0,"Isleaf":1,"Depth":1,"Code":"administrator","Name":"系统管理员"}]
	this.options=$.extend({},this.defaults,options);
};
PopintersectObject.prototype.onSave=function(data){
	var celldata=JSON.parse(data);
	var self=this;
	var so=this.options;
	var mapexists={};
	var mapnewkey={};
	var dt=[];
	var k=1;
	for(var i=0,n=self.horicodeset.length;i<n;i++){
		var hori=self.horicodeset[i];
		if(hori.Isleaf==1){
			for(var j=0,m=self.vertcodeset.length;j<m;j++){
				var vert=self.vertcodeset[j];
				if(vert.Isleaf==1){
					var key=hori.Id+'-'+vert.Id;
					if(celldata.hasOwnProperty(key)){
						var cd=celldata[key];
						if(cd==1){
							if(self.mapkeyid.hasOwnProperty(key)){
								mapexists[key]=1;
							}else{
								mapnewkey[k]=key;
								var o={'_id_':k};
								o[so.hori_codeset+'_id']=hori.Id;
								o[so.vert_codeset+'_id']=vert.Id;
								dt.push(o);
								k ++;
							}
						}
					}
				}
			}
		}
	}
	for(let key in self.mapkeyid){
		if(!mapexists.hasOwnProperty(key)){
			dt.push({'id':self.mapkeyid[key],'_m_':'DEL'});
			delete self.mapkeyid[key];
		}
	}
	var o={eid:so.entity_id,sub:so.subentity,rmi:'',lid:2,dat:$.base64.encode(JSON.stringify(dt))};
	$.ajaxSettings.async = false;
	$.getJSON('/savebatchinstance',o,function(m){
		if(m.Code=='100'){//m.MapID  _id_ : id  --- mapkeynew   _id_ : key
			for(let nid in m.MapID){//load new instance id.
				if(mapnewkey.hasOwnProperty(nid)){
					self.mapkeyid[mapnewkey[nid]]=m.MapID[nid]
				}
			}
		}else{alert(m.Msg);}
	});
	$.ajaxSettings.async = true;
};
PopintersectObject.prototype.close_pane=function(){
	this.IS={};
	this.element.find('#pis_grid_area').remove();
	this.element.find('#'+this.pp).remove();
	this.element.find('#'+this.po).remove();
	this.options.onClose();
};
PopintersectObject.prototype.parseData=function(){
	var self=this,so=this.options;
	self.vertical=JSON.parse($.base64.decode(so.vertcodeset_bs64));
	self.horizontal=JSON.parse($.base64.decode(so.horicodeset_bs64));
	if(self.vertical['Code']=='100'){self.vertcodeset=self.vertical.Children;}
	if(self.horizontal['Code']=='100'){self.horicodeset=self.horizontal.Children;}	
	var data=JSON.parse($.base64.decode(so.data_bs64));
	self.kvcells={};
	for(var i=0,n=data.length;i<n;i++){
		var dt=data[i];
		var key=dt[so.hori_codeset+'_id']+'-'+dt[so.vert_codeset+'_id'];
		self.kvcells[key]=1;
		self.mapkeyid[key]=dt['id'];
	}
};
PopintersectObject.prototype.include_callback=function(){//call at include.js
	var self=this,thebox=this.element,so=this.options;
	self.IS=$('#pis_grid_area').Intersection({
		vertcodeset: self.vertical,
		horicodeset: self.horizontal,
		height: so.height-self.header_footer,
        kvcells: self.kvcells,
        onChange: function(){thebox.find('#pis_save').show();}
	});
};
PopintersectObject.prototype.setpane=function(){
	var self=this;
	var wd='',id_bs64=this.options.widget_dependency_bs64;
	if(id_bs64.length>0){
		wd=$.base64.decode(id_bs64);
	}
	include_queue(this,wd);	// ➸ include_callback
};
PopintersectObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
PopintersectObject.prototype.showSavebtn=function(){
	this.element.find('#pis_save').show();
};
PopintersectObject.prototype.hideSavebtn=function(){
	this.element.find('#pis_save').hide();
};
PopintersectObject.prototype.init=function(){
	this.i18n_options();
	var self=this,thebox=this.element,so=this.options;
	self.header_footer=70;
	self.parseData();
	var aos='z-index: '+so.zindex+';';
	thebox.append('<div id="'+self.po+'" style="'+aos+'"></div>');
	var ao=thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.35);
	var txt= '<div id="'+self.pp+'" style="display: none;width:'+so.width+'px;height:'+so.height+'px;">';
	txt += '<span class="pis_window_icon"><i class="fa fa-window-maximize"></i></span>';
	txt += '<span class="pis_window_icon pis_window_hide"><i class="fa fa-window-restore"></i></span>';
	txt += '<span id="pis_close_icon"><i class="fa fa-close"></i></span>';
	txt += '<div class="pis_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
	txt += '<div id="pis_grid_area" style="height:'+(so.height-self.header_footer)+'px;"></div>';
	txt += '<div class="pis_panebtm">';
	txt += '<span style="margin-right:80px;" class="pis_button" id="pis_clear"><i class="fa fa-eraser">&nbsp;'+so.txt_clear+'</i></span>';
	txt += '<span style="margin-right:80px;display:none;" class="pis_button" id="pis_save"><i class="fa fa-save">&nbsp;'+so.txt_save+'</i></span>';
	txt += '<span class="pis_button" id="pis_close"><i class="fa fa-times-circle-o">&nbsp;'+so.txt_close+'</i></span></div>';
	txt += '</div>';
	thebox.append(txt);
	var pane = thebox.find('#'+self.pp);
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('#pis_save').off("click").on("click",function(event){
		event.stopPropagation();
		self.hideSavebtn();
		self.onSave(self.IS.getData());
	});
	thebox.find('#pis_close').off("click").on("click",function(event){
		event.stopPropagation();	self.close_pane();
	});
	thebox.find('#pis_clear').off("click").on("click",function(event){
		event.stopPropagation();
		$('body').YesnoAlert({
			yesText:self.options.t_yes,noText:self.options.t_no,
			doyes: function(id,action){
				self.IS.clearData();
				self.showSavebtn();
			}
		}).show_alertpane('',self.options.txt_clearornot,'clear');
	});
	thebox.find('.pis_window_icon').off("click").on("click",function(event){
		thebox.find('.pis_window_icon').removeClass('pis_window_hide');
		event.stopPropagation();
		$(this).addClass('pis_window_hide');
		var bk = thebox.find('#'+self.po);
		var maxW=bk.outerWidth(),maxH=bk.outerHeight();
		if($(this).find('.fa-window-maximize').length>0){
			pane.css({"margin-left":-(maxW/2)+"px","margin-top":-(maxH/2)+"px","width":maxW+"px","height":maxH+"px"});
			thebox.find('#pis_grid_area').css({"height":(maxH-self.header_footer)+"px"});
		}else{
			pane.css({"margin-left":-(modal_width/2)+"px","margin-top":-(modal_height/2)+"px","width":modal_width+"px","height":modal_height+"px"});
			thebox.find('#pis_grid_area').css({"height":(modal_height-self.header_footer)+"px"});
		}
	});
	thebox.find('#'+self.po).off("click").on("click",function(event){/*self.close_pane();*/});
	thebox.find('#pis_close_icon').off("click").on("click",function(event){self.close_pane();});
	self.setpane();
};
$.fn.Popintersect=function(options){
	var ais=new PopintersectObject(this,options);
	ais.init();
	return ais;
};