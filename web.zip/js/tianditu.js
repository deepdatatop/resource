function TiandituObject(element,options){
	this.element=element;
	this.defaults={
		token:'',
		container:'tianditu',
		longitude: 0,
		latitude: 0
	};
	this.options=$.extend({},this.defaults,options);
};
TiandituObject.prototype.setmapaddress=function(){
	var self = this;
	var thebox = this.element;
	var theaddress = thebox.find('#address');
	theaddress.text(self.options.address);
	if(self.options.longitude>0){
		self.showMap(self.options.longitude,self.options.latitude);
	}else{
        var theurl='http://api.tianditu.gov.cn/geocoder';
        $.getJSON(theurl,{"tk": self.options.token,"ds": "{\"keyWord\":\""+self.options.address+"\"}"},function(m){
          if(m.msg=='ok'){
			self.showMap(m.location.lon,m.location.lat);
          }else{ theaddress.text('地址有误！'); }
        });
	}
}
TiandituObject.prototype.showMap=function(lon,lat){
	if(lon>0){
		var zoom = 16;
		var pos = new T.LngLat(lon,lat);
		var map = new T.Map(this.options.container);
		map.centerAndZoom(pos, zoom);
		map.addOverLay(new T.Marker(pos));
 	}
};
TiandituObject.prototype.init=function(){
	var self = this;
	var thebox = this.element;
	var container=thebox.find('#'+self.options.container);
	container.before('<div id="mappop"><span id="address"></span></div>');
	container.siblings('#mappop').css({'width':container.width()+'px'});
	self.setmapaddress();
};
$.fn.Tianditu=function(options){
	var amap=new TiandituObject(this,options);
	amap.init();
	return amap;
};