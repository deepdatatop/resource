//jQuery.datetimepicker.setLocale(this.options.language_code);
var langentity='languages';
var form_recent='';
var form_data=new Object();
var static_dt=new Object();
var recent_languages=new Object();
var editor_objects=new Object();/*created at userinterface.makeEditorJS*/
var editor_types=new Object();
function merge2recent(property,o){
	for(var lid in o){
		var oo={};
		if(recent_languages.hasOwnProperty(lid)){oo=recent_languages[lid];}
		oo[property]=o[lid];
		recent_languages[lid]=oo;
	}
}
function set_recent_languages(oo){
	recent_languages={};
	for(var i=0,n=oo.length;i<n;i++){
		var o=oo[i];
		var newo={},lid='';
		for(var k in o){
			if(k=='language_id'){lid=o[k];}
			else if(k=='language_tag'||k=='_m_'){
				newo[k]=o[k];
			}
		}
		if(lid.length>0){recent_languages[lid]=newo;}
	}
}

function setEditor(base64text){
	recent_languages={};
	form_recent=base64text;
	var dt = JSON.parse($.base64.decode(base64text));
	var keys=Object.keys(dt);
	$.each(keys,function(i,key){
		var v=dt[key];
		var eo=editor_objects[key];
		switch(editor_types[key]){
			case 'static':break;
			case 'uniqueinput': eo.setValue(v);break;
			case 'input': 
			case 'text': eo.val(v);break;
			case 'fulllanguage': merge2recent(key,eo.setText(v));break;
			case 'datepicker':
			case 'timepicker': /*eo.val(v);*/break;
			case 'wenhao': eo.setValue(v);break;
			case 'selector': eo.setResult(v);break;
			case 'nselect1': eo.Select(v);break;
			case 'switch': eo.prop('checked',(v=='1'));break;
			case 'hierarchytext': eo.setText(v);break;
			case 'hierarchyset': eo.setText(v);break;
			case 'illustrator': eo.setImages(v);break;
			case 'appendix': eo.setAppendixes(v);break;
		}
	});
}
function form_operationinit(){
	clearmodify();
}
function unique(property,dt){
	var entity_id=$('#entity_id').val();
	var instance_id=parseInt($('#instance_id').val());
	var subentity=$('#subentity').val();
	var isunique=false;
	var kv=$.base64.encode(property+'='+dt);
	kv=kv.replace(new RegExp('=','g'),'-');
	$.ajaxSettings.async = false;
	$.getJSON('/instanceretrieve',{eid:entity_id,sub:subentity,kv:kv},function(m){
		if(m.Code=="100"){
			var iid=parseInt(m.ID);
			if(iid==0){
				isunique=true;
			}else{if(instance_id>0&&instance_id==iid){isunique=true;}}
			if(isunique){modified(property,dt);}
		}
	});
	$.ajaxSettings.async = true;
	return isunique;
}
function modified(property,dt){
	form_data[property]=$.trim(dt);
	setmodify();
}
function mlmodified(property,dt,def_langid,accept_languages){
	//name,	{"1":"deepest.in_en","2":"deepest.in_zh"}
	var value='';
	if(dt.hasOwnProperty(def_langid)){
		value=dt[def_langid];
	}
	form_data[property]=value;
	var languages=[];
	if(form_data.hasOwnProperty(langentity)){languages=form_data[langentity];}
	for(var id in dt){//make languages json, _m_: DEL/UPD/INS
		var o={language_id:id};
		if(accept_languages.hasOwnProperty(id)){o['language_tag']=accept_languages[id].Tag;}
		var m='INS';if(recent_languages.hasOwnProperty(id)){m='UPD';}//? recent何时更新
		var thevalue=dt[id];
		o[property]=thevalue;
		var nn=0,nm=0,ilang=-1;
		for(var i=0,n=languages.length;i<n;i++){//Merge the multifield values of the same language
			var oo=languages[i];
			if(oo.language_id==id){
				for(var k in oo){
					if(k=='language_id'||k=='language_tag'||k=='_m_'||k==property){
						/*ignore*/
					}else{
						var v=oo[k];o[k]=v;nn++;
						if(v.length==0){nm++;}
					}
				}
				ilang=i;
				break;
			}
		}
		if(thevalue.length>0){
			o['_m_']=m;
			if(ilang>=0){languages[ilang]=o;}else{languages.push(o);}		
		}else{
			if(nn==0||nn==nm){
				if(m=='UPD'){
					o={'language_id':id,'_m_':'DEL'};
					if(ilang>=0){languages[ilang]=o;}else{languages.push(o);}
				}
			}else{
				o['_m_']=m;
				if(ilang>=0){languages[ilang]=o;}else{languages.push(o);}
			}
		}
	}
	form_data[langentity]=languages;
	setmodify();
}
function multimodified(dt){
	var o=JSON.parse(dt);
	for(var property in o){
		var t=JSON.stringify(o[property]);
		var reg = /^['|"](.*)['|"]$/;
		form_data[property]=t.replace(reg, "$1");
		//var te=new CustomEvent('VALUE_CHANGE',{detail:{property:property}});
		//window.dispatchEvent(te);
	}
	setmodify();
}
function setmodify(){
	$('#undo').css('display','inline-block');
	$('#save').css('display','inline-block');
	//form toolbar button
	$('.dt_save').removeClass('dt_save').addClass('dt_save_active');
	$('.dt_refresh').removeClass('dt_refresh').addClass('dt_refresh_active');
}
function clearmodify(){
	$('#undo').css('display','none');
	$('#save').css('display','none');
	//object.go editor toolbar button
	$('.dt_save_active').removeClass('dt_save_active').addClass('dt_save');
	$('.dt_refresh_active').removeClass('dt_refresh_active').addClass('dt_refresh');
	//$('.enter_button').hide();
}
function form_undo(){
	setEditor(form_recent);
	clearmodify();
}
function form_save(){
	savedata();
	clearmodify();
}
function savedata(){
	var keys=Object.keys(editor_objects);
	$.each(keys,function(i,key){
		var o=editor_objects[key];
		switch(editor_types[key]){
			case 'hierarchytext':
			case 'hierarchyset':	o.save();break;
		}
	});
	for(let key in static_dt){
		form_data[key]=static_dt[key];
	}
	/*$('input.static').each(function(i){//static的简单化处理方案，待删除
		var me=$(this);
		form_data[me.attr('id')]=me.val();
	});*/
//alert(JSON.stringify(form_data));//******
/*
{
	"name": "di_zh",
	"languages": [{
		"language_id": "1",
		"language_tag": "English [en]",
		"description": "description_en",
		"name": "di_en",
		"_m_": "INS"
	}, {
		"language_id": "2",
		"language_tag": "Chinese 中文 [zh]",
		"description": "description_zh",
		"_m_": "INS"
	}],
	"description": "description_zh"
}*/
	var entity_id=$('#entity_id').val();
	var instance_id=$('#instance_id').val();
	var language_id=$('#language_id').val();
	var subentity=$('#subentity').val();
	var roadmap=$('#instance_rmi').val();

	$.getJSON('/saveinstance',{eid:entity_id,sub:subentity,rmi:roadmap,iid:instance_id,lid:language_id,dat:$.base64.encode(JSON.stringify(form_data))},
		function(m){
			if(m.Code=='100'){
				if(form_data.hasOwnProperty(langentity)){
					set_recent_languages(form_data[langentity]);
				}
				if(Number(instance_id)==0){
					$('#instance_id').val(m.Instance_id);
					$('.normal_row').show();
				}
				if(!$.isEmptyObject(opener)){
					if(opener.hasOwnProperty('location')){
						opener.location.reload();/*refresh grid page = opener*/
					}
				}
			}else{alert('=*='+m.Msg);}
		}
	);
}
function parseI18n(){
	if(i18n_bs64.length>0){
		form_i18n=JSON.parse($.base64.decode(i18n_bs64));
/*		case '"': rr += `\"`
		case '\\':rr += "\\\\"
		case '\r':rr += "\\r"
		case '\n':rr += "\\n"
		case '\t':rr += "\\t"*/
		for(var k in form_i18n){
			var v=form_i18n[k];
			var u=v.replace(/\"/g,'"');
			if(u!=v){form_i18n[k]=u;}
		}
	}
}
function form_static_init(){
	parseI18n();
	if(Number($('#instance_id').val())==0){$('.normal_row').hide();}
/*	$('.enter_button').hide();
	$('.enter_button').on('click',function(){savedata();});
	$('.unique_input').on('keypress',function(event){
		if(event.keyCode == "13"){
			event.preventDefault();savedata();
		}else{
			$('.enter_button').css('display','inline-block');
		}
	});*/
	$('.dt_save_active').die('click').live('click',function(){form_save();});
	$('.dt_refresh_active').die('click').live('click',function(){form_undo();});
}
/*Action(target,parameter,id); userinterface.makeEditorJS [codesetchooser]*/
function fill_templet(target,parameter,id){
	var v=parameter.replace(/\[id\]/,id);
	$('#'+target).val(v);
	modified(target,v);
}
function read_instance(target,parameter,id){
	var pp=parameter.split('|');
	if(pp.length==2){
		var kvs={iid:id,lid:$('#language_id').val()};
		var imps=pp[0].split('&');//idf=module&jin=url_export
		for(var i=0,n=imps.length;i<n;i++){
			var kv=imps[i].split('=');
			if(kv.length==2){
				kvs[kv[0]]=kv[1];
			}
		}
		var outs=pp[1].split(',');
		if(outs.length>0){
			$.getJSON('/drawinstance',kvs,function(m){
				if(m.Code=='100'){
					var o=JSON.parse(m.Json_text);
					for(var i=0,n=outs.length;i<n;i++){
						var out=outs[i];
						if(o.hasOwnProperty(out)){
							var v=o[out];
							if(v.length>0){
								$('#'+target).val(v);
								modified(target,v);
								break;
							}
						}
					}
				}else{alert(m.Msg);}
			});
		}
	}
}
/*RecentIllustration for illustration widget*/
function saveRecentIllustration(src,tag){
	var user_id=$('#user_id').val();
	var language_id=$('#language_id').val();
	var scene='illustration'; var data={scene:scene,src:src,tag:tag};
	$.getJSON('/saveinstance',{idf:'user',sub:'recent'+scene,rmi:user_id,dat:$.base64.encode(JSON.stringify(data)),lid:language_id},
		function(m){if(m.Code!='100'){alert(m.Msg);}});
}
function readRecentIllustration(){
	var user_id=$('#user_id').val();
	var recent_illustration=[];
	$.ajaxSettings.async = false;
	$.getJSON('/getdatagrid',{wgt:'RCNT',scene:'illustration',idf:'user',rmi:user_id},function(m){
		if(m.status=='success'){
			var allid=[];
			var n=m.data.length;
			for(var i=0;i<n;i++){
				var data=m.data[i];
				var mid=$.md5(data.src);
				if(allid.indexOf(mid)==-1){
					allid.push(mid);
					recent_illustration.push({src:data.src,tag:data.tag});
				}
			}
		}
	});
	$.ajaxSettings.async = true;
	return recent_illustration;
}
function saveRecentAppendix(src,tag){
	var user_id=$('#user_id').val();
	var language_id=$('#language_id').val();
	var scene='appendix'; var data={scene:scene,src:src,tag:tag};
	$.getJSON('/saveinstance',{idf:'user',sub:'recent'+scene,rmi:user_id,dat:$.base64.encode(JSON.stringify(data)),lid:language_id},
		function(m){if(m.Code!='100'){alert(m.Msg);}});
}
function readRecentAppendix(){
	var user_id=$('#user_id').val();
	var recent_appendix=[];
	$.ajaxSettings.async = false;
	$.getJSON('/getdatagrid',{wgt:'RCNT',scene:'appendix',idf:'user',rmi:user_id},function(m){
		if(m.status=='success'){
			var allid=[];
			var n=m.data.length;
			for(var i=0;i<n;i++){
				var data=m.data[i];
				var mid=$.md5(data.src);
				if(allid.indexOf(mid)==-1){
					allid.push(mid);
					recent_appendix.push({src:data.src,tag:data.tag});
				}
			}
		}
	});
	$.ajaxSettings.async = true;
	return recent_appendix;
}