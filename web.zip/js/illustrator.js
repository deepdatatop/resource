function modifyillutag(dom,src){
	var self=$(dom);
	var mid=self.attr('mid');
	var text=self.text();
	$('body').SimpleInputDialog({
		//okText:'{{.t_ok}}',
		//cancelText:'{{.t_cancel}}',
		//hintText:'{{.t_inputemail}}',
		doOK:function(text,id){
			var te = new CustomEvent('illu_event',{ 
 				detail:{status:'modified',mid:id,src:src,tag:text}
			});
			window.dispatchEvent(te);
			return true;
		}
	}).textinput(text.trim(),mid);		
}
function removeillu(dom,tag){
	var self=$(dom);
	var mid=self.attr('mid');
	$('body').YesnoAlert({
		//yesText:obj.options.txt_yes,noText:obj.options.txt_no,
		doyes: function(id,action){
			var te=new CustomEvent('illu_event',{detail:{status:'removed',mid:id}});
			window.dispatchEvent(te);					
		}
	}).show_alertpane(mid,'Remove this picture'+'['+tag+']?','remove');
}
	
function IllustratorObject(element,options){
		this.outerID='';
		this.element=element;
		var defaults={
			name:'illustrations',
			i18n:{},
			token:'',
			focus_tab:'history',/*history,link,upload*/
			init_screen: false,
			screen_columns: 1,
			max_columns: 1,
			image_capacity: 16,
			imagelist_scene:'',/*getdatalist .ui scene*/
			owner_identifier:'',
			owner_subentity:'',
			layout_property:'piclayout',
			roadmapids:'0',
			showcase_width:240,
			supportWechat:false,
			exceedcontainerlimit: 'image quantity exceed limit:',
			urlduplicated: 'image URL duplicated!',
			historyStr: 'History',
			linkStr: 'PicURL',
			linkplaceholderStr: '↸ Input picture URL and press enter key to submit',
			localStr: 'Local',
			wechatStr: 'Scan',
			uploadStr: 'Upload file:',
			dragDropStr: '<span>Drag & Drop Files...</span>',
			multiDragErrorStr: 'Multiple File Drag & Drop is not allowed.',
			extErrorStr: 'is not allowed. Allowed extensions: ',
			duplicateErrorStr: 'is not allowed. File already exists.',
			sizeErrorStr: 'is not allowed. Allowed Max size: ',
			uploadErrorStr: 'Upload is not allowed',
			maxFileCountErrorStr: ' is not allowed. Maximum allowed files are:',
			txt_columns: 'cols per row:',
			txt_halign: 'horizontal align:',
			txt_valign: 'vertical align:',
			txt_tag: 'tag',
			txt_src: 'source',
			txt_ext: 'extension',
			txt_operation: 'operation',
			txt_remove: 'remove',
			txt_yes: 'Yes',
			txt_no: 'No',
			txt_removeornot: 'Remove',
			txt_emptylist: 'Empty list?',
			txt_srcduplicated: 'Duplicate image source, updated.',
			saveRecent:function(src,tag){},
			readRecent:function(){return [];},
			screen:{}/*the output windows for image list render*/
		};
		this.options=$.extend({},defaults,options);
		this.cellalign='center';
		this.cellvalign='top';
		this.cell_align={};
		this.cell_valign={};
		this.column_spinner={};
		this.slider={};
		this.fileuploader={};
		this.original_images=new Array();
		this.images=new Array();/*[{"src":"/img/ok.png","tag":""}]*/
		this.wechatConnection={};
};
	IllustratorObject.prototype.appendTR=function(table){
		var n=this.options.screen_columns;
		if(n==0){n=1;}
		var tr='<tr>',width=100;
		var avg=parseInt(width/n);
		for(var i=0;i<n;i++){
			var colwidth=avg; if(i==n-1){colwidth=width-(n-1)*avg;}
			tr+='<td class="blank" style="text-align:'+this.cellalign+';vertical-align:'+this.cellvalign+';width:'+colwidth+'%"></td>';		
		}
		tr+='</tr>';
		table.append(tr);	
	}
	IllustratorObject.prototype.extractFilename=function(src){
		var filename=src;
		var ss=src.split('/');
		var n=ss.length;
		if(n>0){	filename=ss[n-1];}
		return filename;
	};
	IllustratorObject.prototype.initGridblockText=function(){
		return '<div class="ht_gridblock"><table width="100%"></table></div>';
	};
	IllustratorObject.prototype.addScreenImage=function(tag,src){//match with entity.go childBlock function
		var txt=tag;
		if(txt.length==0){txt=this.extractFilename(src)}
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var obj=this;
			var id=$.md5(src);
			if(box.find('#'+id).length==0){
				var table=box.find('table');
				if(table.length==0){
					box.append(this.initGridblockText());table=box.find('table');
				}
				if(table.find('td.blank').length==0){obj.appendTR(table);}
				var td=table.find('td.blank:first');
				if(td.length==1){
					td.append('<img style="max-width:100%" id="'+id+'" src="'+src+'">');
					td.removeClass('blank').addClass('used');
				}
			}
		}
	};
	IllustratorObject.prototype.rmvScreenImage=function(id){
		var flag=false;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var img=box.find('#'+id);
			if(img.length==1){
				flag=true;
				var td=img.parent();
				img.remove();td.removeClass('used').addClass('blank');td.attr('style','');
				var nextids=[];
				td.nextAll('td.used').each(function(){nextids.push($(this).find('img').attr('id'));});
				var tr=td.parent();
				tr.nextAll().find('img').each(function(){nextids.push($(this).attr('id'));});
				var n=nextids.length;
				for(var i=0;i<n;i++){
					var nxt = box.find('#'+nextids[i]);
					if(nxt.length>0){
						var ntd = nxt.parent();
						nxt.appendTo(td);
						td.removeClass('blank').addClass('used');td.attr('style',ntd.attr('style'));
						ntd.removeClass('used').addClass('blank');ntd.attr('style','');
						td=ntd;
					}
				}
				tr.nextAll().each(function(){
					var atr=$(this);if(atr.find('.used').length==0){atr.remove();}
				});
				if(tr.find('.used').length==0){tr.remove();}
				if(box.find('img').length==0){box.find('i.ti').show();}
			}
		}
		return flag;
	};
	IllustratorObject.prototype.moveupNScreenImage=function(i_s,i_e){
		var flag=false;
		var obj=this;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var tds=box.find('td.used');
			if(i_e<tds.length){
				box.append('<div id="space" style="display:none"></div>');
				var space=box.find('#space');
				var td=box.find('#'+$.md5(obj.images[i_e].src)).parent();
				td.children().appendTo(space); var spacestyle=td.attr('style');
				for(var i=i_e;i>i_s;i--){
					var tdpre=box.find('#'+$.md5(obj.images[i-1].src)).parent();
					tdpre.children().appendTo(td);
					td.attr('style',tdpre.attr('style'));
					td=tdpre;
				}
				space.children().appendTo(td);
				td.attr('style',spacestyle);
				space.remove();
				flag=true;
			}
		}
		return flag;
	};
	IllustratorObject.prototype.movedownNScreenImage=function(i_s,i_e){
		var flag=false;
		var obj=this;
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			var tds=box.find('td.used');
			if(i_e<tds.length){
				box.append('<div id="space" style="display:none"></div>');
				var space=box.find('#space');
				var td=box.find('#'+$.md5(obj.images[i_s].src)).parent();
				td.children().appendTo(space); var spacestyle=td.attr('style');
				for(var i=i_s;i<i_e;i++){
					var tdnxt=box.find('#'+$.md5(obj.images[i+1].src)).parent();
					tdnxt.children().appendTo(td);
					td.attr('style',tdnxt.attr('style'));
					td=tdnxt;
				}
				space.children().appendTo(td);
				td.attr('style',spacestyle);
				space.remove();
				flag=true;
			}
		}
		return flag;
	};
	IllustratorObject.prototype.makeGM_data=function(){
		var obj=this;
		var gmData = {totals: obj.images.length};
		var data=[];//{tag:'123',src:'/img/abc.png',extension:'.png'}
		obj.images.forEach(function(img){
			data.push({tag:img.tag,src:img.src,extension:obj.fileExt(img.src)});
		});
		gmData['data']=data;
		return gmData;	
	};
	IllustratorObject.prototype.getIndexbyid=function(id){
		var idx=-1;
		for(var i=0;i<this.images.length;i++){
			if($.md5(this.images[i].src)===id){idx=i;break;}
		}
		return idx;
	};
	IllustratorObject.prototype.addNew=function(){
		var obj=this;
		$('body').Picpane({
			image_capacity: obj.options.image_capacity,
			exceedcontainerlimit: obj.options.exceedcontainerlimit,
			urlduplicated: obj.options.urlduplicated,
			historyStr: obj.options.historyStr,
			linkStr: obj.options.linkStr,
			linkplaceholderStr: obj.options.linkplaceholderStr,
			localStr: obj.options.localStr,
			wechatStr: obj.options.wechatStr,
			addedStr: obj.options.addedStr,
			uploadStr: obj.options.uploadStr,
			dragDropStr: obj.options.dragDropStr,
			multiDragErrorStr: obj.options.multiDragErrorStr,
			extErrorStr: obj.options.extErrorStr,
			duplicateErrorStr: obj.options.duplicateErrorStr,
			sizeErrorStr: obj.options.sizeErrorStr,
			uploadErrorStr: obj.options.uploadErrorStr,
			maxFileCountErrorStr: obj.options.maxFileCountErrorStr,
			token: obj.options.token,
			onAdded: function(tag,src){
				if(obj.addImage(tag,src).length==0){obj.refresh();}
			},
			readRecent: obj.options.readRecent
		});
	};
	IllustratorObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){
				o[k]=o.i18n[k];
			}
		}
	};
	IllustratorObject.prototype.init=function(){
		this.i18n_options();
		var obj=this;
		var self=this.element;
		var gridname='i_'+obj.options.name;
		window.addEventListener('illu_event', function(event){
			var ed=event.detail;
			switch(ed.status){
				case 'modified':
					var idx=obj.getIndexbyid(ed.mid);
					if(idx>=0){
						var o={src:ed.src,tag:ed.tag};
						GridManager.updateRowData(gridname,'src',o);
						obj.images[idx].tag=ed.tag;
						obj.modified();
					}
					break;
				case 'removed':
					var idx=obj.getIndexbyid(ed.mid);
					if(idx>=0){
						obj.rmvScreenImage(ed.mid);
						obj.images.splice(idx,1);
						obj.modified();
						obj.refresh();
					}
					break;
			}
		});
		self.empty();
		if(obj.options.screen_columns>obj.options.image_capacity){
			obj.options.screen_columns=obj.options.image_capacity;
		}
		var ss='<div style="width:100%;height:36px;padding-top:2px;overflow:hidden;"><span id="illu" style="font-size:16px;display:inline-block"><i class="fa fa-picture-o"></i></span>';
		
		if(obj.options.max_columns>1){
			ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_columns+'</span><span id="column_number" style="display:inline-block"></span>';
		}
		if(obj.options.image_capacity>1){
			ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_halign+'</span><span id="cellalign" style="display:inline-block"></span>';
			if(obj.options.max_columns>1){
				ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_valign+'</span><span id="cellvalign" style="display:inline-block"></span>';
			}
		}
		ss+='<div style="display:inline-block;position:absolute;right:0px;width:64px;">';
		ss+='<i class="fa fa-2x fa-plus-square-o illu_add"></i>&nbsp;';
		if(obj.options.image_capacity>1){
			ss+='<i class="fa fa-2x fa-trash-o illu_empty illu_hide"></i>';
		}else{
			ss+='<i class="fa fa-2x fa-times-circle-o illu_remove illu_hide"></i>';
		}
		ss+='</div></div>';
		if(obj.options.image_capacity>1){
			ss+='<table class="illustration_table" style="width:100%;height:100px;"></table>';
		}
		self.append(ss);
		self.find('.illu_remove').on('click',function(){obj.remove();});
		self.find('.illu_empty').on('click',function(){obj.empty();});
		self.find('.illu_add').on('click',function(){obj.addNew();});
		if(obj.options.max_columns>1){
			obj.column_spinner=self.find('#column_number').Spinner({width:60,value:obj.options.screen_columns,max:obj.options.max_columns,
				onChange: function(val){
					obj.options.screen_columns=val;
					obj.resetScreen();
				}
			});
		}
		if(obj.options.image_capacity>1){
			obj.cell_align=self.find('#cellalign').StateButton({
				onChange: function(val) {
					obj.cellalign=val;
					obj.modified();
					var box=obj.options.screen;
					if(JSON.stringify(box)!='{}'){box.find('td').css('text-align',val);}
				}
			}).Select(obj.cellalign);
			if(obj.options.max_columns>1){
				obj.cell_valign=self.find('#cellvalign').StateButton({
					item_option:[
						{value:'top',label:'<i class="fa fa-step-forward fa-rotate-270"></i>'},
						{value:'middle',label:'<i class="fa fa-columns fa-rotate-90"></i>'},
						{value:'bottom',label:'<i class="fa fa-step-forward fa-rotate-90"></i>'}
		        		],
					onChange: function(val) {
						obj.options.cell_valign=val;
						obj.modified();
						var box=obj.options.screen;
						if(JSON.stringify(box)!='{}'){box.find('td').css('vertical-align',val);}				
					}
				}).Select(obj.options.cell_valign);
			}
			self.find('.illustration_table').GM({
				gridManagerName: gridname,
				height: '100% - 36px',
				supportCheckbox: false,
				ajaxData: {totals:0,data:[]},
				columnData: [
					{key: 'tag',text: obj.options.txt_tag,
						template: function(tag, row){
							var ss='<span>';
							ss+='<i mid="'+$.md5(row.src)+'" class="illu_modifytag fa fa-edit"';
							ss+=' onclick="modifyillutag(this,\''+row.src+'\')"> '+tag+'</i>';
							ss+='</span>';
							return ss;
						}
					},
					{key: 'src',text: obj.options.txt_src},
					{key: 'extension',text: obj.options.txt_ext,width: '80px'},
					{key: 'operation',text: obj.options.txt_operation,
						template: function(operation, row){
							var ss='<span>';
							ss+='<i mid="'+$.md5(row.src)+'"';
							ss+=' onclick="removeillu(this,\''+row.tag+'\')"';
							ss+=' class="rmvillu fa fa-minus-square-o"> '+obj.options.txt_remove+'</i>';
							ss+='</span>';
							return ss;
						},align: 'center',width: '80px'
					}],
				ajaxSuccess: function(data){},
				supportMoveRow: true,
				moveRowConfig: {
					handler: (list, tableData) => {
						var n=obj.images.length;
						if(n==tableData.length){
							var mapSrcIndex={};
							var old=[];
							var i_s=-1,i_e=-1;
							for(var i=0;i<n;i++){
								var img=obj.images[i];
								old.push(img);
								mapSrcIndex[img.src]=i;
								if(tableData[i].src!==img.src){
									if(i_s==-1){i_s=i;}
									i_e=i;
								}
							}
							if(i_e>i_s){
								var id=$.md5(obj.images[i_e].src);
								var ins='head';
								if(obj.images[i_s+1].src==tableData[i_s].src){
									ins='end'; id=$.md5(obj.images[i_s].src);
								}
								/*update screen td ordinal position*/
								var flag=false;
								if(ins=='head'){
									flag=obj.moveupNScreenImage(i_s,i_e);
								}else{
									flag=obj.movedownNScreenImage(i_s,i_e);
								}
								if(flag){
									obj.images.length=0;
									for(var i=0;i<n;i++){
										var k=mapSrcIndex[tableData[i].src];
										obj.images.push(old[k]);
									}
									obj.modified();
								}
							}
							old.length=0;mapSrcIndex={};
						}
					}
				}
			});
		}
    };
	IllustratorObject.prototype.resize=function(){
	};
	IllustratorObject.prototype.empty=function(){
		var obj=this;
		if(obj.images.length>0){
			$('body').YesnoAlert({
				yesText:obj.options.txt_yes,noText:obj.options.txt_no,
				doyes: function(id,action){
					var box=obj.options.screen;
					if(JSON.stringify(box)!='{}'){box.find('table').empty();}
					obj.images=[];
					obj.modified();
					obj.refresh();
				}
			}).show_alertpane('',obj.options.txt_emptylist,'empty');
		}		
	};
	IllustratorObject.prototype.remove=function(){
		var obj=this;
		if(obj.images.length>0){
			$('body').YesnoAlert({
				yesText:obj.options.txt_yes,noText:obj.options.txt_no,
				doyes: function(id,action){
					var box=obj.options.screen;
					if(JSON.stringify(box)!='{}'){box.find('table').empty();}
					obj.images=[];
					obj.modified();
					obj.refresh();
				}
			}).show_alertpane('',obj.options.txt_removeornot+'?','remove');
		}		
	};
	IllustratorObject.prototype.setScreen=function(div_item){
		this.options.screen=div_item;	
		var table=div_item.find('table');
		if(table.length==0){
			div_item.append(this.initGridblockText());
		}/*fault-tolerant*/
	};
	IllustratorObject.prototype.show=function(){
		this.element.show();		
	};
	IllustratorObject.prototype.hide=function(){
		this.element.hide();		
	};
	IllustratorObject.prototype.fileExt=function(filename){//use for imageuploader
		var extension = '';
		var ss = filename.split('.');
		if(ss.length>1){
			extension = '.'+ss[ss.length - 1];
		}
		return extension;	
	};
	IllustratorObject.prototype.setOuterID=function(id){
		this.outerID = id;
	};
	IllustratorObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	IllustratorObject.prototype.parseTextImages=function(txt){
		var obj=this;
		obj.images=[];
		if(txt.length>0){
			var columns=1;
			/*format A: {"columns":1,"align":"center","valign":"top","images":[{"src":"/img/ok.png","tag":""}]}*/
			/*format B: /img/ok.png,/img/do.png*/
			/*format C: base64(),base64()*/
			if(obj.isObjectText(txt)){
				var dt=JSON.parse(txt);
				obj.cellalign=dt.align;
				obj.cellvalign=dt.valign;
				if(dt.hasOwnProperty('columns')){if(dt.columns>0){columns=dt.columns;}}
				if(dt.hasOwnProperty('images')){
					for(var i=0;i<dt.images.length;i++){
						obj.images.push(dt.images[i]);
					}
				}
			}else{
				var dtdt=txt.split(',');
				var n=dtdt.length;
				for(var i=0;i<n;i++){
					var dt=dtdt[i];
					if(dt.length>0){
						var src=dt;
						if(dt.indexOf('.')<0){/*base64 encode*/
							src=$.base64.decode(dt)
						}
						if(src.length>0){
							obj.images.push({src:src});
						}
					}
				}
			}
			obj.options.screen_columns=columns;
		}
	};
	IllustratorObject.prototype.refresh=function(){
		var obj=this;
		var self=this.element;
		//var box=obj.options.screen;
		//if(JSON.stringify(box)!='{}'){
		//	if(obj.images.length==0){box.find('p.editorflag').show();	}
		//}
		if(obj.options.max_columns>1){
			obj.column_spinner.setValue(obj.options.screen_columns);
		}
		if(obj.options.image_capacity>1){
			obj.cell_align.Select(obj.cellalign);
			if(obj.options.max_columns>1){
				obj.cell_valign.Select(obj.cellvalign);
			}
			setTimeout(function(){
				GridManager.setAjaxData('i_'+obj.options.name,obj.makeGM_data());
			},200);
		}
	};
	IllustratorObject.prototype.clone=function(a){
		var b={};
		for(var k in a){b[k]=a[k];}
		return b;
	};
	IllustratorObject.prototype.setImages=function(val){
		var obj=this;
		obj.parseTextImages(val);
		if(obj.options.imagelist_scene.length>0){
			$.ajaxSettings.async = false;
			var param={idf:obj.options.owner_identifier,scene:obj.options.imagelist_scene,rmi:obj.options.roadmapids};
			$.getJSON('/getdatalist',param,function(m){
				if(m.status=='success'){
					obj.options.owner_subentity=m.subentity;
					obj.original_images=[];
					if(m.totals>0){
						obj.images=m.data;
						for(var i=0,n=obj.images.length;i<n;i++){
							var image=obj.clone(obj.images[i]);
							obj.original_images.push(image);
						}
					}else{obj.images=[];}
				}
			});
			$.ajaxSettings.async = true;
		}
		obj.refresh();
		if(obj.options.init_screen){
			setTimeout(function(){
				var screen=obj.options.screen;
				if(JSON.stringify(screen)!='{}'){
					var n=obj.images.length;
					for(var i=0;i<n;i++){
						var o=obj.images[i];
						var tag='',src='';
						if(o.hasOwnProperty('tag')){tag=o['tag'];}
						if(o.hasOwnProperty('src')){src=o['src'];}
						obj.addScreenImage(tag,src);
					}
				}		
			},100);			
		}
		this.showEmptyBtn();
		return this;
	};
	IllustratorObject.prototype.getLayout=function(){
		var dt={columns:this.options.screen_columns,align:this.cellalign,valign:this.cellvalign};
		return JSON.stringify(dt);
	};
	IllustratorObject.prototype.getImages=function(){
		var dt={columns:this.options.screen_columns,align:this.cellalign,valign:this.cellvalign,images:this.images};
		return JSON.stringify(dt);
	};
	IllustratorObject.prototype.addImage=function(tag,src){
		var txt=tag;
		if(txt.length==0){txt=this.extractFilename(src)}
		var msg='';
		if(src.length>0){
			var n=this.images.length;
			if(n>0){
				if(this.options.image_capacity>1){
					for(var i=0;i<n;i++){
						var img=this.images[i];
						if(img.src===src){
							if(img.tag!==txt){
								img.tag=txt;
								this.images[i]=img;
								this.modified();
							}
							msg=this.options.txt_srcduplicated;
							break;
						}
					}
				}else{
					var box=this.options.screen;
					if(JSON.stringify(box)!='{}'){box.find('table').empty();}
					this.images=[];			
				}
			}
			if(msg.length==0){
				this.images.push({tag:txt,src:src,extension:this.fileExt(src)});
				this.addScreenImage(tag,src);
				this.options.saveRecent(src,tag);
				this.modified();
			}
		}
		return msg;
	};
	IllustratorObject.prototype.modified=function(){
		var vv='';
		if(this.options.imagelist_scene.length>0){
			var o={},dt=[];
			var o_id2i={};
			for(var i=0,n=this.original_images.length;i<n;i++){
				var oimg=this.original_images[i];
				var exist=false;
				for(var j=0,m=this.images.length;j<m;j++){
					var img=this.images[j];
					if(img.hasOwnProperty('id')){
						if(oimg.id==img.id){	exist=true;break;}
					}
				}
				if(exist){o_id2i[oimg.id]=i;}else{dt.push({'id':oimg.id,'_m_':'DEL'});}
			}
			for(var i=0,n=this.images.length;i<n;i++){
				var image=this.images[i];image['ordinalposition']=i+1;
				if(image.hasOwnProperty('id')){
					if(o_id2i.hasOwnProperty(image.id)){
						var o_image=this.original_images[o_id2i[image.id]];
						var updated=false,u_image={};
						u_image['id']=image.id;
						for(var k in image){
							if(o_image.hasOwnProperty(k)){
								if(image[k]!=o_image[k]){
									updated=true;
									u_image[k]=image[k];
								}
							}else{
								updated=true;
								u_image[k]=image[k];
							}
						}
						if(updated){dt.push(u_image);}
					}
				}else{dt.push(image);}
			}
			o[this.options.layout_property]=this.getLayout();
			o[this.options.owner_subentity]=dt;
			vv=JSON.stringify(o);
		}else{
			vv=this.getImages();
		}
		this.showEmptyBtn();
		this.options.onChange(this.outerID,vv);
	};
	IllustratorObject.prototype.showEmptyBtn=function(){
		var ss='remove';
		if(this.options.image_capacity>1){ss='empty';}
		if(this.images.length>0){
			$('.illu_'+ss).removeClass('illu_hide');
		}else{
			$('.illu_'+ss).addClass('illu_hide');
		}
	};
	IllustratorObject.prototype.resetScreen=function(){
		var box=this.options.screen;
		if(JSON.stringify(box)!='{}'){
			box.empty();
			var n=this.images.length;
			for(var i=0;i<n;i++){
				var o=this.images[i];
				var tag='',src='';
				if(o.hasOwnProperty('tag')){tag=o['tag'];}
				if(o.hasOwnProperty('src')){src=o['src'];}
				this.addScreenImage(tag,src);
			}
			this.modified();
		}	
	};
/*	IllustratorObject.prototype.addImageMask=function(itm){
		var obj=this; var self=this.element;
		var p=itm.parent();
		p.append('<div class="image_mask"><i class="fa fa-times-circle fa-3x image_remove"></i></div>');
		var mask=p.find('.image_mask');
		mask.width(itm.width()+1).height(itm.height()+1);
		var pos=itm.position();
		mask.css('left',pos.left).css('top',pos.top).show();	
		mask.find('.image_remove').on('click',function(event){
			var id=itm.attr('id');
			mask.remove();
			itm.remove();
			self.find('#i_toolbar').show();//change to show add button
			var idx=-1;
			for(var i=0;i<obj.images.length;i++){
				var o=obj.images[i];
				if($.md5(o.src)==id){idx=i;break;	}
			}
			if(idx>=0){obj.images.splice(idx,1);}
			obj.options.onChange(obj.outerID,obj.getImages());
		});		
	};*/
    $.fn.Illustrator=function(options){
		var anillustrator=new IllustratorObject(this,options);
		anillustrator.init();
		return anillustrator;
    };
