function PoppicObject(element,options){
	this.element=element;
	this.defaults={
		width:600,
		height:400,
		zindex:20000
	};
	this.margin=50;
	this.popoverlay='pop_overlay';
	this.options=$.extend({},this.defaults,options);
};
PoppicObject.prototype.closePop=function(){
	this.element.find('#'+this.popoverlay).remove();
	this.element.find('#pop_pane').remove();
};
PoppicObject.prototype.showPop=function(tag,src){
	var self=this;
	var thebox=this.element;
	var aos='cursor:pointer;position:fixed;z-index:'+self.options.zindex+';top:0px;left:0px;height:100%;width:100%;background:#000;display:none;';
	var txt='<div id="'+self.popoverlay+'" style="'+aos+'">';
	txt+='<span class="poppic_close_icon" style="z-index:'+(self.options.zindex+2)+'"><i class="fa fa-times-circle fa-2x"></i></span>';
	txt+='</div>';
	thebox.append(txt);
	var po=thebox.find('#'+self.popoverlay);

	var outerWidth=po.outerWidth()-self.margin,outerHeight=po.outerHeight()-self.margin;
	var ao=po.css({"display":"block",opacity:0}).fadeTo(200,0.5);
	txt='<div id="pop_pane" style="display: none;width:'+outerWidth+'px;height:'+outerHeight+'px;';
	txt+='background:#FFFFFF;border:#dadada solid 1px;z-index:'+(self.options.zindex+1)+'">';
	txt+='</div>';
	thebox.append(txt);
	var pane = thebox.find('#pop_pane');
	pane.iviewer({src: src,mousewheel: false});
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	pane.on("mousewheel",function(e){return false;});
	po.off("click").on("click",function(event){self.closePop();});
	thebox.find('.poppic_close_icon').off("click").on("click",function(event){self.closePop();});
};
$.fn.Poppic=function(options){
	var apic=new PoppicObject(this,options);
	return apic;
};