	function ThethirdedObject(element,options){
		this.element=element;
		var defaults={
			lr_splitter_width:5,
			tb_splitter_height:5,
			min_left_width:300,
			min_top_height:140,
			breadcrumb:'',
			afterInit: function(){}
		};
		this.options=$.extend({},defaults,options);
    };
	ThethirdedObject.prototype.addLeftblock=function(){
		
	};
	ThethirdedObject.prototype.addTopblock=function(){
		
	};
	ThethirdedObject.prototype.addBottomblock=function(){
		
	};
	ThethirdedObject.prototype.init=function(){
		var obj=this;
		obj.ex_init();
		var self=this.element;
		self.empty();
		var 	ss = '<div id="toolbar">'+obj.options.breadcrumb+'</div>';
		ss += '<div id="left_block"></div>';
		ss += '<div id="lr_splitter"></div>';
		ss += '<div id="right_block">';
		ss += '<div id="top_block"></div>';
		ss += '<div id="tb_splitter"></div>';
		ss += '<div id="bottom_block"></div>';
		ss += '</div></div>';
		self.append(ss);
		obj.addLeftblock();
		obj.addTopblock();
		obj.addBottomblock();
		obj.windowResize();
		if(obj.options.lr_splitter_width>0){obj.bindLRSplitter(document.getElementById('lr_splitter'));}
		if(obj.options.tb_splitter_height>0){obj.bindTBSplitter(document.getElementById('tb_splitter'));}
		obj.bindResizeEvent();
		obj.options.afterInit();
    };
	ThethirdedObject.prototype.ex_init=function(){/*virtual function*/};
	ThethirdedObject.prototype.windowResize=function(){
		var self=this.element;
		var toolbar=self.find('#toolbar');
		var left_block=self.find('#left_block');
		var lr_splitter=self.find('#lr_splitter');
		var right_block=self.find('#right_block');
		var top_block=self.find('#top_block');
		var tb_splitter=self.find('#tb_splitter');
		var bottom_block=self.find('#bottom_block');
		var worktopheight=self.height();
		var dy=worktopheight-toolbar.height();
		if(this.options.lr_splitter_width<=0){lr_splitter.hide();}
		if(this.options.tb_splitter_height<=0){tb_splitter.hide();	}
		left_block.css("width",this.options.min_left_width+"px");
		left_block.css("height",dy+"px");
		right_block.css("height",dy+"px");
		top_block.css("height",this.options.min_top_height+"px");
		bottom_block.css("height",(dy-this.options.min_top_height-this.options.tb_splitter_height-1)+"px");
	};
	ThethirdedObject.prototype.bindResizeEvent=function(){
		var obj=this;
		$(window).resize(function() {
			obj.windowResize();
		});
	};
	ThethirdedObject.prototype.bindLRSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var x=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var left_block=self.find('#left_block');
			x=e.clientX-splitter.offsetWidth-left_block.width();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){mouseMove(ev || event);};
				splitter.onmouseup = mouseUp;
			}else{
				left_block.css('cursor','col-resize');
				self.find('#right_block').css('cursor','col-resize');
				$(document).bind("mousemove", mouseMove).bind("mouseup", mouseUp);
			}
		});
		function mouseMove(e){
			e.preventDefault();
			var left_block=self.find('#left_block');
			if((e.clientX/document.body.clientWidth)<0.8){
				left_block.css('width',e.clientX - x + 'px');
			}
			if(e.clientX<obj.options.lr_splitter_width){left_block.hide();}else{left_block.show();}
		}
		function mouseUp(){
			self.find('#left_block').css('cursor','default');
			self.find('#right_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", mouseMove).unbind("mouseup", mouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var left_block=self.find('#left_block');
			left_block.show();
			left_block.css('width',obj.options.min_left_width+'px');
			e.preventDefault();
		});
	};
	ThethirdedObject.prototype.bindTBSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var y=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var top_block=self.find('#top_block');
			y=e.clientY-splitter.offsetHeight-top_block.height();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){tbmouseMove(ev || event);};
				splitter.onmouseup = tbmouseUp;
			}else{
				top_block.css('cursor','row-resize');
				self.find('#bottom_block').css('cursor','row-resize');
				$(document).bind("mousemove", tbmouseMove).bind("mouseup", tbmouseUp);
			}
		});
		function tbmouseMove(e){
			e.preventDefault();
			var top_block=self.find('#top_block');
			var bottom_block=self.find('#bottom_block');
			var max_height=self.find('#right_block').height();
			var dy=e.clientY - y;
			var by=max_height-dy-obj.options.tb_splitter_height;
			if(by>=0){
				top_block.css('height',dy + 'px');
				var h=max_height-dy-obj.options.tb_splitter_height;
				bottom_block.css('height',h+'px');
			}
			if(e.clientY<obj.options.tb_splitter_height){
				top_block.hide();
				var h=max_height-obj.options.tb_splitter_height;
				bottom_block.css('height',h+'px');
			}else{top_block.show();}
		}
		function tbmouseUp(){
			self.find('#top_block').css('cursor','default');
			self.find('#bottom_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", tbmouseMove).unbind("mouseup", tbmouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var max_height=self.find('#right_block').height();
			var top_block=self.find('#top_block');
			top_block.show();
			top_block.css('height',obj.options.min_top_height+'px');
			self.find('#bottom_block').css('height',(max_height-obj.options.min_top_height-obj.options.tb_splitter_height)+'px');
			e.preventDefault();
		});
	};
    $.fn.Thethirded=function(options){
		var ltb=new ThethirdedObject(this,options);
		ltb.init();
		return ltb;
    };
	
	
/*inherit extend use.
<script type="text/javascript">
	function inheritPrototype(subObject, superObject){
		var prototype = Object.create(superObject.prototype);
		prototype.constructor = subObject;
		subObject.prototype = prototype;
	}
	function CodethirdedObject(element,options){
		ThethirdedObject.call(this,element,$.extend({},options));
    };
	inheritPrototype(CodethirdedObject,ThethirdedObject);
	CodethirdedObject.prototype.addLeftblock=function() {
		
	};
    $.fn.Codethirded=function(options){
		var ltb=new CodethirdedObject(this,options);
		ltb.init();
		return ltb;
    };
</script>*/