/*function:split string, ignore the separator within quotes.
design idea: material/splitColumn.graffle
sample: code#name#`desc#ription`	->	result: code name desc#ription
splitfield(line,separator)
if remain separator='' this function extract the separator in predefined string as ',\t;#/|' 
return object:
{
	separator: '#',
	fields: ["code","name","desc#ription"],
	error: ''
}*/
function splitfield(line,separator){
	var separators=',\t;/|';
	var fields=[],value='',sep=separator,err='';
	var state=0,i=0,n=line.length;
	while(i<n){
		var char=line.charAt(i);
		if(sep.length==0 && separators.indexOf(char)>=0){ sep=char; }
		switch(state){
			case 0:
				switch(char){
					case ' ': break;
					case '\r': break;
					case '\n': break;
					case "'": state=2; value += char; break;
					case '"': state=3; value += char; break;
					case '`': state=4; value += char; break;
					default:
						if(char==sep){fields.push(value); value='';}
						else{state=1; value += char;}
						break;						
				}
				break;
			case 1:
				if(char=='\r' || char=='\n'){}
				else if(char==sep){ fields.push(value); value=''; state=0; }
				else{ value+=char; }
				break;
			case 2:
				if(char=="'"){fields.push(value.substr(1)); value=''; state=50;}
				else if(char=="\\"){value+=char; state=10;}
				else{value+=char;}
				break;
			case 3:
				if(char=='"'){fields.push(value.substr(1)); value=''; state=50;}
				else if(char=="\\"){value+=char; state=20;}
				else{value+=char;}
				break;
			case 4:
				if(char=='`'){fields.push(value.substr(1)); value=''; state=50;}
				else if(char=="\\"){value+=char; state=30;}
				else{value+=char;}
				break;
			case 10:value+=char;if(char=="'"){state=11;}else{state=2;}
				break;
			case 11:
				if(char=="'"){fields.push(value.substr(1)); value=''; state=50;}
				else if(char==sep){fields.push(value.substr(1,value.length-2)); value=''; state=0;}
				else{value+=char; state=2;}
				break;
			case 20:value+=char;if(char=='"'){state=21;}else{state=3;}
				break;
			case 21:
				if(char=='"'){fields.push(value.substr(1)); value=''; state=50;}
				else if(char==sep){fields.push(value.substr(1,value.length-2)); value=''; state=0;}
				else{value+=char; state=3;}
				break;
			case 30:value+=char;if(char=='`'){state=31;}else{state=4;}
				break;
			case 31:
				if(char=='`'){fields.push(value.substr(1)); value=''; state=50;}
				else if(char==sep){fields.push(value.substr(1,value.length-2)); value=''; state=0;}
				else{value+=char; state=4;}
				break;
			case 50:
				if(char==' ' || char=='\r' || char=='\n'){}
				else if(char==sep){state=0;}else{
					state=99; i=n;
					err = 'quote right adhesive character:'+char;
				}
				break;
		}
		i ++;
	}
	if(state==2 || state==10 || state==3 || state==20 || state==4 || state==30){
		err='unpaired quotation marks:'+value;
	}else if(state==11 || state==21 || state==31){
		value=value.substr(1,value.length-2);
	}
	if(value.length>0){ fields.push(value); }
	else if(state == 0){ fields.push(''); }
	return {separator:sep,fields:fields,error:err};
}