	function PopformObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			caption:'',
			instance_name:'',
			width:840,
			height:620,
			zindex:200,
			txt_savenclose: 'Save & Close',
			txt_close: 'Close',
			eid: '',
			scene: 'normal',
			rmi: '0',
			widget_dependency: '',//		/css/formarea.css,/js/formarea.js
			onClose: function(){},
			afterSave: function(instance_id){}
		};
		this.id='';
		this.instance_id=0;
		this.po='popform_overlay';
		this.pp='popform_pane';
		this.default_languageid='2';
		this.accept_languageids='';
		this.accept_languages={};
		this.formarea={};
		this.options=$.extend({},this.defaults,options);
    };
	PopformObject.prototype.close_pane=function(){
		this.element.find('#pf_editor_area').remove();
		this.element.find('#'+this.pp).remove();
		this.element.find('#'+this.po).remove();
		this.formarea={};
		this.options.onClose();
	};
	PopformObject.prototype.include_callback=function(){//call at include.js
		var self=this,thebox=this.element,so=this.options;
		self.formarea=thebox.find('#pf_editor_area').Formarea({
			showtoolbar:false,
			language_id:self.default_languageid,
			accept_languageids:self.accept_languageids,
			accept_languages:self.accept_languages,
			entity_id:so.eid,scene:so.scene,
			instance_id:self.instance_id,roadmapids:so.rmi,
			onChange: function(instance_id){
				thebox.find('#pf_savenclose').show();
			},
			afterSave: function(instance_id){
				thebox.find('#pf_savenclose').hide();
				so.afterSave(instance_id);
			},
			setCaption: function(caption){
				thebox.find('#thetitle').text(caption+'#'+so.instance_name);
			}
		});
	};
	PopformObject.prototype.setpane=function(instance_id){
		var self=this;
		this.instance_id=instance_id;
		var wd='';
		if(this.options.widget_dependency.length>0){
			wd=$.base64.decode(this.options.widget_dependency);
		}else{
			$.ajaxSettings.async = false;
			$.getJSON('/readformdependency',{eid:this.options.eid,scene:this.options.scene},function(m){
				if(m.Code=='100'){
					self.default_languageid=m.Default_languageid;
					self.accept_languageids=m.Accept_languageids;
					if(m.Accept_languages.length>0){self.accept_languages=JSON.parse(m.Accept_languages);}
					if(m.Dependency_bs64.length>0){wd=$.base64.decode(m.Dependency_bs64);}
				}else{
					alert(m.Msg);
				}
			});
			$.ajaxSettings.async = true;
		}
		include_queue(this,wd);	// ➸ include_callback
		//pqgrid-3.5.0.min.js is so big, it will be loaded after pq-localize-3.5.0-en.js
		//so, merge pqgrid-3.5.0.min.js+pq-localize-3.5.0-en.js > pqgrid-3.5.0-en.min.js
	};
	PopformObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	PopformObject.prototype.setInstance=function(instance_id){
		this.i18n_options();
		var header_footer=70;//max-restore
		var self=this,so=this.options;
		var thebox=this.element;
		var aos='z-index: '+so.zindex+';';
		thebox.append('<div id="'+self.po+'" style="'+aos+'"><input type="hidden" id="instance_id" value="'+instance_id+'"></div>');
		thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.35);
		var txt= '<div id="'+self.pp+'" style="display: none;width:'+so.width+'px;height:'+so.height+'px;">';
		txt += '<span class="pf_window_icon"><i class="fa fa-window-maximize"></i></span>';
		txt += '<span class="pf_window_icon pf_window_hide"><i class="fa fa-window-restore"></i></span>';
		txt += '<span id="pf_close_icon"><i class="fa fa-close"></i></span>';
		txt += '<div class="pf_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
		txt += '<div id="pf_scroll_box" style="height:'+(so.height-header_footer)+'px;">';
		txt += '<div id="pf_editor_area"></div>';
		txt += '</div>';
		txt += '<div class="pf_panebtm">';
		txt += '<span style="margin-right:40px;display:none;" class="pf_button" id="pf_savenclose"><i class="fa fa-save">&nbsp;'+so.txt_savenclose+'</i></span>';
		txt += '<span class="pf_button" id="pf_close"><i class="fa fa-times-circle-o">&nbsp;'+so.txt_close+'</i></span></div>';
		txt += '</div>';
		thebox.append(txt);
		var pane = thebox.find('#'+self.pp);
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#pf_savenclose').off("click").on("click",function(event){
			event.stopPropagation();
			self.formarea.form_save();
			self.close_pane();
		});
		//max-restore
		thebox.find('.pf_window_icon').off("click").on("click",function(event){
			thebox.find('.pf_window_icon').removeClass('pf_window_hide');
			event.stopPropagation();
			$(this).addClass('pf_window_hide');
			var bk = thebox.find('#'+self.po);
			var maxW=bk.outerWidth(),maxH=bk.outerHeight();
			if($(this).find('.fa-window-maximize').length>0){
				pane.css({"margin-left":-(maxW/2)+"px","margin-top":-(maxH/2)+"px","width":maxW+"px","height":maxH+"px"});
				thebox.find('#pf_scroll_box').css({"height":(maxH-header_footer)+"px"});
			}else{
				pane.css({"margin-left":-(modal_width/2)+"px","margin-top":-(modal_height/2)+"px","width":modal_width+"px","height":modal_height+"px"});
				thebox.find('#pf_scroll_box').css({"height":(modal_height-header_footer)+"px"});
			}
		});
		thebox.find('#pf_close').off("click").on("click",function(event){
			event.stopPropagation();self.close_pane();
		});
		thebox.find('#'+self.po).off("click").on("click",function(event){/*self.close_pane();*/});
		thebox.find('#pf_close_icon').off("click").on("click",function(event){self.close_pane();});
		self.setpane(instance_id);
	};
    $.fn.Popform=function(options){
		var apopform=new PopformObject(this,options);
		return apopform;
    };