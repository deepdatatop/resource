	function PopchartObject(element,options){
		this.element=element;
		this.defaults={
			width:800,
			height:460,
			zindex:20000,
			i18n:{},
			caption:'',
			closeText:'Close',
			eid:'0',	/*entity_id*/
			sub:'',	/*subentity*/
			iid:'0',/*instance_id*/
			scene:'',
			widget_dependency:'',
		};
		this.overlay='popchart_overlay';
		this.pc='popchart_pane';
		this.options=$.extend({},this.defaults,options);
    };
    PopchartObject.prototype.runload=function(instance_id){
    		var thebox=this.element;
		$.getJSON('/readchartblock',{eid:this.options.eid,scene:this.options.scene,iid:instance_id},function(m){
			if(m.Code=="100"){
				var dt=JSON.parse($.base64.decode(m.Block_bs64));
				thebox.find('#thetitle').text(dt.caption);
				var myChart = echarts.init(document.getElementById('pc_chart_area'));
				myChart.setOption(dt.option);
			}else{alert(m.Msg);}
		});		
	}
	PopchartObject.prototype.include_callback=function(){//call at include.js
		this.runload(this.options.iid);
	};
	PopchartObject.prototype.setpane=function(){
		var wd='';
		if(this.options.widget_dependency.length>0){
			wd=$.base64.decode(this.options.widget_dependency);
		}else{
			$.ajaxSettings.async = false;
			$.getJSON('/readchartdependency',{eid:this.options.eid,scene:this.options.scene},function(m){
				if(m.Code=='100'){
					wd=$.base64.decode(m.Dependency_bs64);
				}
			});
			$.ajaxSettings.async = true;
		}
		include_queue(this,wd);	//include.js function.
	};
	PopchartObject.prototype.close=function(){
		this.element.find('#'+this.overlay).remove();
		this.element.find('#'+this.pc).remove();
	};
	PopchartObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	PopchartObject.prototype.show=function(){
		this.i18n_options();
		var self=this,so=self.options;
		var thebox=this.element;
		var aos='z-index: '+so.zindex+';';
		thebox.append('<div id="'+self.overlay+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.overlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="'+self.pc+'" style="display: none;width:'+self.options.width+'px;height:'+self.options.height+'px;">';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 0px;top: 0px;cursor: pointer;';
		txt += '<span id="pc_close_icon"><i class="fa fa-close"></i></span>';
		txt += '<div class="pc_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
		txt += '<div id="pc_chart_area" style="height:'+(self.options.height-70)+'px;"></div>';
		txt += '<div class="pc_panebtm">';
		txt += '<span class="pc_button" id="btn_close"><i class="fa fa-times-circle-o">&nbsp;'+self.options.closeText+'</i></span>';
		txt += '</div>';
		thebox.append(txt); pane = thebox.find("#"+self.pc);
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#btn_close').off("click").on("click",function(event){self.close();});
		thebox.find('#'+self.overlay).off("click").on("click",function(event){self.close();});
		thebox.find('#pc_close_icon').off("click").on("click",function(event){self.close();});
		self.setpane();
	};
    $.fn.Popchart=function(options){
		var apopchart=new PopchartObject(this,options);
		return apopchart;
    };
