function FulllanguageObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		name:'',/*must set*/
		data_bs64:'',
		mode:'single',/*unique,single,multiple*/
		supportMultiplelanguage:false,
		radiotext:true,
		editortype:'input',/* input/text */
		default_languageid:'2',
		accept_languageids:'',
		accept_languages:{},
		txt_yes:'Yes',
		txt_no:'No',
		txt_multiplelanguage:'multilanguage',
		txt_emptymultieditor:'empty multilanguage input?',
		onChange: function(data){},
		afterInit: function(data){},
		uniqueChange: function(val){}
	};
	this.accept_languageids=[];
	this.isunique=false;
	this.data={};
	this.options=$.extend({},this.defaults,options);
};
FulllanguageObject.prototype.setText_bs64=function(bs64){
	var txt='';
	if(bs64.length>0){
		txt=$.base64.decode(bs64);
	}
	return this.setText(txt);
};
FulllanguageObject.prototype.setText=function(txt){
	var a_ids=this.options.accept_languageids.split(',');
	var lnln=txt.split('\n');
	for(var i=0,n=lnln.length;i<n;i++){
		var lid=this.options.default_languageid;
		var txt=lnln[i];
		var idx=txt.indexOf('#');
		if(idx>0){
			var tid=txt.substr(0,idx);
			if(a_ids.indexOf(tid)>=0){
				lid=tid;
				txt=txt.substr(idx+1);
			}
		}
		this.data[lid]=txt;
	}
	return this.data;
};
FulllanguageObject.prototype.getData=function(){
	return this.data;
};
FulllanguageObject.prototype.saveinput=function(id,val){
	var so=this.options;
	this.data[id]=val;
	if(so.supportMultiplelanguage){
		so.onChange(this.data);
	}else{
		so.onChange(val);
	}
};
FulllanguageObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
FulllanguageObject.prototype.init=function(){
	var self=this,thebox=this.element,so=this.options;
	self.i18n_options();
	self.accept_languageids=so.accept_languageids.split(',');
	self.setText_bs64(so.data_bs64);
	self.isunique=thebox.hasClass('unique_input');
	self.setupWidget();
	so.afterInit(self.data);
	thebox.find(':radio').on('click',function(event){
		var se=thebox.find('#fl_pane').find('.fleditor');
		if($(this).val()=='single'){
			se.val(thebox.find('.multiple_table').find('#'+se.attr('id')).val());
			se.css('display','inline-block').focus();
			thebox.find('.multiinput').hide();
			thebox.find('.multiple_table').hide();
			thebox.find('.fl_emptybtn').hide();
		}else{
			se.hide();
			thebox.find('.multiple_table').find('#'+se.attr('id')).val(se.val());
			thebox.find('.multiinput').css('display','inline-block');
			thebox.find('.multiple_table').css('display','inline-block');
			thebox.find('.fl_emptybtn').css('display','inline-block');
		}
	});
	thebox.find('.fleditor').on('input propertychange',function(e){
		var lid=$(this).attr('id').substr(2);
		var val=$.trim($(this).val());
		self.saveinput(lid,val);
		if(self.isunique&&(lid==so.default_languageid)){so.uniqueChange(val);}
	});
	thebox.find('#flempty').on('click',function(event){
		$('body').YesnoAlert({
			yesText:so.txt_yes,noText:so.txt_no,
			doyes: function(id,action){
				thebox.find('.fleditor').each(function(i){
					$(this).val('');
					var lid=$(this).attr('id');
					self.data[lid.substr(2)]='';
				});
				so.onChange(self.data);
				if(self.isunique){so.uniqueChange('');}
			}
		}).show_alertpane('',so.txt_emptymultieditor,'empty');		
	});
}
FulllanguageObject.prototype.setupWidget=function(){
	var self=this,so=self.options,thebox=this.element;
	thebox.empty();
	var txt='<div id="fl_pane" style="position:relative;">';
	var dvalue='';
	if(self.data.hasOwnProperty(so.default_languageid)){dvalue=self.data[so.default_languageid];}
	if(so.editortype=='input'){
		txt+='<input id="fl'+so.default_languageid+'" class="ml_input fleditor unique_input" type="text" value="'+dvalue+'"';
		if(so.mode=='multiple'){txt+=' style="display:none;"'}
		txt+='>';
	}else{
		txt+='<textarea id="fl'+so.default_languageid+'" class="ml_textarea fleditor"';
		if(so.mode=='multiple'){txt+=' style="display:none;"'}
		txt+='>'+dvalue+'</textarea>';
	}
	txt+='</div>';
	if(so.supportMultiplelanguage){
		txt+='<div class="multiple_table" style="';
		if(so.mode!='multiple'){txt+='display:none;';}
		txt+='">';
		for(var i=0,n=self.accept_languageids.length;i<n;i++){
			var id=self.accept_languageids[i];
			if(self.data.hasOwnProperty(id)){dvalue=self.data[id];}else{dvalue='';}
			var editorhtml='';
			if(so.editortype=='input'){
				editorhtml='<input class="ml_input fleditor" id="fl'+id+'" value="'+dvalue+'">';
			}else{
				editorhtml='<textarea class="ml_textarea fleditor" id="fl'+id+'">'+dvalue+'</textarea>';
			}
			if(so.accept_languages.hasOwnProperty(id)){
				var o=so.accept_languages[id];
				txt += '<div class="mleft">'+o.Label+'&nbsp;<img src="'+o.Flag+'"></div>';
				txt += '<div class="mright">'+editorhtml+'</div>';
			}
		}
		txt+='</div>';
		txt+='<div class="sblock"><span id="typeradio"><input type="radio" name="mode'+so.name+'" value="single"';
		if(so.mode!='multiple'){txt+=' checked="checked"';}
		var o=so.accept_languages[so.default_languageid];
		txt+='>&nbsp;<img src="'+o.Flag+'">';
		if(so.radiotext){txt+='&nbsp;'+o.Label;}
		txt+='&nbsp;&nbsp;';
		txt+='<input type="radio" name="mode'+so.name+'" value="more"';
		if(so.mode=='multiple'){txt+=' checked="checked"';}
		txt+='>&nbsp;<i class="fa fa-language"></i>';
		if(so.radiotext){txt+='&nbsp;'+so.txt_multiplelanguage;}
		txt+='</span>';
		txt+='<span class="fl_emptybtn" style="';
		if(so.mode!='multiple'){txt+='display:none;';}
		txt+='width:24px;text-align:right;">';
		txt+='<i id="flempty" class="fa fa-lg fa-times-circle-o"></i></span>';
		txt+='</div>';
	}
	thebox.append(txt);	
}
$.fn.Fulllanguage=function(options){
	var fl=new FulllanguageObject(this,options);
	fl.init();
	return fl;
};