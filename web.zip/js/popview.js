	function PopviewObject(element,options){
		this.element=element;
		this.defaults={
			width:800,
			height:460,
			zindex:200,
			caption:'',
			i18n:{},
			firstText:'First',
			prevText:'Prev',
			nextText:'Next',
			lastText:'Last',
			closeText:'Close',
			copiedText:'Text has been copied to clipboard',
			eid:'0',
			scene:'',
			widget_dependency:'',
			iid:'',/*focus instance id*/
			iids:[]/*all instance ids*/
		};
		this.clipboard={};
		this.overlay='popview_overlay';
		this.pv='popview_pane';
		this.options=$.extend({},this.defaults,options);
    };
    PopviewObject.prototype.runload=function(instance_id){
    	var thebox=this.element;
		$.getJSON('/readviewblock',{eid:this.options.eid,scene:this.options.scene,iid:instance_id},function(m){
			if(m.Code=="100"){
				thebox.find('#thetitle').text(m.Caption);
				thebox.find('#pv_view_area').empty().append($.base64.decode(m.Block_bs64));
				var jstxt=$.base64.decode(m.JS_bs64);
				if(jstxt.length>0){
					eval(jstxt);
				}
			}else{alert(m.Msg);}
		});
	}
	PopviewObject.prototype.buttonVisible=function(){
		var self=this;
		var i=$.inArray(self.options.iid,self.options.iids);
		if(i>=0){
			var thebox=this.element;
			var btnFirst=thebox.find('#btn_first');
			var btnPrev=thebox.find('#btn_prev');
			var btnNext=thebox.find('#btn_next');
			var btnLast=thebox.find('#btn_last');
			var n=self.options.iids.length;
			if(i==0){btnFirst.attr('disabled',true);btnPrev.attr('disabled',true);}
			else{btnFirst.attr('disabled',false);btnPrev.attr('disabled',false);}
			if(i==n-1){btnNext.attr('disabled',true);btnLast.attr('disabled',true);}
			else{btnNext.attr('disabled',false);btnLast.attr('disabled',false);}
		}
	};
	PopviewObject.prototype.include_callback=function(){//call at include.js
		this.runload(this.options.iid);
		this.buttonVisible();
		this.clipboard=new Clipboard('.copytoclipboard',{text: function(){return $.trim($('#c2c').text());}});
	};
	PopviewObject.prototype.setpane=function(){
		var wd='';
		if(this.options.widget_dependency.length>0){
			wd=$.base64.decode(this.options.widget_dependency);
		}else{
			$.ajaxSettings.async = false;
			$.getJSON('/readviewdependency',{eid:this.options.eid,scene:this.options.scene},function(m){
				if(m.Code=='100'){
					wd=$.base64.decode(m.Dependency_bs64);
				}
			});
			$.ajaxSettings.async = true;
		}
		include_queue(this,wd);	//➸ include_callback
	};
	PopviewObject.prototype.close=function(){
		this.element.find('#'+this.overlay).remove();
		this.element.find('#'+this.pv).remove();
	};
	PopviewObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	PopviewObject.prototype.show=function(){
		this.i18n_options();
		var header_footer=70;
		var self=this,thebox=this.element,so=self.options;
		var aos='z-index: '+so.zindex+';';
		thebox.append('<div id="'+self.overlay+'" style="'+aos+'"><input id="t_copied" type="hidden" value="'+so.copiedText+'"><div id="c2c" class="copytoclipboard"></div></div>');
		var ao=thebox.find('#'+self.overlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="'+self.pv+'" style="display: none;width:'+so.width+'px;height:'+so.height+'px;">';
		txt += '<span class="pv_window_icon"><i class="fa fa-window-maximize"></i></span>';
		txt += '<span class="pv_window_icon pv_window_hide"><i class="fa fa-window-restore"></i></span>';
		txt += '<span id="pv_close_icon"><i class="fa fa-close"></i></span>';
		txt += '<div class="pv_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
		txt += '<div id="pv_view_area" style="overflow-x:hidden;height:'+(so.height-header_footer)+'px;"></div>';
		txt += '<div class="pv_panebtm">';
		txt += '<div style="float:left;width:40%;padding-left:4px;"><span class="pv_button" id="btn_first"><i class="fa fa-step-backward">&nbsp;'+so.firstText+'</i></span>';
		txt += '<span class="pv_button" id="btn_prev"><i class="fa fa-caret-left">&nbsp;'+so.prevText+'</i></span>';
		txt += '<span class="pv_button" id="btn_next"><i class="fa fa-caret-right">&nbsp;'+so.nextText+'</i></span>';
		txt += '<span class="pv_button" id="btn_last"><i class="fa fa-step-forward">&nbsp;'+so.lastText+'</i></span></div>';
		txt += '<div style="float:right;width:40%;text-align:right;padding-right:4px;"><span class="pv_button" id="btn_close"><i class="fa fa-times-circle-o">&nbsp;'+so.closeText+'</i></span></div>';
		txt += '</div></div>';
		thebox.append(txt); pane = thebox.find("#"+self.pv);
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		
		
		thebox.find('#btn_first').off("click").on("click",function(event){
			event.stopPropagation();
			var i=$.inArray(so.iid,so.iids);
			if(i>0){
				so.iid=so.iids[0];
				self.runload(so.iid);
				self.buttonVisible();
			}
		});
		thebox.find('#btn_prev').off("click").on("click",function(event){
			event.stopPropagation();
			var i=$.inArray(so.iid,so.iids);
			if(i>0){
				so.iid=so.iids[i-1];
				self.runload(so.iid);
				self.buttonVisible();
			}
		});
		thebox.find('#btn_next').off("click").on("click",function(event){
			event.stopPropagation();
			var n=so.iids.length;
			var i=$.inArray(so.iid,so.iids);
			if(i<n-1){
				so.iid=so.iids[i+1];
				self.runload(so.iid);
				self.buttonVisible();
			}
		});
		thebox.find('#btn_last').off("click").on("click",function(event){
			event.stopPropagation();
			var n=so.iids.length;
			var i=$.inArray(so.iid,so.iids);
			if(i<n-1){
				so.iid=so.iids[n-1];
				self.runload(so.iid);
				self.buttonVisible();
			}
		});
		thebox.find('.pv_window_icon').off("click").on("click",function(event){
			thebox.find('.pv_window_icon').removeClass('pv_window_hide');
			event.stopPropagation();
			$(this).addClass('pv_window_hide');
			var bk = thebox.find('#'+self.overlay);
			var maxW=bk.outerWidth(),maxH=bk.outerHeight();
			if($(this).find('.fa-window-maximize').length>0){
				pane.css({"margin-left":-(maxW/2)+"px","margin-top":-(maxH/2)+"px","width":maxW+"px","height":maxH+"px"});
				thebox.find('#pv_view_area').css({"height":(maxH-header_footer)+"px"});
			}else{
				pane.css({"margin-left":-(modal_width/2)+"px","margin-top":-(modal_height/2)+"px","width":modal_width+"px","height":modal_height+"px"});
				thebox.find('#pv_view_area').css({"height":(modal_height-header_footer)+"px"});
			}
		});
		thebox.find('#btn_close').off("click").on("click",function(event){self.close();});
		thebox.find('#'+self.overlay).off("click").on("click",function(event){self.close();});
		thebox.find('#pv_close_icon').off("click").on("click",function(event){self.close();});
		self.setpane();
	};
    $.fn.Popview=function(options){
		var apopview=new PopviewObject(this,options);
		return apopview;
    };
    
function showTip(obj,hint){
  obj.attr('data-tipso',hint);
  obj.tipso({useTitle:false,delay:0,background:'#4682B4',color:'#ffffff'});
  obj.off('mouseover mouseout');
  obj.tipso('show');
  var tm=setInterval(function(){
	obj.tipso('hide');
	obj.removeAttr('data-tipso');
	clearInterval(tm);
  },1000);    
}
function copyText(id,txt){
	var c2c=$('#c2c');
	c2c.hide().text(txt).click();
	showTip($('#'+id),$('#t_copied').val());
}