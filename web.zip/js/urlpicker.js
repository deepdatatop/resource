	function URLpickerObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			txt_caption:'Please input remote article page URL: (one per row)',
			txt_run:'Start pickup',
			txt_stop:'Stop',
			txt_restart:'Restart',
			txt_close:'Close',
			txt_stopped:'Stopped',
			txt_over:'Over',
			onOver: function(){},
			width:720,
			height:380,
			zindex:20000
		};
		this.iurl=0;
		this.urls=new Array();
		this.running=false;
		this.eo='urlpicker_overlay';
		this.pane='urlpicker_pane';
		this.options=$.extend({},this.defaults,options);
    };
	URLpickerObject.prototype.close_pane=function(){
		this.element.find('#'+this.eo).remove();
		this.element.find('#'+this.pane).remove();
	};
	URLpickerObject.prototype.setClassCSS=function(classnames,cssvalues){//sample:setClassCSS('aclass','font-size:24px;color: green;');
		var id='urlpicer-class';
		var cssContainer = $('#'+id);
	    if(cssContainer.length == 0){
	        cssContainer = $('<style id="'+id+'"></style>');
	        cssContainer.appendTo($('head'));
	    }
		cssContainer.empty();
		for(var i=0,n=classnames.length;i<n;i++){
			cssContainer.append('.'+classnames[i]+ ' {'+cssvalues[i]+'}');
		}
	};
	URLpickerObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	URLpickerObject.prototype.init=function(){
		this.i18n_options();
		var self=this;
		var classnames=['echo-success','echo-failure','echo-normal','echo-over'];
		var cssvalues=['color:green;padding-left:20px;','color:maroon;padding-left:20px;','color:black;','color:red;font-weight:bold;'];
		self.setClassCSS(classnames,cssvalues);
		var thebox=this.element;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.eo+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.eo).css({"display":"block",opacity:0}).fadeTo(200,0.2);
		var txt='<div id="'+self.pane+'" style="display: none;';
		txt+='width:'+self.options.width+'px;height:'+self.options.height+'px;';
		txt+='overflow:hidden;background:#FFFFFF;padding:10px;border:#000000 solid 1px">';
		txt+='<div style="width:100%;">';
		txt+='<span class="fa-stack" style="color:#84bbf3">';
		txt+='<i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-cloud-download fa-stack-1x"></i></span>';
		txt+='<span>'+self.options.txt_caption+'</span></div>';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 2px;top: 2px;cursor: pointer;';
		txt+='<span id="close_icon" style="'+ats+'"></span>';
		txt+='<div id="main" style="border:solid 1px #dadada;width:100%;height:'+(self.options.height-50)+'px;overflow-y:scroll;">';
		txt+='<textarea id="intext" style="border:none;outline:none;width:100%;height:100%">';
		txt+='</textarea>';
		txt+='<ul id="echo" style="display:none;font-size:12px;"></ul>';
		txt+='</div>';
		txt+='<div style="text-align:center;width:100%;margin-top:2px">';
		txt+='<button id="run">'+self.options.txt_run+'</button>';
		txt+='<button id="stop" style="display:none;">'+self.options.txt_stop+'</button>';
		txt+='<button id="restart" style="display:none;">'+self.options.txt_restart+'</button>';
		txt+='<button id="close" style="display:none;">'+self.options.txt_close+'</button>';
		txt+='</div>';
		txt+='</div>';
		thebox.append(txt); pane = thebox.find('#'+self.pane);
		var modal_width=pane.outerWidth(); var modal_height=pane.outerHeight();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,
				"left":"50%","margin-left":-(modal_width/2)+"px","top":"50%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#close_icon').off('click').on('click',function(event){
			event.stopPropagation();
			self.close_pane();
		});
		thebox.find('#close').off('click').on('click',function(event){
			event.stopPropagation();
			self.close_pane();
		});
		thebox.find('#restart').off('click').on('click',function(event){
			event.stopPropagation();
			thebox.find('#restart').hide();
			thebox.find('#run').show();
			thebox.find('#intext').show();
			thebox.find('#echo').hide();			
		});
		thebox.find('#stop').off('click').on('click',function(event){
			event.stopPropagation();
			thebox.find('#stop').hide();
			thebox.find('#restart').show();
			self.running=false;
		});
		thebox.find('#run').off('click').on('click',function(event){
			event.stopPropagation();
			thebox.find('#run').hide();
			thebox.find('#stop').show();
			var intext=thebox.find('#intext');
			self.urls.length=0;
			var v=intext.val();
			var vv=v.split('\n')
			for(var i=0,n=vv.length;i<n;i++){
				self.urls.push(vv[i].trim());
			}
			if(self.urls.length>0){
				intext.hide();
				thebox.find('#echo').show();
				self.running=true;
				self.iurl=0;
				self.picknexturl();
			}
		});
	};
	URLpickerObject.prototype.focusItem=function(itm){
		var themain=this.element.find('#main');
		var ypos=itm.position().top;
		var yobj=ypos+themain.scrollTop();
		var boxheight=themain.height();
		if(ypos>boxheight){
			var yscroll = yobj-boxheight;
			if(yscroll>0){
				themain.animate({scrollTop:yscroll},100);
			}
		}		
	};
	URLpickerObject.prototype.picknexturl=function(){
		var self=this;
		var thebox=this.element;
		var echo=thebox.find('#echo');
		var n=self.urls.length;
		if(self.iurl<n){
			var v=self.urls[self.iurl];
			echo.append('<li id="u'+self.iurl+'" class="echo-normal">'+(self.iurl+1)+'/'+n+': '+v+'</li>');
			self.focusItem(echo.find('#u'+self.iurl));
			$.getJSON('/pickarticle',{url:v},function(m){
				if(m.Code=='100'){
					var ms=m.Nanoseconds/1000000;
					echo.append('<li id="r'+self.iurl+'" class="echo-success">'+m.Msg+' '+ms+'ms</li>');
					self.focusItem(echo.find('#r'+self.iurl));
					self.iurl ++;
					if(self.running){self.picknexturl();}else{
						echo.append('<li id="stopped" class="echo-over">'+self.options.txt_stopped+'!</li>');
						self.focusItem(echo.find('#stopped'));
						self.options.onOver();
					}
				}else{
					echo.append('<li id="r'+self.iurl+'" class="echo-failure">'+m.Msg+'</li>');
					self.focusItem(echo.find('#r'+self.iurl));
					self.iurl ++;
					if(self.running){self.picknexturl();}else{
						echo.append('<li id="stopped" class="echo-over">'+self.options.txt_stopped+'!</li>');
						self.focusItem(echo.find('#stopped'));
						self.options.onOver();
					}
				}
			});
		}else{
			echo.append('<li id="over" class="echo-over">'+self.options.txt_over+'!</li>');
			self.focusItem(echo.find('#over'));		
			self.running=false;
			thebox.find('#stop').hide();
			thebox.find('#close').show();
			self.options.onOver();
		}
	};
    $.fn.URLpicker=function(options){
		var apicker=new URLpickerObject(this,options);
		apicker.init();
		return apicker;
    };