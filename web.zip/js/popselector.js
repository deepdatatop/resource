	function PopSelectorObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			width:380,
			height:432,
			zindex:20000,
			language:2,
			codeset:'',
			multiple_choice:false,
			result_type:'dotids',
			captionStr:'Caption:',
			saveStr:'Save',
			cancelStr:'Cancel',
			dosave: function(val){}
		};
		this.bodyoverflow='';
		this.overlay='popselector_overlay';
		this.options=$.extend({},this.defaults,options);
    };
	PopSelectorObject.prototype.close_editorpane=function(){
		this.element.find('#'+this.overlay).remove();
		this.element.find('#ieditor_pane').remove();
		$('body').css('overflow',this.bodyoverflow);
	};
	PopSelectorObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	PopSelectorObject.prototype.show=function(value){
		this.i18n_options();
		var body=$('body');
		this.bodyoverflow = body.css('overflow');
		body.css('overflow','hidden');
		var self=this;
		var thebox=this.element;
		var aos='z-index: '+self.options.zindex+';';
		thebox.append('<div id="'+self.overlay+'" class="ps_overlay" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.overlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="ieditor_pane" class="ps_editor" style="display: none;';
		txt += 'width:'+self.options.width+'px;height:'+self.options.height+'px;">';
		txt += '<div class="ps_editor_header text_dark">';
		txt += '<span id="thetitle">'+self.options.captionStr+'</span>';
		txt += '<span class="ps_close_icon"></span></div>';
		txt += '<div id="ps_editor_area" style="width:100%;margin:-1px -1px">';
		txt += '<div id="selector" class="h_selector" style="margin:0 auto;width:100%;outline:none;"></div>';
		txt += '</div>';
		txt += '<div class="ps_editor_footer">';
		txt += '<span class="ps_editor_button" id="btn_ok">'+self.options.saveStr+'</span>';
		txt += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
		txt += '<span class="ps_editor_button" id="btn_cancel">'+self.options.cancelStr+'</span>';
		txt += '</div>';
		txt += '</div>';
		thebox.append(txt);
		var pane = thebox.find("#ieditor_pane");
		if(self.options.codeset.length>0){
			pane.find('#selector').show().Selector({
				codeset:self.options.codeset,
				optionbox_height:332,
				optionbox_foldable:false,
				multiple_choice:self.options.multiple_choice,
				result_type:self.options.result_type,
				language:self.options.language
 			}).setResult(value);
		}else{
			alert('not set codeset!');
		}		
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#btn_ok').off("click").on("click",function(event){
			event.stopPropagation();
			var v = $('#selector').val();
			self.options.dosave(v);
			self.close_editorpane();
		});
		thebox.find('#btn_cancel').off("click").on("click",function(event){self.close_editorpane();});
		thebox.find('#'+self.overlay).off("click").on("click",function(event){self.close_editorpane();});
		thebox.find('.ps_close_icon').off("click").on("click",function(event){self.close_editorpane();});
	};
    $.fn.PopSelector=function(options){
		var aselector=new PopSelectorObject(this,options);
		return aselector;
    };
