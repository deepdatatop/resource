function PoolObject(element,options){
	this.element=element;
	this.defaults={
		txt_add: '加入',
		txt_added: '已加入',
		entity: '',
		usedID: {},
		readpool_url:'/readpoolset',
		onAdd:function(id,txt){}
	};
	this.options=$.extend({},this.defaults,options);
	this.thegrid=new Object();
};
PoolObject.prototype.init=function(){
	var self=this;
	var box=this.element;
	var entity = this.options.entity;
	box.append('<div class="filter" id="the_filter"></div>');
	box.append('<table id="grid" style="margin:0px;overflow: auto;width:100%"></table>');
	$.ajaxSettings.async = false;
	$.getJSON(this.options.readpool_url,{idf: entity},function(m){
		if(m.Code=="100"){
			var default_query='"wgt":"GM","scene":"pool","idf":"'+entity+'"';
			box.find('#the_filter').Filter({
				user_id: m.User_id,
				ip: m.Ip,
				entity_id: m.Entity_id,
/*					language_code:'{{.clientlanguage_code}}',
					txt_search:'{{.t_search}}',
					txt_reset:'{{.t_reset}}',
					txt_recent:'{{.t_recent}}',
					txt_bysequence:'{{.t_sequence}}',
					txt_byfrequency:'{{.t_frequency}}',
					txt_ok:'{{.t_ok}}',
					txt_close:'{{.t_close}}',
					txt_today:'{{.t_today}}',
					txt_chooseperiod:'{{.t_chooseperiod}}',
					txt_fullscreen:'{{.t_fullscreen}}',
					txt_moveselect:'{{.t_moveselect}}',
					txt_periodchooser:'{{.t_periodchooser}}',
					txt_yesterday:'{{.t_yesterday}}',
					txt_thisweek:'{{.t_thisweek}}',
					txt_lastweek:'{{.t_lastweek}}',
					txt_last7days:'{{.t_last7days}}',
					txt_last14days:'{{.t_last14days}}',
					txt_thismonth:'{{.t_thismonth}}',
					txt_lastmonth:'{{.t_lastmonth}}',
					txt_last30days:'{{.t_last30days}}',
					txt_last60days:'{{.t_last60days}}',
					txt_last3months:'{{.t_last3months}}',
					txt_last6months:'{{.t_last6months}}',
					txt_thisyear:'{{.t_thisyear}}',
					txt_lastyear:'{{.t_lastyear}}',*/
				htmblock: m.Filter_block,
				inputs: m.Filter_inputs,
				onSearch: function(q,p){//query,prompt
					var txt='{'+default_query;
					if(q.length>0){ txt+=','+q; }
					txt+='}';
					GridManager.setQuery(entity,JSON.parse(txt),true,function(){});
					if(q.length>0){$.getJSON('/savequery',{q:txt,p:p},function(m){});}
				}
			});
			var colcol = JSON.parse(m.Grid_columns)
			$.each(colcol,function(i,col){
				if(col['key']=='operation'){
					col['template']=function(operation, row){
							var ss='<span>';
							if(self.options.usedID.hasOwnProperty(row.id)){
								ss+=self.options.txt_added;
							}else{
								ss+='<i mid="'+row.id+'" mtt="'+$.base64.encode(row.title)+'" class="addin fa fa-plus-square"> '+self.options.txt_add+'</i>';
							}
							ss+='</span>';
							return ss;
						}
				}
			});	
			
			self.thegrid=box.find('#grid');
			self.thegrid.GM({
				gridManagerName: entity,
				height: '100% - '+box.find('#the_filter').outerHeight()+'px',
				supportAjaxPage: true,
				supportCheckbox: false,
				supportMoveRow: false,
				ajaxData: '/getdatagrid',
				ajaxType: 'POST',
				query: JSON.parse('{'+default_query+'}'),
				lineHeight: '25px',
				pageSize: 5,
				columnData: colcol,
				ajaxSuccess: function(data){
					self.registerAddinEvent();
				}
			});
		}
	});
	$.ajaxSettings.async = true;
};

PoolObject.prototype.refresh=function(){
	GridManager.renderGrid(this.options.entity);
	this.registerAddinEvent();
}

PoolObject.prototype.registerAddinEvent=function(){
	var self=this;
	self.thegrid.find('.addin').off('click').on('click',function(){
		var mid=$(this).attr('mid');
		var title=$.base64.decode($(this).attr('mtt'));
		var p=$(this).parent();
		p.append(self.options.txt_added);
		$(this).remove();
		self.options.onAdd(mid,title);
	});
}
	
$.fn.Pool=function(options){
	var pl=new PoolObject(this,options);
	pl.init();
	return pl;
};