	function GridexObject(element,options){
		this.outerID='';
		this.element=element;
		this.defaults={
			title: 'table sample',
			titlealign: 'center',
			tablewidth: '80%',/*actual,100%,80%*/
			tablealign: 'center',
			colalign: 'center',
			columns: [],
			cells: [],
			rectangles: [],
			txt_tblwidth: '表宽:',
			txt_actual: '实际',
			txt_tblalign: '位置:',
			txt_tblsubject: '标题:',
			txt_colalign: '列对齐:',
			txt_cell: '单元格:',
			txt_yes: 'Yes',
			txt_no: 'No',
			txt_left: 'Left',
			txt_center: 'Center',
			txt_right: 'Right',
			txt_top: 'Top',
			txt_middle: 'Middle',
			txt_bottom: 'Bottom',
			
			txt_merge: '合',
			txt_unmerge: '分',
			txt_addrow: '加行',
			txt_insrow: '插行',
			txt_rmvrow: '删行',
			txt_selectinsrowpos: '请选中需插入的行位置！',
			txt_selectrmvrow: '请选中需删除的行！',
			txt_addcol: '加列',
			txt_inscol: '插列',
			txt_selectinscolpos: '请选中需插入的列位置！',
			txt_rmvcol: '删列',
			txt_selectrmvcol: '请选中需删除的列！',
			txt_empty: '清空',
			txt_emptyornot: 'Empty table',
			default_colModel: [{ title: "A", width: 100 }],
			default_dataModel: { data: [['']] },
			noborder: true,
			onTitleChange: function(id,title){},
			onChange: function(id,data){},
			screen: {}/*the output windows for grid table render*/
		};
		this.options=$.extend({},this.defaults,options);
		this.PqGrid=new Object();
		this.tablealignState=new Object();
		this.colalignState=new Object();
		this.cellmergeState=new Object();
		this.actualwidth=0;
		this.columntitle=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
    };
	GridexObject.prototype.setClassCSS=function(classname,cssvalue){//sample:setClassCSS('aclass','font-size:24px;color: green;');
		var id='gridex-'+classname;
		var cssContainer = $('#'+id);
	    if(cssContainer.length == 0){
	        cssContainer = $('<style id="'+id+'"></style>');
	        cssContainer.appendTo($('head'));
	    }
		cssContainer.empty().append('.'+classname+ ' {'+cssvalue+'}');
	};
	//need change to setIdCSS
	GridexObject.prototype.getOuterID=function(){
		return this.outerID;
	};
	GridexObject.prototype.getTitle=function(){
		this.options.title=this.element.find('#tabletitle').val();
		return this.options.title;
	};
	GridexObject.prototype.Titlechange=function(){
		this.options.onTitleChange(this.outerID,this.getTitle());	
		this.setTitleDisplay();
	};
	GridexObject.prototype.focusColIndex=function(){
		var icol=-1;
		try{
			var sel = this.PqGrid.pqGrid("selection",{type: 'cell', method: 'getSelection'});
			if(sel.length>0){icol=sel[0].colIndx;}
		} catch (error) {
  			//alert(error);//TypeError:undefined is not an object(evaluating'r[g].dataIndx')
		}
		return icol;
	};
	GridexObject.prototype.focusRowIndex=function(){
		var irow=-1;
		var sel = this.PqGrid.pqGrid("selection",{type: 'cell', method: 'getSelection'});
		if(sel.length>0){irow=sel[0].rowIndx;}
		return irow;
	};
	GridexObject.prototype.init=function(){
		var rootthis=this;
		var self=this.element;
		self.empty();
		var txt='<div id="a_toolbar" style="width:100%;height:28px;padding-top:2px;overflow:hidden;background-color:#f9f9f9;border-bottom:1px solid #dcdcdc;">';
		txt+='<span id="apx" style="font-size:24px;display:inline-block"><i class="fa fa-table"></i></span>';
		var ws='<select id="tablewidth" style="display:inline-block;outline:none">';
		ws+='<option value="actual">'+this.options.txt_actual+'</option>';
		ws+='<option value="100%">100%</option><option value="90%">90%</option>';
		ws+='<option value="80%">80%</option><option value="75%">75%</option>';
		ws+='<option value="50%">50%</option><option value="25%">25%</option></select>';
		txt+='<span style="padding-left:3px;display:inline-block">'+this.options.txt_tblwidth+'</span>'+ws;
		txt+='<span style="display:inline-block">'+this.options.txt_tblalign+'</span><span id="tablealign" style="display:inline-block"></span>';
		txt+='<span style="display:inline-block">'+this.options.txt_tblsubject+'</span>';
		txt+='<input id="tabletitle" style="display:inline-block;width:180px;height:20px;line-height:20px;outline:none">';
		txt+='<span style="display:inline-block">'+this.options.txt_colalign+'</span><span id="colalign" style="display:inline-block"></span>';
		txt+='<button id="addrow" style="display:inline-block">'+this.options.txt_addrow+'</button>';
		txt+='<button id="insrow" style="display:inline-block">'+this.options.txt_insrow+'</button>';
		txt+='<button id="rmvrow" style="display:inline-block">'+this.options.txt_rmvrow+'</button>';
		txt+='<button id="addcol" style="display:inline-block">'+this.options.txt_addcol+'</button>';
		txt+='<button id="inscol" style="display:inline-block">'+this.options.txt_inscol+'</button>';
		txt+='<button id="rmvcol" style="display:inline-block">'+this.options.txt_rmvcol+'</button>';
		txt+='<span style="display:inline-block">'+this.options.txt_cell+'</span>';
		txt+='<button id="merge" style="display:inline-block">'+this.options.txt_merge+'</button>';
		txt+='<button id="unmerge" style="display:inline-block">'+this.options.txt_unmerge+'</button>';
		txt+='<button id="update" style="display:inline-block">data</button>';
		txt+='<div style="display:inline-block;position:absolute;right:0px;width:24px;height:28px;">';
		txt+='<i id="tableempty" class="fa fa-lg fa-trash-o" style="line-height:28px;cursor:pointer;color:#666666;"></i>';
		txt+='</div></div>';
		txt+='<div class="pqgrid"';
		if(this.options.noborder){txt+=' style="border:none"';}
		txt+='></div>'
		self.append(txt);
		self.find('#addrow').on('click',function(){
			rootthis.PqGrid.pqGrid("addRow",{newRow:[]});
			rootthis.modified();
			rootthis.refreshScreen();
		});
		self.find('#insrow').on('click',function(){
			var irow=rootthis.focusRowIndex();
			if(irow>=0){
				rootthis.PqGrid.pqGrid("addRow",{rowIndx:irow,newRow:[]});
				rootthis.modified();
				rootthis.refreshScreen();
			}else{alert(rootthis.options.txt_selectinsrowpos);}
		});
		self.find('#rmvrow').on('click',function(){
			var irow=rootthis.focusRowIndex();
			if(irow>=0){
				rootthis.PqGrid.pqGrid("deleteRow",{rowIndx:irow});
				rootthis.modified();
				rootthis.refreshScreen();
			}else{alert(rootthis.options.txt_selectrmvrow);}
		});
		self.find('#update').on('click',function(){
			var dt=rootthis.PqGrid.pqGrid("option","dataModel.data");
		});
		self.find('#addcol').on('click',function(){
			var cm=rootthis.PqGrid.pqGrid("option","colModel");
			var n=cm.length;
			if(n<rootthis.columntitle.length){
				var maxCol=0;
				for(var i=0;i<n;i++){
					if(cm[i].dataIndx>maxCol){maxCol=cm[i].dataIndx}
				}
				var newcol={title:rootthis.columntitle[n],dataIndx:maxCol+1};
				cm.push(newcol);
				rootthis.options.columns.push(newcol);
				rootthis.PqGrid.pqGrid("option",{"colModel":cm});
				rootthis.PqGrid.pqGrid("refresh");
				rootthis.modified();
				rootthis.refreshScreen();
			}
		});
		self.find('#inscol').on('click',function(){
			var icol=rootthis.focusColIndex();
			if(icol>=0){
				var cm=rootthis.PqGrid.pqGrid("option","colModel");
				var n=cm.length;
				if(n<rootthis.columntitle.length){
					var maxCol=0;
					for(var i=0;i<n;i++){
						if(cm[i].dataIndx>maxCol){maxCol=cm[i].dataIndx}
					}
					var newcol={title:rootthis.columntitle[icol],dataIndx:maxCol+1};
					cm.splice(icol,0,newcol);
					rootthis.options.columns.splice(icol,0,newcol);
					n=cm.length;
					for(var i=icol+1;i<n;i++){cm[i].title=rootthis.columntitle[i];}
					rootthis.PqGrid.pqGrid("option",{"colModel":cm});
					rootthis.PqGrid.pqGrid("refresh");
					rootthis.modified();
					rootthis.refreshScreen();
				}
			}else{alert(rootthis.options.txt_selectinscolpos);}
		});
		self.find('#rmvcol').on('click',function(){
			var icol=rootthis.focusColIndex();
			if(icol>=0){
				var cm=rootthis.PqGrid.pqGrid("option","colModel");
				if(cm.length>1){
					cm.splice(icol,1);
					rootthis.options.columns.splice(icol,1);
					var n=cm.length;
					for(var i=icol;i<n;i++){cm[i].title=rootthis.columntitle[i];}
					rootthis.PqGrid.pqGrid("option",{"colModel":cm});
					rootthis.PqGrid.pqGrid("refresh");
					rootthis.modified();
					rootthis.refreshScreen();
				}
			}else{alert(rootthis.options.txt_selectrmvcol);}
		});
		self.find('#tableempty').on('click',function(){
			$('body').YesnoAlert({
				yesText:rootthis.options.txt_yes,noText:rootthis.options.txt_no,
					doyes: function(id,action){
						rootthis.PqGrid.pqGrid("option",
								{"colModel":rootthis.options.default_colModel,
								"dataModel":rootthis.options.default_dataModel});
						rootthis.PqGrid.pqGrid("refreshDataAndView");
						rootthis.modified();
						rootthis.refreshScreen();
					}
			}).show_alertpane('',rootthis.options.txt_emptyornot+'?','empty');			
		});
		self.find('#tablewidth').change(function(){
			var width=$(this).val();
			rootthis.options.tablewidth=width;
			if(width=='actual'){
				var w=0;
				for(var i=0,n=rootthis.options.columns.length;i<n;i++){
					w += rootthis.options.columns[i].width;
				}
				width=String(w);
			}
			var box=rootthis.options.screen;
			if(JSON.stringify(box)!='{}'){
				box.find('table.tbl_data').attr('width',width);
				rootthis.modified();
			}
		});
		self.find('#tabletitle').on('input propertychange',function(e){
			rootthis.Titlechange();
		}).on('keypress',function(event){
			if(event.keyCode == "13"){
				event.preventDefault();
				rootthis.modified();
				rootthis.Titlechange();
				var box=rootthis.options.screen;
				if(JSON.stringify(box)!='{}'){
					box.find('#tbltitle').text(rootthis.getTitle());
				}
			}
		});
		rootthis.tablealignState=self.find('#tablealign').StateButton({
			item_option:[
				{value:'left',label:'<i class="fa fa-step-backward"></i>'},
				{value:'center',label:'<i class="fa fa-text-width"></i>'},
				{value:'right',label:'<i class="fa fa-step-forward"></i>'}
        		],
			onChange: function(val) {
				var box=rootthis.options.screen;
				if(JSON.stringify(box)!='{}'){
					var tblcontainer=box.find('#tblcontainer');
					tblcontainer.attr('align',val);
					tblcontainer.find('table.tbl_data').attr('align',val);
					rootthis.options.tablealign=val;
					rootthis.options.titlealign=val;//suggest same as tablealign
					rootthis.setTitleDisplay();
					rootthis.modified();
				}		
			}
		});
		rootthis.colalignState=self.find('#colalign').StateButton({
			onChange: function(val) {
				var sel = rootthis.PqGrid.pqGrid("selection",{type: 'cell', method: 'getSelection'});
				if(sel.length>0){
					var icol=sel[0].colIndx;
					rootthis.options.columns[icol]['align']=val;
					var cm=rootthis.PqGrid.pqGrid("option","colModel");
					cm[icol]['align']=val;
					rootthis.PqGrid.pqGrid("option",{"colModel":cm});
					rootthis.PqGrid.pqGrid("refreshColumn",{colIndx:icol});
					rootthis.modified();
					var screen=rootthis.options.screen;
					if(screen.length>0){screen.find('.col_'+icol).attr('align',val);}
				}
			}
		}).Select('center');
		self.find('#merge').on('click',function(){
			var selection=rootthis.PqGrid.pqGrid("selection");
			if(selection.count()>1){
				selection.merge();
				rootthis.PqGrid.pqGrid("refresh");
				rootthis.modified();
			}
		});
		self.find('#unmerge').on('click',function(){
			var selection=rootthis.PqGrid.pqGrid("selection");
			if(selection.count()==1){
				selection.unmerge();
				rootthis.PqGrid.pqGrid("refresh");
				rootthis.modified();
			}
		});
        var pqgrid_obj = {
			width: "0",
			height: "0",
			showTop: true,
			showTitle: false,
			showBottom: false,
			collapsible: false,
			//dragColumns: { enabled: false },/*disable column header drag*/
			showHeader: true,
			roundCorners: false,
			rowBorders: true,
			columnBorders: true,                                    
			selectionModel: { type: 'cell' },
			numberCell: { show: false },
			stripeRows: false,
			colModel: rootthis.options.default_colModel,
			dataModel: rootthis.options.default_dataModel
        };
		this.PqGrid = self.find('.pqgrid').pqGrid(pqgrid_obj);
		this.PqGrid.pqGrid({cellBeforeSave: function( event, ui ) {
			var cellid=ui.column.leftPos+'-'+ui.rowIndx;
			var screen=rootthis.options.screen;
			if(screen.length>0){
				screen.find('#'+cellid).text(ui.newVal);
			}
		}});	//https://www.paramquery.com/api#event-cellSave
		this.PqGrid.pqGrid({change: function( event, ui ) {rootthis.modified();	}});
		this.PqGrid.pqGrid({columnResize: function( event, ui ) {
			var dw=ui.newWidth-ui.oldWidth;
			var icol=ui.colIndx
			var screen=rootthis.options.screen;
			if(screen.length>0){
				screen.find('.col_'+icol).each(function(){
					var me=$(this);
					var w=parseInt(me.attr('width'))+dw;
					me.attr('width',w);
				});
			}
			rootthis.modified();}});//https://www.paramquery.com/api#event-columnResize
		this.PqGrid.pqGrid({headerCellClick: function( event, ui ) {
		}});
		this.PqGrid.pqGrid({selectEnd: function( event,ui ){
			var addr=ui.selection.address();
			if(addr.length>0){
				var i=addr[0].firstC;
				if(i<rootthis.options.columns.length){
					var align='left';
					var column=rootthis.options.columns[i];
					if(column.hasOwnProperty('align')){
						align=column['align'];
						if(align==null){align='left';}
					}
					rootthis.colalignState.Select(align);
				}
			}
		}});
	};
	GridexObject.prototype.colModelClone=function(sourceObj){
		var rootthis=this;
	    let cloneObj = {};
		var thetype=(typeof sourceObj);
	    if(!sourceObj || thetype !== "object"){
	        return sourceObj;
	    }
		var isarray=false;
	    if(sourceObj instanceof Array){
			cloneObj = [];
			isarray=true;
		}
		Object.keys(sourceObj).forEach(function(key){
			var val=sourceObj[key];
			if(typeof val === 'object') {
				if(key==='colModel' || isarray){
					cloneObj[key] = rootthis.colModelClone(val);
				}
			}else{
				if(key==='title' || key==='align' || key==='width' /*|| key==='dataIndx'*/ ||
					key==='format' || key==='dataType'){//no dataIndex because need cleanData
					cloneObj[key] = val;
				}
			}
		});
		return cloneObj;
	}
	GridexObject.prototype.setScreen=function(div_item){
		this.options.screen=div_item;	
		this.refreshScreen();
		/*var table=div_item.find('table');
		if(table.length==0){
			div_item.append(this.initGridblockText());
		}*/
	};
	GridexObject.prototype.show=function(){
		this.element.show();
	};
	GridexObject.prototype.hide=function(){
		this.element.hide();
	};
	GridexObject.prototype.setOuterID=function(id){
		this.outerID = id;
		var self=this.element;
		self.find('.pqgrid').attr('outerid',id);
	};
	GridexObject.prototype.resize=function(){
		try{
		this.PqGrid.pqGrid("option",{"width":"100%","height":"100%-28"});
		}catch(error){
			alert(error);
		}
		this.PqGrid.pqGrid("refresh");
	};
	GridexObject.prototype.modified=function(){
		this.options.onChange(this.outerID,this.getTable());
	};
	GridexObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	GridexObject.prototype.parseText=function(txt){
		var obj=this;
		obj.options.title = ''; obj.options.titlealign='center';
		obj.options.tablewidth='actual'; obj.options.tablealign='center';
		obj.options.columns = [];
		obj.options.cells = [];
		obj.options.rectangles = [];
		if(txt.length>0){
			/*format: {"title":"able","cells":[],"rectangles":[]}*/
			if(obj.isObjectText(txt)){
				var dt=JSON.parse(txt);
				if(dt.hasOwnProperty('title')){obj.options.title=dt.title;}
				if(dt.hasOwnProperty('titlealign')){obj.options.titlealign=dt.titlealign;}
				if(dt.hasOwnProperty('tablewidth')){obj.options.tablewidth=dt.tablewidth;}
				if(dt.hasOwnProperty('tablealign')){obj.options.tablealign=dt.tablealign;}
				if(dt.hasOwnProperty('columns')){obj.options.columns=dt.columns;}
				if(dt.hasOwnProperty('cells')){obj.options.cells=dt.cells;}
				if(dt.hasOwnProperty('rectangles')){obj.options.rectangles=dt.rectangles;}//left,top,colspan,rowspan
			}
		}else{
			obj.options.columns=obj.options.default_colModel;
			obj.options.cells=obj.options.default_dataModel.data;
		}
	};
	GridexObject.prototype.refresh=function(){
		var obj=this;
		var self=this.element;
		self.find('#tablewidth').val(obj.options.tablewidth);
		obj.tablealignState.Select(obj.options.tablealign);
		self.find('#tabletitle').val(obj.options.title);
		var colModel=[];
		for(var i=0;i<obj.options.columns.length;i++){
			var c=obj.options.columns[i];
			colModel.push({title:c.title,width:c.width,align:c.align});
		}
		var rects=[];
		for(var i=0;i<obj.options.rectangles.length;i++){
			var r=obj.options.rectangles[i];
			rects.push({c1:r['left'],r1:r['top'],cc:r['colspan'],rc:r['rowspan']});
		}
		obj.PqGrid.pqGrid("option",{"colModel":colModel});
		obj.PqGrid.pqGrid("option","dataModel.data",obj.options.cells);
		obj.PqGrid.pqGrid("option","mergeCells",rects);
		obj.PqGrid.pqGrid("refreshDataAndView");
		obj.refreshScreen();
	};
	GridexObject.prototype.refreshScreen=function(){
		var obj=this;	
		var box=obj.options.screen;
		if(JSON.stringify(box)!='{}'){
			box.find('.ht_gridblock').remove();
			var ww=[];
			var width=obj.options.tablewidth;
			if(width=='actual'){
				var w=0;
				for(var i=0,n=obj.options.columns.length;i<n;i++){
					w += obj.options.columns[i].width;
					ww.push(obj.options.columns[i].width);
				}
				width=String(w);
			}
			var ss='<div class="ht_gridblock"><table width="100%""><tr class="titlerow">';
			ss+='<td id="tbltitle" class="tbl_title" align="'+obj.options.titlealign+'">'+obj.options.title+'</td></tr>';
			ss+='<tr><td id="tblcontainer" align="'+obj.options.tablealign+'">';
			ss+='<table align="'+obj.options.tablealign+'" width="'+width+'" cellspacing="0" cellpadding="0" class="tbl_data normal_table"></table>';
			ss+='</td></tr></table></div>';
			box.append(ss);
			var tbl=box.find('table.tbl_data');
			var n=obj.options.cells.length;
			var rowclass='normal_row';
			for(var i=0;i<n;i++){
				if(i==n-1){rowclass='last_row';}
				var rw='<tr class="'+rowclass+'">';
				var cellclass='normal_cell';
				if(Array.isArray(obj.options.cells[i])){
					var m=obj.options.columns.length;
					for(var j=0;j<m;j++){
						var column=obj.options.columns[j];
						var colspan=1,rowspan=1;
						for(var k=0,len=obj.options.rectangles.length;k<len;k++) {
							var r=obj.options.rectangles[k];
							var r1=r.top,c1=r.left,rc=r.rowspan,cc=r.colspan;
							var r2=r1+rc-1,c2=c1+cc-1;
							if(i>=r1&&i<=r2&&j>=c1&&j<=c2){
								if(i==r1&&j==c1){colspan=cc;rowspan=rc;}
								else{colspan=0;rowspan=0;}
								break;
							}
						}
						if(colspan*rowspan>0){
							width='';
							if(obj.options.tablewidth=='actual'){
								var w=0;
								for(var k=0;k<colspan;k++){ w+=ww[k]; }
								if(w>0){	width=' width="'+w+'"';}
							}
							if(j==m-1){cellclass='last_cell';}
							var dt='';
							if(j<obj.options.cells[i].length){
								dt=obj.options.cells[i][j];
								if(!dt || typeof(dt) == "undefined"){dt='';}
							}
							if(dt==''){dt='&nbsp;';}
							rw+='<td id="'+j+'-'+i+'" class="col_'+j+' '+cellclass+'"'+width;
							var align='';
							if(column.hasOwnProperty('align')){
								align=column['align'];
								if(align==null){align='';}
							}
							if(align.length>0){rw+=' align="'+align+'"'};
							if(colspan>1){rw+=' colspan="'+colspan+'"';}
							if(rowspan>1){rw+=' rowspan="'+rowspan+'"';}
							rw+='>'+dt+'</td>';
						}
					}
				}else{//object						
				}
				rw+='</tr>';
				tbl.append(rw);
			}
			obj.setTitleDisplay();
		}
	};
	GridexObject.prototype.setTitleDisplay=function(){
		var box=this.options.screen;
		//var display='none';
		if(this.options.title.length>0){
			//display='inline';
			var tbltitle=box.find('#tbltitle');
			tbltitle.attr('align',this.options.titlealign);
			//tbltitle.attr('text-align',this.options.titlealign);
			//tbltitle.attr('style','text-align:'+this.options.titlealign+';');
		}
		//box.find('.titlerow').attr('style','display:'+display+';');*/
	};
	GridexObject.prototype.setTable=function(val){
		this.parseText(val);
		this.refresh();
		return this;
	};
	GridexObject.prototype.cleanData=function(){
		var cm=this.PqGrid.pqGrid("option","colModel");//colModel is cyclic structures. 
		var dd=this.PqGrid.pqGrid("option","dataModel.data");
		this.options.cells=[];
		for(var i=0,n=dd.length;i<n;i++){
			var rd=dd[i];
			var rw=new Array(cm.length);
			var cc=rd.length;//cell count in rowdata.
			for(var j=0,m=cm.length;j<m;j++){
				var dt='';
				if(cm[j].dataIndx<cc){
					dt=rd[cm[j].dataIndx];
					if(!dt || typeof(dt)=="undefined"){	dt='';}
				}
				rw[j]=dt;
			}
			this.options.cells.push(rw);
		}
		this.options.columns=this.colModelClone(cm);//extract cyclic structures, JSON.stringify cannot serialize.
		this.options.rectangles=[];
		var mc=this.PqGrid.pqGrid("option","mergeCells");
		for(var i=0,n=mc.length;i<n;i++){
			var rt=mc[i];
			this.options.rectangles.push({top:rt['r1'],left:rt['c1'],rowspan:rt['rc'],colspan:rt['cc']});
		}
	};
	GridexObject.prototype.getTable=function(){
		this.cleanData();		
		var dt={title:this.options.title,titlealign:this.options.titlealign,
				tablewidth:this.options.tablewidth,tablealign:this.options.tablealign,
				columns:this.options.columns,cells:this.options.cells,rectangles:this.options.rectangles};
		return JSON.stringify(dt);
	};
	GridexObject.prototype.test=function(){
		//this.PqGrid.pqGrid("range",{c1:2,r1:0,c2:3,r2:1}).clear();
		//this.PqGrid.pqGrid("addRow",{newRow:{}});
		//this.PqGrid.pqGrid("deleteRow",{rowIndx: 4});
		//fill content
		//this.PqGrid.pqGrid("range",{c1:3,r1:2,cc:2,rc:2}).value([[11,1],[22,2]]);
		//this.PqGrid.pqGrid("refresh");
		alert(this.outerID);
	};
    $.fn.Gridex=function(options){
		var a_grid=new GridexObject(this,options);
		a_grid.init();
		return a_grid;
    };