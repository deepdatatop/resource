	function EntranceDialogObject(element,options){
		this.element=element;
		this.defaults={
			//width:560,
			width:420,
			height:84,
			zindex:20000,
			txt_text: 'Text',
			txt_image: 'Image',
			txt_appendix: 'Appendix',
			txt_qrcode: 'QRcode',
			txt_task: 'Task',
			txt_map: 'Map',
			txt_table: 'Table',
			txt_chart: 'Chart',
			txt_code: 'Sourcecode',
			txt_video: 'Video',
			onEnter:function(id,editortype){},
			onCancel:function(id){}
		};
		this.id='';
		this.eo='entrance_overlay';
		this.options=$.extend({},this.defaults,options);
    };
	EntranceDialogObject.prototype.close_pane=function(){
		this.element.find('#'+this.eo).remove();
		this.element.find('#dialog_pane').remove();
	};
	EntranceDialogObject.prototype.show_pane=function(id){
		var self=this;
		var thebox=this.element;
		self.id=id;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.eo+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.eo).css({"display":"block",opacity:0}).fadeTo(200,0.2);
		var txt='<div id="dialog_pane" style="display: none;';
		txt += 'width:'+self.options.width+'px;height:'+self.options.height+'px;';
		txt += 'overflow:hidden;background:#FFFFFF;padding:20px;border:#000000 solid 1px">';
		txt += '<i class="fa fa-magic fa-flip-horizontal fa-2x" style="position:absolute;left:10px;top:10px;color:#84bbf3"></i>';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 2px;top: 2px;cursor: pointer;';
		txt+='<span id="close_icon" style="'+ats+'"></span>';
		txt+='<div style="text-align:center;width:100%;">';
		txt+='<span id="text" class="editor_button"><i class="fa fa-font"></i>&nbsp;'+self.options.txt_text+'</span>';
		txt+='<span id="image" class="editor_button"><i class="fa fa-picture-o"></i>&nbsp;'+self.options.txt_image+'</span>';
		txt+='<span id="appendix" class="editor_button"><i class="fa fa-paperclip"></i>&nbsp;'+self.options.txt_appendix+'</span>';
		txt+='<br><span id="qrcode" class="editor_button"><i class="fa fa-qrcode"></i>&nbsp;'+self.options.txt_qrcode+'</span>';
		txt+='<span id="table" class="editor_button"><i class="fa fa-table"></i>&nbsp;'+self.options.txt_table+'</span>';
		txt+='<span id="code" class="editor_button"><i class="fa fa-code"></i>&nbsp;'+self.options.txt_code+'</span>';
		/*txt+='<span id="task" class="editor_button"><i class="fa fa-tasks"></i>&nbsp;'+self.options.txt_task+'</span>';
		txt+='<span id="map" class="editor_button"><i class="fa fa-map-marker"></i>&nbsp;'+self.options.txt_map+'</span>';
		txt+='<span id="chart" class="editor_button"><i class="fa fa-line-chart"></i>&nbsp;'+self.options.txt_chart+'</span>';
		txt+='<span id="video" class="editor_button"><i class="fa fa-video-camera"></i>&nbsp;'+self.options.txt_video+'</span>';*/
		txt+='</div>';
		txt += '</div>';
		thebox.append(txt); pane = thebox.find("#dialog_pane");
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":40+"%"});
		pane.fadeTo(200,1);
		
		thebox.find('#close_icon').off('click').on('click',function(event){
			event.stopPropagation();
			self.close_pane();
			self.options.onCancel(self.id);
		});
		thebox.find('.editor_button').off('click').on('click',function(event){
			event.stopPropagation();
			self.close_pane();
			var editortype=0;/*1:plain text/2:illustration/3:appendix/4:qrcode/5:task/6:map/7:table/8:chart/9:source code/10:video*/
			switch($(this).attr('id')){
				case 'text': editortype=1; break;
				case 'image': editortype=2; break;
				case 'appendix': editortype=3; break;
				case 'qrcode': editortype=4; break;
				case 'task': editortype=5; break;
				case 'map': editortype=6; break;
				case 'table': editortype=7; break;
				case 'chart': editortype=8; break;
				case 'code': editortype=9; break;
				case 'video': editortype=10; break;
			}
			self.options.onEnter(self.id,editortype);
		});
	};
    $.fn.EntranceDialog=function(options){
		var aDialog=new EntranceDialogObject(this,options);
		return aDialog;
    };