	function PopmemberObject(element,options){
		this.element=element;
		this.defaults={
			width:600,
			height:300,
			zindex:20000,
			i18n:{},
			caption:'Membership function alert',
			trialText:'Keep trial',
			buyText:'Buy licence',
			echoText:'This function is exclusive to premium members',
			scene:'',
			widget_dependency:''
		};
		this.overlay='popmember_overlay';
		this.pv='popmember_pane';
		this.options=$.extend({},this.defaults,options);
    };
	PopmemberObject.prototype.close=function(){
		this.element.find('#'+this.overlay).remove();
		this.element.find('#'+this.pv).remove();
	};
	PopmemberObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	PopmemberObject.prototype.show=function(){
		this.i18n_options();
		var header_footer=70;
		var self=this,thebox=this.element,so=self.options;
		var aos='z-index: '+so.zindex+';';
		thebox.append('<div id="'+self.overlay+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.overlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="'+self.pv+'" style="display: none;width:'+so.width+'px;height:'+so.height+'px;">';
		txt += '<span class="pm_window_icon"><i class="fa fa-window-maximize"></i></span>';
		txt += '<span class="pm_window_icon pm_window_hide"><i class="fa fa-window-restore"></i></span>';
		txt += '<span id="pm_close_icon"><i class="fa fa-close"></i></span>';
		txt += '<div class="pm_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
		var h=so.height-header_footer;
		txt += '<div id="pm_echo_area" style="height:'+h+'px;line-height:'+h+'px">'+so.echoText+'</div>';
		txt += '<div class="pm_panebtm">';
		txt += '<div style="float:left;width:40%;padding-left:4px;text-align:center">';
		txt += '<span class="pm_button" id="btn_trial"><i class="fa fa-forward">'+so.trialText+'</i></span></div>';
		txt += '<div style="float:right;width:40%;text-align:center;padding-right:4px;"><span class="pm_button" id="btn_buy"><i class="fa fa-shopping-cart">'+so.buyText+'</i></span></div>';
		txt += '</div></div>';
		thebox.append(txt); pane = thebox.find("#"+self.pv);
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('.pm_window_icon').off("click").on("click",function(event){
			thebox.find('.pm_window_icon').removeClass('pm_window_hide');
			event.stopPropagation();
			$(this).addClass('pm_window_hide');
			var bk = thebox.find('#'+self.overlay);
			var maxW=bk.outerWidth(),maxH=bk.outerHeight();
			if($(this).find('.fa-window-maximize').length>0){
				pane.css({"margin-left":-(maxW/2)+"px","margin-top":-(maxH/2)+"px","width":maxW+"px","height":maxH+"px"});
				var h=maxH-header_footer;
				thebox.find('#pm_echo_area').css({"height":h+"px","line-height":h+"px"});
			}else{
				var h=modal_height-header_footer;
				pane.css({"margin-left":-(modal_width/2)+"px","margin-top":-(modal_height/2)+"px","width":modal_width+"px","height":modal_height+"px"});
				thebox.find('#pm_echo_area').css({"height":h+"px","line-height":h+"px"});
			}
		});
		thebox.find('#btn_trial').off("click").on("click",function(event){
			self.close();
		});
		thebox.find('#btn_buy').off("click").on("click",function(event){
			self.close();
			location.href='/licence';
		});
		thebox.find('#'+self.overlay).off("click").on("click",function(event){self.close();});
		thebox.find('#pm_close_icon').off("click").on("click",function(event){self.close();});
	};
    $.fn.Popmember=function(options){
		var apopmember=new PopmemberObject(this,options);
		return apopmember;
    };