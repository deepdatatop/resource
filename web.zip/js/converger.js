	function ConvergerObject(element,options){
		this.outerID='';
		this.element=element;
		var defaults={
			token: '',
			i18n:{},
			uploadStr: 'Upload file:',
			dragDropStr: '<span><br><br>Drag & Drop Files...<br><br></span>',
			multiDragErrorStr: 'Multiple File Drag & Drop is not allowed.',
			extErrorStr: 'is not allowed. Allowed extensions: ',
			duplicateErrorStr: 'is not allowed. File already exists.',
			sizeErrorStr: 'is not allowed. Allowed Max size: ',
			uploadErrorStr: 'Upload is not allowed',
			maxFileCountErrorStr: ' is not allowed. Maximum allowed files are:',
			txt_tag: 'tag',
			txt_src: 'source',
			txt_size: 'size',
			txt_ext: 'extension',
			txt_remove: 'remove',
			txt_yes: 'Yes',
			txt_no: 'No',
			txt_removeornot: 'Remove',
			txt_sourcename: 'Source filename:',
			txt_accesspath: 'Access path:',
			txt_alreadycopied: 'Already copied to clipboard!'
		};
		this.id=0;
		this.source_name='';
		this.access_path='';
		this.file_format='';
		this.options=$.extend({},defaults,options);
    };
	ConvergerObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){	o[k]=o.i18n[k];}
		}
	};
	ConvergerObject.prototype.init=function(){
		this.i18n_options();
		var obj=this;
		var self=this.element;
		self.empty();
		var ss='<div class="content">';
		ss+='<span class="fileicon"></span>'
		ss+='<span class="cvg_empty"><i class="fa fa-2x fa-times-circle"></i></span>';
		ss+='<li><span>'+obj.options.txt_sourcename+'</span><span class="sourcename data"></span><i class="fa fa-clone copy"></i></li>';
		ss+='<li><span>'+obj.options.txt_accesspath+'</span><span class="accesspath data"></span><i class="fa fa-clone copy"></i></li></div>';
		ss+='<div class="fileuploader"></div><div id="c2c" class="copytoclipboard"></div>';
		self.append(ss);
		/*self.find('.copy').each(function(i){
			var cp=$(this);
			//---tipso
			cp.attr('data-tipso','复制');
			cp.tipso({useTitle:false,delay:0,background:'#4682B4',color:'#ffffff'});
			cp.off('mouseover mouseout');
			cp.tipso('show');
			var tm=setInterval(function(){
				cp.tipso('hide');cp.removeAttr('data-tipso');
				clearInterval(tm);
			},1000);	
			//---tipso			
		});*/
		new Clipboard('.copytoclipboard',{text: function(){return $('#c2c').text();}});
		self.find('.copy').on('click',function(){
			var cp=$(this);
			$('#c2c').text(cp.siblings('.data').text()).click();
			//---tipso
			cp.attr('data-tipso',obj.options.txt_alreadycopied);
			cp.tipso({useTitle:false,delay:0,background:'#4682B4',color:'#ffffff'});
			cp.tipso('show');
			var tm=setInterval(function(){
				cp.tipso('hide');cp.tipso('destroy');cp.removeAttr('data-tipso');
				clearInterval(tm);
			},1000);	
			//---tipso
		});
		self.find('.cvg_empty').on('click',function(){obj.empty();});
		var at='pdf,doc,docx,xls,xlsx,ppt,pptx';
		var uploadobj=self.find(".fileuploader").uploadFile({
			allowedTypes: at,
			fileCounterStyle: ". ",
			uploadStr: obj.options.uploadStr+'('+at+')',
			dragDropStr: obj.options.dragDropStr,
			multiDragErrorStr: obj.options.multiDragErrorStr,
			extErrorStr: obj.options.extErrorStr,
			duplicateErrorStr: obj.options.duplicateErrorStr,
			sizeErrorStr: obj.options.sizeErrorStr,
			uploadErrorStr: obj.options.uploadErrorStr,
			maxFileCountErrorStr: obj.options.maxFileCountErrorStr,
			url:"/file-upload",
			showStatusAfterSuccess:false,
			showDelete:true,
			showDownload:false,
			multiple:false,
			dragDrop:true,
			fileName:"up",
			maxFileCount:1,
			maxFileSize:50*1024*1024,
			formData: {owner: 'cvg',token: obj.options.token},
			onLoad:function(theobj) {},
			onSuccess: function (files, data, xhr, pd) {//files:local name, data:remote_name
				setTimeout(function(){pd.statusbar.hide();},1500);
				var content=self.find('.content');
				var tag='';if(files.length>0){tag=obj.extractFilename(files[0]);}
				obj.source_name=tag;
				obj.access_path='/u?n='+data;
				obj.file_format=obj.fileExt(obj.access_path);
				obj.modified();
				obj.refresh();
				uploadobj.selectedFiles=0;/*maxFileCount==1*/
			},
			deleteCallback: function (fname, pd){
				var filename='cvg_'+obj.options.token+'-'+$.md5(fname)+'.'+obj.fileExt(fname);//same as server filename rule
				$.post("/file-delete",{name:filename},function(resp,textStatus,jqXHR){pd.statusbar.hide();});
			}
		});
	};
	ConvergerObject.prototype.empty=function(){
		var obj=this;
		if(obj.access_path.length>0){
			$('body').YesnoAlert({
				yesText:obj.options.txt_yes,noText:obj.options.txt_no,
				doyes: function(id,action){
					obj.source_name='';
					obj.access_path='';
					obj.file_format='';
					obj.modified();
					obj.refresh();
				}
			}).show_alertpane('',obj.options.txt_removeornot,'remove');
		}		
	};
	ConvergerObject.prototype.modified=function(){
		this.options.onChange(this.outerID,this.getData());
	};
	ConvergerObject.prototype.extractFilename=function(src){
		var filename=src;
		var ss=src.split('/');
		var n=ss.length;
		if(n>0){	filename=ss[n-1];}
		return filename;
	};
	ConvergerObject.prototype.show=function(){
		this.element.show();		
	};
	ConvergerObject.prototype.hide=function(){
		this.element.hide();		
	};
	ConvergerObject.prototype.fileExt=function(filename){//use for fileuploader
		var extension = '';
		var ss = filename.split('.');
		if(ss.length>1){
			extension = ss[ss.length - 1];
		}
		return extension;	
	};
	ConvergerObject.prototype.filetypeIcon=function(times){//times: 1/2/3
		var icon='';/*class fti: file type icon*/
		var fat='';
		if(times>1){fat=' fa-'+times+'x';}
		var ext=this.file_format.toLowerCase();
		switch(ext){
			case 'doc':
			case 'docx':icon = '<i class="fti fa fa-file-word-o'+fat+'"></i>';break;
			case 'xls':
			case 'xlsx':icon = '<i class="fti fa fa-file-excel-o'+fat+'"></i>';break;
			case 'ppt':
			case 'pptx':icon = '<i class="fti fa fa-file-powerpoint-o'+fat+'"></i>';break;
			case 'pdf':icon = '<i class="fti fa fa-file-pdf-o'+fat+'"></i>';break;
			case 'wma':
			case 'mmf':
			case 'mp3':
			case 'mid':
			case 'rm':icon = '<i class="fti fa fa-file-audio-o'+fat+'"></i>';break;
			case 'avi':
			case 'rmvb':
			case 'mov':
			case 'qt':
			case 'asf':
			case 'flv':
			case 'ogg':
			case 'mpg':
			case 'mpe':
			case 'mpeg':
			case 'mlv':
			case 'm2v':
			case 'wmv':
			case 'mp4':icon = '<i class="fti fa fa-file-video-o'+fat+'"></i>';break;
			default:icon = '<i class="fti fa fa-file-o'+fat+'"></i>';break;
		}
		return icon;		
	};
	ConvergerObject.prototype.setOuterID=function(id){
		this.outerID = id;
	};
	ConvergerObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	ConvergerObject.prototype.parseTextData=function(txt){
		this.id=0;
		this.source_name='';
		this.access_path='';
		this.file_format='';
		if(txt.length>0){
			if(this.isObjectText(txt)){
				var dt=JSON.parse(txt);
				if(dt.hasOwnProperty('id')){
					this.id = dt['id'];
				}
				this.source_name=dt.sourcename;
				this.access_path=dt.accesspath;
				this.file_format=dt.fileformat;
			}
		}
	};
	ConvergerObject.prototype.refresh=function(){
		var content=this.element.find('.content');
		var fileuploader=this.element.find('.fileuploader');
		if(this.access_path.length>0){
			fileuploader.hide();
			content.find('.fileicon').empty().append(this.filetypeIcon(2));
			content.find('.sourcename').text(this.source_name);
			var href = window.document.location.href;
　　			var pathname = window.document.location.pathname;
　　			var server = href.substring(0, href.indexOf(pathname));
			content.find('.accesspath').text(server+this.access_path);
			content.css('display','inline-block');
		}else{
			content.hide();
			fileuploader.css('display','inline-block');
		}
	};
	ConvergerObject.prototype.getData=function(){
		var dt={sourcename:this.source_name,accesspath:this.access_path,fileformat:this.file_format};
		if(this.id>0){dt['id']=this.id;}
		return JSON.stringify(dt);
	};				
	ConvergerObject.prototype.setData=function(val){
		this.parseTextData(val);
		this.refresh();
		return this;
	};
    $.fn.Converger=function(options){
		var aconverger=new ConvergerObject(this,options);
		aconverger.init();
		return aconverger;
    };
