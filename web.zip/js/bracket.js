	function BracketObject(element,options){
		this.element=element;
		this.defaults={
			width: 150,
			value: '',
			ratio: 1,
			leftReplace: '[,［,{,﹛,【,〖,(,（,『,<,〈,‹', 
			rightReplace: '],］,},﹜,】,〗,),）,』,>,〉,›',
			leftBracket:  '〔',
			rightBracket: '〕',
			leftCaption:  '〔&nbsp;&nbsp;',
			rightCaption: '&nbsp;&nbsp;〕',
			wrapperClass: 'bracket-wrap',
			inputClass: 'str-input',
			leftClass: 'bracket-left',
			rightClass: 'bracket-right',
			deepClass: 'bracket-deep',
			onChange: function(val){}
		};
		this.value='';
		this.options=$.extend({},this.defaults,options);
    };
	BracketObject.prototype.setValue=function(v){
		this.element.find('input').val(v);
		this.value=v;
	};
	BracketObject.prototype.getValue=function(){
		return this.value;
	}
	BracketObject.prototype.init=function(){
		var obj=this;
		var self=this.element;
		var ratio=obj.options.ratio;
		if($('#bracket-css').length==0){
			var css='<style id="bracket-css" type="text/css">';
			css+='.'+obj.options.leftClass+':hover,.'+obj.options.rightClass+':hover{background: #d8d8d8;}';
			css+='.'+obj.options.leftClass+',.'+obj.options.rightClass+'{text-align:center;font-size:'+parseInt(80*ratio)+'%;}';
			css+='.'+obj.options.leftClass+'.'+obj.options.deepClass+',.'+obj.options.rightClass+'.'+obj.options.deepClass+'{background: #b3b3b3;}';
			css+='</style>';
			$(css).appendTo('head');
		}
		var wrapper = $('<div class="'+obj.options.wrapperClass+'"></div>');
		wrapper.css({"position": "relative", "display": "inline-block", "vertical-align": "top", "height": 32*ratio, "width": obj.options.width*ratio, "border": "1px solid #ccc", "border-radius": 6, "box-sizing": "border-box", "overflow": "hidden"});
		self.append(wrapper);
		var inputEdt = $('<input type="text" id="'+obj.options.inputClass+'" value="'+obj.options.value+'" class="'+obj.options.inputClass+'">');
		inputEdt.css({"height": 30*ratio, "width": "100%", "padding": "0 25px 0 12px", "font-size": (14*ratio)+"px", "line-height": (30*ratio)+"px", "background": "#fff", "box-shadow": "inset 0 1px 1px rgba(0,0,0,.075)", "box-sizing": "border-box", "border": "none"});
		var leftBtn = $('<span class="'+obj.options.leftClass+'">'+obj.options.leftCaption+'</span>');
		leftBtn.css({"position": "absolute", 'right': 0, 'top': 0, 'width': 25*ratio, "height": 15*ratio, "border-left": "1px solid #ccc", "box-sizing": "border-box", "cursor": "pointer"});
		var rightBtn = $('<span class="'+obj.options.rightClass+'">'+obj.options.rightCaption+'</span>')
		rightBtn.css({"position": "absolute", 'right': 0, 'bottom': 0, 'width': 25*ratio, "height": 15*ratio, "border-left": "1px solid #ccc", "box-sizing": "border-box", "cursor": "pointer"});
		wrapper.append(inputEdt).append(leftBtn).append(rightBtn);
		this.value=obj.options.value;
		leftBtn.on('mousedown', function(event){
			event.preventDefault();
			$(this).addClass(obj.options.deepClass);
			inputEdt.insertAtCaret(obj.options.leftBracket);
			var val=inputEdt.val();
			if(obj.value!=val){
				obj.value=val;
				obj.options.onChange(val);
			}
		}).on('mouseup', function(){$(this).removeClass(obj.options.deepClass)}).on('mouseleave', function(){$(this).removeClass(obj.options.deepClass)});
		rightBtn.on('mousedown', function(event){
			event.preventDefault();
			$(this).addClass(obj.options.deepClass);
			inputEdt.insertAtCaret(obj.options.rightBracket);
			var val=inputEdt.val();
			if(obj.value!=val){
				obj.value=val;
				obj.options.onChange(val);
			}
		}).on('mouseup', function(){$(this).removeClass(obj.options.deepClass)}).on('mouseleave', function(){$(this).removeClass(obj.options.deepClass)});
		inputEdt.on('paste',function(e){
			e.preventDefault();
			var clipboardData  = window.clipboardData || e.originalEvent.clipboardData;
			var txt=clipboardData.getData('text');
			var lr=obj.options.leftReplace.split(',');
			$.each(lr, function(i, v) {txt=txt.replaceAll(v,obj.options.leftBracket);});
			var rr=obj.options.rightReplace.split(',');
			$.each(rr, function(i, v) {txt=txt.replaceAll(v,obj.options.rightBracket);});
			$(this).insertAtCaret(txt);
			var val=$(this).val();
			if(obj.value!=val){
				obj.value=val;
				obj.options.onChange(val);
			}
		}).on('input',function(event){
			event.preventDefault();
			var val=$(this).val();
			if(obj.value!=val){
				obj.value=val;
				obj.options.onChange(val);
			}
		});
	};
	$.fn.extend({
		insertAtCaret: function(myValue){
			var $t=$(this)[0];
			if (document.selection) {
				this.focus();
				sel = document.selection.createRange();
				sel.text = myValue;
				this.focus();
			}
			else
			if ($t.selectionStart || $t.selectionStart == '0') {
				var startPos = $t.selectionStart;
				var endPos = $t.selectionEnd;
				var scrollTop = $t.scrollTop;
				$t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos, $t.value.length);
				this.focus();
				$t.selectionStart = startPos + myValue.length;
				$t.selectionEnd = startPos + myValue.length;
				$t.scrollTop = scrollTop;
			}
			else {
				this.value += myValue;
				this.focus();
			}
		}
	});
    $.fn.Bracket=function(options){
		var abracket=new BracketObject(this,options);
		abracket.init();
		return abracket;
    };
