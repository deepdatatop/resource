function SortlistObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		width: 400,
		checkbox: true,
  		identifier: 'product',
      	scene: 'issales',
      	language: '',
      	getdatalist_url: '/getdatalist',
		onChange: function(data){}/*{"checked":"3,1","items":[{"id":"3","ordinalposition":1},{"id":"1","ordinalposition":2}]}*/
	};
	this.roadmapids='0';
	this.options=$.extend({},this.defaults,options);
};
SortlistObject.prototype.setValue=function(rmi,val){//val: 1,5,3
    var self=this;
	this.roadmapids=rmi;
    var thebox=this.element;
    var dl=thebox.find('.drag-list').empty();
    $.getJSON(this.options.getdatalist_url,{idf:this.options.identifier,scene:this.options.scene,lid:this.options.language,rmi:rmi},function(m){
		if(m.status=="success"){//{"status":"success","totals":2,"data":[{"id":1,"name":"name"},{"id":3,"name":"price"}]} 
			if(m.totals>0){
    				var data=[],dtdt=[];
				var o={};
				var vv=val.split(',');
				for(var i=0;i<m.totals;i++){
					var dt=m.data[i];
					var id=dt.id.toString();
					if(vv.indexOf(id)==-1){
						dt.checked=false;
						dtdt.push(dt);
					}else{
              			o[id]=dt.name;
					}
				}
				for(var i=0,n=vv.length;i<n;i++){
					var id=vv[i];
					if(o.hasOwnProperty(id)){
						data.push({id:id,name:o[id],checked:true});
					}
				}
				var newdata=data.concat(dtdt);
				for(var j=0,n=newdata.length;j<n;j++){
					var dt=newdata[j];
					var ss='<li id="'+dt.id+'">';
					if(self.options.checkbox){
						ss+='<div class="switchuse yesno" style="margin-left:8px;display:inline-block">';
						ss+='<input class="switchcheck" type="checkbox"';
						if(dt.checked){ss+=' checked="checked"';}
						ss+='><label><i></i></label></div>';
					}
					ss+='<span class="title">'+dt.name+'</span><span class="drag-area">⇳</span></li>';
					dl.append(ss);
				}
				var li=dl.find('li');//https://github.com/vishalok12/jquery-dragarrange
				li.arrangeable({dragSelector: '.drag-area'});
				li.parent().on("drag.end.arrangeable", function(){
					self.modified();
				});
				if(self.options.checkbox){
					dl.find('.switchcheck').on('change',function(){
						self.modified();
					});
				}
			}
		}
	});
    return self;
};
SortlistObject.prototype.modified=function(){
	var self=this;
	var items=[],checked=[];
	var result={};
	var op=1;
	this.element.find('li').each(function(){
		var li=$(this);
		var id=li.attr('id');
		items.push({id:id,ordinalposition:op++});
		if(self.options.checkbox){
			if(li.find('.switchcheck').prop('checked')){
				checked.push(id);
			}
		}
	});
	if(self.options.checkbox){
		result['checked']=checked.join(',');
	}
	result['items']=items;
    self.options.onChange(JSON.stringify(result));
};
SortlistObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){	o[k]=o.i18n[k];}
	}
};
SortlistObject.prototype.init=function(){
	this.i18n_options();
	var thebox=this.element;
    thebox.append('<ul class="drag-list"></ul>');
};
$.fn.Sortlist=function(options){
	var alist=new SortlistObject(this,options);
	alist.init();
	return alist;
};