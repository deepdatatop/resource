;(function($){
	var AutoRowsNumbers = function (element, config){
	    this.$element = $(element);
	    this.$group = $('<div/>', { 'class': 'textarea-group' });
	    this.$ol = $('<div/>', { 'class': 'textarea-rows' });
	    this.$wrap = $('<div/>', { 'class': 'textarea-wrap' });
	    this.$group.css({
		    	"width" : this.$element.outerWidth(true) + 'px',
		    	"display" : config.display
	    });
	    this.$ol.css({
		    	"color" : config.color,
		    	"width" : config.width,
		    	"height" : this.$element.height() + 'px',
		    	"font-size" : this.$element.css("font-size"),
		    	"line-height" : this.$element.css("line-height"),
		    	"position" : "absolute",
		    	"overflow" : "hidden",
		    	"margin" : "0",
		    	"padding-right" : "0",
		    	"text-align": "center",
			"font-family": this.$element.css("font-family")
	    });
	    this.$wrap.css({
		    	"padding" : ((this.$element.outerHeight() - this.$element.height())/2) + 'px 0',
		    	"background-color" : config.bgColor,
		    	"position" : "absolute",
		    	"width" : config.width,
		    	"height" : this.$element.height() + 'px'
	    });
	    this.$element.css({
		    	"white-space" : "pre",
		    	"resize": "none",
		    	"margin-left" : (parseInt(config.width) -  parseInt(this.$element.css("border-left-width"))) + 'px',
		    	"width": (this.$element.width() - parseInt(config.width)) + 'px'
	    });
	}

	AutoRowsNumbers.prototype = {
		constructor: AutoRowsNumbers,

		init : function(){
			var that = this;
			that.$element.wrap(that.$group);
			that.$ol.insertBefore(that.$element);
			this.$ol.wrap(that.$wrap)
			that.$element.on('keydown',{ that: that }, that.inputText);
			that.$element.on('scroll',{ that: that },that.syncScroll);
			that.inputText({data:{that:that}});
		},

		inputText: function(event){
			var that = event.data.that;

			setTimeout(function(){
				var value = that.$element.val();
				value.match(/\n/g) ? that.updateLine(value.match(/\n/g).length+1) : that.updateLine(1);
				that.syncScroll({data:{that:that}});
			},0);
		},

		updateLine: function(count){
			var that = this;
			that.$element;
			that.$ol.html('');
			//that.$ol.empty();

			for(var i=1;i<=count;i++){
				that.$ol.append("<div>"+i+"</div>");
			}
		},

		syncScroll: function(event){
			var that = event.data.that;
			that.$ol.children().eq(0).css("margin-top",  -(that.$element.scrollTop()) + "px");
		}
	}

	$.fn.CodeArea = function(option){
		var config = {};
		var option = arguments[0] ? arguments[0] : {};
		var txt=$(this).text();
		//$(this).text(option.text);
		//var nn=option.text.match(/\n/g);
		var nn=txt.match(/\n/g);
		var lines=1;
		if(nn!==null){
			lines=nn.length+1;
			var v=lines.toString();
			option.width = (v.length*10)+'px';
		}
		var height=$(this).css('height');
		if(height=='0px'){
			var lineheight=parseInt($(this).css('line-height'));
			$(this).css('height',(lineheight*lines)+'px');
		}
		
		config.color = option.color ? option.color : "#fff";
		config.width = option.width ? option.width : "30px";
		config.bgColor = option.bgColor ? option.bgColor : "steelblue";
		config.display = option.display ? option.display : "block";
		
		return this.each(function () {
			var $this = $(this),arn = $this.data('arn');
			if (!arn){ $this.data('arn', (arn = new AutoRowsNumbers($this, config))); }
			if(typeof option === 'string'){return false;}else{arn.init();}
	    });
	}
})(jQuery)
//view.html not apply this object.
/*$("#ta").CodeArea({
    text: txt,
    wholeheight: true,
	bgColor: "steelblue",color: "#fff",
	display: "inline-block"
});*/