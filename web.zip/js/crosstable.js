	function CrosstableObject(element,options){
		this.element=element;
		this.defaults={
			title: 'cross table',
			width: 200,
			height: 100,
			pane_zindex: 100,
			horizontal: [/*0,2*/],
			vertical: [/*3,1*/],	
			dimensions: [/*
				{
					"id": 115,
					"name": "color",
					"valueenum": [
						{"id":1,"valuetext": "red"},
						{"id":2,"valuetext": "blue"},
						{"id":3,"valuetext": "green"}
					]
				},
				{
					"id": 354,
					"name": "size",
					"valueenum": [
						{"id":4,"valuetext": "37"},
						{"id":5,"valuetext": "38"},
						{"id":6,"valuetext": "39"}
					]					
				},
				{
					"id": 777,
					"name": "package",
					"valueenum": [
						{"id":7,"valuetext": "bag"},
						{"id":8,"valuetext": "box"}
					]					
				},
				{
					"id": 787,
					"name": "material",
					"valueenum": [
						{"id":9,"valuetext": "wood"},
						{"id":10,"valuetext": "rubber"}
					]						
				}
			*/],
			celltext: '{}',
			txt_yes: 'Yes',
			txt_no: 'No',
			txt_cell: 'cell text:',
			txt_setall: 'Set all',
			txt_empty: '清空',
			txt_emptyornot: 'Empty table',
			txt_verticalproperties: 'Vertical properties:',
			txt_cellcaption: 'price',
			cell_format: '$##,###.00',
			
			noborder: true,

			onChange: function(data){}
		};
		this.options=$.extend({},this.defaults,options);
		this.isModified=false;
		this.toolbarheight=32;
		this.tbl_colModel="";
		this.tbl_dataModel="";
		this.tbl_mergeCells="";
		this.celldata={};
		this.rowIDs=[];
		this.colIDs=[];
		this.vert_dimes=1;/*vertical properties*/
		this.dim_ids=[];
		this.dim_idx={};
		this.PqGrid=new Object();
    };
	CrosstableObject.prototype.setClassCSS=function(classname,cssvalue){//sample:setClassCSS('aclass','font-size:24px;color: green;');
		var id='crosstable-'+classname;
		var cssContainer = $('#'+id);
	    if(cssContainer.length == 0){
	        cssContainer = $('<style id="'+id+'"></style>');
	        cssContainer.appendTo($('head'));
	    }
		cssContainer.empty().append('.'+classname+ ' {'+cssvalue+'}');
	};
	CrosstableObject.prototype.addHTitle=function(pid,di,cm){
		var nd=di.length;
		var sdi=[];
		if(nd>1){sdi=di.slice(1);}
		var idx=di[0];/*dimension idx list*/
		var dim=this.options.dimensions[idx];
		for(var i=0,n=dim.valueenum.length;i<n;i++){
			var v=dim.valueenum[i];
			var cid=v.id;
			if(pid.length>0){cid=pid+'-'+cid;}
			if(nd>1){
				var scm=[];
				this.addHTitle(cid,sdi,scm);
				cm.push({title:v.valuetext,align:"center",colModel:scm});
			}else{
				this.colIDs.push(cid);
				cm.push({title:v.valuetext,width:100,align:"center",format:this.options.cell_format});
			}
		}	
	};
	CrosstableObject.prototype.addVTitle=function(x,y,pid,pnm,di,dt,mc){//mc{ r1: 10, c1: 7, rc: 400, cc: 4, style: 'background:#eee;' }
		var rows=0;
		var nd=di.length;
		var sdi=[];
		if(nd>1){sdi=di.slice(1);}
		var idx=di[0];/*dimension idx list*/
		var dim=this.options.dimensions[idx];
		for(var i=0,n=dim.valueenum.length;i<n;i++){
			var rws=1;
			var v=dim.valueenum[i];
			var cid=v.id;
			if(pid.length>0){cid=pid+'-'+cid;}
			if(nd>1){
				var top=y+rows;
				rws=this.addVTitle(x+1,top,cid,v.valuetext,sdi,dt,mc);
				if(rws>1){
					mc.push({r1:top,c1:x,rc:rws,cc:1});
				}
			}else{
				this.rowIDs.push(cid);
				var rw=[];
				for(var j=0;j<x;j++){rw.push('');}
				rw.push(v.valuetext);
				var oo=this.getLatitude(cid);
				if(oo.length>2){
					if(this.vert_dimes==this.options.dimensions.length){
						var key=this.mergeLongitude(oo,'');
						var val='';
						if(this.celldata.hasOwnProperty(key)){
							val=this.celldata[key];
						}
						rw.push(val);
					}else{
						var m=this.colIDs.length;
						for(var j=this.vert_dimes;j<m;j++){
							var key=this.mergeLongitude(oo,this.colIDs[j]);
							var val='';
							if(this.celldata.hasOwnProperty(key)){
								val=this.celldata[key];
							}
							rw.push(val);
						}
					}
				}
				dt.push(rw);
			}
			if(pid.length>0&&i==0){
				var rw=dt[y+rows];
				rw[x-1]=pnm;
			}
			rows += rws;
		}
		return rows;
	};
	CrosstableObject.prototype.makeColModelandData=function(){
		this.colIDs=[];
		this.rowIDs=[];
		var def_colModel=[];
		var horizontal=this.options.horizontal;
		var vertical=this.options.vertical;
		var nh=horizontal.length;
		var nv=vertical.length;
		for(var i=0;i<nv;i++){
			var dim=this.options.dimensions[vertical[i]];
			def_colModel.push({title:dim.name,width:100,align:"center",editable:false});
			this.colIDs.push('');
		}
		if(nh>0){
			this.addHTitle('',horizontal,def_colModel);
		}else{
			def_colModel.push({title:this.options.txt_cellcaption,width:150,align:"center"});
			this.colIDs.push('');
		}
		var data=[];
		var def_mergeCells=[];
		if(nv>0){
			this.addVTitle(0,0,'','',vertical,data,def_mergeCells);
		}
		this.tbl_dataModel=JSON.stringify({data:data});
		this.tbl_colModel=JSON.stringify(def_colModel);
		this.tbl_mergeCells=JSON.stringify(def_mergeCells);
	};
	CrosstableObject.prototype.setGrid=function(){
		var self=this;
		self.makeColModelandData();
		self.PqGrid.pqGrid("option",{"freezeCols":self.vert_dimes,
			"colModel":JSON.parse(self.tbl_colModel),
			"mergeCells":JSON.parse(self.tbl_mergeCells),
			"dataModel":JSON.parse(self.tbl_dataModel)});
		self.PqGrid.pqGrid("refreshDataAndView");
	};
	CrosstableObject.prototype.init=function(){
		var self=this;
		var thebox=this.element;
		thebox.empty();
		var tb_height=self.toolbarheight-1;
		var txt='<div id="a_toolbar" style="position:relative;width:100%;height:'+tb_height+'px;line-height:'+tb_height+'px;overflow:hidden;background-color:#f9f9f9;border-bottom:1px solid #dcdcdc;">';
		txt+='<div style="float:left;">'+self.options.txt_verticalproperties+'</div>';
		txt+='<div style="float:left;" id="dimes"></div>';
		txt+='<div style="float:left;margin-left:4px;" id="dime_captions"></div>';
		txt+='<div style="float:left">'+self.options.txt_cell+'</div>';
		txt+='<button id="update" style="display:inline-block">'+self.options.txt_setall+'</button>';
		txt+='<div style="display:inline-block;width:48px;height:'+tb_height+'px;line-height:'+tb_height+'px;text-align:center">';
		txt+='<i id="tableempty" class="fa fa-lg fa-trash-o"></i>';
		txt+='&nbsp;<i id="tablesave" class="fa fa-lg fa-save unmodified"></i>';
		txt+='</div></div>';
		txt+='<div class="pqgrid"';
		var style='border:solid 1px #f00;';
		if(self.options.noborder){style='border:none;';}
		txt+=' style="'+style+'"></div>';
		thebox.append(txt);
		txt='';
		self.vert_dimes=self.options.vertical.length;
		$.each(self.options.dimensions,function(i,o){self.dim_idx[o.id]=i;});
		var idxidx=self.options.vertical.concat(self.options.horizontal);
		$.each(idxidx,function(i,idx){
			var o=self.options.dimensions[idx];
			self.dim_ids.push(o.id);
			txt+='<i class="fa fa-chevron-circle-right dim-lnk"></i><span id="dim'+i+'" class="dim-cap';
			if(i<self.vert_dimes){txt+=' vert';}
			txt+='">'+o.name+'</span>';
		});
		thebox.find('#dime_captions').empty().append(txt);
		thebox.find('#dimes').Spinner({width:60,min:1,max:self.options.dimensions.length,onChange: function(val){
			var td=self.getTabledata();
			self.celldata=JSON.parse(td);
			self.options.horizontal=[];self.options.vertical=[];
			var k=parseInt(val);
			self.vert_dimes=k;
			var dc=thebox.find('#dime_captions');
			for(var i=0,n=self.dim_ids.length;i<n;i++){
				var idx=self.dim_idx[self.dim_ids[i]];
				if(i<k){	self.options.vertical.push(idx);}else{self.options.horizontal.push(idx);}
				var o=dc.find('#dim'+i),vn='vert';
				if(o.hasClass(vn)){
					if(i>=k){o.removeClass(vn);}
				}else{
					if(i<k){	o.addClass(vn);}
				}
			}
			self.setGrid();
		}}).setValue(self.vert_dimes);
		
		self.makeColModelandData();
        var pqgrid_option = {
			width: '100%',
			height: '200',
			showTop: true,
			showTitle: false,
			showBottom: false,
			collapsible: false,
			dragColumns: { enabled: false },
			showHeader: true,
			roundCorners: false,
			rowBorders: true,
			columnBorders: true,                                    
			selectionModel: { type: 'cell' },
			numberCell: { show: false },
			stripeRows: false,
			colModel: JSON.parse(self.tbl_colModel),
			dataModel: JSON.parse(self.tbl_dataModel),
			mergeCells: JSON.parse(self.tbl_mergeCells),
			freezeCols: self.options.vertical.length
        };
		self.PqGrid = thebox.find('.pqgrid').pqGrid(pqgrid_option);
		self.PqGrid.pqGrid({
			change: function( event, ui ) {self.modified();}
		});
		self.resize();

		thebox.find('#update').on('click',function(){
			//alert(JSON.stringify(self.colIDs));
			//alert(JSON.stringify(self.rowIDs));
			
		});
		thebox.find('#tablesave').on('click',function(){
			var tabledata=self.getTabledata();
			self.options.onChange(tabledata);
			self.celldata=JSON.parse(tabledata);
			self.clearmodified();
		});
		thebox.find('#tableempty').on('click',function(){
			$('body').YesnoAlert({
				zindex:self.options.pane_zindex+1000,
				yesText:self.options.txt_yes,noText:self.options.txt_no,
					doyes: function(id,action){
						var data=[];
						var dt=self.PqGrid.pqGrid("option","dataModel.data");
						for(var i=0,n=dt.length;i<n;i++){
							var rw=dt[i],row=[];
							var m=self.options.vertical.length;
							if(rw.length<m){m=rw.length;}
							for(var j=0;j<m;j++){row.push(rw[j]);}
							data.push(row);
						}
						self.PqGrid.pqGrid("option",{"dataModel":{"data":data}});
						self.PqGrid.pqGrid("refreshDataAndView");
						self.modified();
					}
			}).show_alertpane('',self.options.txt_emptyornot+'?','empty');		
		});		
	};
	CrosstableObject.prototype.show=function(){
		this.element.show();
	};
	CrosstableObject.prototype.hide=function(){
		this.element.hide();
	};
	CrosstableObject.prototype.resize=function(){
		try{
			this.PqGrid.pqGrid("option",{"width":"100%","height":"100%-"+this.toolbarheight});
		}catch(error){
			alert(error);
		}
		this.PqGrid.pqGrid("refresh");
	};
	CrosstableObject.prototype.modified=function(){
		this.isModified=true;
		this.element.find('#tablesave').removeClass('unmodified').addClass('modified');
	};
	CrosstableObject.prototype.clearmodified=function(){
		this.isModified=false;
		this.element.find('#tablesave').removeClass('modified').addClass('unmodified');
	};
	CrosstableObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	CrosstableObject.prototype.parseText=function(txt){
		var obj=this;
	};
	CrosstableObject.prototype.refresh=function(){
		var obj=this;
		obj.PqGrid.pqGrid("refreshDataAndView");
	};
	CrosstableObject.prototype.setData=function(val){
		this.celldata=JSON.parse(val);
		this.setGrid();
		return this;
	};
	CrosstableObject.prototype.getLatitude=function(rowpath){
		var o={};
		var rowids=rowpath.split('-');
		var n=this.options.vertical.length;
		if(n==rowids.length){
			for(var i=0;i<n;i++){
				var v=this.options.vertical[i];
				o[this.options.dimensions[v].id]=rowids[i];
			}
		}
		return JSON.stringify(o);
	};
	CrosstableObject.prototype.mergeLongitude=function(olatitude,colpath){
		var kvkv=[];
		var o=JSON.parse(olatitude);
		if(colpath.length==0){
			for(let k in o){kvkv.push(k+'-'+o[k]);}
		}else{
			var colids=colpath.split('-');
			var n=this.options.horizontal.length;
			if(n==colids.length){
				for(var i=0;i<n;i++){
					var h=this.options.horizontal[i];
					o[this.options.dimensions[h].id]=colids[i];
				}				
				for(let k in o){kvkv.push(k+'-'+o[k]);}
			}
		}
		return kvkv.sort().join(';');
	};						
	CrosstableObject.prototype.getTabledata=function(){
		var dt={};/*key:'115-1;354-4;777-7;787-9' value:10.88*/
		/*key format:dimension1.id-dimension1.valueenum[x].id;dimension2.id-dimension2.valueenum[y].id*/
		var data=this.PqGrid.pqGrid("option","dataModel.data");
		var data_rows=data.length;
		for(var i=0,n=this.rowIDs.length;i<n;i++){
			if(i<data_rows){
				var oo=this.getLatitude(this.rowIDs[i]);
				if(oo.length>2){
					var row=data[i];
					var row_cells=row.length;
					if(this.vert_dimes==this.options.dimensions.length){
						var key=this.mergeLongitude(oo,'');
						var value='';
						if(row_cells==(this.vert_dimes+1)){
							value=row[row_cells-1];
						}
						dt[key]=value;
					}else{
						var m=this.colIDs.length;
						for(var j=this.vert_dimes;j<m;j++){
							var key=this.mergeLongitude(oo,this.colIDs[j]);
							var value='';
							if(j<row_cells){	value=row[j];}
							dt[key]=value;
						}
					}
				}
			}
		}
		return JSON.stringify(dt);
	};
    $.fn.Crosstable=function(options){
		var atable=new CrosstableObject(this,options);
		atable.init();
		return atable;
    };