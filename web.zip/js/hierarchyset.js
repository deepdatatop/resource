	function HierarchySetObject(element,options){
		this.element=element;
		var defaults={
			name:'hs',
			i18n:{},
			txt_yes: 'Yes',
			txt_no: 'no',
			txt_emptyornot: 'Empty all content?',
			txt_packet: 'Packet:',
			txt_documentadded: 'Document already added!',
			txt_inputlabel: 'Please input label text',
			txt_catalogue: 'catalogue item',
			txt_packetemptyhint: 'The file packet is empty, please use [<i class="fa fa-search icon"></i>Search] function to <i class="fa fa-plus-square icon"></i> add file in below window<br>or use top-right corner <i class="fa fa-plus-circle icon"></i> button to add directory item.',
/*			exceedcontainerlimit: 'quantity exceed limit:',
			urlduplicated: 'image URL duplicated!',
			codeduplicated: 'code text duplicated!',
			historyStr: 'History',
			linkStr: 'PicURL',
			frequentStr: 'frequent',
			textStr: 'code',
			linkplaceholderStr: 'Input text and press enter key to submit',
			localStr: 'Local',
			selectedStr: 'Selected',*/
			/*txt_tag: 'tag',
			txt_src: 'source',
			txt_size: 'size',
			txt_ext: 'extension',
			txt_operation: 'operation',
			txt_choose: 'choose',
			txt_remove: 'remove',
			txt_emptylist: 'Empty list?',
			txt_srcduplicated: 'Duplicate appendix source, updated.',*/
			txt_removeornot:'Remove',
			txt_descendant:'and all descendant',
			onChange:function(){},
			readTreeset:function(){return {Code:'200',Msg:'no data'};},
			saveHierarchyset: function(s_new,s_rmv,s_par,s_pos,s_pts,s_cts){return {Code:'200',Msg:'not save'};},
			token:'',
			lr_splitter_width:5,
			tb_splitter_height:5,
			min_right_width:500,
			min_bottom_height:320
		};
		this.options=$.extend({},defaults,options);
		this.isModified=false;
		this.inEditing=false;
		this.DocumentID=new Object();
		this.NodeType=new Object();
		this.NU_parent=new Object();
		this.NU_position=new Object();
		this.NU_content=new Object;
		this.TreeSet=new Object();
		this.Pool=new Object();
    };
	HierarchySetObject.prototype.string2Json=function(s){   
	    var newstr = "";  
	    for (var i=0; i<s.length; i++) {  
	        c = s.charAt(i);       
	        switch (c) {       
	            /*case '\"':       
	                newstr+="\\\"";       
	                break;*/   
	            case '\\':       
	                newstr+="\\\\";       
	                break;       
	            case '/':       
	                newstr+="\\/";       
	                break;       
	            case '\b':       
	                newstr+="\\b";       
	                break;       
	            case '\f':       
	                newstr+="\\f";       
	                break;       
	            case '\n':       
	                newstr+="\\n";       
	                break;       
	            case '\r':       
	                newstr+="\\r";       
	                break;       
	            case '\t':       
	                newstr+="\\t";       
	                break;       
	            default:       
	                newstr+=c;       
	        }  
	   }  
	   return newstr;       
	};
	HierarchySetObject.prototype.addDocument=function(id,txt){
		this.TreeSet.newdocument(id,txt);
	};
	HierarchySetObject.prototype.createEditor=function(){
		var self=this;
		var thebox=this.element;
		var ss = '<div id="hierarchytoolbar">';
			ss += '<div style="width:90%;display:inline-block;">';
			ss += '<span>&nbsp;'+self.options.txt_packet+'</span>';
			ss += '<span class="fa-stack hs_empty"><i class="fa fa-circle-thin fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x"></i></span>';
			ss += '<span>&nbsp;&nbsp;<i class="fa fa-angle-double-left fa-2x hs_collapseall"></i></span>';
			ss += '<span>&nbsp;<i class="fa fa-angle-double-right fa-2x hs_expandall"></i></span>';
			ss += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
			ss += '<span class="title">'+$('.unique_input').val()+'</span>';
			ss += '</div>';
			ss += '<div style="display:inline-block;float:right">';
			ss += '<span><i class="fa fa-floppy-o fa-2x dt_save"></i>&nbsp;</span>';/*control in form.js*/
			ss += '<span><i class="fa fa-compress fa-2x hs_hide"></i>&nbsp;&nbsp;</span>';
			ss += '</div>';
			ss += '</div>';//--hierarchytoolbar
			ss += '<div id="popup"><div class="addicon"></div>';
			ss += '<div class="left_block">';
			ss += '<div id="top_block" class="top_block"></div>';
			ss += '<div id="tb_splitter"></div>';
			ss += '<div id="pool" class="bottom_block"></div>';
			ss += '</div>';
			ss += '<div id="lr_splitter"></div>';
			ss += '<div class="right_block">';
			ss += '</div></div>';//--popup
		thebox.append(ss);
			
		var i_o=new Array();
		var nt=new Object();
		var ct=new Object();
		var m=self.options.readTreeset();
		if(m.Code=="100"){
			for(var i=0;i<m.Nitem;i++){
				var v=m.Items[i];//type itemT struct {Id int,Pid int,Did int,Caption string}
				var nodetype=v.Did>0?2:1;	//1:catalogue 2:document
				nt[v.Id]=nodetype;
				if(v.Did>0){	ct[v.Did]=v.Id;}
				var label=self.typeIcon('ti',nodetype);
				if(v.Caption.length>0){
					label+='&nbsp;'+$.base64.decode(v.Caption);
				}
				i_o.push({value:v.Id.toString(),parent:v.Pid.toString(),label:label});
			}
		}else{
			alert(m.Msg);
		}
		self.NodeType=nt;
		self.DocumentID=ct;
			
		self.Pool=thebox.find('#pool').Pool({
			entity: 'document',//待上层参数化
			usedID: self.DocumentID,
			onAdd: function(id,txt){
				if(self.DocumentID.hasOwnProperty(id)){
					alert(txt_documentadded);
				}else{self.addDocument(id,txt);}
			}
		});

		self.TreeSet=thebox.find('#top_block').TreeSet({
			self_hierarchy:true,
			item_option:i_o,
			node_type:self.NodeType,
			txt_yes:self.options.txt_yes,
			txt_no:self.options.txt_no,
			txt_removeornot:self.options.txt_removeornot,
			txt_descendant:self.options.txt_descendant,
			txt_inputlabel:self.options.txt_inputlabel,
			txt_catalogue:self.options.txt_catalogue,
			txt_packetemptyhint:self.options.txt_packetemptyhint,
			//onChange: function(id,val){self.focusParagraph(id);},//onSelChange
			onEmpty: function(){self.empty();},
			onNodetypeMount: function(id,ntype){self.setNodetype(id,ntype);},
			onParentChange: function(id,pid){self.setParent(id,pid);},
			onNewItem: function(id,elderid,newid,data,caption){self.newItem(id,elderid,newid,data,caption);},
			onSplitItem: function(id,newid,data){self.splitItem(id,newid,data);},
			onRemoveItem: function(id){self.removeItem(id);},
			onReleaseUsed: function(usedids){self.releaseUsed(usedids);},
			onCaptionChange: function(id,caption){self.setCaption(id,caption);},
			onMoveup: function(id){self.moveupItem(id);},
			onMovedown: function(id){self.movedownItem(id);},
			onUpgrade: function(id){self.upgradeItem(id);},
			onDowngrade: function(id){self.downgradeItem(id);},
			onPositionChange: function(id,children){self.setPosition(id,children);}
			/*onAppendText: function(pid,newid,text){self.appendText(pid,newid,text);}*/
		});
		self.bindLRSplitter(document.getElementById('lr_splitter'));
		self.bindTBSplitter(document.getElementById('tb_splitter'));
		self.bindToolBarEvent();
		self.bindResizeEvent();
		self.bindAddiconEvent();
		thebox.find('.bodyview').addClass('editorloaded');
	};
	HierarchySetObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	HierarchySetObject.prototype.init=function(){
		this.i18n_options();
		var self=this;
		var thebox=this.element;
		thebox.empty();
		var ss = '<div class="hierarchysetbar">';
		ss += '<i class="fa fa-pencil-square-o fa-2x hs_edit"></i>';
		ss += '<span>&nbsp;</span>';
		ss += '<i class="fa fa-angle-double-up fa-2x hs_viewcollapseall"></i>';
		ss += '<span>&nbsp;</span>';
		ss += '<i class="fa fa-angle-double-down fa-2x hs_viewexpandall"></i>';
		ss += '<span>&nbsp;</span>';
		ss += '</div>';
		ss += '<div class="bodyview"></div>';
		thebox.append(ss);
		self.bindExpandCollapseEvent();
		thebox.find('.hs_edit').on('click',function(){
			if(!thebox.find('.bodyview').hasClass('editorloaded')){
				self.createEditor();
			}else{
				thebox.find('#hierarchytoolbar').show();
				thebox.find('#popup').show();
			}
			self.inEditing=true;
			self.windowSet();
			//self.TreeSet.defaultFocus();
		});
    };
/*remove
	HierarchySetObject.prototype.showDocumentID=function(){
		var self=this;
		var ss=new Array();
		for(var did in self.DocumentID){
			ss.push(did+'='+self.DocumentID[did]);
		}
		alert(ss.join());		
	};*/
	HierarchySetObject.prototype.empty=function(){
		this.NU_parent={};
		this.NU_position={};
		this.NU_content.length=0;
		for(var did in this.DocumentID){	delete this.DocumentID[did];	}//because used in pool,so can not use this.DocumentID={}
		this.element.find('.bodyview').find('#cld0').empty();
		this.Pool.refresh();
		this.modified();
	};
	HierarchySetObject.prototype.moveupItem=function(id){
		var itm=this.element.find('.bodyview').find('#'+id);
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		var pre = itm.prev();
		var prc = itm.prev();
		if( prc.length>0 ){
			if(prc.attr('class')=='children'){
				pre = prc.prev();
			}else{prc.length=0;}
		}
		if(pre.length>0){
			var ppre=pre.prev();
			itm.insertBefore(pre);
			if(cld.length>0){
				cld.insertBefore(pre);
			}
		}
		this.modified();
	};
	HierarchySetObject.prototype.movedownItem=function(id){
		var itm=this.element.find('.bodyview').find('#'+id);
		var nxt = itm.next();
		var cld = itm.next();
		if( cld.length>0 ){
			if(cld.attr('class')=='children'){
				nxt = cld.next();
			}else{cld.length=0;}
		}
		if(nxt.length>0){
			var ncld=nxt.next();
			var nnxt=nxt.next();
			if( ncld.length>0 ){
				if(ncld.attr('class')=='children'){
					nnxt = ncld.next();
				}else{ncld.length=0;}
			}
			var np=ncld;
			if(np.length==0){np=nxt;}
			if(cld.length>0){cld.insertAfter(np);}
			itm.insertAfter(np);
		}
		this.modified();
	};
	HierarchySetObject.prototype.refreshNOCtag=function(itm){
		if(itm.attr('id')!='0'){
			var noc=0;
			var cld=itm.next();
			if(cld.length>0){
				if(cld.attr('class')=='children'){
					noc=cld.children('div.hs_item').length;
				}
			}
			itm.children('span.noc').remove();
			if(noc>0){
				itm.append('<span class="noc">&nbsp;('+noc+')</span>');
			}
		}
	};
	HierarchySetObject.prototype.incitemdepth=function(itm){
		var depth=parseInt(itm.attr('depth'))+1;
		itm.attr('depth',depth.toString());
		itm.children('i.ef').after('<div class="indent"></div>');
	};
	HierarchySetObject.prototype.incdepth=function(block){
		var self=this;
		block.find('div.hs_item').each(function(){
			self.incitemdepth($(this));
		});
	};
	HierarchySetObject.prototype.decitemdepth=function(itm){
		var depth=parseInt(itm.attr('depth'))-1;
		itm.attr('depth',depth.toString());
		itm.children('.indent:first').remove();
	};
	HierarchySetObject.prototype.decdepth=function(block){
		var self=this;
		block.find('div.hs_item').each(function(){
			self.decitemdepth($(this));
		});
	};

	HierarchySetObject.prototype.upgradeItem=function(id){
		var self=this;
		var itm=this.element.find('.bodyview').find('#'+id);
		if(parseInt(itm.attr('depth'))>1){
			var cld=itm.next();
			if( cld.length>0 ){
				if( cld.attr('class')!='children' ){
					cld.length=0;
				}
			}
			var pcld=itm.parent();
			var pitm=pcld.prev();
			//self.setParent(id,pcld.parent().attr('id').replace('cld',''));
			if(cld.length>0){
				cld.insertAfter(pcld);
				self.decdepth(cld);
			}
			self.decitemdepth(itm);
			itm.insertAfter(pcld);
			if(pcld.children().length==0){
				pitm.find('i.e-c').remove();
				pcld.remove();
			}
			self.refreshNOCtag(pitm);
			pcld=pitm.parent();
			pitm=pcld.prev();
			self.refreshNOCtag(pitm);
			self.modified();
		}
	};	
	HierarchySetObject.prototype.downgradeItem=function(id){
		var self=this;
		var itm=this.element.find('.bodyview').find('#'+id);
		var pcld=itm.parent();
		var pitm=pcld.prev();
		var pre=itm.prev();
		var pcd=itm.prev();
		if( pcd.length>0 ){
			if( pcd.attr('class')=='children' ){
				pre = pcd.prev();
			}else{pcd.length=0;}
		}
		var cld=itm.next();
		if( cld.length>0 ){
			if( cld.attr('class')!='children' ){cld.length=0;}
		}
		if(pre.length>0){
			if(pcd.length==0){
				if(pre.find('i.e-c').length==0){pre.append('<i class="fa fa-angle-up e-c"></i>');self.bindItemECEvent(pre);}
				pre.after('<div class="children" id="cld'+pre.attr('id')+'"></div>');
				pcd=pre.next();
			}
			self.incitemdepth(itm);
			itm.appendTo(pcd);
			if(cld.length>0){self.incdepth(cld);cld.appendTo(pcd);}
			//self.setParent(id,pre.attr('id'));
			self.refreshNOCtag(pitm);
			self.refreshNOCtag(pre);
		}
		self.modified();
	};
	HierarchySetObject.prototype.initBodyview=function(){
		var thebox=this.element;
		var bodyview=thebox.find('.bodyview');
		var itm=bodyview.find('#0');
		if(itm.length==0){
			var tt='<div class="hs_item" id="0" depth="0" style="height:0px"></div>';
			tt+='<div class="children" id="cld0"></div>';
			bodyview.append(tt);
		}
		return bodyview;
	};
	HierarchySetObject.prototype.setCaption=function(id,caption){
		this.NU_content[id]=caption;//caption is base64.encoded
		var thebox=this.element;
		var itm=thebox.find('.bodyview').find('#'+id);
		if(itm.length>0){
			itm.find('span.hs_catalogue').text(caption);
		}
		this.modified();
	};
	HierarchySetObject.prototype.releaseUsed=function(usedids){
		var self=this;
		var ids=usedids.split(',');
		for(var did in self.DocumentID){
			var id=self.DocumentID[did].toString();
			if($.inArray(id,ids)>=0){
				delete self.DocumentID[did];
			}
		}
		self.Pool.refresh();
	};
	HierarchySetObject.prototype.typeIcon=function(cls,nodetype){
		var icon='';
		switch(nodetype){
			case 1:icon = '<i class="'+cls+' fa fa-folder-open-o"></i>';break;//fa-folder-o
			case 2:icon = '<i class="'+cls+' fa fa-file-text-o"></i>';break;
		}
		return icon;		
	};
	
	HierarchySetObject.prototype.newItem=function(pid,elderid,newid,data,caption){
		var self=this;
		var nodetype=self.NodeType[newid];
		if(nodetype==2){
			var did=$.base64.decode(data)
			self.DocumentID[did]=newid;
		}
		self.NU_content[newid]=data;//data is base64.encoded. as nodetype: 1=catalogue_name 2=document_id
		var thebox=this.element;
		var bodyview=self.initBodyview();
		var pitm=bodyview.find('#'+pid);
		if(pitm.length>0){
			var depth=parseInt(pitm.attr('depth'))+1;
			var pcld = pitm.next();
			if( pcld.length>0 ){
				if(!pcld.hasClass('children')){pcld.length=0;}
			}
			if(pcld.length==0){
				pitm.after('<div class="children" id="cld'+pid+'"></div>');
				pcld=pitm.next();
			}
			var tt = '<div class="hs_item" id="'+newid+'" depth="'+depth+'">';
			tt += self.typeIcon('ef',nodetype);
			for(var i=1;i<depth;i++){tt+='<div class="indent"></div>';}
			tt += '<span class="';
			if(nodetype==1){tt+='hs_catalogue';}else{tt+='hs_document';}
			tt += '">'+caption+'</span>';
			if(elderid==''){
				pcld.append(tt);
			}else{
				var eitm=pcld.children('#'+elderid);
				if(eitm.length>0){
					var ecld=eitm.next();
					if(ecld.length>0){
						if(ecld.hasClass('children')){eitm=ecld;}
					}
					eitm.after(tt);
				}
			}
			self.refreshNOCtag(pitm);
			//thebox.find('#'+newid).on('click',function(){self.clickItem($(this));});
		}
		self.modified();
	};
	HierarchySetObject.prototype.splitItem=function(id,newid,data){
		var self=this;
		self.NU_content[newid]=data;//data is base64.encoded. split only for nodetype: 1=catalogue_name
		var thebox=this.element;
		var itm=thebox.find('.bodyview').find('#'+id);
		if(itm.length>0){
			var depth=parseInt(itm.attr('depth'))+1;
			var tt = '<div class="children" id="cld'+id+'">';
			tt += '<div class="hs_item" id="'+newid+'" depth="'+depth+'">';
			tt += self.typeIcon('ef',1);
			for(var i=1;i<depth;i++){tt+='<div class="indent"></div>';}
			tt += '<span class="hs_catalogue">'+self.options.txt_catalogue+'</span></div></div>';
			itm.after( tt );
			if(itm.find('i.e-c').length==0){itm.append('<i class="fa fa-angle-up e-c"></i>');self.bindItemECEvent(itm);}
			self.refreshNOCtag(itm);
			/*itm.next().find('#'+newid).on('click',function(){
				self.clickItem($(this));
			});*/
		}
		self.modified();
	};
	/*HierarchySetObject.prototype.appendText=function(pid,newid,text){
		var obj=this;
		var self=this.element;
		var bodyview=obj.initBodyview();
		var pitm=bodyview.find('#'+pid);
		if(pitm.length>0){
			var depth=parseInt(pitm.attr('depth'))+1;
			var addcld=true;
			var pcld = pitm.next();
			if( pcld.length>0 && pcld.hasClass('children') ){addcld=false;}
			if(addcld){
				pitm.after('<div class="children" id="cld'+pid+'"></div>');
				pcld=pitm.next();
			}
			var tt = '<div class="ht_item" id="'+newid+'" depth="'+depth+'">';
			tt += '<span class="ef fa-stack" style="font-size:7px;"><i class="fa fa-square-o fa-stack-2x"></i><i class="fa fa-font fa-stack-1x"></i></span>';
			tt += '<span class="text ht_text ht_size">'+text+'</span>';
			tt += '</div>';
			if(pcld.length>0){
				pcld.append(tt);
				pcld.find('#'+newid).on('click',function(){obj.clickItem($(this));});
			}
			if(pitm.find('i.e-c').length==0){pitm.append('<i class="fa fa-angle-up e-c"></i>');obj.bindItemECEvent(pitm);}
			if(obj.isPlainText(pid)){
				obj.text2heading(pitm);
			}
			obj.setParent(newid,pid);
			obj.setParagraphtype(newid,1);
			var dt={heading:false,align:'left',text:text};
			obj.Content[newid]=JSON.stringify(dt);
			if($.inArray(newid,obj.NU_content)==-1){obj.NU_content.push(newid);}
			obj.modified();
		}
	};*/
	HierarchySetObject.prototype.removeItem=function(id){
		var self=this;
		if(self.NodeType.hasOwnProperty(id)){delete self.NodeType[id];}
		if(self.NU_parent.hasOwnProperty(id)){delete self.NU_parent[id];}
		if(self.NU_content.hasOwnProperty(id)){delete self.NU_content[id];}
		for(var did in self.DocumentID){
			var theid=self.DocumentID[did].toString();
			if(id==theid){
				delete self.DocumentID[did];
				break;
			}
		}
		var thebox=this.element;
		var itm=thebox.find('.bodyview').find('#'+id);
		if(itm.length>0){
			var pcld = itm.parent();//div children
			var pitm = pcld.prev();
			var nxt = itm.next();
			var cld = itm.next();
			if( cld.length>0 ){
				if(cld.attr('class')=='children'){
					nxt = cld.next();
				}else{cld.length=0;}
			}
			var pre = itm.prev();
			var prc = itm.prev();
			if( prc.length>0 ){
				if(prc.attr('class')=='children'){
					pre = prc.prev();
				}else{prc.length=0;}
			}
			var removed=false;
			if(nxt.length==0){//the last one
				if(pre.length==0){
					if(pcld.length>0&&pitm.length>0){
						removed=true;
						var pid=pitm.attr('id');
						if(pid!='0'){
							pcld.remove();
							pitm.find('i.e-c').remove();
						}else{pcld.empty();}
					}
					if(pitm.length>0){
						pitm.find('.e-c').remove();
					}
				}
			}
			if(!removed){
				if(cld.length>0){cld.remove();}
				itm.remove();
			}
			self.refreshNOCtag(pitm);
		}
		self.modified();
	};
	HierarchySetObject.prototype.setNodetype=function(id,ntype){
		this.NodeType[id]=ntype;
	};
	HierarchySetObject.prototype.setParent=function(id,pid){
		this.NU_parent[id]=pid;
	};
	HierarchySetObject.prototype.setPosition=function(id,children){
		var self=this;
		if(children.length==0){
			if(self.NU_position.hasOwnProperty(id)){
				delete self.NU_position[id];
			}
		}else{
			self.NU_position[id]=children;
		}
	};
	HierarchySetObject.prototype.setText=function(base64val){
		this.element.find('.bodyview').empty().append($.base64.decode(base64val));
		this.bindTextEvent();
		return this;
	};
	HierarchySetObject.prototype.modified=function(){
		this.isModified=true;
		this.options.onChange('-');//only warning, real changed in the save method
	};
	HierarchySetObject.prototype.save=function(){
		var self=this;
		if(self.isModified){
			var thebox=this.element;
			var newIDs=self.TreeSet.getNewIDs();
			var nts=new Array();
			$.each(newIDs,function(i,id){
				if(self.NodeType.hasOwnProperty(id)){
					nts.push(id+'='+self.NodeType[id]);
				}
			});
			var m=self.options.saveHierarchyset(newIDs.join(),self.TreeSet.getRmvIDs(),
					JSON.stringify(self.NU_parent),JSON.stringify(self.NU_position),nts.join(),
					JSON.stringify(self.NU_content));
			if(m.Code=="100"){
				self.TreeSet.refreshID(m.NewIDs);
				var box=thebox.find('.bodyview').find('#cld0');
				var oids=Object.keys(m.NewIDs);
				$.each(oids,function(i,oid){
					var nid=m.NewIDs[oid];
					self.NodeType[nid]=self.NodeType[oid];/*refresh nodetype*/
					delete self.NodeType[oid];
					for(var did in self.DocumentID){/*refresh DocumentID*/
						var id=self.DocumentID[did].toString();
						if(id==oid){
							self.DocumentID[did]=nid;
							break;
						}
					}
					box.find('#'+oid).attr('id',nid);
					box.find('#cld'+oid).attr('id','cld'+nid);	
				});
				self.NU_parent={};
				self.NU_position={};
				self.NU_content.length=0;
			}else{
				alert(m.Msg);
			}
			//var solidify=thebox.find('.bodyview').html();
			//self.options.onChange(solidify.replace(' htitem_focus',''));
			self.isModified=false;
		}	
	};
	/*HierarchySetObject.prototype.focusParagraph=function(id){
		var self=this.element;
		var bodyview=self.find('.bodyview');
		var viewitem=bodyview.find('#'+id);
		if(viewitem.length>0){
			var itm=viewitem;
			var iid=parseInt(id);
			while(iid>0){
				var pitm=itm.parent().prev();
				if(pitm.length>0){
					iid=parseInt(pitm.attr('id'));
					if(iid>0){
						var i_up='fa-angle-up';var i_dn='fa-angle-down';
						var ii=pitm.find('.e-c');
						if(ii.length>0){
							if(ii.hasClass(i_dn)){
								var nxt=pitm.next();
								if(nxt.length>0 && nxt.hasClass('children')){nxt.show();}
								ii.removeClass(i_dn).addClass(i_up);
							}
						}
						itm=pitm;
					}
				}else{iid=0;}
			}			
			this.focusItem(bodyview,viewitem);
			var top_block=$('.top_block');
			var boxheight=top_block.height();
			var half_boxheight=parseInt(boxheight/2);
			var quarter_itemheight=parseInt(viewitem.height()/4);
			var ypos=viewitem.position().top;
			var yobj=ypos+top_block.scrollTop();
			if(ypos<0 || ypos>boxheight-quarter_itemheight){
				var yscroll = yobj-half_boxheight;
				if(yscroll<0){yscroll=0;}
				top_block.animate({scrollTop:yscroll},100);
			}
			if(this.inEditing){this.setView(id);}
		}
	};*/
	/*HierarchySetObject.prototype.focusItem=function(bodyview,itm){//待改造
		var tf='htitem_focus';
		if(!itm.hasClass(tf)){
			var ef='ef_focus';
			bodyview.find('.'+tf).removeClass(tf);
			bodyview.find('.'+ef).removeClass(ef);
			itm.addClass(tf);
			itm.children('.ef').addClass(ef);			
		}
		var id=itm.attr('id');
		var ptype=0;
		if(this.NodeType.hasOwnProperty(id)){ptype=this.NodeType[id];}
		var align=this.defaultAlign(ptype);
		var content={};
		if(this.Content.hasOwnProperty(id)){content=this.Content[id];}
		if(content.hasOwnProperty('align')){align=content['align'];}
		if(this.inEditing){
			//this.ItemAlign.Select(align);
		}
	};*/
	HierarchySetObject.prototype.windowSet=function(){
		var obj=this;
		var self=this.element;
		var popup=self.find('#popup');
		var left_block=popup.find('.left_block');
		var top_block=popup.find('.top_block');
		var tb_splitter=popup.find('#tb_splitter');
		var bottom_block=popup.find('.bottom_block');
		var lr_splitter=popup.find('#lr_splitter');
		var right_block=popup.find('.right_block');
		var toolbar=self.find('#hierarchytoolbar');
		var toolbarheight=toolbar.height();
		var windowwidth=$(window).width();
		var windowheight=$(window).height();
		var dy=windowheight-toolbarheight;
		toolbar.css({"display":"block","position":"fixed","z-index":11000,"top":"0px","left":"0px","width":"100%","height":toolbarheight+"px"});
		popup.css({"display":"block","position":"fixed","background":"#fff","z-index":11000,"top":toolbarheight+"px","left":"0px","width":"100%","height":dy+"px"});
		left_block.css({"width":(windowwidth-lr_splitter.width()-obj.options.min_right_width)+"px","height":dy+"px"});
		right_block.css("height",dy+"px");
		top_block.css("height",(dy-this.options.min_bottom_height-this.options.tb_splitter_height)+"px");
		bottom_block.css("height",this.options.min_bottom_height+"px");
		var addicon=popup.find('.addicon');
		addicon.css("left",(lr_splitter.position().left-addicon.width()-8)+"px");	
//		this.EditorResize();待改造
	};
	HierarchySetObject.prototype.bindResizeEvent=function(){
		var obj=this;
		$(window).resize(function() {
			if(obj.inEditing){obj.windowSet();}
		});
	};
	HierarchySetObject.prototype.bindAddiconEvent=function(){
		var obj=this;
		var self=this.element;
		self.find('.addicon').on('click',function(){
			obj.TreeSet.newcatalogue();
		});		
	};
	/*HierarchySetObject.prototype.emptybodyview=function(){
		var obj=this;
		var self=this.element;
		self.find('.bodyview').find('#cld0').empty();
		obj.TreeText.emptyitem();待改造
		self.find('.hs_editor').hide();		
		obj.modified();
	};*/
	HierarchySetObject.prototype.hidepopup=function(){
		this.inEditing=false;
		var thebox=this.element;
		thebox.find('#popup').hide();	
		thebox.find('#hierarchytoolbar').hide();
	};
	HierarchySetObject.prototype.bindToolBarEvent=function(){
		var self=this;
		var thebox=this.element;
		thebox.find('.hs_empty').on('click',function(){
			thebox.YesnoAlert({width:300,height:100,yesText:self.options.txt_yes,noText:self.options.txt_no,
				doyes:function(id,action){
					self.TreeSet.emptyitem();
				}
			}).show_alertpane( '',self.options.txt_emptyornot,'empty' );
		});
		thebox.find('.hs_collapseall').on('click',function(){
			self.TreeSet.collapseall();
		});
		thebox.find('.hs_expandall').on('click',function(){
			self.TreeSet.expandall();
		});
		thebox.find('.hs_hide').on('click',function(){
			self.hidepopup();
		});
		self.bindExpandCollapseEvent();
	};
	HierarchySetObject.prototype.bindExpandCollapseEvent=function(){
		var thebox=this.element;
		var i_up='fa-angle-up';var i_dn='fa-angle-down';
		thebox.find('.hs_viewexpandall').off('click').on('click',function(){
			var root=thebox.find('.bodyview').find('#cld0');
			root.find('div.children').show();
			root.find('.'+i_dn).removeClass(i_dn).addClass(i_up);
		});
		thebox.find('.hs_viewcollapseall').off('click').on('click',function(){
			var root=thebox.find('.bodyview').find('#cld0');
			root.find('div.children').hide();
			root.find('.'+i_up).removeClass(i_up).addClass(i_dn);
		});
	};
	HierarchySetObject.prototype.clickItem=function(itm){
		var obj=this;
		var self=this.element;
/*		var bodyview=self.find('.bodyview');
		obj.focusItem(bodyview,itm);
		var id=itm.attr('id');
		if(id.length>0 && obj.inEditing){
			obj.TreeText.paththrough($('.left_block'),id);
			obj.TreeText.focus(id);
			obj.setView(id);
		}	*/	
	};
	HierarchySetObject.prototype.bindTextEvent=function(){
		var self=this;
		var thebox=this.element;
		var bodyview=thebox.find('.bodyview');
		/*bodyview.find('.hs_item').on('click',function(){
			self.clickItem($(this));
		});*/
		self.bindItemECEvent(bodyview);
	};
	HierarchySetObject.prototype.bindItemECEvent=function(block){
		block.find('.e-c').on('click',function(){
			var i_up='fa-angle-up';var i_dn='fa-angle-down';
			var item=$(this);
			var pitm=item.parent();
			var nxt=pitm.next();
			var flag=false;
			if(nxt.length>0 && nxt.hasClass('children')){flag = true;}
			if(item.hasClass(i_up)){
				if(flag){nxt.hide();}
				item.removeClass(i_up).addClass(i_dn);
			}else if(item.hasClass(i_dn)){
				if(flag){nxt.show();}
				item.removeClass(i_dn).addClass(i_up);
			}
		});
	};
	HierarchySetObject.prototype.bindLRSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var x=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var left_block=self.find('.left_block');
			x=e.clientX-splitter.offsetWidth-left_block.width();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){mouseMove(ev || event);};
				splitter.onmouseup = mouseUp;
			}else{
				left_block.css('cursor','col-resize');
				self.find('.right_block').css('cursor','col-resize');
				$(document).bind("mousemove", mouseMove).bind("mouseup", mouseUp);
			}
		});
		function mouseMove(e){
			e.preventDefault();
			var left_block=self.find('.left_block');
			if((e.clientX/document.body.clientWidth)<0.8){
				left_block.css('width',e.clientX - x + 'px');
				var addicon=self.find('.addicon');
				addicon.css("left",(self.find('#lr_splitter').position().left-addicon.width()-8)+"px");
			}
			if(e.clientX<obj.options.lr_splitter_width){left_block.hide();}else{left_block.show();}
		}
		function mouseUp(){
			self.find('.left_block').css('cursor','default');
			self.find('.right_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", mouseMove).unbind("mouseup", mouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var left_block=self.find('.left_block');
			left_block.show();
			var lr_splitter=self.find('#lr_splitter');
			left_block.css('width',($(window).width()-lr_splitter.width()-obj.options.min_right_width)+'px');
			var addicon=self.find('.addicon');
			addicon.css("left",(lr_splitter.position().left-addicon.width()-8)+"px");
			e.preventDefault();
		});
	};
	HierarchySetObject.prototype.bindTBSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var y=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var top_block=self.find('.top_block');
			y=e.clientY-splitter.offsetHeight-top_block.height();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){tbmouseMove(ev || event);};
				splitter.onmouseup = tbmouseUp;
			}else{
				top_block.css('cursor','row-resize');
				self.find('#bottom_block').css('cursor','row-resize');
				$(document).bind("mousemove", tbmouseMove).bind("mouseup", tbmouseUp);
			}
		});
		function tbmouseMove(e){
			e.preventDefault();
			var top_block=self.find('.top_block');
			var bottom_block=self.find('.bottom_block');
			var max_height=self.find('.right_block').height();
			var dy=e.clientY - y;
			var by=max_height-dy-obj.options.tb_splitter_height;
			if(by>=0){
				top_block.css('height',dy + 'px');
				var h=max_height-dy-obj.options.tb_splitter_height;
				bottom_block.css('height',h+'px');
				obj.EditorResize();
			}
			if(e.clientY<obj.options.tb_splitter_height){
				top_block.hide();
				var h=max_height-obj.options.tb_splitter_height;
				bottom_block.css('height',h+'px');
				obj.EditorResize();
			}else{top_block.show();}
		}
		function tbmouseUp(){
			self.find('.top_block').css('cursor','default');
			self.find('.bottom_block').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", tbmouseMove).unbind("mouseup", tbmouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var max_height=self.find('.right_block').height();
			self.find('.bottom_block').css('height',obj.options.min_bottom_height+'px');
			var top_block=self.find('.top_block');
			top_block.show();
			top_block.css('height',(max_height-obj.options.min_bottom_height-obj.options.tb_splitter_height)+'px');
			e.preventDefault();
		});
	};
    $.fn.HierarchySet=function(options){
		var hso=new HierarchySetObject(this,options);
		hso.init();
		return hso;
    };