function SimpleInputObject(element,options){
	this.element=element;
	this.defaults={
		width:440,
		height:124,
		zindex:20000,
		okText:'OK',
		cancelText:'Cancel',
		hintText:'Please input text:',
		doOK: function(text,extra){return true;}
	};
	this.yn='simpleinput_overlay';
	this.options=$.extend({},this.defaults,options);
};
SimpleInputObject.prototype.close_inputpane=function(){
	this.element.find('.'+this.yn).remove();
	this.element.find('.input_pane').remove();
};
SimpleInputObject.prototype.pressenter=function(){
	var self=this;
	var thebox=this.element;
	if(self.options.doOK(thebox.find('#inputvalue').val(),thebox.find('#extra').val())){
		self.close_inputpane();
	}else{ self.focusinput(); }
};
SimpleInputObject.prototype.focusinput=function(){
	var thebox=this.element;
	thebox.find('#inputvalue').select().focus();
};
SimpleInputObject.prototype.textinput=function( text,extra ){
	this.showinput('text',text,extra);
};
SimpleInputObject.prototype.passwordinput=function( text,extra ){
	this.showinput('password',text,extra);
};
SimpleInputObject.prototype.showinput=function( type,text,extra ){
	var self=this;
	var thebox=this.element;
	thebox.append('<div class="'+self.yn+'" style="z-index: '+self.options.zindex+';"></div>');
	thebox.find('.'+self.yn).css({"display":"block",opacity:0}).fadeTo(200,0.5);
	var txt='<div class="input_pane" style="width:'+self.options.width+'px;height:'+self.options.height+'px;">';
	txt += '<div><span class="close_icon"></span></div>';
	txt += '<input type="hidden" id="extra" value="'+extra+'">';
	txt += '<div style="width:100%;font-size:24px;"><span style="padding-left:5px;">'+self.options.hintText+'</span></div>';
	txt += '<div style="width:100%;height: 14px"></div>';
	txt += '<div style="width:100%;text-align:center"><input type="'+type+'" id="inputvalue" value="'+text+'" class="bigvalue"></div>';
	txt += '<div style="width:100%;height: 20px"></div>';
	txt += '<div style="float:left;width:40%;"><span style="float: right;" class="editor_button" id="btn_ok"><i class="fa fa-check"></i>&nbsp;'+self.options.okText+'</span></div>';
	txt += '<div style="float:right;width:40%;"><span style="float: left;" class="editor_button" id="btn_cancel"><i class="fa fa-ban"></i>&nbsp;'+self.options.cancelText+'</span></div>';
	txt += '</div>';
	thebox.append(txt); pane = thebox.find('.input_pane');
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":30+"%"});
	pane.fadeTo(200,1);
	self.focusinput();
	thebox.find('#btn_ok').off("click").on("click",function(event){event.stopPropagation();self.pressenter();});
	thebox.find('#btn_cancel').off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
	thebox.find('.'+self.yn).off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
	thebox.find('.close_icon').off("click").on("click",function(event){event.stopPropagation();self.close_inputpane();});
	thebox.find('#inputvalue').bind('keypress',function(event){
		if(event.keyCode == "13"){self.pressenter();}else if(event.keyCode == "27"){self.close_inputpane();}
	});
};
$.fn.SimpleInputDialog=function(options){
	var adialog=new SimpleInputObject(this,options);
	return adialog;
};