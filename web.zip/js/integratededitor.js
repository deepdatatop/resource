	function IntegratedEditorObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			width:540,
			height:650,
			zindex:20000,
			supportMultiplelanguage:false,
			default_languageid:'2',
			accept_languageids:'',
			accept_languages:{},
			token:'',
			paramStr:'Parameter value:',
			saveStr:'Save',
			cancelStr:'Cancel',
			uploadStr: "Upload file:",
			dragDropStr: "<span>Drag & Drop Files...</span>",
			multiDragErrorStr: "Multiple File Drag & Drop is not allowed.",
			extErrorStr: "is not allowed. Allowed extensions: ",
			duplicateErrorStr: "is not allowed. File already exists.",
			sizeErrorStr: "is not allowed. Allowed Max size: ",
			uploadErrorStr: "Upload is not allowed",
			maxFileCountErrorStr: " is not allowed. Maximum allowed files are:",
			dosave: function(iid,val,raw){}
		};
		this.bodyoverflow='';
		this.overlay='integrated_overlay';
		this.data={};
		this.options=$.extend({},this.defaults,options);
    };
	IntegratedEditorObject.prototype.close_editorpane=function(){
		this.element.find('#'+this.overlay).remove();
		this.element.find('#ieditor_pane').remove();
		$('body').css('overflow',this.bodyoverflow);
	};
	IntegratedEditorObject.prototype.fileExt=function(filename){
		var extension = '';
		var ss = filename.split('.');
		if(ss.length>1){
			extension = '.'+ss[ss.length - 1];
		}
		return extension;	
	};
	IntegratedEditorObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){
				o[k]=o.i18n[k];
			}
		}
	};
	IntegratedEditorObject.prototype.show_editorpane=function(iid,title,key,value,editor,valueconsistent){
		this.i18n_options();
		var body=$('body');
		this.bodyoverflow = body.css('overflow');
		body.css('overflow','hidden');
		var self=this,so=this.options;
		var ee = editor.split(':',2);
		var n = ee.length; var et = editor; var ep = '';
		if(n>0){et = ee[0];} if(n>1){ep = ee[1];}
		var editortype='input';
		var thetype = et;
		switch(et){
			case 'image':
				so.height=340;
				break;
			case 'switch':
				so.height=230;
				break;
			case 'selector':
				so.height=160;
				break;
			case 'text':
				var nn=parseInt(ep);
				if(nn>36){
					editortype='text';
				}
				if(valueconsistent=='1'){
					if(nn<256){
						so.height=200;
					}else if(nn<1024){
						so.height=360;
					}else{
						so.height=640;
					}
				}else{
					so.height=640;
				}
				break;
			case 'html':
				so.height=640;
				break;
			case 'number':
				so.height=200;
				break;
		}
		var thebox=this.element;
		var aos='z-index: '+so.zindex+';';
		thebox.append('<div id="'+self.overlay+'" class="overlay" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.overlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="ieditor_pane" class="editor" style="display: none;';
		txt += 'width:'+so.width+'px;height:'+so.height+'px;">';
		txt += '<input type="hidden" id="theiid"><input type="hidden" id="thetype">';
		txt += '<div class="editor_header text_dark">';
		txt += '<span id="thetitle"></span><span id="thekey"></span>';
		txt += '<span class="close_icon"></span></div>';
		txt += '<div style="width:100%;height:32px;text-align:left;padding:0px 8px;"><span>'+so.paramStr+'</span><span id="languagetag" style="color: #080;font-weight: bold"></span></div>';
		txt += '<div id="editor_area" style="width:100%;padding:0px 8px;">';
		txt += '<div id="imager" style="margin:0 auto;display:none;width:100%">';
		txt += '<div style="overflow:hidden;width:100%;height:120px;"><img id="image" src="" style=""></div>';
		txt += '<div id="imageuploader" style="margin: 0 auto;"></div>';
		txt += '</div>';
		txt += '<div id="switch" class="switch yesno" style="display:none;"><input id="switcher" type="checkbox"><label><i></i></label></div>';
		txt += '<div id="selector" class="h_selector" tabindex="0" style="margin:0 auto;width:360px;outline:none;display:none;"></div>';
		txt += '<div id="numbereditor" class="numberwrapper" style="display:none;"></div>';
		txt += '<div id="fulllanguage" class="input_border" style="display:none;padding:0 4px;width:'+(so.width-24)+'px;height:'+(so.height-130)+'px;overflow-y:auto;"></div>';
		txt += '</div>';
		txt += '<div class="editor_footer">';
		txt += '<span class="editor_button" id="btn_ok"><i class="fa fa-save"></i>&nbsp;'+so.saveStr+'</span>';
		txt += '<span style="width:100px;">&nbsp;&nbsp;&nbsp;&nbsp;</span>';
		txt += '<span class="editor_button" id="btn_cancel"><i class="fa fa-times-circle-o"></id>&nbsp;'+so.cancelStr+'</span>';
		txt += '</div>';
		txt += '</div>';
		thebox.append(txt);
		var pane = thebox.find("#ieditor_pane");
		switch(et){
			case 'image'://favico|ico   logo|jpg,png,gif
				var f_n = ''; var f_e = ep;
				var pp = ep.split('|',2);
				if(pp.length>1){f_n=pp[0];f_e=pp[1];}
				var v=value;if(v.length==0){v="default.png";}
				pane.find('#imager').val(value).attr('rel',f_n).show();
				pane.find('#image').attr('src','/img/'+v);
				pane.find("#imageuploader").uploadFile({
					allowedTypes: f_e,
					maxFileCount:1,
					maxFileSize:10*1024*1024,
					fileCounterStyle: ". ",
					uploadStr: so.uploadStr+f_e,
					dragDropStr: so.dragDropStr,
					multiDragErrorStr: so.multiDragErrorStr,
					extErrorStr: so.extErrorStr,
					duplicateErrorStr: so.duplicateErrorStr,
					sizeErrorStr: so.sizeErrorStr,
					uploadErrorStr: so.uploadErrorStr,
					maxFileCountErrorStr: so.maxFileCountErrorStr,
					url:"/file-upload",
					showDelete:true,
					showDownload:false,
					dragDrop:true,
					fileName:"up",
					formData: {owner: 'config',token: self.options.token},
					onLoad:function(obj) {},
					onSuccess:function(files,data,xhr,pd) {//files: list of files data: response from server xhr: jquer xhr object
						pane.find('#image').attr('src','/u?n='+data);
						pane.find('#imager').val(data);
						setTimeout(function(){	pd.statusbar.hide(); },1500);
					},
					deleteCallback: function (fname, pd) {
						var filename='config_'+self.options.token+'-'+$.md5(fname)+self.fileExt(fname);//same as server filename rule
						$.post("/file-delete",{name: filename},function (resp,textStatus,jqXHR) { 
								pd.statusbar.hide();
								pane.find('#image').attr('src','');
							});
					}
				});
				break;
			case 'switch':
				pane.find('#switch').show();
				pane.find('#switcher').prop("checked",(value=="1"));
				break;
			case 'selector':
				var pp = ep.split('|',2); n = pp.length;
				var cst = ''; if(n>0){cst=pp[0];}
				var s_m = ''; if(n>1){s_m=pp[1];}
				if(cst.length>0){
					pane.find('#selector').show().Selector({
						codeset:cst,multiple_choice:(s_m=='multiple'),language:so.default_languageid
	      			}).setResult(value);
				}else{
					alert('not set codeset!');
				}
				break;
			case 'text':
				var imode='single';
				if(so.supportMultiplelanguage){
					imode='multiple';
				}
				pane.find('#fulllanguage').show().Fulllanguage({
					name:key,
					data_bs64:$.base64.encode(value),//1#aaa\n2#一二三
					mode:imode,
					editortype:editortype,
					supportMultiplelanguage:so.supportMultiplelanguage,
					default_languageid:so.default_languageid,
					accept_languageids:so.accept_languageids,
					accept_languages:so.accept_languages,
					onChange: function(data){
						self.data=data;
					}
				});
				break;
			case 'html':
				break;
			case 'number':
				var pp = ep.split('|',2); n = pp.length;
				var decimal_places=0; var step=1;
				if(n>0){decimal_places = parseInt(pp[0]);}
				if(n>1){if(decimal_places==0){step = parseInt(pp[1]);}else{step = parseFloat(pp[1]);}}
				pane.find('#numbereditor').show().numInput({negative: false,width: 80,ratio: 2,value:value,floatCount: decimal_places,interval: step});
				break;
		}		
		
		pane.find('#theiid').text(iid);
		pane.find('#thetitle').text(title);
		pane.find('#thekey').text(key);
		pane.find('#thetype').text(thetype);
		
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('#btn_ok').off("click").on("click",function(event){
			event.stopPropagation();
			var v = '';var r = '';
			var et=$('#thetype').text();
			switch(et){
				case 'image':
					var theimager=thebox.find('#imager');
					if(theimager.length==1){
						r=theimager.val();
						if(r.length>0){
							v=theimager.attr('rel');
							if(v.length>0){
								var lc=pane.find('#languagecode').val();
								if(lc.length>0){ v+="_"+lc; }
								v+=self.fileExt(r);
							}else{ v = r; }
						}
					}//v:logo.png r:config_63cc9063a6188f78f21ed49bba08d5c2-5ececb546ff0981605ed0deabdfdde3c.png
					break;
				case 'switch':
					v='0';
					if($('#switcher').prop("checked")){v='1';}
					break;
				case 'selector':
					v=$('#selector').val();
					break;
				case 'text':
					if(so.supportMultiplelanguage){
						var vv=[];
						for (let lid in self.data) {
						    vv.push(lid+'#'+self.data[lid]);
						}
						v=vv.join('\n');
					}else{
						v=self.data;
					}
					break;
				case 'html':
					break;
				case 'number':
					v=$('#numbereditor').find('#num-input').val();
					break;
			}
			var theiid = pane.find('#theiid').text();
			so.dosave(theiid,v,r);
			self.close_editorpane();
		});
		thebox.find('#btn_cancel').off("click").on("click",function(event){self.close_editorpane();});
		thebox.find('#'+self.overlay).off("click").on("click",function(event){self.close_editorpane();});
		thebox.find('.close_icon').off("click").on("click",function(event){self.close_editorpane();});
	};
    $.fn.IntegratedEditor=function(options){
		var aneditor=new IntegratedEditorObject(this,options);
		return aneditor;
    };
