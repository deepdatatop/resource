	Date.prototype.Format = function(fmt) {
		var o = {
			"M+": this.getMonth() + 1,
			"d+": this.getDate(),
			"H+": this.getHours(),
			"m+": this.getMinutes(),
			"s+": this.getSeconds(),
			"q+": Math.floor((this.getMonth() + 3) / 3),
			"S": this.getMilliseconds()
		};
		if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
		for (var k in o)
			if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		return fmt;
	}
	/*usage: 
	var dt = new Date().Format("yyyy-MM-dd");
	var tm = new Date().Format("yyyy-MM-dd HH:mm:ss");
	*/
	function PeriodchooserObject(element,options){
		this.element=element;
		this.defaults={
			i18n:{},
			width:250,
			height:290,
			zindex:20000,
			txt_periodchooser:'Common used date periods:',
			txt_today:'Today',
			txt_yesterday:'Yesterday',
			txt_thisweek:'This week',
			txt_lastweek:'Last week',
			txt_last7days:'Last 7 days',
			txt_last14days:'Last 14 days',
			txt_thismonth:'This month',
			txt_lastmonth:'Last month',
			txt_last30days:'Last 30 days',
			txt_last60days:'Last 60 days',
			txt_last3months:'Last 3 months',
			txt_last6months:'Last 6 months',
			txt_thisyear:'This year',
			txt_lastyear:'Last year',
			onChoose: function(start,end){}
		};
		this.yn='periodchooser_overlay';
		this.options=$.extend({},this.defaults,options);
    };
	PeriodchooserObject.prototype.close_pane=function(){
		this.element.find('#'+this.yn).remove();
		this.element.find('#chooser_pane').remove();
	};
	PeriodchooserObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	PeriodchooserObject.prototype.show_pane=function(){
		this.i18n_options();
		var self=this;
		var thebox=this.element;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.yn+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.yn).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="chooser_pane" style="display:none;text-align:center;';
		txt += 'width:'+self.options.width+'px;height:'+self.options.height+'px;';
		txt += 'overflow:hidden;background:#fff;padding:8px;border:#000 solid 1px">';
		var ats='position: absolute;width: 13px;height: 13px;background-image: url(/img/icon_x.gif);';
		ats+='background-repeat: no-repeat;right: 0px;top: 0px;cursor: pointer;';
		txt +='<div>'+self.options.txt_periodchooser+'<span class="at_close_icon" style="'+ats+'"></span></div>';
		txt +='<span class="choose_button" id="today">'+self.options.txt_today+'</span>';
		txt +='<span class="choose_button" id="yesterday">'+self.options.txt_yesterday+'</span>';
		txt +='<span class="choose_button" id="thisweek">'+self.options.txt_thisweek+'</span>';
		txt +='<span class="choose_button" id="lastweek">'+self.options.txt_lastweek+'</span>';
		txt +='<span class="choose_button" id="last7days">'+self.options.txt_last7days+'</span>';
		txt +='<span class="choose_button" id="last14days">'+self.options.txt_last14days+'</span>';
		txt +='<span class="choose_button" id="thismonth">'+self.options.txt_thismonth+'</span>';
		txt +='<span class="choose_button" id="lastmonth">'+self.options.txt_lastmonth+'</span>';
		txt +='<span class="choose_button" id="last30days">'+self.options.txt_last30days+'</span>';
		txt +='<span class="choose_button" id="last60days">'+self.options.txt_last60days+'</span>';
		txt +='<span class="choose_button" id="last3months">'+self.options.txt_last3months+'</span>';
		txt +='<span class="choose_button" id="last6months">'+self.options.txt_last6months+'</span>';
		txt +='<span class="choose_button" id="thisyear">'+self.options.txt_thisyear+'</span>';
		txt +='<span class="choose_button" id="lastyear">'+self.options.txt_lastyear+'</span>';
		txt +='</div>';
		thebox.append(txt);
		var pane = thebox.find('#chooser_pane');
		var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
		pane.fadeTo(200,1);
		thebox.find('.choose_button').on("click",function(event){/*event.stopPropagation();*/
			var today=new Date();
			var dt_fmt='yyyy-MM-dd';
			var start=today.Format(dt_fmt);
			var end=start;
			var oneday = 1000 * 60 * 60 * 24;
			switch($(this).attr('id')){
				case 'today':break;
				case 'yesterday':
					start=(new Date(today - oneday)).Format(dt_fmt);
					end=start;
					break;
				case 'thisweek':
					var firstday_thisweek=new Date(today.getTime()-today.getDay()*oneday);
					start=firstday_thisweek.Format(dt_fmt);
					end=(new Date(firstday_thisweek.getTime()+6*oneday)).Format(dt_fmt);
					break;
				case 'lastweek':
					var firstday_lastweek=new Date(today.getTime()-(today.getDay()+7)*oneday);
					start=firstday_lastweek.Format(dt_fmt);
					end=(new Date(firstday_lastweek.getTime()+6*oneday)).Format(dt_fmt);				
					break;
				case 'last7days':
					start=(new Date(today - 7*oneday)).Format(dt_fmt);
					end=today.Format(dt_fmt);
					break;
				case 'last14days':
					start=(new Date(today - 14*oneday)).Format(dt_fmt);
					end=today.Format(dt_fmt);
					break;
				case 'thismonth':
					var firstday_thismonth=today;
					firstday_thismonth.setDate(1);
					var lastday_thismonth=new Date(today.getFullYear(),today.getMonth()+1,0,0,0,0,0);
					start=firstday_thismonth.Format(dt_fmt);
					end=lastday_thismonth.Format(dt_fmt);
					break;
				case 'lastmonth':
					var lastday_lastmonth=today;
					lastday_lastmonth.setDate(0);
					var firstday_lastmonth=new Date(lastday_lastmonth.getFullYear(),lastday_lastmonth.getMonth(),1,0,0,0,0);
					start=firstday_lastmonth.Format(dt_fmt);
					end=lastday_lastmonth.Format(dt_fmt);
					break;
				case 'last30days':
					start=(new Date(today - 30*oneday)).Format(dt_fmt);
					end=today.Format(dt_fmt);
					break;
				case 'last60days':
					start=(new Date(today - 60*oneday)).Format(dt_fmt);
					end=today.Format(dt_fmt);
					break;
				case 'last3months':
					var firstday_last3months=new Date();
					firstday_last3months.setMonth(firstday_last3months.getMonth()-3,1);
					var lastday_lastmonth=today;
					lastday_lastmonth.setDate(0);
					start=firstday_last3months.Format(dt_fmt);
					end=lastday_lastmonth.Format(dt_fmt);
					break;
				case 'last6months':
					var firstday_last6months=new Date();
					firstday_last6months.setMonth(firstday_last6months.getMonth()-6,1);
					var lastday_lastmonth=today;
					lastday_lastmonth.setDate(0);
					start=firstday_last6months.Format(dt_fmt);
					end=lastday_lastmonth.Format(dt_fmt);
					break;
				case 'thisyear':
					var firstday_thisyear=new Date(today.getFullYear(),0,1,0,0,0,0);
					var lastday_thisyear=new Date(today.getFullYear(),11,31,0,0,0,0);
					start=firstday_thisyear.Format(dt_fmt);
					end=lastday_thisyear.Format(dt_fmt);
					break;
				case 'lastyear':
					var firstday_lastyear=new Date(today.getFullYear()-1,0,1,0,0,0,0);
					var lastday_lastyear=new Date(today.getFullYear()-1,11,31,0,0,0,0);
					start=firstday_lastyear.Format(dt_fmt);
					end=lastday_lastyear.Format(dt_fmt);
					break;
			}
			self.close_pane();
			self.options.onChoose(start,end);
		});
		thebox.find('#'+self.yn).off("click").on("click",function(event){self.close_pane();});
		thebox.find('.at_close_icon').off("click").on("click",function(event){self.close_pane();});
	};
    $.fn.Periodchooser=function(options){
		var achooser=new PeriodchooserObject(this,options);
		return achooser;
    };