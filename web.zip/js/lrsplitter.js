	function LRSplitterObject(element,options){
		this.element=element;
		var defaults={
			lr_splitter_width:5,
			min_left_width:300
		};
		this.options=$.extend({},defaults,options);
    };
	LRSplitterObject.prototype.addLeftblock=function(){
		
	};
	LRSplitterObject.prototype.addRightblock=function(){
		
	};
	LRSplitterObject.prototype.init=function(){
		var obj=this;
		obj.ex_init();
		var self=this.element;
		self.empty();
		var 	ss = '<div id="lrs_leftblock"></div>';
		ss += '<div id="lrs_splitter"></div>';
		ss += '<div id="lrs_rightblock"></div>';
		self.append(ss);
		obj.addLeftblock();
		obj.addRightblock();
		obj.windowResize();
		if(obj.options.lr_splitter_width>0){obj.bindLRSplitter(document.getElementById('lrs_splitter'));}
		obj.bindResizeEvent();
    };
	LRSplitterObject.prototype.ex_init=function(){/*virtual function*/};
	LRSplitterObject.prototype.windowResize=function(){
		var self=this.element;
		var left_block=self.find('#lrs_leftblock');
		var lr_splitter=self.find('#lrs_splitter');
		var right_block=self.find('#lrs_rightblock');
		if(this.options.lr_splitter_width<=0){lr_splitter.hide();}
		left_block.css("width",this.options.min_left_width+"px");
	};
	LRSplitterObject.prototype.bindResizeEvent=function(){
		var obj=this;
		$(window).resize(function() {
			obj.windowResize();
		});
	};
	LRSplitterObject.prototype.bindLRSplitter=function(splitter){
		var self=this.element;
		var obj=this;
		var x=0;	
		$(splitter).mousedown(function (e){
			e.preventDefault();
			var left_block=self.find('#lrs_leftblock');
			x=e.clientX-splitter.offsetWidth-left_block.width();
			if(splitter.setCapture){
				splitter.setCapture();
				splitter.onmousemove=function(ev){mouseMove(ev || event);};
				splitter.onmouseup = mouseUp;
			}else{
				left_block.css('cursor','col-resize');
				self.find('#lrs_rightblock').css('cursor','col-resize');
				$(document).bind("mousemove", mouseMove).bind("mouseup", mouseUp);
			}
		});
		function mouseMove(e){
			e.preventDefault();
			var left_block=self.find('#lrs_leftblock');
			if((e.clientX/document.body.clientWidth)<0.8){
				left_block.css('width',e.clientX - x + 'px');
			}
			if(e.clientX<obj.options.lr_splitter_width){left_block.hide();}else{left_block.show();}
		}
		function mouseUp(){
			self.find('#lrs_leftblock').css('cursor','default');
			self.find('#lrs_rightblock').css('cursor','default');
			if(splitter.releaseCapture){
				splitter.releaseCapture();
				splitter.onmousemove = splitter.onmouseup = null;
			}else{
				$(document).unbind("mousemove", mouseMove).unbind("mouseup", mouseUp);
			}
		}
		$(splitter).dblclick(function (e){
			var left_block=self.find('#lrs_leftblock');
			left_block.show();
			left_block.css('width',obj.options.min_left_width+'px');
			e.preventDefault();
		});
	};
    $.fn.LRSplitter=function(options){
		var lrs=new LRSplitterObject(this,options);
		lrs.init();
		return lrs;
    };
		
/*inherit extend use.
<script type="text/javascript">
	function inheritPrototype(subObject, superObject){
		var prototype = Object.create(superObject.prototype);
		prototype.constructor = subObject;
		subObject.prototype = prototype;
	}
	function InheritObject(element,options){
		LRSplitterObject.call(this,element,$.extend({},options));
    };
	inheritPrototype(InheritObject,LRSplitterObject);
	InheritObject.prototype.addLeftblock=function() {
		
	};
    $.fn.Inherit=function(options){
		var iobj=new InheritObject(this,options);
		iobj.init();
		return iobj;
    };
</script>*/