	function StepwizardWidget(element,options){
		this.element=element;
		this.defaults={
			width:600,
			height:400,
			zindex:20000,
			caption:'Code item import',
			prevText:'Prev',
			nextText:'Next',
			closeText:'Close',
			lockatLast: false,/*lock all previous steps while came in last step.*/
			goPrev: function(){},
			beforeNext: function(istep){return true;},
			goNext: function(istep){},
			nextbuttonvisible: function(istep){return true;},
			onClose: function(){}
		};
		this.istep=0;
		this.stepLabels=[];/*'start','process','finish'*/
		this.overlay='step_overlay';
		this.options=$.extend({},this.defaults,options);
    };
	StepwizardWidget.prototype.addStep=function(label,htmlblock){
		var i=this.stepLabels.length;
		this.stepLabels.push(label);
		var thebox=this.element;
		thebox.find('#stepwizard_body').append('<div id="step'+i+'" class="stepwizard_block">'+htmlblock+'</div>');
		
	};
	StepwizardWidget.prototype.closepane=function(){
		this.element.find('#step_pane').remove();
		this.element.find('#'+this.overlay).remove();
		this.options.onClose();
	};
	StepwizardWidget.prototype.setbutton=function(){
		var btnprev=this.element.find('#step_prev');
		if(this.istep==0){btnprev.hide();	}else{btnprev.show();}
		var btnnext=this.element.find('#step_next');
		var btnclose=this.element.find('#step_close');
		if(this.istep==this.stepLabels.length-1){
			btnnext.hide();btnclose.show();
		}else{btnclose.hide();
			if(this.options.nextbuttonvisible(this.istep)){
				btnnext.show();
			}else{btnnext.hide();}
		}
	};
	StepwizardWidget.prototype.hideprevbutton=function(){
		var btnprev=this.element.find('#step_prev');
		btnprev.hide();
	};
	StepwizardWidget.prototype.hidenextbutton=function(){
		var btnnext=this.element.find('#step_next');
		btnnext.hide();
	};
	StepwizardWidget.prototype.shownextbutton=function(){
		var btnnext=this.element.find('#step_next');
		btnnext.show();
	};
	StepwizardWidget.prototype.hideblock=function(i){
		if(i<this.stepLabels.length){
			this.element.find('#step'+i).hide();
		}
	};
	StepwizardWidget.prototype.showblock=function(i){
		if(i<this.stepLabels.length){
			this.element.find('#step'+i).show();
		}
	};
	StepwizardWidget.prototype.showpane=function(){
		var self=this;
		var thebox=this.element;
		var pane = thebox.find("#step_pane");
		pane.css({"display":"block","position":"fixed","opacity":0,"z-index":self.options.zindex+100,"left":"50%","margin-left":-(pane.outerWidth()/2)+"px","top":"50%","margin-top":-(pane.outerHeight()/2)+"px"});
		pane.fadeTo(200,1);
		self.showblock(self.istep);
		self.setbutton();
		var bar = '<ul class="stepbar">';
		$.each(self.stepLabels, function (index, label) {
			bar += '<li';
			if(index==0){bar+= ' class="active"';}
			bar += '>'+label+'</li>';
		});
		bar += '</ul>';
		thebox.find('#stepwizard_header').append(bar);
		thebox.find('.stepbar li').css('width', 100 / self.stepLabels.length + '%');
		thebox.find(".stepbar li").off('click').on('click',function(event){
			var idx=$(this).index();
			if(idx<self.istep){
				if(self.istep==self.stepLabels.length-1 && self.options.lockatLast){
					/*skip*/
				}else{
					self.hideblock(self.istep);
					$(this).nextAll('li').removeClass('active');
					self.istep=idx;
					self.showblock(self.istep);
					self.setbutton();
				}
			}
		});
	};
	StepwizardWidget.prototype.showNext=function(){
		this.hideblock(this.istep);
		this.istep++;
		this.element.find('#stepwizard_header').find('li').eq(this.istep).addClass('active');
		this.showblock(this.istep);
		this.setbutton();
	};
	StepwizardWidget.prototype.init=function(){
		var self=this,thebox=this.element,so=this.options;
		var aos='position: fixed;z-index: '+self.options.zindex+';top: 0px;left: 0px;height:100%;width:100%;background: #000;display: none;';
		thebox.append('<div id="'+self.overlay+'" style="'+aos+'"></div>');
		var ao=thebox.find('#'+self.overlay).css({"display":"block",opacity:0}).fadeTo(200,0.5);
		var txt='<div id="step_pane" style="display: none;border-radius:8px;';
		txt += 'width:'+self.options.width+'px;height:'+self.options.height+'px;';
		txt += 'overflow:hidden;background:#FFFFFF;border:#dadada solid 1px">';
		txt += '<div id="stepwizard_header">';
		txt += '<div class="stepwizard_caption"><span id="thetitle">'+so.caption+'</span></div>';
		txt += '<span class="sw_close_icon"><i class="fa fa-close"></i></span></div>';
		txt += '<div id="stepwizard_body"></div>';
		txt += '<div id="stepwizard_footer">';
		txt += '<div style="float:left;width:20%;text-align:right;margin-top:5px;"><span class="stepbutton" id="step_prev">'+self.options.prevText+'</span></div>';
		txt += '<div style="float:right;width:20%;text-align:left;margin-top:5px;"><span class="stepbutton" id="step_next">'+self.options.nextText+'</span>';
		txt += '<span class="stepbutton" id="step_close">'+self.options.closeText+'</span></div>';
		txt += '</div>';
		txt += '</div>';
		thebox.append(txt);
		thebox.find('#step_prev').off("click").on("click",function(event){
			event.stopPropagation();
			if(self.istep>0){
				thebox.find('#stepwizard_header').find('li').eq(self.istep).removeClass('active');
				self.hideblock(self.istep);
				self.istep--;
				self.showblock(self.istep);
				self.setbutton();
			}
			self.options.goPrev();
		});
		thebox.find('#step_next').off("click").on("click",function(event){
			event.stopPropagation();
			if(self.istep<self.stepLabels.length-1 && self.options.beforeNext(self.istep)){
				self.showNext();
				self.options.goNext(self.istep);
			}
		});
		thebox.find('#step_close').off("click").on("click",function(event){
			event.stopPropagation();
			self.closepane();
		});
		thebox.find('.sw_close_icon').off("click").on("click",function(event){self.closepane();});
	};
    $.fn.Stepwizard=function(options){
		var aWidget=new StepwizardWidget(this,options);
		aWidget.init();
		return aWidget;
    };