function SimpleUploadObject(element,options){
	this.element=element;
	this.defaults={
		width:540,
		height:244,
		zindex:20000,
		token:'',
		closeText:'Close',
		hintText:'Please upload file:',
		uploadStr: "Upload file:",
		dragDropStr: "<span>Drag & Drop Files...</span>",
		multiDragErrorStr: "Multiple File Drag & Drop is not allowed.",
		extErrorStr: "is not allowed. Allowed extensions: ",
		duplicateErrorStr: "is not allowed. File already exists.",
		sizeErrorStr: "is not allowed. Allowed Max size: ",
		uploadErrorStr: "Upload is not allowed",
		maxFileCountErrorStr: " is not allowed. Maximum allowed files are:",
		onUploaded: function(filename){}
	};
	this.uploadfile='',
	this.yn='simpleupload_overlay';
	this.options=$.extend({},this.defaults,options);
};
SimpleUploadObject.prototype.close_uploadpane=function(){
	this.element.find('.'+this.yn).remove();
	this.element.find('.upload_pane').remove();
};
SimpleUploadObject.prototype.fileExt=function(filename){
	var extension = '';
	var ss = filename.split('.');
	if(ss.length>1){
		extension = '.'+ss[ss.length - 1];
	}
	return extension;	
};
SimpleUploadObject.prototype.show=function(){
	var self=this,so=this.options;
	var thebox=this.element;
	thebox.append('<div class="'+self.yn+'" style="z-index: '+so.zindex+';"></div>');
	thebox.find('.'+self.yn).css({"display":"block",opacity:0}).fadeTo(200,0.5);
	var txt='<div class="upload_pane" style="width:'+so.width+'px;height:'+so.height+'px;">';
	txt += '<div><span class="close_icon"></span></div>';
	txt += '<div style="width:100%;font-size:24px;"><span style="padding-left:5px;">'+so.hintText+'</span>';
	txt += '</div>';
	txt += '<div style="width:100%;height: 14px"></div>';
	txt += '<div id="uploader" style="width:100%;height:130px;margin: 0 auto;"></div>';
	txt += '<div style="width:100%;height: 20px"></div>';
	txt += '<div style="width:100%;text-align:center;"><span class="editor_button" id="btn_close"><i class="fa fa-times-circle-o"></i>&nbsp;'+so.closeText+'</span></div>';
	txt += '</div>';
	thebox.append(txt); pane = thebox.find('.upload_pane');
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('#uploader').uploadFile({
		allowedTypes: 'dpkg',
		maxFileCount:1,
		maxFileSize:30*1024*1024,
		fileCounterStyle: ". ",
		uploadStr: so.uploadStr,
		dragDropStr: so.dragDropStr,
		multiDragErrorStr: so.multiDragErrorStr,
		extErrorStr: so.extErrorStr,
		duplicateErrorStr: so.duplicateErrorStr,
		sizeErrorStr: so.sizeErrorStr,
		uploadErrorStr: so.uploadErrorStr,
		maxFileCountErrorStr: so.maxFileCountErrorStr,
		url:"/file-upload",
		showDelete:true,
		showDownload:false,
		dragDrop:true,
		fileName:"up",
		formData: {owner: 'su',token: so.token},
		onSuccess:function(files,data,xhr,pd) {
			setTimeout(function(){pd.statusbar.hide();},1000);
			self.close_uploadpane();
			if(files.length>0){so.onUploaded(data);}
		},
		deleteCallback: function (fname, pd) {
			var filename='su_'+so.token+'-'+$.md5(fname)+self.fileExt(fname);//same as server filename rule
			$.post("/file-delete",{name: filename},function(resp,textStatus,jqXHR) { 
				pd.statusbar.hide();
			});
		}
	});
	thebox.find('#btn_close').off("click").on("click",function(event){event.stopPropagation();self.close_uploadpane();});
	thebox.find('.'+self.yn).off("click").on("click",function(event){event.stopPropagation();self.close_uploadpane();});
	thebox.find('.close_icon').off("click").on("click",function(event){event.stopPropagation();self.close_uploadpane();});
};
$.fn.SimpleUpload=function(options){
	var adialog=new SimpleUploadObject(this,options);
	return adialog;
};