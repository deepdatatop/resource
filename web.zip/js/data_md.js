/*Multidimension interface function used for form+view html>> */
	function readMultidimensiondata(identifier,mdt_scene){
		var data={};
		var cell={};
		$.ajaxSettings.async = false;
		var instance_id=$('#instance_id').val();
		$.getJSON('/getdatalist',{idf:identifier,scene:mdt_scene,rmi:instance_id},function(m){
			if(m.status=='success'){//{"status":"success","subentity":"price","caption":"price","listproperty":["properties","price"],"totals":1,"data":[{"properties":"5-1;6-10;7-13;9-11","price":123}]}
				if(m.hasOwnProperty('subentity')){
					data['subentity']=m['subentity'];
				}
				if(m.hasOwnProperty('caption')){
					data['caption']=m['caption'];
				}
				for(var i=0,n=m.listproperty.length;i<n;i++){
					if(m.listproperty[i]!='properties'){
						data['valueproperty']=m.listproperty[i];
						break;
					}
				}
				for(var i=0;i<m.totals;i++){
					var o=m.data[i];
					var k='',v='';
					for(var x in o){
						if(x=='properties'){
							k=o[x];
						}else{
							v=o[x];
						}
					}
					cell[k]=v;
				}
			}
		});
		$.ajaxSettings.async = true;
		data['cell']=cell;
		return data;
	}
	/*{
		"subentity": "price",
		"valueproperty": "price",
		"cell": {"5-1;6-10;7-13;9-11":"123"}
	}*/
/* << Multidimension function*/