	function StateButtonObject(element,options){
		this.element=element;
		var defaults={
			item_option:[
				{value:'left',label:'<i class="fa fa-align-left"></i>'},
				{value:'center',label:'<i class="fa fa-align-center"></i>'},
				{value:'right',label:'<i class="fa fa-align-right"></i>'}
        		],
			onChange: function(val){}
		};
		this.options=$.extend({},defaults,options);
    };
	StateButtonObject.prototype.init=function(){
		var obj=this;
		var self=this.element;
		self.empty();
		var n=this.options.item_option.length;
		for(var i=0;i<n;i++){
			var value=this.options.item_option[i].value;
			var label=this.options.item_option[i].label;
			self.append('<span class="state_button state_normal" id="'+value+'">'+label+'</span>');
		}
		self.find('.state_normal').on('click',function(event){
			var val=$(this).attr('id');
			obj.Select(val);
			obj.options.onChange(val);
		});
    };
	StateButtonObject.prototype.Select=function(val){
		var obj=this;
		var self=this.element;
		var s_class='state_selected';
		var i=self.find('#'+val);
		if(i.length>0){
			if(!i.hasClass(s_class)){
				var n_class='state_normal';
				self.find('.'+s_class).removeClass(s_class).addClass(n_class).on('click',function(event){
					var val=$(this).attr('id');
					obj.Select(val);
					obj.options.onChange(val);
				});
				i.removeClass(n_class).addClass(s_class);
				i.off('click');
			}
		}
		return obj;
	};
	StateButtonObject.prototype.Value=function(){
		return this.element.find('.state_selected').attr('id');
	}
    $.fn.StateButton=function(options){
		var abutton=new StateButtonObject(this,options);
		abutton.init();
		return abutton;
    };
