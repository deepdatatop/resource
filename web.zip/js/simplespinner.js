/*no input item,only up&down click*/
	function SimplespinnerObject(element,options){
		this.element=element;
		this.defaults={
			width: 100,
			min: 0,
			max: 100,
			value: 1,
			ratio: 1,
			interval: 1,
			wrapperClass: 'spinner-wrap',
			//inputClass: 'num-input',
			addClass: 'spinner-add',
			subClass: 'spinner-sub',
			deepClass: 'spinner-deep',
			onChange: function(val){}
		};
		this.value=0;
		this.options=$.extend({},this.defaults,options);
    };
	SimplespinnerObject.prototype.setMax=function(max){
		this.options.max=max;
		return this;
	};
	SimplespinnerObject.prototype.setValue=function(v){
		var vv = parseInt(v);
		vv = isNaN(vv) ? 0 : vv;
		//this.element.find('input').val(vv);
		this.value=vv;
		return this;
	};
	SimplespinnerObject.prototype.getValue=function(){
		return this.value;
	}
	SimplespinnerObject.prototype.init=function(){
		var obj=this;
		var self=this.element;
		var ratio=obj.options.ratio;
		if($('#spinner-css').length==0){
			var css='<style id="spinner-css" type="text/css">';
			css+='.'+obj.options.addClass+':hover,.'+obj.options.subClass+':hover{background: #d8d8d8;}';
			css+='.'+obj.options.addClass+'.'+obj.options.deepClass+',.'+obj.options.subClass+'.'+obj.options.deepClass+'{background: #b3b3b3;}';
			css+='.'+obj.options.addClass+'::after{position: absolute;left: '+parseInt((25*ratio-9)/2)+'px;top: '+parseInt((15*ratio-5)/2)+'px;content: "";border-left: 4px solid transparent;border-right: 4px solid transparent;border-bottom: 6px solid #333;}';
			css+='.'+obj.options.subClass+'::after{position: absolute;left: '+parseInt((25*ratio-9)/2)+'px;bottom: '+parseInt((15*ratio-5)/2)+'px;content: "";border-left: 4px solid transparent;border-right: 4px solid transparent;border-top: 6px solid #333;}</style>';
			$(css).appendTo('head');
		}
		var wrapper = $('<div class="'+obj.options.wrapperClass+'"></div>');
		wrapper.css({"position": "relative", "display": "inline-block", "vertical-align": "top", "height": 32*ratio, "width": obj.options.width*ratio, /*"border": "1px solid #ccc", "border-radius": 6,*/ "box-sizing": "border-box", "overflow": "hidden"});
		self.append(wrapper);
		//var inputEdt = $('<input type="text" id="'+obj.options.inputClass+'" value="'+obj.options.value+'" class="'+obj.options.inputClass+'">');
		//inputEdt.css({"height": 30*ratio, "width": "100%", "padding": "0 25px 0 12px", "font-size": (14*ratio)+"px", "line-height": (30*ratio)+"px", "background": "#fff", "box-shadow": "inset 0 1px 1px rgba(0,0,0,.075)", "box-sizing": "border-box", "border": "none"});
		var addBtn = $('<span class="'+obj.options.addClass+'"></span>');
		addBtn.css({"position": "absolute", 'right': 0, 'top': 0, 'width': 25*ratio, "height": 15*ratio, "border-left": "1px solid #ccc", "box-sizing": "border-box", "cursor": "pointer"});
		var subBtn = $('<span class="'+obj.options.subClass+'"></span>')
		subBtn.css({"position": "absolute", 'right': 0, 'bottom': 0, 'width': 25*ratio, "height": 15*ratio, "border-left": "1px solid #ccc", "box-sizing": "border-box", "cursor": "pointer"});
		wrapper/*.append(inputEdt)*/.append(addBtn).append(subBtn);
		this.value=obj.options.value;
		addBtn.on('mousedown', function(event){
			event.preventDefault();
			$(this).addClass(obj.options.deepClass);
			var interval = obj.options.interval;
			var val=obj.value;
			//var val = parseInt(inputEdt.val());
			val = isNaN(val) ? 0 : val;
			val += interval;
			if(val>obj.options.max){val=obj.options.max}
			//inputEdt.val(val);
			if(obj.value!=val){
				obj.value=val;
				obj.options.onChange(val);
			}
		}).on('mouseup', function(){$(this).removeClass(obj.options.deepClass)}).on('mouseleave', function(){$(this).removeClass(obj.options.deepClass)});
		subBtn.on('mousedown', function(event){
			event.preventDefault();
			$(this).addClass(obj.options.deepClass);
			var interval = obj.options.interval;
			//var val = parseInt(inputEdt.val());
			var val=obj.value;
			val = isNaN(val) ? 0 : val;
			val -= interval;
			if(val<obj.options.min){val=obj.options.min}
			//inputEdt.val(val);
			if(obj.value!=val){
				obj.value=val;
				obj.options.onChange(val);
			}
		}).on('mouseup', function(){$(this).removeClass(obj.options.deepClass)}).on('mouseleave', function(){$(this).removeClass(obj.options.deepClass)});
		/*inputEdt.on('keypress',function(event){
			if(event.keyCode == "13"){
				event.preventDefault();
				var val = parseInt(inputEdt.val());
				val = isNaN(val) ? 0 : val;
				if(val>obj.options.max){val=obj.options.max}
				if(val<obj.options.min){val=obj.options.min}
				inputEdt.val(val);
				if(obj.value!=val){
					obj.value=val;
					obj.options.onChange(val);
				}
			}
		});*/
	};
    $.fn.Simplespinner=function(options){
		var aspinner=new SimplespinnerObject(this,options);
		aspinner.init();
		return aspinner;
    };
