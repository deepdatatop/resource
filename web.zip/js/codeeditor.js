	function CodeEditorObject(element,options){
		this.outerID='';
		this.originText='';
		this.resultText='';
		this.element=element;
		var defaults={
			pagewidth: 800,
			i18n:{},
			txt_actual: 'actual',
			txt_cawidth: 'width:',
			txt_caheight: 'height:',
			txt_hint: 'ctrl+enter save code.',
			onChange:function(id,gist,val){},
			screen:{}/*the output DIV for code render*/
		};
		this.options=$.extend({},defaults,options);
		this.toolbarheight=36;
		this.ca_width='80%';
		this.ca_height='actual';
		this.widthLN=30;
		this.pad=4;
		this.lines=1;
    };
	CodeEditorObject.prototype.i18n_options=function(){
		var o=this.options;
		for(var k in o.i18n){
			if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
		}
	};
	CodeEditorObject.prototype.init=function(){
		this.i18n_options();	
		var obj=this;
		var self=this.element;
		self.empty();
		var ss='<div style="width:100%;height:'+obj.toolbarheight+'px;padding-top:2px;overflow:hidden;border-bottom:solid 1px #ccc;"><span id="ce" style="font-size:24px;display:inline-block"><i class="fa fa-code"></i></span>';
		var ws='<select id="ca_width" style="display:inline-block;outline:none">';
		ws+='<option value="100%">100%</option><option value="90%">90%</option>';
		ws+='<option value="80%">80%</option><option value="75%">75%</option>';
		ws+='<option value="50%">50%</option><option value="25%">25%</option></select>';
		ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_cawidth+'</span>'+ws;
		var hs='<select id="ca_height" style="display:inline-block;outline:none">';
		hs+='<option value="actual">'+obj.options.txt_actual+'</option>';
		hs+='<option value="100px">100px</option><option value="200px">200px</option>';
		hs+='<option value="300px">300px</option><option value="400px">400px</option>';
		hs+='<option value="500px">500px</option></select>';
		ss+='<span style="padding-left:3px;display:inline-block">'+obj.options.txt_caheight+'</span>'+hs;
		ss+='<div style="display:inline-block;position:absolute;right:0px;width:32px;">';
		ss+='<i class="fa fa-2x fa-trash-o ce_empty"></i>';
		ss+='</div>';
		ss+='</div>';
		ss+='<textarea id="atext" style="width:100%;height:100px;outline:none;font-size:16px;line-height:20px;overflow-y:auto;border:none;resize:none"></textarea>';
		ss+='<div style="width:100%;height:'+obj.toolbarheight+'px;font:14px/30px arial;color:#ccc;text-align:right;border-top:solid 1px #ccc;">';
		ss+='<span class="ce_enter_button" id="undo" style="display:none"><i class="fa fa-undo"></i></span>';
		ss+='<span>&nbsp;↸&nbsp;'+obj.options.txt_hint+'&nbsp;</span>';
		ss+='<span class="ce_enter_button" id="enter" style="display:none"><i class="fa fa-level-down fa-lg fa-rotate-90"></i></span></div>';
		ss+='</div>';
		self.append(ss);
		self.find('#atext').on('keypress',function(e){
			if((e.keyCode == "13" || e.keyCode=="108") && e.ctrlKey){e.preventDefault();obj.clickEnter();}//ctrl+enter
			//alert(e.keyCode+'='+e.ctrlKey);
			//if(e.keyCode == "26" && e.ctrlKey){//ctrl+Z  同级新增item
			//}
		});
		self.find('#atext').on('input propertychange',function(e){
			self.find('#undo').show();self.find('#enter').show();
			obj.resultText = $(this).val();
		});
		self.find('#undo').on('click',function(){
			obj.setText(obj.originText);
		});
		self.find('.ce_empty').on('click',function(){obj.empty();});
		self.find('#enter').on('click',function(){obj.clickEnter();});
		self.find('#ca_width').change(function(){
			obj.ca_width=$(this).val();
			obj.setWidthHeight(true,false);
			obj.modified();
		});
		self.find('#ca_height').change(function(){
			obj.ca_height=$(this).val();
			obj.setWidthHeight(false,true);
			obj.modified();
		});
	};
	CodeEditorObject.prototype.resize=function(){
		var self=this.element;
		var height=self.innerHeight()-this.toolbarheight*2;
		self.find('#atext').css('height',height+'px');	
	};
	CodeEditorObject.prototype.modified=function(){
		var gist='';
		var ss=this.resultText.split('\n');
		if(ss.length>0){
			gist=ss[0];
			if(gist.length>this.options.gistchars){
				gist=gist.substring(0,this.options.gistchars);
			}
		}
		this.options.onChange(this.outerID,gist,this.getText());
	};
	CodeEditorObject.prototype.calcLines=function(){
		this.lines=1;
		var vm=this.resultText.match(/\n/g);
		if(vm){this.lines=vm.length+1;}
	};
	CodeEditorObject.prototype.clickEnter=function(){
		var obj=this;
		this.element.find('#enter').hide();
		var box=obj.options.screen;
		if(JSON.stringify(box)!='{}'){
			var ta=box.find('textarea');
			if(ta.length>0){
				obj.calcLines();
				ta.html(obj.resultText);	
				obj.screenReset();			
			}
		}
		obj.modified();
	};
	CodeEditorObject.prototype.empty=function(){
		var obj=this;
		if(obj.resultText.length>0){
			var box=obj.options.screen;
			if(JSON.stringify(box)!='{}'){
				box.find('.codearea-ino').empty();
				box.find('.ln_codearea').empty();
			}
			obj.lines=1;
			obj.resultText='';
			if(obj.originText!==obj.resultText){obj.modified();}
			obj.refresh();
		}		
	};
	CodeEditorObject.prototype.setScreen=function(div_item){
		this.options.screen=div_item;
		if(div_item.children('.codearea-block').length==0){
			this.widthLN=30;
			var width=Math.round(parseInt(this.ca_width)*this.options.pagewidth/100);
			var height=100;
			div_item.css('height',height+'px');
			var ss='<div class="codearea-block"><div class="codearea-container" style="width:'+width+'px;height:'+height+'px;">';
			ss+='<div class="codearea-wrap" style="width:'+(this.widthLN-1)+'px;height:'+(height-this.pad-1)+'px;">';
			ss+='<div class="codearea-ino"></div></div>';
			ss+='<textarea readonly="readonly" class="ln_codearea" id="'+this.outerID+'"';
			ss+=' style="width:'+(width-this.widthLN-this.pad*2)+'px;height:'+(height-this.pad*2-2)+'px;margin-left: '+(this.widthLN-1)+'px;">';
			ss+='</textarea></div></div>';
			div_item.append(ss);
			div_item.find('.ln_codearea').on('scroll',function(){
  				var ca=$(this);
  				ca.parent().find('.codearea-ino').css('margin-top', '-'+ca.scrollTop()+'px');
			});
		}
	};
	CodeEditorObject.prototype.screenReset=function(){
		var scn=this.options.screen;
		if(JSON.stringify(scn)!='{}'){
			var ta=scn.find('textarea');
			if(ta.length>0){
				var ss='';
				for(var i=1;i<=this.lines;i++){ss+='<div>'+i+'</div>';}	
				scn.find('.codearea-ino').empty().append(ss);
				this.setWidthHeight(true,true);
			}
		}
	};
	CodeEditorObject.prototype.setWidthHeight=function(setW,setH){/*false:ignore true:set*/
		var scn=this.options.screen;
		if(JSON.stringify(scn)!='{}'){
			var ta=scn.find('textarea');
			if(ta.length>0){
				var width=0,height=0;
				var o_c={},o_w={},o_a={};
				if(setW){
					this.widthLN=30;
					var v=this.lines.toString();
					if(v.length>3){
						this.widthLN=v.length*10;
					}
					width=Math.round(parseInt(this.ca_width)*this.options.pagewidth/100);
					var w='width';
					o_c[w]=width+'px';
					o_w[w]=(this.widthLN-1)+'px';
					o_a[w]=(width-this.widthLN-this.pad*2)+'px';
					o_a['margin-left']=(this.widthLN-1)+'px';
				}
				if(setH){
					if(this.ca_height=='actual'){
						height=this.lines*parseInt(ta.css('line-height'))+this.pad*2+2;
					}else{height=parseInt(this.ca_height);}
					var h='height';
					o_c[h]=height+'px';
					o_w[h]=(height-this.pad-1)+'px';
					o_a[h]=(height-this.pad*2-2)+'px';
					scn.css('height',height+'px');
				}
				scn.find('.codearea-container').css(o_c);
				scn.find('.codearea-wrap').css(o_w);
				ta.css(o_a);
			}
		}
	};	
	CodeEditorObject.prototype.show=function(){
		this.element.show();
	};
	CodeEditorObject.prototype.hide=function(){
		this.element.hide();
	};
	CodeEditorObject.prototype.setOuterID=function(id){
		this.outerID = id;
	};
	CodeEditorObject.prototype.isObjectText=function(txt){
		var flag=false;
		if(txt.length>0){
			var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
			if(ht=='{}'){flag=true;}
		}
		return flag;
	};
	CodeEditorObject.prototype.parseText=function(txt){
		var obj=this;
		obj.originText = '';
		obj.resultText = '';
		if(txt.length>0){
			/*format: {"width":"80%","height":"100px","text":"abcd"}*/
			if(obj.isObjectText(txt)){
				var dt=JSON.parse(txt);
				if(dt.hasOwnProperty('width')){
					obj.ca_width=dt.width;
				}
				if(dt.hasOwnProperty('height')){
					obj.ca_height=dt.height;
				}
				if(dt.hasOwnProperty('text')){
					obj.originText=dt.text;
					obj.resultText=dt.text;
					obj.calcLines();
				}
			}
		}
	};
	CodeEditorObject.prototype.refresh=function(){
		var obj=this;
		var self=this.element;
		self.find('#ca_width').val(obj.ca_width);
		self.find('#ca_height').val(obj.ca_height);
		self.find('#undo').hide();
		self.find('#enter').hide();
		self.find('#atext').val(obj.resultText).focus();
		obj.screenReset();
	};
	CodeEditorObject.prototype.setText=function(val){
		this.parseText(val);
		this.refresh();
		return this;
	};
	CodeEditorObject.prototype.getText=function(){
		var dt={width:this.ca_width,height:this.ca_height,text:this.resultText};
		return JSON.stringify(dt);
	};
    $.fn.CodeEditor=function(options){
		var ce=new CodeEditorObject(this,options);
		ce.init();
		return ce;
    };
