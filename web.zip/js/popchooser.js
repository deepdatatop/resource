var i18n={};
var grid_name='';
var grid_scene='';
var column_data=[];
var gridentity_id='0';
var gridsubentity='';
var roadmapids='0';
var rowids=[];/*use for popview*/
var form_scene='';
var form_dependency='';
var view_scene='';
var view_dependency='';
var popgrid_modified=0;
var onChoose={};
function pop_action_param(row){
	var ss='';
	if(row.hasOwnProperty('name')){
		ss+="'"+row['name']+"'";
	}else{
		ss="''";
	}
	return ss;
	//above return string is use for the "pop_do_action -> a_p" function.
};
function pop_do_action(dom,a_p){
	var self=$(dom);
	var action=self.attr('action');
	var instance_id=self.attr('iid');
	switch(action){
	case 'choose':
		onChoose(instance_id,a_p);
		break;
	}
};

function PopchooserObject(element,options){
	this.element=element;
	this.defaults={
		width:800,
		height:540,
		zindex:200,
		i18n: {},
		caption: '',
		query: '',
		closeText: 'Close',
		identifier: '',
		entity_id: '0',
		user_id: '0',
		ip: '',
		scene: '',
		roadmapids: '1',
		filter_block_bs64: '',
		filter_inputs_bs64: '',
		form_dependency_bs64: '',
		grid_dependency_bs64: '',
		column_block_bs64: '',
		column_template_bs64: '',
		onChoose: function(iid,name){}
	};
	this.id='';
	this.instance_id=0;
	this.po='popchooser_overlay';
	this.pp='popchooser_pane';
	this.gridarea={};
	this.options=$.extend({},this.defaults,options);
};
PopchooserObject.prototype.close_pane=function(){
	this.element.find('#grid_area').remove();
	this.element.find('#'+this.po).remove();
	this.element.find('#'+this.pp).remove();
};
PopchooserObject.prototype.include_callback=function(){//call at include.js
	this.setWidget();
};

PopchooserObject.prototype.setWidget=function(){
	var self=this,so=this.options;
	var recommendremoved=false;
	var default_query='"wgt":"GM","scene":"'+so.scene+'","eid":"'+so.entity_id+'"';
	//^filter---
	var thefilter=$('#the_filter').Filter({
		user_id: so.user_id,
		ip: so.ip,
		entity_id: so.entity_id,
		i18n: so.i18n,
		htmblock: so.filter_block_bs64,
		inputs: so.filter_inputs_bs64,
		onSearch: function(q,p){//query,prompt
			var txt='{'+default_query;
			if(q.length>0){ txt+=','+q; }
			txt+='}';
			GridManager.setQuery(grid_name,JSON.parse(txt),true,function(){});
			if(q.length>0){$.getJSON('/savequery',{q:txt,p:p},function(m){});}
		}
	});
	var init_query='{'+default_query;
	if(so.query.length>0){ init_query+=','+so.query; }
	init_query+='}';
	
	var dy=$('#the_filter').outerHeight()+70;
	var gmHeight=(so.height-104)+'px';
	var g_m=$('#the_grid').GM({gridManagerName: grid_name,
		height: gmHeight,
		supportAjaxPage:true,
		supportCheckbox:false,
		ajaxData: '/getdatagrid',
		ajaxType: 'POST',
		query: JSON.parse(init_query),
		pageSize: 20,
		columnData: column_data,
		summaryHandler: function(data){
			rowids.length=0;
			data.forEach(item => {rowids.push(item.id);});
			return;
		}/*rowids use for popview*/
	},function(){
		$('#'+grid_scene+'_popnew_btn').live('click',function(){
			$('body').Popform({
				eid:gridentity_id,rmi:roadmapids,
				scene:form_scene,i18n:i18n,
				afterSave:function(instance_id){
					GridManager.refreshGrid(grid_name);
				}
			}).setInstance(0);
		});
	});
};
PopchooserObject.prototype.setpane=function(){
	var self=this;
	var jscode=$.base64.decode(self.options.column_template_bs64);
	jscode+='column_data='+$.base64.decode(self.options.column_block_bs64)+';';
	eval(jscode);
	var gd='';
	if(self.options.grid_dependency_bs64.length>0){gd=$.base64.decode(self.options.grid_dependency_bs64);}
	include_queue(self,gd);
};
PopchooserObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){o[k]=o.i18n[k];}
	}
};
PopchooserObject.prototype.init=function(){
	this.i18n_options();
	i18n=this.options.i18n;
	var self=this,so=this.options;
	var thebox=this.element;
	onChoose=this.options.onChoose;
	grid_name='gm_'+so.identifier;
	gridentity_id = so.entity_id;
	gridsubentity = so.subentity;
	roadmapids = so.roadmapids;
	grid_scene = so.scene;
	form_scene = so.form_scene;
	form_dependency = so.form_dependency_bs64;
	view_scene = so.view_scene;
	view_dependency = so.view_dependency_bs64;
	thebox.append('<div id="'+self.po+'" style="z-index: '+so.zindex+';"></div>');
	var ao=thebox.find('#'+self.po).css({"display":"block",opacity:0}).fadeTo(200,0.35);
	var dh=so.height;
	var txt= '<div id="'+self.pp+'" style="display: none;width:'+so.width+'px;height:'+dh+'px;">';
	txt += '<span id="pc_close_icon"><i class="fa fa-close"></i></span>';
	txt += '<div class="pc_paneheader"><span id="thetitle">'+so.caption+'</span></div>';
	txt += '<div id="the_filter" class="filter" style="width:100%;height:34px;margin-left:-1px"></div>';
	txt += '<table id="the_grid" style="margin:0px;overflow: auto;width:100%;height:'+(dh-104)+'px;"></table>';
	txt += '<div class="pc_panebtm">';
	txt += '<span class="pc_button" id="pc_close"><i class="fa fa-times-circle-o">&nbsp;'+so.closeText+'</i></span>';
	txt += '</div>';
	txt += '</div>';
	thebox.append(txt);
	var pane = thebox.find('#'+self.pp);
	var modal_height=pane.outerHeight(); var modal_width=pane.outerWidth();
	pane.css({"display":"block","position":"fixed","opacity":0,"z-index":so.zindex+100,"left":50+"%","margin-left":-(modal_width/2)+"px","top":50+"%","margin-top":-(modal_height/2)+"px"});
	pane.fadeTo(200,1);
	thebox.find('#pc_close_icon').off("click").on("click",function(event){
		event.stopPropagation();	self.close_pane();
	});
	thebox.find('#pc_close').off("click").on("click",function(event){
		event.stopPropagation();	self.close_pane();
	});
	self.setpane();
};
$.fn.Popchooser=function(options){
	var achooser=new PopchooserObject(this,options);
	achooser.init();
	return achooser;
};