function FormareaObject(element,options){
	this.element=element;
	this.defaults={
		entity_id:0,
		scene:'normal',
		showtoolbar:true,
		instance_id:0,
		roadmapids:'0',
		language_id:2,
		t_duplicated:'duplicated',
		accept_languageids:[],
		accept_languages:{},
		onChange: function(instance_id){},
		afterSave: function(instance_id){},
		setCaption: function(caption){}
	};
	this.subentity='';
	this.langentity='languages';
	this.i18n={};
	this.form_recent_bs64='';
	this.form_data={};
	this.static_dt={};
	this.recent_languages={};
	this.editor_objects={};/*same as userinterface.makeEditorJS*/
	this.editor_types={};
	this.options=$.extend({},this.defaults,options);
};
FormareaObject.prototype.merge2recent=function(property,o){
	var self=this;
	for(var lid in o){
		var oo={};
		if(self.recent_languages.hasOwnProperty(lid)){oo=self.recent_languages[lid];}
		oo[property]=o[lid];
		self.recent_languages[lid]=oo;
	}
};
FormareaObject.prototype.set_recent_languages=function(){
	this.recent_languages={};
	var oo=[];
	if(this.form_data.hasOwnProperty(this.langentity)){
		oo=this.form_data[this.langentity];
	}
	for(var i=0,n=oo.length;i<n;i++){
		var o=oo[i];
		var newo={},lid='';
		for(var k in o){
			if(k=='language_id'){lid=o[k];}
			else if(k=='language_tag'||k=='_m_'){
				newo[k]=o[k];
			}
		}
		if(lid.length>0){this.recent_languages[lid]=newo;}
	}
};
FormareaObject.prototype.form_static_init=function(){
	var self=this,thebox=this.element,so=this.options;
	if(Number(so.instance_id)==0){thebox.find('.normal_row').hide();}
/*	thebox.find('.enter_button').hide();//initial status
	thebox.find('.enter_button').off('click').on('click',function(){self.form_save();});
	thebox.find('.unique_input').off('keypress').on('keypress',function(event){
		if(event.keyCode == "13"){
			event.preventDefault();self.form_save();
		}
	});*/
	if(so.showtoolbar){
		thebox.find('.dt_save_active').die('click').live('click',function(){self.form_save();});
		thebox.find('.dt_refresh_active').die('click').live('click',function(){self.form_undo();});
	}
};
FormareaObject.prototype.form_operationinit=function(){
	this.clearmodify();
};
FormareaObject.prototype.savedata=function(){
	var self=this,thebox=this.element,so=this.options;
	var keys=Object.keys(self.editor_objects);
	$.each(keys,function(i,key){
		var type=self.editor_types[key];
		if(type=='hierarchytext' || type=='hierarchyset'){
			self.editor_objects[key].save();
		}
	});
	for(let key in self.static_dt){
		self.form_data[key]=self.static_dt[key];
	}
	/*thebox.find('input.static').each(function(i){//static的简单化处理方案，待删除
		var me=$(this);
		self.form_data[me.attr('id')]=me.val();
	});*/
	//alert("eid:"+self.options.entity_id+" sub:"+self.subentity+" rmi:"+self.options.roadmapids+' iid:'+self.options.instance_id);
	/*var txt='iid:'+self.options.instance_id+'\n';
	txt+='lid:'+self.options.language_id+'\n';
	txt+=JSON.stringify(self.form_data);
	alert(txt);*/
	$.getJSON('/saveinstance',{eid:self.options.entity_id,sub:self.subentity,rmi:so.roadmapids,iid:so.instance_id,lid:so.language_id,dat:$.base64.encode(JSON.stringify(self.form_data))},
		function(m){
			if(m.Code=='100'){
				self.set_recent_languages();
				if(Number(so.instance_id)==0){
					so.instance_id=m.Instance_id;
					thebox.find('.normal_row').show();
				}
				so.afterSave(self.options.instance_id);
			}else{alert(m.Msg);}
		}
	);
};
FormareaObject.prototype.getData=function(){
	var self=this;
	var dt=JSON.parse($.base64.decode(self.form_recent_bs64));
	var keys=Object.keys(self.form_data);
	$.each(keys,function(i,key){
		dt[key]=self.form_data[key];
	});
	return JSON.stringify(dt);
};
FormareaObject.prototype.unique=function(property,dt){
	var self=this,so=this.options;
	var isunique=false;
	var kv=$.base64.encode(property+'='+dt);
	kv=kv.replace(new RegExp('=','g'),'-');
	$.ajaxSettings.async = false;
	$.getJSON('/instanceretrieve',{eid:so.entity_id,sub:self.subentity,kv:kv},function(m){
		if(m.Code=="100"){
			var iid=parseInt(m.ID);
			if(iid==0){
				isunique=true;
			}else{if(so.instance_id>0&&so.instance_id==iid){isunique=true;}}
			if(isunique){self.modified(property,dt);}
		}else{
			alert(m.Msg);
		}
	});
	$.ajaxSettings.async = true;
	return isunique;
};
FormareaObject.prototype.modified=function(property,dt){
	this.form_data[property]=$.trim(dt);
	this.setmodify();
};
FormareaObject.prototype.mlmodified=function(property,dt){
	var self=this,so=this.options;
	var value='';
	if(dt.hasOwnProperty(so.language_id)){value=dt[so.language_id];}
	self.form_data[property]=value;
	var languages=[];
	if(self.form_data.hasOwnProperty(self.langentity)){languages=this.form_data[self.langentity];}
	for(var id in dt){//make languages json, _m_: DEL/UPD/INS
		var o={language_id:id};
		if(so.accept_languages.hasOwnProperty(id)){o['language_tag']=so.accept_languages[id].Tag;}
		var m='INS';if(self.recent_languages.hasOwnProperty(id)){m='UPD';}
		var thevalue=dt[id];
		o[property]=thevalue;
		var nn=0,nm=0,ilang=-1;
		for(var i=0,n=languages.length;i<n;i++){//Merge the multifield values of the same language
			var oo=languages[i];
			if(oo.language_id==id){
				for(var k in oo){
					if(k=='language_id'||k=='language_tag'||k=='_m_'||k==property){
						/*skip*/
					}else{
						var v=oo[k];o[k]=v;nn++;
						if(v.length==0){nm++;}
					}
				}
				ilang=i;
				break;
			}
		}
		if(thevalue.length>0){
			o['_m_']=m;
			if(ilang>=0){languages[ilang]=o;}else{languages.push(o);}				
		}else{
			if(nn==0||nn==nm){
				if(m=='UPD'){
					o={'language_id':id,'_m_':'DEL'};
					if(ilang>=0){languages[ilang]=o;}else{languages.push(o);}
				}
			}else{
				o['_m_']=m;
				if(ilang>=0){languages[ilang]=o;}else{languages.push(o);}
			}
		}
	}
	this.form_data[this.langentity]=languages;
	this.setmodify();
};
FormareaObject.prototype.form_undo=function(){
	this.seteditor(this.form_recent_bs64);
	this.clearmodify();
};
FormareaObject.prototype.form_save=function(){
	this.savedata();
	this.clearmodify();
};
FormareaObject.prototype.setmodify=function(){
	var thebox=this.element,so=this.options;
	thebox.find('#undo').css('display','inline-block');
	thebox.find('#save').css('display','inline-block');
	//form toolbar button
	if(so.showtoolbar){
		thebox.find('.dt_save').removeClass('dt_save').addClass('dt_save_active');
		thebox.find('.dt_refresh').removeClass('dt_refresh').addClass('dt_refresh_active');
	}
	this.options.onChange(this.options.instance_id);
};
FormareaObject.prototype.clearmodify=function(){
	var thebox=this.element,so=this.options;
	thebox.find('#undo').css('display','none');
	thebox.find('#save').css('display','none');
	//object.go editor toolbar button
	if(so.showtoolbar){
		thebox.find('.dt_save_active').removeClass('dt_save_active').addClass('dt_save');
		thebox.find('.dt_refresh_active').removeClass('dt_refresh_active').addClass('dt_refresh');
	}
	//thebox.find('.enter_button').hide();
};
FormareaObject.prototype.isempty=function(o){
	var flag=false;
	if(!o && typeof(o)!='undefined'){
		flag=true;
	}
	return flag;
};
FormareaObject.prototype.setCSS=function(css){
	var id='formarea-css';
	var cssContainer = $('#'+id);
    if(cssContainer.length == 0){
        cssContainer = $('<style id="'+id+'"></style>');
        cssContainer.appendTo($('head'));
    }
	cssContainer.empty().append(css);
};
FormareaObject.prototype.parseI18n=function(i18n_bs64){
	if(i18n_bs64.length>0){
		this.i18n=JSON.parse($.base64.decode(i18n_bs64));
		for(var k in this.i18n){
			var v=this.i18n[k];
			var u=v.replace(/\"/g,'"');
			if(u!=v){
				this.i18n[k]=u;
			}
		}
	}
};
FormareaObject.prototype.seteditor=function(base64text){
	var self=this;
	if(base64text.length>0){
		var dt=JSON.parse($.base64.decode(base64text));
		var keys=Object.keys(dt);
		$.each(keys,function(i,key){
			var v=dt[key];
			var eo=self.editor_objects[key];
			switch(self.editor_types[key]){
				case 'static': break;
				case 'uniqueinput': eo.setValue(v);break;
				case 'input': 
				case 'text': eo.val(v);break;
				case 'fulllanguage': self.merge2recent(key,eo.setText(v));break;
				case 'spinner': eo.setValue(v);break;
				case 'wenhao': eo.setValue(v);break;
				case 'tag': eo.tagEditor('setTags',v);break;
				case 'iuvo': eo.idusagevalueordinalEditor('setData',v);break;
				case 'selector': eo.setResult(v);break;
				case 'switch': eo.prop('checked',(v=='1'));break;
				case 'nselect1': eo.Select(v);break;
				case 'hierarchytext': eo.setText(v);break;
				case 'hierarchyset': eo.setText(v);break;
				case 'illustrator': eo.setImages(v);break;
				case 'appendix': eo.setAppendixes(v);break;
			}
		});
	}
};
FormareaObject.prototype.init=function(){
	var self=this,thebox=this.element,so=this.options;
	var tb=0;
	if(so.showtoolbar){tb=1;}
	$.getJSON('/readformblock',{eid:so.entity_id,scene:so.scene,iid:so.instance_id,rmi:so.roadmapids,toolbar:tb},function(m){
		if(m.Code=="100"){
			self.parseI18n(m.I18n_bs64);
			self.subentity=m.Subentity;
			self.setCSS(m.CSS);
			thebox.append($.base64.decode(m.Block_bs64));
			self.form_recent_bs64=m.Instancetxt_bs64;
			self.form_static_init();
			so.setCaption(m.Caption);
			thebox.find('.form_caption').text(m.Caption);
			//below codes function not use userinterface.makeEditorJS
			self.editor_types=JSON.parse($.base64.decode(m.Editortypes_bs64));
			if(!self.isempty(m.Statics)){
				m.Statics.forEach(function(item){
					var o=thebox.find('#'+item.FormID);
					var val=o.attr('value');
					self.editor_objects[item.FormID]=o.Static({
						value: val,visible:(item.Visible=='1')
					});
					self.static_dt[item.Property]=val;
				});
			}
			if(!self.isempty(m.Paramgroups)){
				m.Paramgroups.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Paramgroup({
						i18n: self.i18n,
		                identifier: item.Identifier,
		                interface_scene: item.Interface_scene,
		                roadmapids: so.instance_id,//后续合并so.roadmapids和so.instance_id
		                initial_base64: item.Value,
		                onChange: function(val){self.modified(item.Property, val);}
		            });
				});
			}
			if(!self.isempty(m.Uniqueinputs)){
				m.Uniqueinputs.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).UniqueInput({
						value: item.Value,
						onEnter: function(val){
							if(self.unique(item.Property,val)){
								self.editor_objects[item.FormID].hideEnter();
								thebox.find('.normal_row').show();
							}else{
								alert('['+item.Property+'*'+val+'] '+so.t_duplicated+'!');
							}
						}
					});
				});
			}
			if(!self.isempty(m.Textinputs)){
				m.Textinputs.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).on('input propertychange',function(e){
						self.modified(item.Property,$(this).val());
						//alert(item.Property+'*'+$(this).val());
						e.preventDefault();
					});
				});
			}
			if(!self.isempty(m.Fulllanguages)){
				m.Fulllanguages.forEach(function(item){
					var supportML=(item.SupportML=='1');
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Fulllanguage({
						editortype:item.Editortype,i18n:self.i18n,name:item.Property,
						data_bs64:item.BS64_val,mode:item.Mode,
						supportMultiplelanguage:supportML,
						default_languageid:so.language_id,
						accept_languageids:so.accept_languageids,
						accept_languages:so.accept_languages,
						onChange:function(v){
							if(supportML){
								self.mlmodified(item.Property,v);
							}else{
								self.modified(item.Property,v);
							}
						},
						afterInit:function(v){
							self.merge2recent(item.Property,v);
						},
						uniqueChange:function(val){
							var eb=thebox.find('.enter_button');
							if(val.length>0){
								eb.css('display','inline-block');
							}else{
								eb.hide();
							}
						}
					});	
				});
			}
			if(!self.isempty(m.Spinners)){
				m.Spinners.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Spinner({
						value: parseInt(item.Value),
						max: parseInt(item.Max),
						interval: parseInt(item.Interval),
						onChange:function(val){self.modified(item.Property,val);}
					});
				});
			}
			if(!self.isempty(m.Switches)){
				m.Switches.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).on('click',function(e){
						var v='0';
						if($(this).prop("checked")){v='1';}
						self.modified(item.Property,v);
					}).prop('checked',(item.Value=='1'));
				});
			}
			if(!self.isempty(m.Nselect1s)){
				m.Nselect1s.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Nselect1({
						selected: item.Value,
						optionitems: item.Options,
						codeset: item.Codeset,
						codesetval: item.Codesetval,
						onChange: function(val){
							self.modified(item.Property,val);
						}
					});
				});
			}
			if(!self.isempty(m.IUVOs)){
				m.IUVOs.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).idusagevalueordinalEditor({
						initialCols: item.Initialcolumn,
						initialData: item.Initialdata,
						beforeTagDelete: function(field, editor, tags, val, vid) {
							if(vid.indexOf('-')>0){
								//alert(val+'{{.t_used}}');
								return false;
							}else{return true;}
						},
						onChange: function(el, ed, tag_list,val_json){//tag_list like: join initialTags, val_json like: [{id,valuetext},{id,valuetext}]
							self.modified(item.Property,val_json);
						},
						delimiter: ', ',
						placeholder: item.Placeholder
					});
				});
			}
			if(!self.isempty(m.Illustrators)){
				m.Illustrators.forEach(function(item){
					var capacity = 1;
					if(item.Capacity.length>0){
						capacity = parseInt(item.Capacity);
					}
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Illustrator({
						name:'illu_'+item.FormID,
						//layout_mode:'embed',//没查到，全面清查删除定义
						show_border:false,
						init_screen:true,
						image_capacity:capacity,
						token:item.FormID,
						screen:thebox.find('#'+item.FormID+'_screen'),
						i18n:self.i18n,
						//readRecent: obj.options.readRecentIllustration,
						//saveRecent: function(src,tag){obj.options.saveRecentIllustration(src,tag);},
						onChange: function(id,val){
							self.modified(item.Property,val);
						}
					}).setImages(item.Value);
				});
			}
			if(!self.isempty(m.Appendixes)){
				m.Appendixes.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Appendix({
						name:'apx_'+item.FormID,
						show_border: true,
						init_screen: true,
						appendix_capacity: 5,
						i18n:self.i18n,
						onChange: function(id,val){
							self.modified(item.Property,val);
						},
						token:item.FormID,
						screen:thebox.find('#'+item.FormID+'_screen')
					}).setAppendixes(item.Value);
				});
			}
			//readRecent: readRecentAppendix,`
			//saveRecent: function(src,tag){saveRecentAppendix(src,tag);}
			if(!self.isempty(m.Datepickers)){
				m.Datepickers.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).val(item.Value).datetimepicker({timepicker:false,format:'Y-m-d',
						onChangeDateTime:function(dp,$input){
							self.modified(item.Property,$input.val());
						}
					});
				});
			}
			if(!self.isempty(m.Timepickers)){
				m.Timepickers.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).val(item.Value).datetimepicker({timepicker:true,format:'Y-m-d H:i:s',
						onChangeDateTime:function(dp,$input){
							self.modified(item.Property,$input.val());
						}
					});
				});
			}
			if(!self.isempty(m.Codesetchoosers)){
				m.Codesetchoosers.forEach(function(item){
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).on('click',function(){
						$('body').Codesetchooser({
							onChoose:function(id){
								var v='';
								var jscode="v="+item.Action+"('"+item.Target+"','"+item.Parameter+"',id);"
								eval(jscode);
								self.modified(item.Target,v);
							},codeset:item.Codeset,codeset_title:item.Caption,
							language_id:item.Language_id,i18n:self.i18n
						}).show_chooserpane();
					});
				});
			}
			if(!self.isempty(m.Selectors)){
				m.Selectors.forEach(function(item){
					var mc=false;
					if(item['Choosetype']=='multiple'){mc=true;}
					self.editor_objects[item.FormID]=thebox.find('#'+item.FormID).Selector(
						{codeset:item.Codeset,multiple_choice:mc,language:item.Clientlanguage,
							result_type:item.Result,
							onChange: function(id,ids,codes,labels,pathnames){
								var rt='';
								switch(item.Result){
									case 'value.label':
										var vv=[];
										for(var i=0,n=ids.length;i<n;i++){
											vv.push(ids[i]+'.'+labels[i]);
										}
										rt=vv.join();
										break;
									case 'string':rt=codes.join();break;
									default:rt=ids.join();break;
								}
								self.modified(item.Property,rt);
								if(item.Onchange.length>0){/*pathname:districtname*/
									if(item.Onchange.indexOf('pathname:')==0){
										var ss=item.Onchange.split(':');
										if(ss.length==2){
											self.modified(ss[1],pathnames);
										}
									}
								}
							}
						}).setResult(item.Selected);
				});
			}
		}else{alert(m.Code+m.Msg);}
	});
};
$.fn.Formarea=function(options){
	var anarea=new FormareaObject(this,options);
	anarea.init()
	return anarea;
};

/*Action(target,parameter,id); userinterface.makeEditorJS [codesetchooser]*/
function fill_templet(target,parameter,id){
	var value=parameter.replace(/\[id\]/,id);
	$('#'+target).val(value);
	return value;
}
function read_instance(target,parameter,id){
	var value='';
	var pp=parameter.split('|');
	if(pp.length==2){
		var kvs={iid:id,lid:$('#language_id').val()};
		var imps=pp[0].split('&');//idf=module&jin=url_export
		for(var i=0,n=imps.length;i<n;i++){
			var kv=imps[i].split('=');
			if(kv.length==2){
				kvs[kv[0]]=kv[1];
			}
		}
		var outs=pp[1].split(',');
		if(outs.length>0){
			$.ajaxSettings.async = false;
			$.getJSON('/drawinstance',kvs,function(m){
				if(m.Code=='100'){
					var o=JSON.parse(m.Json_text);
					for(var i=0,n=outs.length;i<n;i++){
						var out=outs[i];
						if(o.hasOwnProperty(out)){
							value=o[out];
							if(value.length>0){
								$('#'+target).val(value);
								break;
							}
						}
					}
				}else{alert(m.Msg);}
			});
			$.ajaxSettings.async = true;
		}
	}
	return value;
}
/*for illustration widget*/
/*	function saveRecentIllustration(src,tag){
		var user_id=$('#user_id').val();
		var language_id=$('#language_id').val();
		var scene='illustration'; var data={scene:scene,src:src,tag:tag};
		$.getJSON('/saveinstance',{idf:'user',sub:'recent'+scene,rmi:user_id,dat:$.base64.encode(JSON.stringify(data)),lid:language_id},
				function(m){if(m.Code!='100'){alert(m.Msg);}});
	}
	function readRecentIllustration(){
		var user_id=$('#user_id').val();
		var recent_illustration=[];
		$.ajaxSettings.async = false;
		$.getJSON('/getdatagrid',{wgt:'RCNT',scene:'illustration',idf:'user',rmi:user_id},function(m){
			if(m.status=='success'){
				var allid=[];
				var n=m.data.length;
				for(var i=0;i<n;i++){
					var data=m.data[i];
					var mid=$.md5(data.src);
					if(allid.indexOf(mid)==-1){
						allid.push(mid);
						recent_illustration.push({src:data.src,tag:data.tag});
					}
				}
			}
		});
		$.ajaxSettings.async = true;
		return recent_illustration;
	}*/
