function PictableObject(element,options){
	this.element=element;
	this.defaults={
		layout: '{columns:1,align:"left",valign:"center"}',
  		identifier: 'product',
		pic_scene: 'picsetx',/*_list*/
		roadmapids: '0',/*product instance_id*/
      	getdatalist_url: '/getdatalist'//idf=product&scene=picsetx&rmi=1
	};
	this.options=$.extend({},this.defaults,options);
	this.subentity='';
	this.columns=1;
	this.cellalign='left';
	this.cellvalign='center';
	this.pics=[];
};
PictableObject.prototype.isObjectText=function(txt){
	var flag=false;
	if(txt.length>0){
		var ht=txt.substr(0,1)+txt.substr(txt.length-1,1);
		if(ht=='{}'){flag=true;}
	}
	return flag;
};
PictableObject.prototype.setPics=function(table){
	var ncells=this.pics.length;
	var ncols=this.columns;
	if(ncols==0){ncols=1;}
	var colwidths=[],width=100;
	var avg=parseInt(width/ncols);
	for(var i=0;i<ncols;i++){
		var colwidth=avg; if(i==ncols-1){colwidth=width-(ncols-1)*avg;}
		colwidths.push(colwidth);
	}
	var nrows=parseInt((ncells+ncols-1)/ncols);
	for(var i=0;i<nrows;i++){
		var tr='<tr>';
		for(var j=0;j<ncols;j++){
			var k=i*ncols+j;
			tr+='<td style="text-align:'+this.cellalign+';vertical-align:'+this.cellvalign+';width:'+colwidths[j]+'%">';
			if(k<ncells){
				var pic=this.pics[k];
				tr+=this.imageBlock(pic.tag,pic.src);
			}
			tr+='</td>';		
		}
		tr+='</tr>';
		table.append(tr);
	}
}
PictableObject.prototype.imageBlock=function(tag,src){
	var ss='<img src="'+src+'" style="max-width:100%;" alt="'+tag+'">';
	return ss;
}
PictableObject.prototype.init=function(){
	var self=this;
	var thebox=this.element;
	var lo=self.options.layout.replace(/\\"/g,'"');
	if(self.isObjectText(lo)){
		var o=JSON.parse(lo);
		if(o.hasOwnProperty('columns')){self.columns=parseInt(o['columns']);}
		if(o.hasOwnProperty('align')){self.align=o['align'];}
		if(o.hasOwnProperty('valign')){self.valign=o['valign'];}
	}
	$.ajaxSettings.async = false;
	$.getJSON('/getdatalist',{idf:self.options.identifier,scene:self.options.pic_scene,rmi:self.options.roadmapids},function(m){
		if(m.status=='success'){/*{"status": "success","subentity": "picset","listproperty":["src","tag"],"totals": 1,"data": [{"src": "/u?n=ided48e.jpg","tag": "01"}]}*/
			if(m.hasOwnProperty('subentity')){
				self.subentity=m['subentity'];
			}
			if(m.hasOwnProperty('data')){
				self.pics=m['data'];
			}
		}
	});
	$.ajaxSettings.async = true;
	self.setPics(thebox);
};
$.fn.Pictable=function(options){
	var pt=new PictableObject(this,options);
	pt.init();
	return pt;
};