function EmbeddedviewObject(element,options){
	this.element=element;
	this.defaults={
		initial_base64: ''
		/*identifier: 'product',
		interface_scene: 'propertyview',
		roadmapids: '1',*/
	};
	this.options=$.extend({},this.defaults,options);
};
/*EmbeddedviewObject.prototype.isempty=function(o){
	var flag=false;
	if(!o && typeof(o)!='undefined'){
		flag=true;
	}
	return flag;
};*/
EmbeddedviewObject.prototype.setupWidget=function(){
	var self=this,so=this.options;
	var thebox=this.element;
	//var view_data={};
	var data=so.initial_base64;
	if(data.length>0){
		var o=JSON.parse($.base64.decode(data));
		for(var key in o){//"6.使用手册":"manual"
			var ss=key.split('.');
			if(ss.length==2){
				//view_data[ss[0]]=o[key];
				thebox.append('<span class="ev_item">'+ss[1]+':&nbsp;'+o[key]+'</span><br>');
			}
		}
	}else{
	/*$.getJSON('/drawinstances',{idf:self.options.identifier,scene:self.options.interface_scene,pid:self.options.roadmapids},function(m){
		if(m.Code=='100'){
			alert(JSON.stringify(m));
			var items=JSON.parse(m.Instances_stringify);
			for(var i=0,n=items.length;i<n;i++){
				var o=items[i];
				var key=o.name,flag=o.flag,vtype=o.valuetype,val='';
				if(view_data.hasOwnProperty(o.id)){
					val=view_data[o.id];
				}
				thebox.append('<span class="ev_item">'+key+':'+val+'</span>');
			}
		}
	});*/
	}
};
EmbeddedviewObject.prototype.init=function(){
	this.setupWidget();
};
$.fn.Embeddedview=function(options){
	var aview=new EmbeddedviewObject(this,options);
	aview.init();
	return aview;
};