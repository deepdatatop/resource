/*inherit from HierarchyObject, need load tree.js first*/
	function inheritPrototype(subObject, superObject){
		var prototype = Object.create(superObject.prototype);
		prototype.constructor = subObject;
		subObject.prototype = prototype;
	}
    function SelectorObject(element,options){
		var selectdefaults={
			codeset:'',
			multiple_choice:false,
			result_type:'ids',/*ids,codes,dotids*/
			max_choices:0,
			optionbox_height:302,
			optionbox_foldable:true,
			readlabels_url:'/readlabels',
			item_option:[]
		};
		HierarchyObject.call(this,element,$.extend({},selectdefaults,options));
		this.result_ids=[];
		this.result_codes=[];
		this.result_labels=[];
		this.result_pathids=[];
		this.result_pathnames=[];
    };
	inheritPrototype(SelectorObject,HierarchyObject);
	SelectorObject.prototype.ex_init=function(){
		Array.prototype.contains = function(obj) {
			var i = this.length;
			while (i--) {
				if (this[i] == obj) {
					return i;
				}
			}
			return -1;
		}
		this.registerCloseSelectEvent();
		this.registerSelectoptionOnblur();
	};
	SelectorObject.prototype.selectflag=function(id){
		var tt='';
		if(this.result_ids.length>0 && this.result_ids.contains(id)>=0){
			tt = '<div class="item_selected"></div>';
		}
		return tt;
	};
	SelectorObject.prototype.resetWidget=function(){
		var root=this.element;
		root.empty();
		var ss='<div class="resultWrap"><ul></ul><div class="resultholder"></div>';
		if(this.options.optionbox_foldable){ss+='<span class="open_option"></span>';}
		if(this.options.multiple_choice){ss+='<div id="indicator"></div>';}
		ss+='</div><div id="select-option"';
		if(this.options.optionbox_foldable){
			ss+=' class="foldable" style="max-height:'+this.options.optionbox_height+'px;"';
		}else{
			ss+=' class="fixed" style="height:'+this.options.optionbox_height+'px;"';
		}
		ss+='></div>';
		root.append(ss);
		var selectoption=root.find("#select-option");
		var n=this.resetBox(selectoption);
		if(n>0){
			this.setIndicator();
			if(this.options.optionbox_foldable){
				var mh=this.options.row_height*n;
				if(mh<this.options.optionbox_height){
					selectoption.css('max-height',mh+'px');
				}
			}
		}
	};
	SelectorObject.prototype.rowsChange=function(){
		/*var selectoption=this.element.find("#select-option");
		var curHeight=parseInt(selectoption.css('max-height'));
		var newHeight=Math.min(selectoption.prop('scrollHeight'),this.options.optionbox_height);
		if(curHeight!=newHeight){
			selectoption.css('max-height',newHeight+'px');
		}*/
		//scrollHeight, some bugs in collpase mode.
	};
	SelectorObject.prototype.setIndicator=function(){
		if(this.options.multiple_choice){
			var dots='';
			for(var i=0;i<this.result_ids.length;i++){dots+='.';}
			this.element.find('#indicator').text(dots);
		}
	};
	SelectorObject.prototype.setVal=function(){
		var self=this;
		var root=this.element;
		var vl=[];
		for(var i=0;i<self.result_ids.length;i++){
			var v='';
			switch(self.options.result_type){
				case 'ids':
					v=self.result_ids[i]+':'+self.result_labels[i];
					break;
				case 'codes':
					v=self.result_codes[i]+':'+self.result_labels[i];
					break;
				case 'dotids':
					v=self.result_pathids[i]+':'+self.result_labels[i];
					break;
			};
			vl.push(v);
		}
		root.val(vl.join(','));
	}
	SelectorObject.prototype.clickitemcaption=function(ic){
		var self=this;
		var root=this.element;
		var itm=ic.parent();
		var pathname=self.fullPathname(itm);
		var pathid=self.fullPathid(itm);
		var id=itm.attr('id');
		var code=itm.attr('code');
		var checked = itm.find('div.item_selected');
		if(self.options.multiple_choice){
			if(checked.length>0){
				checked.remove();
				if(self.result_ids.length>0){
					var idx = self.result_ids.contains(id);
					if(idx>=0){
						self.result_ids.splice(idx,1);
						self.result_codes.splice(idx,1);
						self.result_labels.splice(idx,1);
						self.result_pathids.splice(idx,1);
						self.result_pathnames.splice(idx,1);
						root.find(".resultWrap ul li").each(function(){
							if($(this).attr("rel")==id){$(this).remove();}
						});
					}
				}
			}else{
				var flag = true;
				if(self.options.max_choices>0){
					if(self.result_ids.length>=self.options.max_choices){
						flag = false;
						alert('maximum choices is limited to:'+self.options.max_choices);
					}
				}
				if(flag){
					var lab = ic.text();
					self.result_ids.push(id);
					self.result_codes.push(code);
					self.result_labels.push(lab);
					self.result_pathids.push(pathid);
					self.result_pathnames.push(pathname);
					var newli = root.find(".resultWrap ul").append(self.resultLI(id,lab,true)).last();
					self.registerResultRemoveEvent(newli);
					self.registerResultEvent(newli);
					self.setSelected(itm);	
				}
			}
			self.setVal();
			self.setIndicator();
			if(self.options.max_choices>0){
				if(self.options.optionbox_foldable){
					if(self.result_ids.length==self.options.max_choices){
						self.closeSelectOption();
					}
				}else{
					alert('over max-choices');
				}
			}
		}else{
			var oid='';
			if(self.result_ids.length>0){
				oid=self.result_ids[0];
				root.find(".resultWrap ul").empty();
				root.find(".item#"+oid).find(".item_selected").remove();
				self.result_ids.length=0;
				self.result_codes.length=0;
				self.result_labels.length=0;
				self.result_pathids.length=0;
				self.result_pathnames.length=0;
			}
			if(oid!=id){
				var lab = ic.text();
				self.result_ids.push(id);
				self.result_codes.push(code);
				self.result_labels.push(lab);
				self.result_pathids.push(pathid);
				self.result_pathnames.push(pathname);
				var newli=root.find(".resultWrap ul").append('<li rel="'+id+'"><span>'+lab+'</span>&nbsp;&nbsp;</li>').last();
				self.registerResultEvent(newli);
				self.setSelected(itm);
				self.setVal();
				if(self.options.optionbox_foldable){
					self.closeSelectOption();
				}
			}else{
				root.val('');
			}
		}
		self.options.onChange(root.attr('id'),self.result_ids,self.result_codes,self.result_labels,self.result_pathids,self.result_pathnames);
	};
	SelectorObject.prototype.registerResultEvent=function(resultitem){
		var self=this;
		var root=this.element;
		resultitem.find('span').off("click").on("click",function(event){
			event.stopPropagation();
			var id=$(this).parent().attr('rel');
			if(self.options.optionbox_foldable){
				if(self.isclosedSelectOption()){
					self.openSelectOption();
				}
			}
			self.paththrough(root.find("#select-option"),id);
		});
	};
	SelectorObject.prototype.registerResultRemoveEvent=function(newli){
		var self=this;
		var root=this.element;
		newli.find(".remove_selected").off("click").on("click",function(event){
			event.stopPropagation();
			var dv=$(this).attr("data-value");
			if(self.result_ids.length>0){
				var idx=self.result_ids.contains(dv);
				if(idx>=0){
					self.result_ids.splice(idx,1);
					self.result_codes.splice(idx,1);
					self.result_labels.splice(idx,1);
					self.result_pathids.splice(idx,1);
					self.result_pathnames.splice(idx,1);
					self.setVal();
					root.find("div#"+dv).find(".item_selected").remove();
					$(this).parents('li').remove();
				}
			}
			self.setIndicator();
			self.options.onChange(root.attr('id'),self.result_ids,self.result_codes,self.result_labels,self.result_pathids,self.result_pathnames);
		});
	};
	SelectorObject.prototype.registerSelectoptionOnblur=function(){
		var self=this;
		if(this.options.optionbox_foldable){//div tabindex used for blur event
			this.element.blur(function(){ self.closeSelectOption(); });
		}
	};
	SelectorObject.prototype.registerCloseSelectEvent=function(){
		if(this.options.optionbox_foldable){
			var self=this;
			var root=this.element;
			root.find(".resultWrap").off("click").on("click",function(event){
				event.stopPropagation();
				if(self.isclosedSelectOption()){
					self.openSelectOption();
				}else{
					self.closeSelectOption();
				}
			});
			$("html").off("click").on("click",function(){
				self.closeSelectOption();
			});
		}
	};
	SelectorObject.prototype.isclosedSelectOption=function(){
		return this.element.find(".resultWrap").children('span').hasClass("open_option");
	};
	SelectorObject.prototype.openSelectOption=function(){
		var root=this.element;
		root.find(".resultWrap").children('span').removeClass("open_option").addClass("close_option");
		root.find("#select-option").show().animate({height:"400px",opacity:"1"},"fast","swing");
		root.focus();
	};
	SelectorObject.prototype.closeSelectOption=function(){
		var root=this.element;
		root.find(".resultWrap").children('span').removeClass("close_option").addClass("open_option");
		root.find("#select-option").animate({height:"0",opacity:"0"},"fast","swing").hide();
	};
	SelectorObject.prototype.resultLI=function(id,lab,rmv){
		var ss='<li rel="'+id+'"><span>'+lab+'</span>&nbsp;&nbsp;';
		if(rmv){ ss+='<div data-value="'+id+'" class="remove_selected">'; }
		ss+='</li>';
		return ss;
	};
	SelectorObject.prototype.clear=function(){
		var self=this; var root=this.element;
		var resultBox = root.find(".resultWrap ul"); resultBox.empty();
		this.result_ids.length=0;
		this.result_codes.length=0;
		this.result_labels.length=0;
		this.result_pathids.length=0;
		this.result_pathnames.length=0;	
		var selectOption = root.find("#select-option");
		selectOption.find('.item_selected').remove();
	};
    SelectorObject.prototype.setResult=function(r){/*result_type:ids/codes/dotids*/
    		this.clear();
		if(r.length>0){
			var root=this.element;
			var selectOption = root.find("#select-option");
			var rtype=this.options.result_type;
			var m=this.options.item_option.length;
			if(m>0){
				var rr=r.split(',');
				var n=this.options.multiple_choice?rr.length:1;
				switch(rtype){
					case 'ids':
						for(var i=0;i<n;i++){
							var value=parseInt(rr[i]);
							for(var j=0;j<m;j++){
								var i_o=this.options.item_option[j];
								if(i_o.hasOwnProperty('value')){
									if(i_o.value==value){
										this.result_ids.push(value);
										this.result_codes.push(i_o.code);
										this.result_labels.push(i_o.label);
										this.result_pathids.push('');
										this.result_pathnames.push('');									
										break;
									}
								}
							}
						}
						break;
					case 'codes':
						for(var i=0;i<n;i++){
							var code=rr[i];
							var k=code.indexOf(':');
							if(k>0){	code=code.substr(0,k);}
							for(var j=0;j<m;j++){
								var i_o=this.options.item_option[j];
								if(i_o.hasOwnProperty('code')){
									if(i_o.code==code){
										this.result_ids.push(i_o.value);
										this.result_codes.push(code);
										this.result_labels.push(i_o.label);
										this.result_pathids.push('');
										this.result_pathnames.push('');									
										break;
									}
								}
							}
						}
						break;
				}
				if(this.Self_hierarchy){
					for(var i=0;i<this.result_ids.length;i++){
						var id=this.result_ids[i];
						var itm=selectOption.find('#'+id);
						if(itm.length>0){
							this.result_pathids[i]=this.fullPathid(itm);
							this.result_pathnames[i]=this.fullPathname(itm);
						}
					}
				}
			}
			if(this.options.dynamic_loading&&this.options.codeset.length>0){
				var o={cst:this.options.codeset,lid:this.options.language};
				if(rtype=='ids'){/*fault-tolerant: 1.English[en],2.Chinese[zh] ➸ 1,2*/
					var vv=[],rr=r.split(',');
					var n=this.options.multiple_choice?rr.length:1;
					for(var i=0;i<n;i++){vv.push(parseInt(rr[i]));}
					o[rtype]=vv.join();
				}else{o[rtype]=r;}
				$.ajaxSettings.async = false; var self=this;
				$.getJSON(this.options.readlabels_url,o,function(m){
					if(m.Code=="100"){
						self.result_ids = m.IDs;
						self.result_codes = m.Codes;
						self.result_labels = m.Labels;
						self.result_pathids = m.Pathids;
						self.result_pathnames = m.Pathnames;
					}else{
						alert(m.Code+'.'+m.Msg);
					}
				});	
				$.ajaxSettings.async = true;		
			}
			var resultBox = root.find(".resultWrap ul");
			for(var i=0;i<this.result_ids.length;i++){
				var v=this.result_ids[i]; var l=this.result_labels[i];
				var newli = resultBox.append(this.resultLI(v,l,this.options.multiple_choice)).last();
				if(this.options.multiple_choice){ this.registerResultRemoveEvent(newli); 	}
				this.registerResultEvent(newli);
				var itm = selectOption.find("div#"+v);
				if(itm.length>0){ this.setSelected(itm); }
			}
			if(this.result_ids.length>0){
				this.paththroughSilent(selectOption,this.result_ids[0]);
			}
			this.setVal();
		}
		this.setIndicator();
		return this.result_labels.join(',');
	};
	SelectorObject.prototype.setSelected=function(itm){
		if(itm.find(".item_selected").length==0){
			if(this.hierarchy){
				itm.find('span.indent').children().first().append('<div class="item_selected"></div>');
			}else{
				itm.find('span.blank').append('<div class="item_selected"></div>');
			}
		}
	}
    $.fn.Selector=function(options){
		var a_selector=new SelectorObject(this,options);
		a_selector.init();
		return a_selector;
    };