;(function ($, window, document, undefined) {

  var GalleryObject = function(element,options) {
    var self = this;
    this.element = element;
    this.defaults={
    		normalwidth:400,
		thumbnailwidth:54,
    		imagelist:[]
    	};
    this.options=$.extend({},this.defaults,options);
  };

  GalleryObject.prototype = {
    moveBigPic: function () {
      var scaleX = this.$normalBox_mask.position().left / (this.$normalBox.width() - this.$normalBox_mask.width());
      var scaleY = this.$normalBox_mask.position().top / (this.$normalBox.height() - this.$normalBox_mask.height());
      var scroll_l = scaleX * (this.$bigBox_pic.width() - this.$bigBox.width());
      var scroll_t = scaleY * (this.$bigBox_pic.height() - this.$bigBox.height());

      this.$bigBox.scrollLeft(scroll_l).scrollTop(scroll_t);
    },

    changeSrouce: function (index, cur_src) {
      this.$normalBox_pic.attr('src', cur_src);
      this.$bigBox_pic.attr('src', this.options.imagelist[index]);
    },

    setMask: function () {
      var mask_w = this.$normalBox.width() / (this.$bigBox_pic.width() / this.$bigBox.width());
      var mask_h = this.$normalBox.height() / (this.$bigBox_pic.height() / this.$bigBox.height());

      this.$normalBox_mask.css({width: mask_w, height: mask_h});
    },

    init: function () {
    var self = this,so=this.options;
    var thebox = this.element;
 	var txt='<div class="normal-box">';
	txt += '<img src="';
	if(so.imagelist.length>0){txt += so.imagelist[0];}
	txt += '" width="'+so.normalwidth+'" alt="#">';
    txt += '  <span class="hover"></span>';
    txt += '</div>';
    txt += '<div class="thumbnail-box">';
    for(var i=0,n=so.imagelist.length;i<n;i++){
    		txt += '<div class="item';
		if(i==0){txt += ' item-cur';}
		txt += '" data-src="'+so.imagelist[i]+'"><img src="'+so.imagelist[i]+'" width="'+so.thumbnailwidth+'" alt="#"></div>';
    }
    txt += '</div>';
    txt += '<div class="big-box">';
    txt += '  <img src="';
    if(so.imagelist.length>0){txt += so.imagelist[0];}
    txt += '" alt="#">';
    txt += '</div>';
    thebox.append(txt);
    this.$normalBox = thebox.find('.normal-box');
    this.$normalBox_pic = this.$normalBox.find('img');
    this.$normalBox_mask = this.$normalBox.find('.hover');
    this.$thumbnailBox = thebox.find('.thumbnail-box');
    this.$thumbnailBox_prev = this.$thumbnailBox.find('.btn-prev');
    this.$thumbnailBox_next = this.$thumbnailBox.find('.btn-next');
    this.$thumbnailBox_wrapper = this.$thumbnailBox.find('.wrapper');
    this.$thumbnailBox_item = this.$thumbnailBox.find('.item');
    this.$thumbnailBox_pic = this.$thumbnailBox.find('img');
    this.$bigBox = thebox.find('.big-box');
    this.$bigBox_pic = this.$bigBox.find('img');      
    this.$thumbnailBox_item.mouseover(function () {
        var cur_src = $(this).attr('data-src');

        self.$thumbnailBox_item.removeClass('item-cur');

        $(this).addClass('item-cur');

        self.changeSrouce($(this).index(), cur_src);
      });
	this.$normalBox.hover(function () {
        self.$bigBox.show();
        self.$normalBox_mask.show();
        self.setMask();
	$(this).mousemove(function (ev) {
          var oEvent = ev || window.event;
          var offset_pos = {
            left: oEvent.clientX - $(this).offset().left - self.$normalBox_mask.width() / 2,
            top: oEvent.clientY - $(this).offset().top - self.$normalBox_mask.height() / 2 + $(window).scrollTop()
          };

          if (offset_pos.left < 0) {
            offset_pos.left = 0;
          } else if (offset_pos.left > $(this).width() - self.$normalBox_mask.width()) {
            offset_pos.left = $(this).width() - self.$normalBox_mask.width();
          }
          if (offset_pos.top < 0) {
            offset_pos.top = 0;
          } else if (offset_pos.top > $(this).height() - self.$normalBox_mask.height()) {
            offset_pos.top = $(this).height() - self.$normalBox_mask.height();
          }

          self.$normalBox_mask.css(offset_pos);

          self.moveBigPic();
        });
      }, function () {
        self.$normalBox_mask.hide();
        self.$bigBox.hide();
      });
    },
    constructor: GalleryObject
  };

  $.fn.Gallery = function(options) {
    var gallery = new GalleryObject(this,options);
    return gallery.init();
  };

})(jQuery, window, document);