function UniqueInputObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		value:'',
		onEnter:function(val){}
	};
	this.value='';
	this.options=$.extend({},this.defaults,options);
};
UniqueInputObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){
			o[k]=o.i18n[k];
		}
	}
};
UniqueInputObject.prototype.hideEnter=function(){
	var thebox=this.element;
	thebox.find('.enter_button').hide();
	thebox.find('.u_input').css('width',thebox.css('width'));
};
UniqueInputObject.prototype.value=function(){
	return this.value;
};
UniqueInputObject.prototype.setValue=function(val){
	this.value=val;
	this.element.find('.u_input').val(val);
};
UniqueInputObject.prototype.init=function(){
	this.i18n_options();
	var self=this,thebox=this.element,so=this.options;
	self.value=so.value;
	var font=thebox.css('font');
	thebox.css({'position':'relative','overflow':'hidden','white-space':'nowrap','border':'solid 1px #dadada'});
	var boxwidth=thebox.css('width');
	var ss='<input class="u_input" autofocus="autofocus" style="width:'+boxwidth+';font:'+font+'" value="'+so.value+'">';
	ss+='<span class="enter_button" style="display:none"><i class="fa fa-level-down fa-lg fa-rotate-90"></i></span>';
	thebox.append(ss);	
	thebox.find('.u_input').on('input propertychange',function(e){
		self.value=$.trim($(this).val());
		var inputwidth=$(this).css('width');
		if(boxwidth==inputwidth){
			var ww=thebox.find('.enter_button').show().outerWidth();
			$(this).css('width',(thebox.innerWidth()-ww-3)+'px');
		}
	}).on('keypress',function(event){
		if(event.keyCode == "13"){
			event.preventDefault();
			so.onEnter(self.value);
		}
	});
	thebox.find('.enter_button').on('click',function(event){
		so.onEnter(self.value);
	});
};
$.fn.UniqueInput=function(options){
	var ainput=new UniqueInputObject(this,options);
	ainput.init();
	return ainput;
};