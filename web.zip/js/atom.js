function atomswitch(switchobject){
    var stopflag=0;
    if(switchobject.prop("checked")){stopflag=1;}
    var iid=switchobject.attr('iid');
    var action='/stopword';
    if(h_id>1){action='/stopentityword';}
    $.ajaxSettings.async = false;
	$.getJSON(action,{iid:iid,flag:stopflag},function(m){
		if(m.Code=='100'){
        //m.Timeconsuming  ➸  hint
      }else{alert(m.Msg);}
	});
	$.ajaxSettings.async = true;
}

function entityatomswitch(switchobject){
    var stopflag=0;
    if(switchobject.prop("checked")){stopflag=1;}
    var iid=switchobject.attr('iid');
    var action='/stopentityword';
    $.ajaxSettings.async = false;
	$.getJSON(action,{iid:iid,flag:stopflag},function(m){
		if(m.Code=='100'){
        //m.Timeconsuming  ➸  hint
      }else{alert(m.Msg);}
	});
	$.ajaxSettings.async = true;
}