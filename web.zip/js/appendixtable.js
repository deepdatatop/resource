function AppendixtableObject(element,options){
	this.element=element;
	this.defaults={
		i18n:{},
		identifier: 'application',
		grid_scene: 'releasedown',/*_grid*/
		roadmapids: '0',/*application instance_id*/
		t_releasenumber: 'ReleaseNO.',
		t_releasetime: 'Releasetime',
		t_osarch: 'OS&Architecture',
		t_filename: 'Filename',
		t_filesize: 'Filesize',
		t_download: 'Download',
		appdown_path: '/appdown/'
	};
	this.options=$.extend({},this.defaults,options);
};
AppendixtableObject.prototype.i18n_options=function(){
	var o=this.options;
	for(var k in o.i18n){
		if(o.hasOwnProperty(k)){
			o[k]=o.i18n[k];
		}
	}
};
AppendixtableObject.prototype.init=function(){
	var self=this,thebox=this.element,so=this.options;
	self.i18n_options();
	$.ajaxSettings.async = false;
	//var txt='<table style="width:100%;margin:0 auto">';
	var txt='<tr><th>'+so.t_releasenumber+'</th>';
	txt+='<th>'+so.t_osarch+'</th>';
	txt+='<th>'+so.t_filename+'</th>';
	txt+='<th>'+so.t_filesize+'</th>';
	txt+='<th>'+so.t_releasetime+'</th>';
	txt+='<th>'+so.t_download+'</th></tr>';
	var scene=so.grid_scene;
	if(scene.indexOf('_grid')>0){
		scene=scene.replace('_grid','');
	}
	$.getJSON('/getdatagrid',{idf:so.identifier,scene:scene,rmi:so.roadmapids,wgt:'GM'},function(m){
		if(m.status=='success'){
			for(var i=0,n=m.totals;i<n;i++){
				var dt=m.data[i],cla='white';
				if(i%2!=0){cla='emphasize';}
				txt+='<tr class="'+cla+'">';
				txt+='<td>'+dt.releasenumber+'</td>';
				txt+='<td>'+dt.os_arch+'</td>';
				txt+='<td>'+dt.filename+'</td>';
				txt+='<td align="right">'+dt.filesize+'</td>';
				txt+='<td align="center">'+dt.releasetime+'</td>';
				txt+='<td class="download_cell"><a href="'+so.appdown_path+dt.filename+'" target="_blank" download="'+dt.filename+'">';
				txt+='<i class="fa fa-download"></i></a></td>';
				txt+='</tr>';
			}
			self.columns=m.data;
		}
	});
	//{"status":"success","totals":2,"data":[{"releasenumber":"1.0","os_arch":"","filename":"","filesize":"0","releasetime":"2024-02-01","operation":"{\"download\":1}","id":"1","_id_":"idBL--"}]}
	//txt+='</table>';
	$.ajaxSettings.async = true;
	thebox.append(txt);
};
$.fn.Appendixtable=function(options){
	var at=new AppendixtableObject(this,options);
	at.init();
	return at;
};